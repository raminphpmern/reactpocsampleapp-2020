window._env_ = {
  API_URL: "http://localhost:4000/api",
}