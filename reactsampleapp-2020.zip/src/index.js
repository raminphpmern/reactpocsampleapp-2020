import React from 'react';
import ReactDOM from 'react-dom';
import './i18n';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
// import * as Sentry from '@sentry/browser';

// Sentry.init({
//     // dsn: 'http://39cd3d4fed3e4eb195def66238d97af8@localhost:9000/2',
//     dsn: 'https://aa115e5828ce4f41adcc34ebfa03a263@logistics-sentry.herokuapp.com//2',
//     maxBreadcrumbs: 50,
//     debug: true,
// })

ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
