import i18n from "i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import { initReactI18next } from 'react-i18next';
import translationEN from './locales/en/translation.json';
import brHubEN from './locales/en/BrHub/Form.json';
import brHubGridEN from './locales/en/BrHub/Grid.json';
import csFormEN from './locales/en/CollectionSummary/Form.json';
import inventoryHubEN from './locales/en/InventoryHub/Form.json'
import inventoryHubSearchEN from './locales/en/InventoryHub/Search.json';
import inventoryHubGridEN from './locales/en/InventoryHub/Grid.json';
import tripHubEN from './locales/en/TripHub/Form.json';
import tripHubGridEN from './locales/en/TripHub/Grid.json'
import searchTemplatesEN from './locales/en/searchTemplates.json';
import searchFieldEN from './locales/en/BrHub/Search.json'
import brHubFooterEN from './locales/en/BrHub/Footer.json'
import csSearchEN from './locales/en/CollectionSummary/Search.json'
import csGridEN from './locales/en/CollectionSummary/Grid.json'
import csValidationMsgEN from './locales/en/CollectionSummary/Validation.json'
import csHelpOnEN from './locales/en/CollectionSummary/Help.json'
import csReceiptEN from './locales/en/CollectionSummary/Receipt.json'
import hubLoadGridEN from './locales/en/HubLoading/Grid.json';
import hubFormEN from './locales/en/HubLoading/Form.json';
import hubReceiptEN from './locales/en/HubReceipt/Form.json';
import dispatchSearchFormEN from './locales/en/DispatchSearch/Form.json';
import dispatchSearchGridEN from './locales/en/DispatchSearch/Grid.json';
import dispatchViewFormEN from './locales/en/DispatchView/Form.json';
import dispatchCreateFormEN from './locales/en/DispatchCreate/Form.json';
import tripPlanEN from './locales/en/TripPlan/Form.json';
import linkHouseGridEN from './locales/en/DispatchCreate/LinkHouseGrid.json';
import helpOnTripFormEN from './locales/en/HelpOnTrip/Form.json';
import helpOnTripGirdEN from './locales/en/HelpOnTrip/Grid.json';
import ThuGridEN from './locales/en/DispatchView/ThuGrid.json';
import helpOnCustomerFormEN from './locales/en/HelpOnCustomer/Form.json';
import helpOnCustomerGirdEN from './locales/en/HelpOnCustomer/Grid.json';
import createDispatchvalidationEN from './locales/en/DispatchCreate/Validation.json';
import hubLoadingvalidationEN from './locales/en/HubLoading/Validation.json';
import tripHubHelpEN from './locales/en/TripHub/Help.json';
import acceptance from './locales/en/QBR/acceptance.json';
import customer from './locales/en/QBR/customer.json';
import hubReceiptvalidationEN from './locales/en/HubReceipt/Validation.json';
import helpOnVehicleFormEN from './locales/en/HelpOnVehicle/Form.json';
import helpOnVehicleGridEN from './locales/en/HelpOnVehicle/Grid.json';
import helpOnCarrierFormEN from './locales/en/HelpOnCarrier/Form.json';
import helpOnCarrierGridEN from './locales/en/HelpOnCarrier/Grid.json';
import helpOnEquipmentFormEN from './locales/en/HelpOnEquipment/Form.json';
import helpOnEquipmentGridEN from './locales/en/HelpOnEquipment/Grid.json';
import bayTransferFormEN from './locales/en/BayTransfer/Form.json';
import bayTransferGridEN from './locales/en/BayTransfer/Grid.json';
import chargesEN from './locales/en/QBR/charges.json';
import customerValidationEN from './locales/en/QBR/customerValidation.json';
import consigneeValidationEN from './locales/en/QBR/consigneeValidation.json';
import birthCertificateEN from './locales/en/QBR/birthCertificate.json';
import helpOnShipPointEN from './locales/en/QBR/helpOnShipPoint.json'
import freightConversionFormEN from './locales/en/FreightConversion/Form.json';
import freightConversionGridEN from './locales/en/FreightConversion/Grid.json';
import bayTransferValidationEN from './locales/en/BayTransfer/Validation.json';
import fcConsDeconsFormEN from './locales/en/FCConsDecons/Form.json';
import fcInputThuEn from './locales/en/FCConsDecons/InputThu.json';
import fcOutputThuEn from './locales/en/FCConsDecons/OutputThu.json';
import thuInventoryFormEN from './locales/en/ThuInventory/Form.json';
import thuInventoryGridEN from './locales/en/ThuInventory/Grid.json';
import loadThuEN from './locales/en/LoadTHU/Form.json';
import thuInventoryFooterEN from './locales/en/ThuInventory/Footer.json';
import allocatethuFormEN from './locales/en/AllocateTHU/Form.json'
import allocatethuGridEN from './locales/en/AllocateTHU/Grid.json'
import vehicleSealEN from './locales/en/HelpOnVehicleSeal/Form.json'
import fcValidationEn from './locales/en/FCConsDecons/Validation.json';
import tripAttachmentsEn from './locales/en/TripPlan/Attachments.json';
import helpOnSerialNoFormEN from './locales/en/HelpOnSerialNo/Form.json';
import helpOnSerialNoGirdEN from './locales/en/HelpOnSerialNo/Grid.json';
import helpOnDispatchDocNoFormEN from './locales/en/HelpOnDispatchDocNo/Form.json';
import helpOnDispatchDocNoGirdEN from './locales/en/HelpOnDispatchDocNo/Grid.json';
import documentTrackerEN from './locales/en/DocumentTracker/Form.json'
import customerDocumentEN from './locales/en/TripPlan/customerDocument.json'
import acknowledgementReceiptEN from './locales/en/QBR/acknowledgementReceipt.json';
import newConsigneeEN from './locales/en/QBR/newConsignee.json';
import newShipperEN from './locales/en/QBR/newShipper.json';
import nonReccuringBrEN from './locales/en/QBR/nonReccuringBr.json';
import taxDetailsEN from './locales/en/QBR/taxDetails.json';
import certificateTypeEN from './locales/en/QBR/certificateType.json';
import orderDetailEN from './locales/en/QBR/orderDetail.json';
import contentDetailEN from './locales/en/QBR/contentDetail.json';
import reccuringBrEN from './locales/en/QBR/reccuringBr.json';
import recurringConsigFieldsEN from './locales/en/QBR/recurringConsigFields.json';
import documentAttachmentEN from './locales/en/QBR/documentAttachment.json';
import shipperValidationEN from './locales/en/QBR/shipperValidation.json';
import shipmentDetailsEN from './locales/en/QBR/shipmentDetails.json';
import vasEN from './locales/en/QBR/vas.json';
import disbursementDetailEN from './locales/en/QBR/disbursementDetail.json';
import reeferDetailsEN from './locales/en/QBR/reeferDetails.json';
import cenomarCertificateEN from './locales/en/QBR/cenomarCertificate.json';
import marriageCertificateEN from './locales/en/QBR/marriageCertificate.json';
import deathCertificateEN from './locales/en/QBR/deathCertificate.json';
import shipmentGuideEN from './locales/en/ShipmentGuide/Form.json';
import updateResourceEN from './locales/en/TripPlan/UpdateResource.json';
import fcSealNoEN from './locales/en/FCConsDecons/SealNo.json';


// the translations
const resources = {
  en: {
    translation: translationEN,
    brHub: brHubEN,
    brHubGrid: brHubGridEN,
    brHubFooter: brHubFooterEN,
    searchTemplates: searchTemplatesEN,
    csForm: csFormEN,
    inventoryHub: inventoryHubEN,
    inventoryHubSearch: inventoryHubSearchEN,
    inventoryHubGrid: inventoryHubGridEN,
    csSearch: csSearchEN,
    csGrid: csGridEN,
    csValidMsg: csValidationMsgEN,
    csHelp: csHelpOnEN,
    csReceipt: csReceiptEN,
    searchField: searchFieldEN,
    hubLoadGrid: hubLoadGridEN,
    hubLoadForm: hubFormEN,
    hubReceiptForm: hubReceiptEN,
    tripHub: tripHubEN,
    tripHubGrid: tripHubGridEN,
    tripHubForm: tripHubEN,
    dispatchSearchForm: dispatchSearchFormEN,
    dispatchSearchGrid: dispatchSearchGridEN,
    dispatchViewForm: dispatchViewFormEN,
    dispatchCreateForm: dispatchCreateFormEN,
    TripPlan: tripPlanEN,
    linkHouseGrid: linkHouseGridEN,
    ThuGrid: ThuGridEN,
    helpOnTripForm: helpOnTripFormEN,
    helpOnTripGird: helpOnTripGirdEN,
    helpOnCustomerForm: helpOnCustomerFormEN,
    helpOnCustomerGird: helpOnCustomerGirdEN,
    dispatchvalidation: createDispatchvalidationEN,
    hubLoadingvalidation: hubLoadingvalidationEN,
    hubReceiptvalidation: hubReceiptvalidationEN,
    tripHubHelp: tripHubHelpEN,
    acceptance: acceptance,
    customer: customer,
    helpOnVehicleForm: helpOnVehicleFormEN,
    helpOnVehicleGrid: helpOnVehicleGridEN,
    helpOnCarrierForm: helpOnCarrierFormEN,
    helpOnCarrierGrid: helpOnCarrierGridEN,
    helpOnEquipmentForm: helpOnEquipmentFormEN,
    helpOnEquipmentGrid: helpOnEquipmentGridEN,
    bayTransferForm: bayTransferFormEN,
    bayTransferGrid: bayTransferGridEN,
    charges: chargesEN,
    custValidation: customerValidationEN,
    consigneeValidation: consigneeValidationEN,
    birthCertificate: birthCertificateEN,
    helpOnShipPoint: helpOnShipPointEN,
    freightConversionForm: freightConversionFormEN,
    freightConversionGrid: freightConversionGridEN,
    bayTransferValidation: bayTransferValidationEN,
    fcConsDeconsForm: fcConsDeconsFormEN,
    fcInputThu: fcInputThuEn,
    fcOutputThu: fcOutputThuEn,
    loadTHU: loadThuEN,
    thuInventoryForm: thuInventoryFormEN,
    thuInventoryGrid: thuInventoryGridEN,
    thuInventoryFooter: thuInventoryFooterEN,
    allocatethuForm: allocatethuFormEN,
    allocatethuGrid: allocatethuGridEN,
    vehicleSeal: vehicleSealEN,
    fcValidation: fcValidationEn,
    tripAttachments: tripAttachmentsEn,
    helpOnSerialNoForm: helpOnSerialNoFormEN,
    helpOnSerialNoGird: helpOnSerialNoGirdEN,
    helpOnDispatchDocNoForm: helpOnDispatchDocNoFormEN,
    helpOnDispatchDocNoGird: helpOnDispatchDocNoGirdEN,
    documentTracker: documentTrackerEN,
    customerDocument: customerDocumentEN,
    acknowledgementReceipt: acknowledgementReceiptEN,
    newConsignee: newConsigneeEN,
    newShipper: newShipperEN,
    nonReccuringBr: nonReccuringBrEN,
    taxDetails: taxDetailsEN,
    certificateType: certificateTypeEN,
    orderDetail: orderDetailEN,
    contentDetail: contentDetailEN,
    reccuringBr: reccuringBrEN,
    recurringConsigFields: recurringConsigFieldsEN,
    documentAttachment: documentAttachmentEN,
    shipperValidation: shipperValidationEN,
    shipmentDetails: shipmentDetailsEN,
    vas: vasEN,
    disbursementDetail: disbursementDetailEN,
    reeferDetails: reeferDetailsEN,
    cenomarCertificate: cenomarCertificateEN,
    marriageCertificate: marriageCertificateEN,
    deathCertificate: deathCertificateEN,
    shipmentGuide: shipmentGuideEN,
    updateResource:updateResourceEN,
	fcSealNo: fcSealNoEN
  },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next) // passes i18n down to react-i18next
  .init({
    resources,
    ns: ["translations", "brHub", "searchTemplates", "csForm", "inventoryHubEN", "hubLoadForm", "hubReceiptForm", "tripHub", "dispatchSearchForm", "dispatchViewForm", "dispatchCreateForm", "TripPlan", "helpOnTripForm", "helpOnCustomerForm", "tripHubHelp", "acceptance", "customer", "helpOnVehicleForm", "helpOnVehicleGrid", "helpOnCarrierForm", "helpOnCarrierGrid", "inventoryHub", "helpOnEquipmentForm", "helpOnEquipmentGrid", "thuInventoryForm", "thuInventoryGrid", "thuInventoryFooter", "loadTHU", "allocatethuForm", "allocatethuGrid", "vehicleSeal", "fcValidation", "helpOnSerialNoForm", "helpOnSerialNoGird", "helpOnDispatchDocNoForm", "helpOnDispatchDocNoGird", "documentTracker", "customerDocument", "shipmentGuide","updateResource","fcSealNo"],
    defaultNS: "translations",
    lng: "en",
    fallbackLng: "en", // use en if detsected lng is not available

    keySeparator: false, // we do not use keys in form messages.welcome

    interpolation: {
      escapeValue: false // react already safes from xss
    }
  });

export default i18n;
