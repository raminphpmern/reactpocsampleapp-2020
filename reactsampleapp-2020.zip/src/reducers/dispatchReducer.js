import * as actions from "types/dispatchsearch.type";

export const initialState = {
  options: {
    dispatch_type: [],
    service_type: [],
    subservice_type: [],
    br_service_type: [],
    currency_value: [],
    unit_value: [],
    weight_value: [],
    doc_status: [],
    customer_status: [],
  },
  message: null,
  isRequested: false,
  isSuccess: false,
  result: [],
  result_thu: [],
  result_link_house: [],
  result_help_customer: [],
  result_help_trip: [],
  result_help_trip_by_id: [],
  result_change_master_number: [],
  dd_data: null,
  totalPage: 0,
  currentPage: 1,
  totalRecord: 0,
  totalRecord_thu: 0,
  totalPage_thu: 0,
  totalRecord_help_customer: 0,
  totalPage_help_customer: 0,
  totalRecord_help_trip: 0,
  totalPage_help_trip: 0,
  totalPage_link_house: 0,
  totalRecord_link_house: 0,
  customerList: [],
  tripPlanStatus: [],
  lastPage: null,
  activeStep: 1,
  currentStep: 1,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.DISPATCH_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.DISPATCH_FETCH_SUCCESS:
      return {
        ...state,
        result: action.data.result,
        totalPage: action.data.totalPage,
        totalRecord: action.data.totalRecord
      };
    case actions.DISPATCH_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
        isSuccess: false
      };
    case actions.PAGINATION_ATTR:
      return {
        ...state,
        lastPage: action.lastPage
      };
    case actions.RESET_DISPATCH_FETCH_DATA:
      return {
        ...state,
        result: []
      };

    //DISPATCH View data
    case actions.LOAD_VIEW_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.DISPATCH_VIEW_DATA_SUCCESS:
      return {
        ...state,
        dd_data: action.result,
      };

    case actions.DISPATCH_DATA_RESET:
      return {
        ...state,
        dd_data: null
      };

    //DISPATCH Master View data
    case actions.LOAD_MASTER_VIEW_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.LOAD_MASTER_VIEW_SUCCESS:
      return {
        ...state,
        dd_data: action.result,
      };

    //DISPATCH View THU Table
    case actions.DISPATCH_THU_FETCH_SUCCESS:
      return {
        ...state,
        result_thu: action.data.result,
        totalPage_thu: action.data.totalPage,
        totalRecord_thu: action.data.totalRecord
      };
    case actions.DISPATCH_THU_FETCH_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.RESET_DISPATCH_THU_DATA:
      return {
        ...state,
        result_thu: []
      };

    // HelpCustomer
    case actions.DISPATCH_HELP_CUSTOMER_RESULT_SUCCESS:
      return {
        ...state,
        result_help_customer: action.data.result,
        totalPage_help_customer: action.data.totalPage,
        totalRecord_help_customer: action.data.totalRecord
      };
    case actions.HELP_FETCH_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.DISPATCH_HELP_SEARCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };

    //Help for Trip Log
    case actions.TRIP_HELP_ID_FETCH_SUCCESS:
      return {
        ...state,
        result_help_trip: action.data.result,
        totalPage_help_trip: action.data.totalPage,
        totalRecord_help_trip: action.data.totalRecord
      };
    case actions.TRIP_HELP_ID_FETCH_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.TRIP_HELP_SEARCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };

    // To Save details from the dispatch Create
    case actions.DISPATCH_CREATE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.DISPATCH_CREATE_SUCCESS:
      return {
        ...state,
        result: action.data.result
      };
    case actions.DISPATCH_CREATE_FAILURE:
      return {
        ...state,
        message: action.message
      };

    // Link House
    case actions.LINK_HOUSE_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.LINK_HOUSE_FETCH_SUCCESS:
      return {
        ...state,
        result_link_house: action.data.result,
        totalPage_link_house: action.data.totalPage,
        totalRecord_link_house: action.data.totalRecord
      };
    case actions.LINK_HOUSE_FETCH_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.RESET_DISPATCH_LINK_HOUSE_RECORDS:
      return {
        ...state,
        result_link_house: []
      };

    //Help for Trip Log_BY_ID
    case actions.TRIP_HELP_ID_FETCH_SUCCESS_BY_ID:
      return {
        ...state,
        result_help_trip_by_id: action.data.result
      };
    case actions.TRIP_HELP_ID_FETCH_FAILURE_BY_ID:
      return {
        ...state,
        message: action.message
      };
    case actions.TRIP_HELP_SEARCH_REQUEST_BY_ID:
      return {
        ...state,
        isRequested: action.isRequested
      };

    //Assign& Unassign
    case actions.CHANGE_MASTER_NUMBER_SUCCESS:
      return {
        ...state,
        result_change_master_number: action.data.result
      };
    case actions.CHANGE_MASTER_NUMBER_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.CHANGE_MASTER_NUMBER_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };

    default:
      return state;
  }
}