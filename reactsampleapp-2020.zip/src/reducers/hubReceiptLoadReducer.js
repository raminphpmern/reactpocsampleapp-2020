import * as actions from 'types/hubreceiptload.type';

export const initialState = {
  options: {
    employee: [],
    mhe: [],
    stageid: [],
    trip_to: [],
    serialNoDtls: [],
    moreDtls: [],
    region: []
  },
  message: null,
  isRequested: false,
  isSaveRequested: false,
  isSuccess: false,
  totalPageLink: 0,
  totalRecordLink: 0,
  currentPageLink: 1,
  receiptresult: [],
  loadingresult: [],
  load_response: [],
  result: [],
  gridReceiptResult: [],
  gridLoadResult: [],
  receiptHeaderResult: [],
  loadHeaderResult: [],
  receipt_cbm: [],
  loading_cbm: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  lastPage: 0,
  status: null,
  equipmentResult: [],
  equipmentTotalPage: 0,
  equipmentTotalRecord: 0,
  equipmentCurrentPage: 1
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.TRIP_LOG_DATA_FETCH_SUCCESS:
      return {
        ...state,
        result: action.data,
        gridReceiptResult: action.data[0].receipt_grid_details,
        receiptHeaderResult: action.data[0].receipt_header,
        receipt_cbm: action.data[0].receipt_cbm,
        gridLoadResult: action.data[0].loading_grid_details,
        loadHeaderResult: action.data[0].loading_header,
        loading_cbm: action.data[0].result_cbm,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord
      }
    case actions.TRIP_LOG_DATA_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIP_LOG_DATA_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.RESET_TRIP_LOG_DATA_RECORDS:
      return {
        ...state,
        result: [],
        gridReceiptResult: [],
        gridLoadResult: [],
        totalPage: 0,
        totalRecord: 0
      }
    case actions.RESET_SERIAL_NUMBER_RECORDS:
      return {
        ...state,
        serialNoDtls: []
      }
    case actions.RESET_HEADER_RECORDS:
      return {
        ...state,
        receiptHeaderResult: [],
        loadHeaderResult: []
      }
    case actions.RECEIPT_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.RECEIPT_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message,
        status: action.status
      };
    case actions.SCAN_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message,
        status: action.status
      };
    case actions.LOADING_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.RECORDS_SAVE_SUCCESS:
      return {
        ...state,
        load_response: action.result,
        message: action.message
      };
    case actions.LOADING_DISPATCH_DOCUMENT_RECORDS:
      return {
        ...state,
        gridReceiptResult: action.data,
        gridLoadResult: action.data,
        receipt_cbm: action.cbmData,
        loading_cbm: action.cbmData,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord
      };
    case actions.LOADING_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message,
        status: action.status
      };
    case actions.OPTIONS_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
        lastPage: 0
      };
    case actions.OPTIONS_FETCH_SUCCESS:
      return {
        ...state,
        options: action.data,
        isSuccess: true
      };
    case actions.OPTIONS_FETCH_FAILURE:
      return {
        ...state,
        isSuccess: false
      };
    case actions.HUB_EQUIPMENT_FETCH_SUCCESS:
      return {
        ...state,
        equipmentResult: action.data,
        equipmentTotalPage: action.totalPage,
        equipmentTotalRecord: action.totalRecord,
        equipmentLimit: action.limit,
      }
    case actions.HUB_EQUIPMENT_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.HUB_EQUIPMENT_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        equipmentResult: [],
        equipmentTotalPage: 0,
        equipmentTotalRecord: 0,
        equipmentCurrentPage: 1
      }
    case actions.HUB_EQUIPMENT_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.RECEIPT_SEAL_DETAILS_SUCCESS:
      return {
        ...state,
        receiptresult: action.data,
        totalPageLink: action.totalPage,
        totalRecordLink: action.totalRecord
      }
    case actions.RECEIPT_SEAL_DETAILS_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.RECEIPT_SEAL_DETAILS_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        receiptresult: [],
        totalPageLink: 0,
        totalRecordLink: 0,
        currentPageLink: 1,
      }
    case actions.RECEIPT_SEAL_DETAILS_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.RECEIPT_SEAL_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isSaveRequested: action.isSaveRequested,
      };
    case actions.RECEIPT_SEAL_RECORDS_SAVE_SUCCESS:
      return {
        ...state,
        message: action.message,
        receiptresult: action.data,
      }
    case actions.RECEIPT_SEAL_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message
      }
    case actions.LOADING_SEAL_DETAILS_SUCCESS:
      return {
        ...state,
        loadingresult: action.data,
        totalPageLink: action.totalPage,
        totalRecordLink: action.totalRecord,
      }
    case actions.LOADING_SEAL_DETAILS_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.LOADING_SEAL_DETAILS_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        loadingresult: [],
        totalPageLink: 0,
        totalRecordLink: 0,
        currentPageLink: 1,
      }
    case actions.LOADING_SEAL_DETAILS_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.LOADING_SEAL_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isSaveRequested: action.isSaveRequested,
      };
    case actions.LOADING_SEAL_RECORDS_SAVE_SUCCESS:
      return {
        ...state,
        message: action.message,
        loadingresult: action.data,
      }
    case actions.LOADING_SEAL_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message
      }
    default:
      return state;
  }
}