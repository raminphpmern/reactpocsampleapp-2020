import * as actions from 'types/loadTHU.type';
import _ from 'lodash'

export const initialState = {
  message: null,
  result: [],
  isSaveRequested: false
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.LOADTHU_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isSaveRequested: action.isSaveRequested,
      };
    case actions.LOADTHU_RECORDS_SAVE_SUCCESS:
      return {
        ...state,
        message: action.message,
        result: action.data,
      }
    case actions.LOADTHU_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message
      }

    default:
      return state;
  }
}