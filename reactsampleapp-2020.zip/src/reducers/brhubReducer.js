import * as actions from "types/brHub.type";

export const initialState = {
  message: null,
  isRequested: false,
  result: [],
  totalPage: 0,
  currentPage: 1,
  totalRecord: 0,
  limit: 10,
  currentTrip: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.BRHUB_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.BRHUB_FETCH_SUCCESS:
      return {
        ...state,
        result: action.data.result,
        totalPage: action.data.totalPage,
        totalRecord: action.data.totalRecord,
        limit: action.limit,
      };
    case actions.BRHUB_FETCH_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.BRHUB_ACTION_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
      };
    case actions.BRHUB_ACTION_SUCCESS:
      return {
        ...state,
        result: action.result
      }
    case actions.BRHUB_ACTION_FAILURE:
      return {
        ...state,
        message: action.message
      }
    case actions.BRHUB_ACTION_RESET:
      return {
        ...state,
        result: []
      }
    case actions.BR_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        result: [],
        totalPage: 0,
        currentPage: 1,
        totalRecord: 0,
        limit: 10,
      }
    default:
      return state;
  }
}
