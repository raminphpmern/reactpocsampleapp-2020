import * as actions from "types/master.type";

export const initialState = {
  options: {
    countries: [],
    province: [],
    city: [],
    barangay: [],
    zip: [],
    brsd_from_ship_point_id: [],
    brsd_to_ship_point_id: [],
    zone: [],
    sub_zone: [],
    shipper: [],
    shipper_first_name: [],
    shipper_last_name: [],
    consignee: [],
    consignee_first_name: [],
    consignee_last_name: [],
    service_mode: [],
    shipment_type: [],
    request_type: [],
    billing_status: [],
    last_event: [],
    event_location: [],
    failed_attempts: [],
    reason_code: [],
    current_location: [],
    creation_mode: [],
    request_status: [],
    payment_type: [],
    mode_of_collections: [],
    products: [],
    class_of_stores: [],
    product_items: [],
    vas: [],
    temp_uom: [],
    relations: [],
    document_profiles: [],
    employee: [],
    currencies: [],
    bankCodes: [],
    status: [],
    amend_reason_code: [],
    ccd_receipt_no_from: [],
    ccd_receipt_no_to: [],
    wms_emp_employee_code: [],
    bay_id: [],
    trip_id: [],
    bayType: [],
    discrepancy: [],
    dispatchDocNos: [],
    employeeStatus: [],
    receiptNoStatus: [],
    tripPlanIds: [],
    dispatch_doc_type: [],
    tripStatus: [],
    ownerType: [],
    vehicleType: [],
    hubLocationsTo: [],
    hubLocationsFrom: [],
    leg: [],
    dd_no: [],
    taxStatus: [],
    taxExempt: [],
    certificate_type: [],
    certificate_purpose: [],
    carrierStatus: [],
    classifications: [],
    documentType: [],
    equipmentType: [],
    damageCode: [],
    disbursementMode: [],
    dgClass: [],
    transportMode: [],
    restrictionCategory: [],
    sku: [],
    docType: [],
    alt_uom: [],
    codIncludes: [],
  },
  isSuccess: false,
  isLoading: false,
  isSearching: false,
  lastPage: 0,
  totalRecords: 0,
  total_cop: 0,
  total_cod: 0,
  shipperList: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.MASTER_FETCH_SUCCESS:
      return {
        ...state,
        options: action.data,
        isSuccess: true
      };
    case actions.MASTER_FETCH_INITIALIZE:
      return {
        ...state,
        ...initialState
      };
    case actions.MASTER_FETCH_REQUEST:
      return {
        ...state,
        isLoading: action.isLoading,
        lastPage: 0
      };
    case actions.MASTER_FETCH_FAILURE:
      return {
        ...state,
        isSuccess: false
      };
    case actions.MASTER_MULTI_SEARCH_REQUEST:
      return {
        ...state,
        isSearching: action.isSearching
      };
    case actions.PAGINATION_ATTR:
      return {
        ...state,
        lastPage: action.lastPage,
        totalRecords: action.total
      };
    case actions.CALCULATE_COP_COD:
      return {
        ...state,
        total_cop: action.data.total_cop,
        total_cod: action.data.total_cod
      };
    case actions.MASTER_SHIPPING_FETCH_SUCCESS:
      return {
        ...state,
        shipperList: action.data
      };
    case actions.INITIALIZE_SHIPPER_IDS:
      return {
        ...state,
        shipperList: []
      };
    case actions.INITIALIZE_BR_OPTIONS:
      return {
        ...state,
        options: action.options,
      }
    default:
      return state;
  }
}
