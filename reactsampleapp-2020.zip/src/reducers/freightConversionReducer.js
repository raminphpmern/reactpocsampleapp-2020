import * as actions from 'types/freightConversion.type';

export const initialState = {
  options: {
    employee: [],
    mhe: [],
    bayid: [],
    volume: [],
    weight: [],
    operators: []
  },
  message: null,
  isRequested: false,
  isSuccess: false,
  result: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  lastPage: 0,
  count: 0,
  input_Thu_result: [],
  input_Thu_totalPage: 0,
  input_Thu_totalRecord: 0,
  output_Thu_result: [],
  output_Thu_totalPage: 0,
  output_Thu_totalRecord: 0,
  compute_result: [],
  dispatch_doc_help_result: [],
  dispatch_doc_help_totalPage: 0,
  dispatch_doc_help_totalRecord: 0,
  serial_no_help_result: [],
  serial_no_help_totalRecord: 0,
  serial_no_help_totalPage: 0,
  cons_seal_result: [],
  cons_seal_totalRecord: 0,
  cons_seal_totalPage: 0,
  decons_seal_result: [],
  decons_seal_totalRecord: 0,
  decons_seal_totalPage: 0,
  status: '',
  deconExpandClick: ''
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.FREIGHT_CONVERSION_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.FREIGHT_CONVERSION_FETCH_SUCCESS:
      return {
        ...state,
        result: action.data.result,
        totalPage: action.data.totalPage,
        totalRecord: action.data.totalRecord,
        count: action.count
      }
    case actions.FREIGHT_CONVERSION_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.RESET_FC_SEARCH_RECORDS:
      return {
        ...state,
        result: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1,
        lastPage: 0,
        count: 0,
        input_Thu_result: [],
        input_Thu_totalPage: 0,
        input_Thu_totalRecord: 0,
        output_Thu_result: [],
        output_Thu_totalPage: 0,
        output_Thu_totalRecord: 0,
        compute_result: [],
        status: ''
      }
    case actions.DELETE_FC_DECONSOLIDATION_RECORD:
      return {
        ...state,
        input_Thu_result: [],
        input_Thu_totalPage: 0,
        input_Thu_totalRecord: 0,
        output_Thu_result: [],
        output_Thu_totalPage: 0,
        output_Thu_totalRecord: 0,
      }
    case actions.RESET_FC_HELP_SCREEN_SEARCH_RECORDS:
      return {
        ...state,
        dispatch_doc_help_result: [],
        dispatch_doc_help_totalPage: 0,
        dispatch_doc_help_totalRecord: 0,
        serial_no_help_result: [],
        serial_no_help_totalRecord: 0,
        serial_no_help_totalPage: 0,
      }
    case actions.FC_RECORDS_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.FC_RECORDS_FETCH_SUCCESS:
      return {
        ...state,
        result: action.result
      }
    case actions.FC_RECORDS_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.FC_INPUT_THU_RECORDS_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.FC_INPUT_THU_RECORDS_FETCH_SUCCESS:
      return {
        ...state,
        input_Thu_result: action.result,
        input_Thu_totalRecord: action.totalRecord,
        input_Thu_totalPage: action.totalPage
      }
    case actions.FC_INPUT_THU_RECORDS_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.FC_OUTPUT_THU_RECORDS_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.FC_OUTPUT_THU_RECORDS_FETCH_SUCCESS:
      return {
        ...state,
        output_Thu_result: action.result,
        output_Thu_totalRecord: action.totalRecord,
        output_Thu_totalPage: action.totalPage,
        deconExpandClick: action.expand
      }
    case actions.FC_OUTPUT_THU_RECORDS_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.FC_OUTPUT_THU_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.FC_OUTPUT_THU_FETCH_SUCCESS:
      return {
        ...state,
        output_Thu_result: action.result,
        output_Thu_totalRecord: action.totalRecord,
        output_Thu_totalPage: action.totalPage
      }
    case actions.FC_OUTPUT_THU_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.FC_INPUT_THU_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.FC_INPUT_THU_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.FC_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.FC_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.FC_MASTER_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
        lastPage: 0
      };
    case actions.FC_MASTER_FETCH_SUCCESS:
      return {
        ...state,
        options: action.data,
        isSuccess: true
      };
    case actions.FC_MASTER_FETCH_FAILURE:
      return {
        ...state,
        isSuccess: false
      };
    case actions.FC_INPUT_THU_COMPUTE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.FC_INPUT_THU_COMPUTE_SUCCESS:
      return {
        ...state,
        compute_result: action.result,
        isSuccess: true
      };
    case actions.FC_INPUT_THU_COMPUTE_FAILURE:
      return {
        ...state,
        message: action.message,
      };
    case actions.FC_HELP_SCREENS_SEARCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
      };
    case actions.DDNO_HELP_SEARCH_SUCCESS:
      return {
        ...state,
        dispatch_doc_help_result: action.data,
        dispatch_doc_help_totalRecord: action.totalRecord,
        dispatch_doc_help_totalPage: action.totalPage,
        isSuccess: true
      };
    case actions.FC_HELP_SCREENS_SEARCH_FAILURE:
      return {
        ...state,
        isSuccess: false
      };
    case actions.SERIAL_NO_HELP_SEARCH_SUCCESS:
      return {
        ...state,
        serial_no_help_result: action.data,
        serial_no_help_totalRecord: action.totalRecord,
        serial_no_help_totalPage: action.totalPage,
        isSuccess: true
      };
    case actions.FC_CONSOLIDATION_SEAL_DETAILS_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
      };
    case actions.FC_CONSOLIDATION_SEAL_DETAILS_SUCCESS:
      return {
        ...state,
        cons_seal_result: action.data,
        cons_seal_totalRecord: action.totalRecord,
        cons_seal_totalPage: action.totalPage,
        isSuccess: true
      };
    case actions.FC_CONSOLIDATION_SEAL_DETAILS_FAILURE:
      return {
        ...state,
        message: action.message,
        isSuccess: false
      };
    case actions.FC_CONSOLIDATION_SEAL_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isRequested: action.isSaveRequested,
      };
    case actions.FC_CONSOLIDATION_SEAL_RECORDS_SAVE_SUCCESS:
      return {
        ...state,
        message: action.message,
        cons_seal_result: action.data,
        status: action.status
      }
    case actions.FC_CONSOLIDATION_SEAL_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message
      }



    case actions.FC_DECONSOLIDATION_SEAL_DETAILS_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
      };
    case actions.FC_DECONSOLIDATION_SEAL_DETAILS_SUCCESS:
      return {
        ...state,
        decons_seal_result: action.data,
        decons_seal_totalRecord: action.totalRecord,
        decons_seal_totalPage: action.totalPage,
        isSuccess: true
      };
    case actions.FC_DECONSOLIDATION_SEAL_DETAILS_FAILURE:
      return {
        ...state,
        message: action.message,
        isSuccess: false
      };
    case actions.FC_DECONSOLIDATION_SEAL_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isRequested: action.isSaveRequested,
      };
    case actions.FC_DECONSOLIDATION_SEAL_RECORDS_SAVE_SUCCESS:
      return {
        ...state,
        message: action.message,
        decons_seal_result: action.data,
        status: action.status
      }
    case actions.FC_DECONSOLIDATION_SEAL_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message
      }

    default:
      return state;
  }
}