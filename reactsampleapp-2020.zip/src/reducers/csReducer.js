import * as actions from 'types/cs.type';

export const initialState = {
  message: null,
  isRequested: false,
  result: [],
  receiptResult: [],
  employeeResult: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  limit: 10,
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.CS_FETCH_SUCCESS:
      return {
        ...state,
        result: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
        limit: action.limit,
      }
    case actions.CS_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.CS_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        result: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1
      }
    case actions.CS_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.CS_STATUS_UPDATE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
      };
    case actions.CS_STATUS_UPDATE_FAILURE:
      return {
        ...state,
        message: action.message
      }
    case actions.CS_STATUS_UPDATE_RESET:
      return {
        ...state,
        result: []
      }
    case actions.CS_RECEIPT_SUCCESS:
      return {
        ...state,
        receiptResult: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
      }
    case actions.CS_RECEIPT_FAILURE:
      return {
        ...state,
        message: action.message,
      }

    case actions.CS_RECEIPT_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.CS_EMPLOYEE_SUCCESS:
      return {
        ...state,
        employeeResult: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
      }
    case actions.CS_EMPLOYEE_FAILURE:
      return {
        ...state,
        message: action.message,
      }

    case actions.CS_EMPLOYEE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.CS_EMP_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        employeeResult: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1
      }
    case actions.CS_RECEIPT_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        receiptResult: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1
      }


    default:
      return state;
  }
}