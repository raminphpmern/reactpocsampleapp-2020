import * as actions from 'types/tripHub.type';
import _ from 'lodash';

export const initialState = {
  message: null,
  isRequested: false,
  result: [],
  vehicleResult: [],
  carrierResult: [],
  tripsToday: 0,
  tripsWeek: 0,
  all: 0,
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  limit: 10,
  vehicleTotalPage: 0,
  vehicleTotalRecord: 0,
  vehicleCurrentPage: 1,
  vehicleLimit: 10,
  carrierTotalPage: 0,
  carrierTotalRecord: 0,
  carrierCurrentPage: 1,
  carrierLimit: 10,
  totalPageLink: 0,
  totalRecordLink: 0,
  currentPageLink: 1,
  tripresult: [],
  isSaveRequested: false,
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.TRIPHUB_FETCH_SUCCESS:
      return {
        ...state,
        result: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
        limit: action.limit,
        tripsToday: action.filterType === 'today' ? action.totalRecord : state.tripsToday,
        tripsWeek: action.filterType === 'week' ? action.totalRecord : state.tripsWeek,
        all: _.includes(['all', undefined], action.filterType) ? action.totalRecord : state.all,
      }
    case actions.TRIPHUB_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIPHUB_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        result: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1
      }
    case actions.TRIPHUB_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }

    case actions.TRIPHUB_VEHICLE_FETCH_SUCCESS:
      return {
        ...state,
        vehicleResult: action.data,
        vehicleTotalPage: action.totalPage,
        vehicleTotalRecord: action.totalRecord,
        vehicleLimit: action.limit,
      }
    case actions.TRIPHUB_VEHICLE_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIPHUB_VEHICLE_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        vehicleResult: [],
        vehicleTotalPage: 0,
        vehicleTotalRecord: 0,
        vehicleCurrentPage: 1
      }
    case actions.TRIPHUB_VEHICLE_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }

    case actions.TRIPHUB_CARRIER_FETCH_SUCCESS:
      return {
        ...state,
        carrierResult: action.data,
        carrierTotalPage: action.totalPage,
        carrierTotalRecord: action.totalRecord,
        carrierLimit: action.limit
      };
    case actions.TRIPHUB_CARRIER_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.TRIPHUB_CARRIER_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        carrierResult: [],
        carrierTotalPage: 0,
        carrierTotalRecord: 0,
        carrierCurrentPage: 1
      };
    case actions.TRIPHUB_CARRIER_FETCH_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.TRIP_SEAL_DETAILS_SUCCESS:
      return {
        ...state,
        tripresult: action.data,
        totalPageLink: action.totalPage,
        totalRecordLink: action.totalRecord,
      }
    case actions.TRIP_SEAL_DETAILS_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIP_SEAL_DETAILS_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        tripresult: [],
        totalPageLink: 0,
        totalRecordLink: 0,
        currentPageLink: 1,
      }
    case actions.TRIP_SEAL_DETAILS_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.TRIP_SEAL_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isSaveRequested: action.isSaveRequested,
      };
    case actions.TRIP_SEAL_RECORDS_SAVE_SUCCESS:
      return {
        ...state,
        message: action.message,
        tripresult: action.data,
      }
    case actions.TRIP_SEAL_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message
      }
    default:
      return state;
  }
}