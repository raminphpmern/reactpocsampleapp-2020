import * as actions from 'types/searchTemplate.type';

export const initialState = {
  message: null,
  isLoading: false,
  templates: [],
}

export default function (state = initialState, action) {

  switch (action.type) {
    case actions.SEARCH_TEMPLATE_FETCH_SUCCESS:
      return {
        ...state,
        templates: action.data,
      }
    case actions.SEARCH_TEMPLATE_FETCH_REQUEST:
      return {
        ...state,
        isLoading: action.isLoading
      }
    case actions.SEARCH_TEMPLATE_FETCH_FAILURE:
      return {
        ...state,
        message: action.message
      }
    default:
      return state;
  }
}