import * as actions from "types/updateResource.type";
import _ from 'lodash';

export const initialState = {
  message: null,
  isRequested: false,
  attachments: [],
  totalPage: 0,
  totalRecord: 0,
  limit: 0,
  isOptionRequested: false,
  typeOptions: [],
}
export default function (state = initialState, action) {
  switch (action.type) {
    case actions.TRIP_RESOURCE_FETCH_SUCCESS:
      return {
        ...state,
        attachments: action.attachments,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
        limit: action.limit,
      }
    case actions.TRIP_RESOURCE_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIP_RESOURCE_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.TRIP_RESOURCE_SAVE_SUCCESS:
      return {
        ...state,
        result: action.result
      }
    case actions.TRIP_RES_OPTIONS_FETCH_REQUEST:
      return {
        ...state,
        isOptionRequested: action.isRequested
      }
    case actions.TRIP_RES_OPTIONS_FETCH_SUCCESS:
      return {
        ...state,
        typeOptions: action.typeOptions
      }
    default:
      return state;
  }
}