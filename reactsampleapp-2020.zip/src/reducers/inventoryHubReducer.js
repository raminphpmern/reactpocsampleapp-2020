import * as actions from 'types/inventoryHub.type';

export const initialState = {
  message: null,
  isRequested: false,
  result: [],
  lastattemptresult: [],
  serialnoresult: [],
  moredetailsresult: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  limit: 10,
  totalPageLink: 0,
  totalRecordLink: 0,
  currentPageLink: 1,
  linkLimit: 10,
  serialNumberOptions: [],
  isSaveRequested: false,
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.IH_FETCH_SUCCESS:
      return {
        ...state,
        result: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
        limit: action.limit,
      }
    case actions.IH_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.IH_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        result: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1,
      }
    case actions.IH_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.IH_LAST_ATTEMPT_SUCCESS:
      return {
        ...state,
        lastattemptresult: action.data,
        totalPageLink: action.totalPage,
        totalRecordLink: action.totalRecord,
        linkLimit: action.limit,
      }
    case actions.IH_LAST_ATTEMPT_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.IH_LAST_ATTEMPT_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        lastattemptresult: [],
        totalPageLink: 0,
        totalRecordLink: 0,
        currentPageLink: 1,
      }
    case actions.IH_LAST_ATTEMPT_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.IH_SERIAL_NO_SUCCESS:
      return {
        ...state,
        serialnoresult: action.data,
        totalPageLink: action.totalPage,
        totalRecordLink: action.totalRecord,
        linkLimit: action.limit,
      }
    case actions.IH_SERIAL_NO_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.IH_SERIAL_NO_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        serialnoresult: [],
        totalPageLink: 0,
        totalRecordLink: 0,
        currentPageLink: 1,
      }
    case actions.IH_SERIAL_NO_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.IH_DISCREPANCY_DETAILS_SUCCESS:
      return {
        ...state,
        moredetailsresult: action.data,
        totalPageLink: action.totalPage,
        totalRecordLink: action.totalRecord,
        serialNumberOptions: action.serialNumbers,
        linkLimit: action.limit,
      }
    case actions.IH_DISCREPANCY_DETAILS_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.IH_DISCREPANCY_DETAILS_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        moredetailsresult: [],
        totalPageLink: 0,
        totalRecordLink: 0,
        currentPageLink: 1,
      }
    case actions.IH_DISCREPANCY_DETAILS_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.DISCREPANCY_RECORDS_SAVE_REQUEST:
      return {
        ...state,
        isSaveRequested: action.isSaveRequested,
      };
    case actions.DISCREPANCY_RECORDS_SAVE_SUCCESS:
      return {
        ...state,
        message: action.message,
        moredetailsresult: action.data,
      }
    case actions.DISCREPANCY_RECORDS_SAVE_FAILURE:
      return {
        ...state,
        message: action.message
      }
    case actions.IH_SERIAL_NO_OPTION_SUCCESS:
      return {
        ...state,
        serialNumberOptions: action.data
      }
    case actions.IH_STATUS_UPDATE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
      };
    case actions.IH_STATUS_UPDATE_FAILURE:
      return {
        ...state,
        message: action.message
      }
    case actions.IH_STATUS_UPDATE_RESET:
      return {
        ...state,
        result: []
      }

    default:
      return state;
  }
}