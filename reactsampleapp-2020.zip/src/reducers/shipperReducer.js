import * as actions from 'types/shipper.type';

export const initialState = {
  shipper: [],
  message: null,
  isLoading: false,
  isSuccess: false,
  currentShipper: null
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.CREATE_SHIPPER_INITIALIZE:
      return {
        ...state,
        ...initialState
      }
    case actions.CREATE_SHIPPER_SUCCESS:
      return {
        ...state,
        currentShipper: action.shipper,
        isSuccess: true
      }
    case actions.CREATE_SHIPPER_REQUEST:
      return {
        ...state,
        isLoading: action.isLoading
      }
    case actions.CREATE_SHIPPER_FAILURE:
      return {
        ...state,
        message: action.message,
        isSuccess: false
      }
    default:
      return state;
  }
}