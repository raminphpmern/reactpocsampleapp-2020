import * as customerTypes from 'types/customer.type.js'
import * as bookingTypes from 'types/booking.type.js'
import * as orderTypes from 'types/order.type.js'
import * as documentTypes from 'types/document.type.js'
import * as chargesTypes from 'types/charges.type.js'
import * as disbursementTypes from 'types/disbursement.type.js'
import * as certificateTypes from 'types/certificate.type'
import * as promoTypes from 'types/promo.type.js'

const initialState = {
  bookingData: null,
  message: null,
  isSearching: false,
  isRequested: false,
  currentBooking: null,
  isSuccess: false,
  activeStep: 1,
  currentStep: 1,
  prePrintedIsValid: true,
  copyBooking: null,
  recurring: 'N',
  trackingValid: false,
  taxDetails: [],
  uomResult: [],
  ethuTrackingValid: false,
  prePrintedIsValidEthu: true,
  ethuProduct: [],
  chargesData: null,
  vShipment: false,
  tariff: [],
  contract: {},
  validationProfile: null,
  childThuValid: true,
  isPromoRequest: false,
  isPromoValid: false,
}

export default function (state = initialState, action) {
  switch (action.type) {
    case customerTypes.CUSTOMER_CREATE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case customerTypes.CUSTOMER_CREATE_SUCCESS:
      return {
        ...state,
        currentBooking: action.data,
        isSuccess: true,
        activeStep: action.activeStep,
        currentStep: action.currentStep,
        copyBooking: null,
        isRequested: false,
        validationProfile: action.configResponse
      }
    case customerTypes.CUSTOMER_CREATE_FAILURE:
      return {
        ...state,
        message: action.message,
        isSuccess: false,
        isRequested: false
      }
    case bookingTypes.BOOKING_SEARCH_REQUEST:
      return {
        ...state,
        isSearching: action.isSearching,
      }
    case bookingTypes.BOOKING_SEARCH_SUCCESS:
      return {
        ...state,
        bookingData: action.data,
        currentBooking: action.data,
        message: null,
        isRequested: false,
        validationProfile: action.configResponse
      }
    case bookingTypes.BOOKING_SEARCH_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }
    case bookingTypes.BOOKING_STEP_CHANGE:
      return {
        ...state,
        currentStep: action.step,
        isRequested: false
      }
    case bookingTypes.BOOKING_REFRESH_SEARCH_SUCCESS:
      return {
        ...state,
        currentBooking: action.data,
        isSuccess: true,
        activeStep: action.activeStep,
        currentStep: action.currentStep,
        isRequested: false,
        validationProfile: action.configResponse
      }
    case orderTypes.CREATE_ORDER_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case orderTypes.CREATE_ORDER_SUCCESS:
      return {
        ...state,
        currentBooking: action.data,
        activeStep: action.activeStep,
        currentStep: action.currentStep,
        isRequested: false
      }
    case orderTypes.CREATE_ORDER_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }
    case orderTypes.PREPRINTED_DOC_NUMBER_IS_VALID:
      return {
        ...state,
        prePrintedIsValid: action.isValid,
        trackingValid: action.isValid
      }
    case orderTypes.ETHU_VALID:
      return {
        ...state,
        prePrintedIsValidEthu: action.isValid,
        ethuTrackingValid: action.isValid,
        ethuProduct: action.data
      }
    case orderTypes.V_SHIPMENT_SUCCESS:
      return {
        ...state,
        vShipment: action.contract.value_shipment,
        chargesData: action.result,
        tariff: action.data,
        isRequested: false,
        contract: action.contract
      }
    case orderTypes.V_SHIPMENT_REQUEST:
      return {
        ...state,
        vShipment: false,
        isRequested: action.isRequested,
        chargesData: null,
        tariff: []
      }
    case documentTypes.CREATE_DOCUMENT_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case documentTypes.CREATE_DOCUMENT_SUCCESS:
      return {
        ...state,
        currentBooking: action.data,
        activeStep: action.activeStep,
        currentStep: action.currentStep,
        isRequested: false
      }
    case documentTypes.CREATE_DOCUMENT_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }
    case disbursementTypes.CREATE_DISBURSEMENT_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case disbursementTypes.CREATE_DISBURSEMENT_SUCCESS:
      return {
        ...state,
        currentBooking: action.data,
        isRequested: false
      }
    case disbursementTypes.CREATE_DISBURSEMENT_FAILURE:
      return {
        ...state,
        message: action.message
      }
    case certificateTypes.CREATE_CERTIFICATE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case certificateTypes.CREATE_CERTIFICATE_SUCCESS:
      return {
        ...state,
        currentBooking: action.data,
        isRequested: false
      }
    case certificateTypes.CREATE_CERTIFICATE_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }
    case chargesTypes.CREATE_CHARGES_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case chargesTypes.CREATE_CHARGES_SUCCESS:
      return {
        ...state,
        currentBooking: action.data,
        isRequested: false
      }
    case chargesTypes.CREATE_CHARGES_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }
    case bookingTypes.BOOKING_INITIALIZE:
      return {
        ...state,
        bookingData: null,
        message: null,
        isSearching: false,
        isRequested: false,
        currentBooking: null,
        isSuccess: false,
        activeStep: 1,
        currentStep: 1,
        recurring: action.recurring,
        copyBooking: null,
        chargesData: null,
      }
    case bookingTypes.COPY_BOOKING_INITIALIZE:
      return {
        ...state,
        copyBooking: action.copyBooking,
        message: null,
        isSearching: false,
        isRequested: false,
        currentBooking: null,
        isSuccess: false,
        activeStep: 1,
        currentStep: 1,
        chargesData: null,
      }
    case customerTypes.CUSTOMER_PICKUP_BRANCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case customerTypes.CUSTOMER_PICKUP_BRANCH_SUCCESS:
      return {
        ...state,
        currentBooking: action.data,
        isRequested: false
      }
    case customerTypes.CUSTOMER_PICKUP_BRANCH_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }
    case bookingTypes.CHANGE_RECURRING:
      return {
        ...state,
        recurring: action.data
      }
    case customerTypes.CUSTOMER_TAX_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case customerTypes.CUSTOMER_TAX_SUCCESS:
      return {
        ...state,
        taxDetails: action.data,
        isRequested: false
      }
    case customerTypes.CUSTOMER_TAX_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }

    case orderTypes.UOM_FETCH_SUCCESS:
      return {
        ...state,
        uomResult: action.data,
        isRequested: false
      }
    case orderTypes.UOM_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case orderTypes.UOM_FETCH_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }
    case chargesTypes.CALCULATE_CHARGES_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
        chargesData: null,
        tariff: []
      }
    case chargesTypes.CALCULATE_CHARGES_SUCCESS:
      return {
        ...state,
        chargesData: action.result,
        tariff: action.data,
        isRequested: false
      }
    case chargesTypes.CALCULATE_CHARGES_FAILURE:
      return {
        ...state,
        message: action.message,
        isRequested: false
      }
    case orderTypes.CHILD_THU_REQUEST:
      return {
        ...state,
        isRequested: true,
        childThuValid: true
      }
    case orderTypes.CHILD_THU_VALID:
      return {
        ...state,
        childThuValid: true,
        isRequested: false,
      }
    case orderTypes.CHILD_THU_INVALID:
      return {
        ...state,
        isRequested: false,
        childThuValid: false
      }
    case promoTypes.PROMOCODE_REQUEST:
      return {
        ...state,
        isPromoRequest: action.isPromoRequest
      }
    case promoTypes.PROMOCODE_SUCCESS:
      return {
        ...state,
        isPromoValid: true,
        currentBooking: action.currentBooking,
        chargesData: action.result,
        tariff: action.data,
      }
    case promoTypes.PROMOCODE_FAILURE:
      return {
        ...state,
        isPromoValid: action.isValid,
      }
    default:
      return state;
  }
}