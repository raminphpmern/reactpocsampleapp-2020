import * as actions from 'types/trip.type';
import _ from 'lodash';

export const initialState = {
  message: null,
  isRequested: false,
  limit: 10,
  result: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  currentTrip: [],
  incidentDetails: {
    result: [],
    totalPage: 0,
    totalRecord: 0,
    currentPage: 1,
    limit: 10
  },
  expenseDetails: {
    result: [],
    totalPage: 0,
    totalRecord: 0,
    currentPage: 1,
  },
  expenseDelDetails: {
    result: [],
    totalPage: 0,
    totalRecord: 0,
    currentPage: 1,
  },
  expenseDtlRequested: false,
  expenseDtlMessage: null,
  expenseDtlDelRequested: false,
  expenseDtlDelMessage: null,
  incidentRequested: false,
  incidentMessage: null,
  customerRequested: false,
  customerMessage: null,
  options: {
    legBehaviours: [],
    dispatchDocno: [],
    idType: [],
    stdEvents: [],
    relationType: [],
    expenseType: [],
    incidentType: [],
    tripEvents: [],
    accidentType: [],
    legIds:[]
  }
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.TRIPLOG_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      };
    case actions.TRIPLOG_FETCH_SUCCESS:
      return {
        ...state,
        result: action.data.result,
        totalPage: action.data.totalPage,
        totalRecord: action.data.totalRecord,
        limit: action.limit,
        legBehaviours: action.data.legs,
        dispatchDocno: action.data.dd_nos,
        serialnoresult: action.data,
        legIds: action.data.leg_ids,
      };
    case actions.TRIPLOG_FETCH_FAILURE:
      return {
        ...state,
        message: action.message
      };
    case actions.TRIPLOG_SEARCH_SUCCESS:
      return {
        ...state,
        options: action.data
      };

    case actions.TRIPLOG_SERIAL_NO_SUCCESS:
      return {
        ...state,
        serialnoresult: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
      }
    case actions.TRIPLOG_SERIAL_NO_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIPLOG_SERIAL_NO_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        serialnoresult: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1,
      }
    case actions.TRIPLOG_SERIAL_NO_FAILURE:
      return {
        ...state,
        message: action.message,
      }

    case actions.TRIPLOG_EXPENSE_DETAILS_SUCCESS:
      return {
        ...state,
        expenseDetails: action.expenseDetails
      }
    case actions.TRIPLOG_EXPENSE_DETAILS_REQUEST:
      return {
        ...state,
        expenseDtlRequested: action.expenseDtlRequested
      }
    case actions.TRIPLOG_EXPENSE_DETAILS_FAILURE:
      return {
        ...state,
        expenseDtlMessage: action.expenseDtlMessage,
      }

    case actions.TRIPLOG_POST_SUCCESS:
      return {
        ...state,
        result: action.result,
      }
    case actions.TRIPLOG_POST_REQUEST:
      return {

        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIPLOG_POST_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.TRIPLOG_POST_RESET:
      return {
        ...state,
        result: []
      }
    case actions.TRIPLOG_REMOVEBR_SUCCESS:
      return {
        ...state,
        currentTrip: action.data,
        legBehaviours: action.data.legs,
        dispatchDocno: action.data.dd_nos,
        result: action.data.result,
        legIds: action.data.leg_ids,
      }
    case actions.TRIPLOG_REMOVEBR_REQUEST:
      return {

        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIPLOG_REMOVEBR_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.TRIPLOG_EXPENSE_DEL_DETAILS_SUCCESS:
      return {
        ...state,
        result: action.result,
      }
    case actions.TRIPLOG_EXPENSE_DEL_DETAILS_REQUEST:
      return {
        ...state,
        expenseDtlDelRequested: action.expenseDtlDelRequested
      }
    case actions.TRIPLOG_EXPENSE_DEL_DETAILS_FAILURE:
      return {
        ...state,
        expenseDtlDelMessage: action.expenseDtlDelMessage,
      }
    case actions.TRIPLOG_REJECT_SUCCESS:
      return {
        ...state,
        currentTrip: action.data,
        legBehaviours: action.data.legs,
        dispatchDocno: action.data.dd_nos,
        result: action.data.result,
        legIds: action.data.leg_ids,
      }
    case actions.TRIPLOG_REJECT_REQUEST:
      return {

        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIPLOG_REJECT_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.TRIPLOG_ACTIONS_SUCCESS:
      return {
        ...state,
        currentTrip: action.data,
        legBehaviours: action.data.legs,
        dispatchDocno: action.data.dd_nos,
        result: action.data.result,
        legIds: action.data.leg_ids,
      }
    case actions.TRIPLOG_ACTIONS_REQUEST:
      return {

        ...state,
        isRequested: action.isRequested
      }
    case actions.TRIPLOG_ACTIONS_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.TRIPLOG_INCIDENT_SUCCESS:
      return {
        ...state,
        incidentDetails: action.incidentDetails

      }
    case actions.TRIPLOG_INCIDENT_REQUEST:
      return {
        ...state,
        incidentRequested: action.incidentRequested

      }
    case actions.TRIPLOG_INCIDENT_FAILURE:
      return {
        ...state,
        incidentMessage: action.incidentMessage,
      }
    case actions.TRIPLOG_INITIALIZE:
      return {
        ...state,
        ..._.cloneDeep(initialState),
      }
    default:
      return state
  }
}