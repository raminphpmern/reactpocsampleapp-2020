import * as actions from 'types/shipmentGuide.type';

export const initialState = {
  options: {
    profileIds: [],
    validationDocument: [],
    validationStage: [],
    status: [],
  },
  message: null,
  isRequested: false,
  result: [],
  profileResult: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  limit: 10,
  totalPageLink: 0,
  totalRecordLink: 0,
  currentPageLink: 1,
  shipmentResult: [],
  lastPage: 0,
  isSuccess: false,
  geoType: [],
  dph_description: null,
  dph_profile_id: null,
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.PROFILE_SUCCESS:
      return {
        ...state,
        profileResult: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
      }
    case actions.PROFILE_FAILURE:
      return {
        ...state,
        message: action.message,
      }

    case actions.PROFILE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.PROFILE_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        profileResult: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1
      }
    case actions.SHIPMENT_DETAILS_SUCCESS:
      return {
        ...state,
        shipmentResult: action.data,
        totalPageLink: action.totalPage,
        totalRecordLink: action.totalRecord,
        limit: action.limit,
        dph_description: action.dph_description,
        dph_profile_id: action.dph_profile_id,
      }
    case actions.SHIPMENT_DETAILS_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.SHIPMENT_DETAILS_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        shipmentResult: [],
        totalPageLink: 0,
        totalRecordLink: 0,
        currentPageLink: 1,
      }
    case actions.SHIPMENT_DETAILS_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.OPTIONS_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
        lastPage: 0
      };
    case actions.OPTIONS_FETCH_SUCCESS:
      return {
        ...state,
        options: action.data,
        isSuccess: true
      };
    case actions.OPTIONS_FETCH_FAILURE:
      return {
        ...state,
        isSuccess: false
      };
    case actions.PROFILE_GEOTYPE_SUCCESS:
      return {
        ...state,
        geoType: action.data
      }
    case actions.PROFILE_DROPDOWN_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.PROFILE_DROPDOWN_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    default:
      return state;
  }
}