import { combineReducers } from "redux";
import { pendingTasksReducer as pendingTasks } from 'react-redux-spinner';
import { reducer as formReducer } from "redux-form";
import loginReducer from "./loginReducer";
import masterReducer from "./masterReducer";
import shipperReducer from "./shipperReducer";
import consigneeReducer from "./consigneeReducer";
import bookingReducer from "./bookingReducer";
import brhubReducer from "./brhubReducer";
import csReducer from './csReducer';
import inventoryHubReducer from './inventoryHubReducer'
import searchTemplateReducer from './searchTemplateReducer';
import dispatchReducer from './dispatchReducer';
import hubReceiptLoadReducer from './hubReceiptLoadReducer';
import triphubReducer from './triphubReducer';
import tripplanReducer from './tripplanReducer';
import bayTransferReducer from './bayTransferReducer';
import thuInventoryReducer from './thuInventoryReducer';
import freightConversionReducer from './freightConversionReducer';
import loadTHUReducer from './loadTHUReducer';
import tripAttachmentsReducer from './tripAttachmentsReducer';
import customerDocumentReducer from './customerDocumentReducer';
import documentTrackerReducer from './documentTrackerReducer';
import shipmentGuideReducer from './shipmentGuideReducer';
import updateResourceReducer from './updateResourceReducer';

const appReducers = combineReducers({
  form: formReducer,
  pendingTasks,
  loginReducer,
  masterReducer,
  shipperReducer,
  consigneeReducer,
  bookingReducer,
  brhubReducer,
  csReducer,
  inventoryHubReducer,
  searchTemplateReducer,
  dispatchReducer,
  hubReceiptLoadReducer,
  triphubReducer,
  tripplanReducer,
  bayTransferReducer,
  thuInventoryReducer,
  freightConversionReducer,
  loadTHUReducer,
  tripAttachmentsReducer,
  customerDocumentReducer,
  documentTrackerReducer,
  shipmentGuideReducer,
  updateResourceReducer  
});

export default appReducers;
