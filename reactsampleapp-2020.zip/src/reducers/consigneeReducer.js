import * as actions from 'types/consignee.type';

export const initialState = {
  consignee: [],
  message: null,
  isLoading: false,
  isSuccess: false,
  currentConsignee: null,
  consigneeResult: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  isRequested: false,
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.CREATE_CONSIGNEE_INITIALIZE:
      return {
        ...state,
        ...initialState
      }
    case actions.CREATE_CONSIGNEE_SUCCESS:
      return {
        ...state,
        currentConsignee: action.consignee,
        isSuccess: true
      }
    case actions.CREATE_CONSIGNEE_REQUEST:
      return {
        ...state,
        isLoading: action.isLoading
      }
    case actions.CREATE_CONSIGNEE_FAILURE:
      return {
        ...state,
        message: action.message,
        isSuccess: false
      }
    case actions.CONSIGNEE_SUCCESS:
      return {
        ...state,
        consigneeResult: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord
      }
    case actions.CONSIGNEE_FAILURE:
      return {
        ...state,
        message: action.message,
      }

    case actions.CONSIGNEE_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.CONSIGNEE_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        consigneeResult: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1
      }
    default:
      return state;
  }
}