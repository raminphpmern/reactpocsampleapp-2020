import * as actions from 'types/customerDocument.type';

export const initialState = {
  message: null,
  isRequested: false,
  limit: 10,
  result: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.CUSTOMER_DOCUMENT_SUCCESS:
      return {
        ...state,
        result: action.result,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
        limit: action.limit,
      }
    case actions.CUSTOMER_DOCUMENT_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.CUSTOMER_DOCUMENT_INITIALIZE:
      return {
        ...state,
        result: [],
        totalPage: 0,
        totalRecord: 0,
        currentPage: 1,
        isRequested: false,
        message: null,
      }
    case actions.CUTOMER_DOCUMENT_FAILURE:
      return {
        ...state,
        customerMessage: action.customerMessage,
      }
    default:
      return state
  }
}