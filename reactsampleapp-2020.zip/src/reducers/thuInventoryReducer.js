import * as actions from 'types/thuInventory.type';
import _ from 'lodash'

export const initialState = {
  message: null,
  isRequested: false,
  status: [],
  availabilityStatus: [],
  result: [],
  updateResult: [],
  allocationLevel: [],
  validSerialNumber: true,
  serialNumber: false,
  total: 0,
  available: 0,
  allocated: 0,
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  limit: 10,
  serialNumberResult: [],
  serialNumbertotalPage: 0,
  serialNumbertotalRecord: 0,
  serialNumberlimit: 10
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.THUINVENTORY_SEARCH_SUCCESS:
      return {
        ...state,
        result: action.data,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord,
        limit: action.limit,
        available: action.filterType === 'available' ? action.totalRecord : state.available,
        allocated: action.filterType === 'allocated' ? action.totalRecord : state.allocated,
        total: _.includes(['total', undefined], action.filterType) ? action.totalRecord : state.total,
      }
    case actions.THUINVENTORY_SEARCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.THUINVENTORY_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        result: [],
        totalPage: 0,
        totalRecord: 0,
        total: 0,
        available: 0,
        allocated: 0,
        currentPage: 1
      }
    case actions.THUINVENTORY_SEARCH_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.THUINVENTORY_STATUS_SUCCESS:
      return {
        ...state,
        status: action.data
      }
    case actions.THUINVENTORY_AVAILABILITY_SUCCESS:
      return {
        ...state,
        availabilityStatus: action.data
      }
    case actions.THUINVENTORY_ALLOCATION_SUCCESS:
      return {
        ...state,
        allocationLevel: action.data
      }
    case actions.SERIALNUMBER_IS_VALID:
      return {
        ...state,
        validSerialNumber: action.isValid,
        serialNumber: action.isValid
      }
    case actions.THUINVENTORY_DROPDOWN_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.THUINVENTORY_DROPDOWN_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
        allocationLevel: []
      }
    case actions.THUINVENTORY_SEARCH_SERIALNUMBER_SUCCESS:
      return {
        ...state,
        serialNumberResult: action.data,
        serialNumbertotalPage: action.totalPage,
        serialNumbertotalRecord: action.totalRecord,
        serialNumberlimit: action.limit,
      }
    case actions.THUINVENTORY_SERIALNUMBER_INITIALIZE:
      return {
        ...state,
        serialNumberResult: [],
        serialNumbertotalPage: 0,
        serialNumbertotalRecord: 0
      }
    default:
      return state;
  }
}