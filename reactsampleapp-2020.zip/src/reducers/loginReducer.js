import {
  LOGIN_FAILURE,
  LOGIN_SUCCESS,
  LOGIN_REQUEST,
  LOGIN_INITIALIZE,
  LOGOUT,
  ONLINE_STATUS,
  LOGIN_SELECTED_BRANCH_TYPE
} from 'types/login.type'

const initialState = {
  user: null,
  message: null,
  online: null,
  branchType: null
}

export default function (state = initialState, action) {
  switch (action.type) {
    case LOGIN_SUCCESS:
      return {
        ...state,
        user: action.user,
        message: null
      }
    case LOGIN_INITIALIZE:
      return {
        ...state,
        user: null,
        message: null
      }
    case LOGIN_REQUEST:
      return {
        ...state,
        message: null
      }
    case LOGIN_FAILURE:
      return {
        ...state,
        message: action.message
      }
    case LOGOUT:
      return {
        ...state,
        user: null,
        message: null
      }
    case ONLINE_STATUS:
      return {
        ...state,
        online: action.online
      }
    case LOGIN_SELECTED_BRANCH_TYPE:
      return {
        ...state,
        branchType: action.branchType
      }
    default:
      return state;
  }
}
