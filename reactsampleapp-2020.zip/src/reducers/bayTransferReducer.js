import * as actions from 'types/bayTransfer.type';

export const initialState = {
  options: {
    employee: [],
    mhe: [],
    stageid: [],
    defaultuser: []
  },
  message: null,
  isRequested: false,
  isSuccess: false,
  result: [],
  saveRecords: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  lastPage: 0,
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.DISPATCH_DOCUMENT_SCAN_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.DISPATCH_DOCUMENT_SCAN_SUCCESS:
      return {
        ...state,
        result: action.result,
        totalPage: action.totalPage,
        totalRecord: action.totalRecord
      }
    case actions.SAVE_BAY_TRANSFER_SUCCESS:
      return {
        ...state,
        saveRecords: action.result[0],
      }
    case actions.CONFIRM_BAY_TRANSFER_SUCCESS:
      return {
        ...state,
        saveRecords: action.result[0],
      }
    case actions.DISPATCH_DOCUMENT_SCAN_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.OPTIONS_FETCH_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested,
        lastPage: 0
      };
    case actions.OPTIONS_FETCH_SUCCESS:
      return {
        ...state,
        options: action.data,
        isSuccess: true
      };
    case actions.OPTIONS_FETCH_FAILURE:
      return {
        ...state,
        isSuccess: false
      };
    case actions.RESET_BAY_TRANSFER_RECORDS:
      return {
        ...state,
        result: [],
        defaultuser: []
      }
    default:
      return state;
  }
}