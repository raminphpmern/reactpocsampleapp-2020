import * as actions from 'types/documentTracker.type';
import _ from 'lodash';

export const initialState = {
  message: null,
  isRequested: false,
  limit: 10,
  result: [],
  totalPage: 0,
  totalRecord: 0,
  currentPage: 1,
  selectedRows: [],
}

export default function (state = initialState, action) {
  switch (action.type) {
    case actions.DOCUMENT_TRACKER_SUCCESS:
      return {
        ...state,
        result: action.data,
        totalPageLink: action.totalPage,
        totalRecordLink: action.totalRecord,
        linkLimit: action.limit,
        selectedRows: action.selectedRows,
      }
    case actions.DOCUMENT_TRACKER_REQUEST:
      return {
        ...state,
        isRequested: action.isRequested
      }
    case actions.DOCUMENT_TRACKER_INITIALIZE:
      return {
        ...state,
        message: null,
        isRequested: false,
        result: [],
        totalPageLink: 0,
        totalRecordLink: 0,
        currentPageLink: 1,
      }
    case actions.DOCUMENT_TRACKER_FAILURE:
      return {
        ...state,
        message: action.message,
      }
    case actions.DOCUMENT_TRACKER_SAVE_REQUEST:
      return {
        ...state,
        isSaveRequested: action.isSaveRequested,
      };
    case actions.DOCUMENT_TRACKER_SAVE_SUCCESS:
      return {
        ...state,
        message: action.message,
        result: action.data,
        selectedRows: [],
      }
    case actions.DOCUMENT_TRACKER_SAVE_FAILURE:
      return {
        ...state,
        message: action.message
      }
    default:
      return state
  }
}