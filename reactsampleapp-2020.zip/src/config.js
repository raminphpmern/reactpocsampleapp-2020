export const DIVISION = {
  corporate: "corporate",
  retail: "retail"
}

export const SEARCH_WORD_COUNT = 3;

const screenWidth = window.innerWidth;
export const isMobile = screenWidth < 740;

export const commonDateFormat = 'MMM-dd-yyyy';
export const commonDateTimeFormat = 'MMM-dd-yyyy, h:mm aa';
export const commonDateDisplayFormat = 'MMM-DD-YYYY'


export const SERVICE_TYPES = ['Order Padala - Island Rose', 'Order Padala - PSA']