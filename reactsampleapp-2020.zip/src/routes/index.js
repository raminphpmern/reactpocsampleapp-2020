import React, { Component } from "react";
import { Router, Route, Switch, Redirect } from "react-router-dom";
import history from "./history";
import PrivateLayout from "./PrivateLayout";
import LoginLayout from "./LoginLayout";
import Login from "components/Login";
import LandingPage from "components/LandingPage";
import CreatePassword from "components/Login/CreatePassword";
import Password from "components/Login/Password";
import Acceptence from "components/Qbr/Acceptence";
import Utilities from "components/Utilities";
import BrHub from "components/BrHub";
import CollectionSummary from 'components/CollectionSummary';
import InventoryHub from 'components/InventoryHub';
import BrHubNew from 'components/BrHub-New';
import BrHubNewOne from 'components/BrHub-New/One';
import BrHubNewTwo from 'components/BrHub-New/Two';
import TripPlan from 'components/TripPlan';
import TripHub from 'components/TripHub';
import DispatchSearch from 'components/Dispatch/DispatchSearch';
import DispatchCreateForm from "components/Dispatch/DispatchCreate";
import DispatchViewForm from "components/Dispatch/DispatchView";
import HubLoadingForm from "components/HubLoadAndReceipt/Loading";
import HubReceiptForm from "components/HubLoadAndReceipt/Receipt";
import BayTransfer from "components/BayTransfer";
import FreightConversion from "components/FreightConversion/Search";
import ConsolidationDeConsolidation from "components/FreightConversion/FcConsDecons";
import LoadThu from 'components/LoadTHU';
import ThuInventory from "components/ThuInventory";
import AllocateTHU from "components/ThuInventory/AllocateTHU"

export default class Routes extends Component {
  render() {
    return (
      <Router history={history}>
        <Switch>
          <LoginLayout exact path="/login" component={Login} />
          <LoginLayout
            exact
            path="/create-password"
            component={CreatePassword}
          />
          <LoginLayout exact path="/password" component={Password} />
          <PrivateLayout exact path="/" component={LandingPage} />
          <PrivateLayout exact path="/utilities" component={Utilities} />
          <PrivateLayout exact path="/acceptance" component={Acceptence} />
          <PrivateLayout exact path="/brhub-new" component={BrHubNew} />
          <PrivateLayout exact path="/brhub-new-1" component={BrHubNewOne} />
          <PrivateLayout exact path="/brhub" component={BrHubNewTwo} />
          <PrivateLayout exact path="/acceptance/:brId" component={Acceptence} />
          <PrivateLayout exact path="/collections" component={CollectionSummary} />
          <PrivateLayout exact path="/inventoryHub" component={InventoryHub} />
          <PrivateLayout exact path="/tripHub" component={TripHub} />
          <PrivateLayout exact path="/tripLog/:trId" component={TripPlan} />
          <PrivateLayout exact path="/tripLog" component={TripPlan} />
          <PrivateLayout exact path="/dispatchDocument/hub" component={DispatchSearch} />
          <PrivateLayout exact path="/dispatchDocument/create" component={DispatchCreateForm} />
          <PrivateLayout exact path="/dispatchDocument/create/:ddId" component={DispatchCreateForm} />
          <PrivateLayout exact path="/dispatchDocument/view/:ddId" component={DispatchViewForm} />
          <PrivateLayout exact path="/hub/loading" component={HubLoadingForm} />
          <PrivateLayout exact path="/hub/receipt" component={HubReceiptForm} />
          <PrivateLayout exact path="/hub/bayTransfer" component={BayTransfer} />
          <PrivateLayout exact path="/hub/freightConversion" component={FreightConversion} />
          <PrivateLayout exact path="/hub/freightConversion/consDecons" component={ConsolidationDeConsolidation} />
          <PrivateLayout exact path="/hub/freightConversion/:fcNo" component={ConsolidationDeConsolidation} />
          <PrivateLayout exact path="/loadThu" component={LoadThu} />
          <PrivateLayout exact path="/thuInventory" component={ThuInventory} />
          <PrivateLayout exact path="/thuInventory/allocateTHU" component={AllocateTHU} />
          <PrivateLayout exact path="/thuInventory/allocateTHU" component={AllocateTHU} />
          <Route path="" render={() => <Redirect to="/login" />} />
        </Switch>
      </Router>
    );
  }
}
