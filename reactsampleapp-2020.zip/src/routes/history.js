import { createBrowserHistory } from 'history'
export default new createBrowserHistory()