import React from 'react'
import { Route } from 'react-router-dom'
import Header from 'components/Login/Header'
import Footer from 'components/Login/Footer'

const Layout = ({ children, ...rest }) => {
  return (
    <div>
      <Header />
      {children}
      <Footer />
    </div>
  )
}

/*
  Route wrapper
 */

const LoginLayout = ({ component: Component, ...rest }) => {
  return (
    <Route {...rest} render={matchProps => (
      <Layout>
        <Component {...matchProps} />
      </Layout>
    )} />
  )
};

export default LoginLayout