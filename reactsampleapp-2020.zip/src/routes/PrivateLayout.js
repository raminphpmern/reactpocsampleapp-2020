import React from 'react'
import { Redirect, Route } from 'react-router-dom'
import { getValue } from 'lib/LocalStorage'

const Layout = ({ children, ...rest }) => {
  return (
    <div>
      {children}
    </div>
  )
}

const PrivateLayout = ({ component: Component, ...rest }) => {
  let loggedIn = false;

  if (getValue('user')) {
    const user = JSON.parse(getValue('user'))
    if (user.loggedIn) {
      loggedIn = true
    }
  }

  return (
    <Route
      {...rest}
      render={props =>
        loggedIn ? (
          <Layout>
            <Component {...props} />
          </Layout>
        ) : (
            <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
          )
      }
    />
  )
}

export default PrivateLayout
