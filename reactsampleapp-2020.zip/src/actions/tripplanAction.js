import Api from "lib/api";
import * as actions from "types/trip.type";
import { pendingTask, begin, end } from 'react-redux-spinner'
import _ from 'lodash'
import { AlertSuccess, AlertError } from 'lib/Alert'

export const getTripLogs = (data, pageNo, limit) => {
  return (dispatch, getState) => {
    const { tripplanReducer } = getState();
    const options = tripplanReducer.options;
    dispatch(tripRequest(true));
    return Api.post(`/tripLogs?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          const hash = {
            legBehaviours: response.legs,
            dispatchDocno: response.dd_nos,
            legIds :response.leg_ids
          }
          dispatch(tripSuccess({ result: [], totalPage: response.totalPage }, limit));
          dispatch(fetchSuccess(hash, options));
          dispatch(tripSuccess(response, limit));
          AlertSuccess(response.message)
        } else {
          dispatch(tripFailure(response.message));
          AlertError(response.message)
        }
        dispatch(tripRequest(false));
      })
      .catch(err => {
        console.log("TripPlanId -- search ", err);
        dispatch(tripFailure(err));
        dispatch(tripRequest(false));
      });
  };
};

const tripRequest = isRequested => {
  return {
    type: actions.TRIPLOG_FETCH_REQUEST,
    [pendingTask]: isRequested ? begin : end,
    isRequested
  };
};

const tripSuccess = (data, limit) => {
  return {
    type: actions.TRIPLOG_FETCH_SUCCESS,
    data,
    limit
  };
};

const tripFailure = msg => {
  return {
    type: actions.TRIPLOG_FETCH_FAILURE,
    msg
  };
};

const search = (action, queryString, stateName) => {
  return (dispatch, getState) => {
    const { tripplanReducer } = getState();
    const options = tripplanReducer.options;
    dispatch(fetchRequest(true));
    return Api.get(`/search/${action}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.result;
          } else {
            responseData[action] = response.result;
          }
          dispatch(fetchSuccess(responseData, options));
        } else {
          dispatch(fetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const fetchRequest = isLoading => {
  return {
    type: actions.TRIPLOG_SEARCH_REQUEST,
    isLoading
  };
};

export const fetchSuccess = (data, existingState) => {
  _.map(data, (value, key) => {
    existingState[key] = value;
  });

  data = existingState;
  return {
    type: actions.TRIPLOG_SEARCH_SUCCESS,
    data: data
  };
};

export const fetchFailure = err => {
  return {
    type: actions.TRIPLOG_SEARCH_REQUEST,
    err
  };
};

export const getSerialNumbers = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(serialNoRequest(true))
    return Api.get(`/tripLogs/serialNumbers?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(initializeSN())
          dispatch(serialNoSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(serialNoFailure(response.message))
          AlertError(response.message)
        }
        dispatch(serialNoRequest(false))
      }).catch((err) => {
        dispatch(serialNoRequest(false))
        dispatch(serialNoFailure(err))
      })
  }
}

export const initializeSN = () => {
  return dispatch => {
    dispatch(initializeSerialNo())
  }
}

const initializeSerialNo = () => {
  return {
    type: actions.TRIPLOG_SERIAL_NO_INITIALIZE
  }
}
const serialNoRequest = (isRequested) => {
  return {
    type: actions.TRIPLOG_SERIAL_NO_REQUEST,
    isRequested
  }
}

const serialNoSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.TRIPLOG_SERIAL_NO_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const serialNoFailure = (message) => {
  return {
    type: actions.TRIPLOG_SERIAL_NO_FAILURE,
    message
  }
}


export const fetchExpenseDetails = (tripId, pageNo, limit) => {
  return (dispatch) => {
    dispatch(expenseDtlRequest(true))
    return Api.get(`/tripLogs/expenseDetails/${encodeURIComponent(tripId)}?pageNo=${pageNo}&limit=${limit}`)
      .then(response => response.json())
      .then(response => {
        const message = response.message
        if (response.status === 200) {
          delete response['status']
          delete response['message']
          dispatch(expenseDtlSuccess(response))
          // AlertSuccess(message)
        } else {
          dispatch(expenseDtlFailure(message))
          AlertError(response.message)
        }
        dispatch(expenseDtlRequest(false))
      }).catch((err) => {
        dispatch(expenseDtlRequest(false))
        dispatch(expenseDtlFailure(err))
      })
  }
}

const expenseDtlRequest = (expenseDtlRequested) => {
  return {
    type: actions.TRIPLOG_EXPENSE_DETAILS_REQUEST,
    expenseDtlRequested
  }
}

const expenseDtlSuccess = (expenseDetails) => {
  return {
    type: actions.TRIPLOG_EXPENSE_DETAILS_SUCCESS,
    expenseDetails
  }
}

const expenseDtlFailure = (expenseDtlMessage) => {
  return {
    type: actions.TRIPLOG_EXPENSE_DETAILS_FAILURE,
    expenseDtlMessage
  }
}

export const getLegBehaviours = search;
export const getdispatchDocno = search;
export const getidType = search;
export const getstdEvents = search;
export const getrelationType = search;
export const getOptions = search;
export const getlegIds = search;

export const tripPost = (data, pageNo, limit) => {
  return (dispatch, getState) => {
    dispatch(trippostRequest(true));
    return Api.post(`/tripLogs/post?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          const message = response.message
          if (data.activeTab === 0 || data.activeTab === 1) {
            dispatch(tripSuccess({ result: [] }));
            dispatch(trippostSuccess([]));
            dispatch(trippostSuccess(response.result));
          } else {
            delete response['status']
            delete response['message']
            if (data.activeTab === 2) {
              dispatch(expenseDtlSuccess(response))
            }
            if (data.activeTab === 3) {
              dispatch(incidentDtlSuccess(response))
            }
          }
          AlertSuccess(message)
        } else {
          dispatch(trippostFailure(response.message));
          AlertError(response.message)
        }
        dispatch(trippostRequest(false));
      })
      .catch(err => {
        console.log("TripPlan -- search ", err);
        dispatch(trippostFailure(err));
        dispatch(trippostRequest(false));
      });
  };
};

const trippostRequest = isRequested => {
  return {
    type: actions.TRIPLOG_POST_REQUEST,
    isRequested
  };
};

const trippostSuccess = (result) => {
  return {
    type: actions.TRIPLOG_POST_SUCCESS,
    result,
  };
};

const trippostFailure = msg => {
  return {
    type: actions.TRIPLOG_POST_FAILURE,
    msg
  };
};

export const updateTripActual_date = (data) => {
  return {
    type: actions.TRIPLOG_POST_SUCCESS,
    data
  }
}

export const gettripRemovebr = (data, pageNo, limit) => {
  return (dispatch) => {
    return Api.post(`/tripLogs/tripRemovebr?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(tripSuccess(response, limit));
          dispatch(tripremovebrSuccess(response, limit));
          AlertSuccess(response.message)
        } else {
          dispatch(tripremovebrFailure(response.message));
          AlertError(response.message)
        }
        dispatch(tripremovebrRequest(false));
      })
      .catch(err => {
        console.log("TripPlan -- search ", err);
        dispatch(tripremovebrFailure(err));
        dispatch(tripremovebrRequest(false));
      });
  };
};

const tripremovebrRequest = isRequested => {
  return {
    type: actions.TRIPLOG_REMOVEBR_REQUEST,
    isRequested
  };
};

const tripremovebrSuccess = (data, limit) => {
  return {
    type: actions.TRIPLOG_REMOVEBR_SUCCESS,
    data,
    limit
  };
};

const tripremovebrFailure = msg => {
  return {
    type: actions.TRIPLOG_REMOVEBR_FAILURE,
    msg
  };
};

export const deleteExpAndIncidentDtl = (action, tripId, data, pageNo, limit) => {
  return (dispatch) => {
    dispatch(expenseDtlDelRequest(true))
    return Api.post(`/tripLogs/${action}/${encodeURIComponent(tripId)}?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        const message = response.message
        if (response.status === 200) {
          if (data.tabIndex === 2) {
            dispatch(expenseDtlSuccess(response))
          }
          else {
            dispatch(incidentDtlSuccess(response))
          }
          AlertSuccess(message)
        } else {
          dispatch(expenseDtlDelFailure(message))
          AlertError(response.message)
        }
        dispatch(expenseDtlDelRequest(false))
      }).catch((err) => {
        dispatch(expenseDtlDelRequest(false))
        dispatch(expenseDtlDelFailure(err))
      })
  }
}
const expenseDtlDelRequest = (expenseDtlDelRequest) => {
  return {
    type: actions.TRIPLOG_EXPENSE_DEL_DETAILS_REQUEST,
    expenseDtlDelRequest
  }
}

const expenseDtlDelFailure = (expenseDtlDelMessage) => {
  return {
    type: actions.TRIPLOG_EXPENSE_DEL_DETAILS_FAILURE,
    expenseDtlDelMessage
  }
}
export const tripReject = (data, pageNo, limit) => {
  return (dispatch) => {
    return Api.post(`/tripLogs/tripReject?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(tripSuccess(response, limit));
          AlertError(response.message)
        } else {
          dispatch(triprejectFailure(response.message))
          AlertError(response.message)
        }
        dispatch(triprejectRequest(false));
      })
      .catch(err => {
        dispatch(triprejectRequest(false))
        dispatch(triprejectFailure(err))
        console.log("TripPlan -- search ", err);
      });
  };
};

const triprejectRequest = isRequested => {
  return {
    type: actions.TRIPLOG_REJECT_REQUEST,
    isRequested
  };
};

const triprejectFailure = msg => {
  return {
    type: actions.TRIPLOG_REJECT_FAILURE,
    msg
  };
};

export const tripButtonActions = (action, data, pageNo, limit) => {
  return (dispatch) => {
    return Api.post(`/tripLogs/${action}?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(tripSuccess(response, limit));
          dispatch(tripactionsSuccess(response, limit));
          AlertSuccess(response.message)
        } else {
          dispatch(tripactionsFailure(response.message));
          AlertError(response.message)
        }
        dispatch(tripactionsRequest(false));
      })
      .catch(err => {
        console.log("TripPlan -- search ", err);
        dispatch(tripactionsFailure(err));
        dispatch(tripactionsRequest(false));
      });
  };
};

const tripactionsRequest = isRequested => {
  return {
    type: actions.TRIPLOG_ACTIONS_REQUEST,
    isRequested
  };
};

const tripactionsSuccess = (data, limit) => {
  return {
    type: actions.TRIPLOG_ACTIONS_SUCCESS,
    data,
    limit
  };
};

const tripactionsFailure = msg => {
  return {
    type: actions.TRIPLOG_ACTIONS_FAILURE,
    msg
  };
};

export const getIncidentDetails = (tripId, pageNo, limit) => {
  return (dispatch) => {
    dispatch(incidentDtlRequest(true))
    return Api.get(`/tripLogs/getIncidentDetails/${encodeURIComponent(tripId)}?pageNo=${pageNo}&limit=${limit}`)
      .then(response => response.json())
      .then(response => {
        const message = response.message
        if (response.status === 200) {
          dispatch(incidentDtlSuccess({ result: [], totalPage: response.totalPage }, limit));
          dispatch(incidentDtlSuccess(response, limit))
          // AlertSuccess(message)
        } else {
          dispatch(incidentDtlFailure(message))
          AlertError(response.message)
        }
        dispatch(incidentDtlRequest(false))
      }).catch((err) => {
        dispatch(incidentDtlRequest(false))
        dispatch(incidentDtlFailure(err))
      })
  }
}

const incidentDtlRequest = (incidentDtlRequested) => {
  return {
    type: actions.TRIPLOG_INCIDENT_REQUEST,
    incidentDtlRequested
  }
}

const incidentDtlSuccess = (incidentDetails, limit) => {
  return {
    type: actions.TRIPLOG_INCIDENT_SUCCESS,
    incidentDetails,
    limit
  }
}

const incidentDtlFailure = (incidentDtlMessage) => {
  return {
    type: actions.TRIPLOG_INCIDENT_FAILURE,
    incidentDtlMessage
  }
}

export const initializeTripLogs = () => {
  return dispatch => {
    dispatch(initialize())
  }
}

const initialize = () => {
  return {
    type: actions.TRIPLOG_INITIALIZE
  }
}

