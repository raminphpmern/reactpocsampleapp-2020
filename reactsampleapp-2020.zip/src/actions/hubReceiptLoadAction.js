import Api from "lib/api";
import * as actions from "types/hubreceiptload.type"
import { AlertSuccess, AlertError } from 'lib/Alert'
import _ from 'lodash';
import i18n from 'i18n';

export const getTripDataReceipt = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(TripDataRequest(true));
    return Api.post(`/hub/tripPlanReceipt/search?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(TripDataSuccess(response.result, response.totalPage, response.totalRecord));
          AlertSuccess(response.message)
        } else {
          dispatch(TripDataFailure(response.message));
          AlertError(response.message)
        }
        dispatch(TripDataRequest(false));
      })
      .catch(err => {
        dispatch(TripDataFailure(err));
        dispatch(TripDataRequest(false));
      });
  };
};

export const saveReceiptRecords = (action, data) => {
  return dispatch => {
    dispatch(saveReceiptRecordsRequest(true));
    return Api.post(`/hub/tripPlanReceipt/${action}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (action === 'dispatch') {
            dispatch(saveDispatchDocumentRecords(response.result, response.result_cbm, response.totalPage, response.totalRecord))
            AlertSuccess(i18n.t("hubReceiptForm:scanSuccess"))
          } else {
            dispatch(saveReceiptRecordsSuccess(response.result[0]))
            AlertSuccess(response.message)
          }
        } else if (response.status !== 200) {
          if (action === 'dispatch') {
            dispatch(scanRecordsFailure(response.message, response.status))
            AlertSuccess(response.message)
          }
          else {
            dispatch(saveReceiptRecordsFailure(response.message, response.status))
            AlertError(response.message)
          }
        }
        dispatch(saveReceiptRecordsRequest(false))
      })
      .catch(err => {
        dispatch(saveReceiptRecordsFailure(err))
        dispatch(saveReceiptRecordsRequest(false))
      });
  };
};

const saveReceiptRecordsRequest = isRequested => {
  return {
    type: actions.RECEIPT_RECORDS_SAVE_REQUEST,
    isRequested
  }
}

const saveReceiptRecordsSuccess = (result, msg) => {
  return {
    type: actions.RECORDS_SAVE_SUCCESS,
    result,
    msg
  }
}

const scanRecordsFailure = (msg, status) => {
  return {
    type: actions.SCAN_RECORDS_SAVE_FAILURE,
    msg,
    status
  }
}

const saveReceiptRecordsFailure = (msg, status) => {
  return {
    type: actions.RECEIPT_RECORDS_SAVE_FAILURE,
    msg,
    status
  }
}

export const getTripDataLoading = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(TripDataRequest(true));
    return Api.post(`/hub/tripPlanLoad/search?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(TripDataSuccess(response.result, response.totalPage, response.totalRecord));
          AlertSuccess(response.message)
        } else {
          dispatch(TripDataFailure(response.message));
          AlertError(response.message)
        }
        dispatch(TripDataRequest(false));
      })
      .catch(err => {
        dispatch(TripDataFailure(err));
        dispatch(TripDataRequest(false));
      });
  };
};

const TripDataRequest = isRequested => {
  return {
    type: actions.TRIP_LOG_DATA_FETCH_REQUEST,
    isRequested
  }
}

const TripDataSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.TRIP_LOG_DATA_FETCH_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const TripDataFailure = msg => {
  return {
    type: actions.TRIP_LOG_DATA_FETCH_FAILURE,
    msg
  }
}

export const resetTripDataRecords = () => {
  return {
    type: actions.RESET_TRIP_LOG_DATA_RECORDS,
  }
}

export const resetSerialRecords = () => {
  return {
    type: actions.RESET_SERIAL_NUMBER_RECORDS,
  }
}

export const resetHeaderRecords = () => {
  return {
    type: actions.RESET_HEADER_RECORDS,
  }
}

export const saveLoadingRecords = (action, data, pageNo, limit) => {
  return (dispatch) => {
    dispatch(saveLoadingRecordsRequest(true));
    return Api.post(`/hub/tripPlanLoad/${action}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (action === 'dispatch') {
            dispatch(saveDispatchDocumentRecords(response.result, response.result_cbm, response.totalPage, response.totalRecord))
            AlertSuccess(i18n.t("hubLoadForm:scanSuccess"))
          }
          else if (action === 'cutoff') {
            return Api.post(`/hub/tripPlanLoad/search?pageNo=${pageNo}&limit=${limit}`, data)
              .then(response => response.json())
              .then(response => {
                dispatch(TripDataSuccess(response.result, response.totalPage, response.totalRecord));
                AlertSuccess(response.message)
              }
              )
          }
          else {
            dispatch(saveLoadingRecordsSuccess(response.result[0]));
            AlertSuccess(response.message)
          }
        } else if (response.status !== 200) {
          if (action === 'dispatch') {
            dispatch(saveLoadingRecordsFailure(response.message, response.status));
            AlertSuccess(response.message)
          }
          else {
            dispatch(saveLoadingRecordsFailure(response.message, response.status))
            AlertError(response.message)
          }
        }
        dispatch(saveLoadingRecordsRequest(false));
      })
      .catch(err => {
        dispatch(saveLoadingRecordsFailure(err));
        dispatch(saveLoadingRecordsRequest(false));
      });
  };
};

const saveLoadingRecordsRequest = isRequested => {
  return {
    type: actions.LOADING_RECORDS_SAVE_REQUEST,
    isRequested
  }
}

const saveLoadingRecordsSuccess = (result, msg) => {
  return {
    type: actions.RECORDS_SAVE_SUCCESS,
    result,
    msg
  }
}

export const saveDispatchDocumentRecords = (data, cbmData, totalPage, totalRecord) => {
  return {
    type: actions.LOADING_DISPATCH_DOCUMENT_RECORDS,
    data: data,
    cbmData: cbmData,
    totalPage,
    totalRecord
  };
};

const saveLoadingRecordsFailure = (msg, status) => {
  return {
    type: actions.LOADING_RECORDS_SAVE_FAILURE,
    msg,
    status
  }
}

export const updateReceiptRow = (row, updateKey) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer } = getState();
    const result = hubReceiptLoadReducer.result;
    const response = _.reduce(result, (arr, item) => {
      if (item.dispatch_doc_no === row.dispatch_doc_no) {
        _.merge(item, updateKey)
      }
      arr.push(item)
      return arr
    }, [])
    dispatch(TripDataSuccess(response, hubReceiptLoadReducer.totalPage, hubReceiptLoadReducer.totalRecord))
  }
}

export const updateLoadingRow = (row, updateKey) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer } = getState();
    const result = hubReceiptLoadReducer.result;
    const response = _.reduce(result, (arr, item) => {
      if (item.hmhid_ref_doc_no === row.hmhid_ref_doc_no) {
        _.merge(item, updateKey)
      }
      arr.push(item)
      return arr
    }, [])
    dispatch(TripDataSuccess(response, hubReceiptLoadReducer.totalPage, hubReceiptLoadReducer.totalRecord))
  }
}

export const getLoadingFieldDetails = (action, queryString, stateName) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer } = getState();
    const options = hubReceiptLoadReducer.options;
    dispatch(fetchRequest(true));
    return Api.get(`/hub/tripPlanLoad/${action}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.data;
          } else {
            responseData[action] = response.data;
          }
          dispatch(fetchSuccess(responseData, options, false));
        } else {
          dispatch(fetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const getReceiptFieldDetails = (action, queryString, stateName) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer } = getState();
    const options = hubReceiptLoadReducer.options;
    dispatch(fetchRequest(true));
    return Api.get(`/hub/tripPlanReceipt/${action}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.data;
          } else {
            responseData[action] = response.data;
          }
          dispatch(fetchSuccess(responseData, options, false));
        } else {
          dispatch(fetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const fetchRequest = isRequested => {
  return {
    type: actions.OPTIONS_FETCH_REQUEST,
    isRequested
  };
};

export const fetchSuccess = (data, existingState, isMerge) => {
  _.map(data, (value, key) => {
    existingState[key] = isMerge ? existingState[key].concat(value) : value;
  });

  data = existingState;
  return {
    type: actions.OPTIONS_FETCH_SUCCESS,
    data: data
  };
};

export const fetchFailure = err => {
  return {
    type: actions.OPTIONS_FETCH_FAILURE,
    err
  };
};

export const equipmentSearch = (values, pageNo, limit, isSearch) => {
  return dispatch => {
    dispatch(equipmentSearchRequest(true));
    return Api.post(`/hub/equipmentSearch?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initialize())
          }
          dispatch(equipmentSearchSuccess(response.result, response.totalPage, response.totalRecord, limit))
          AlertSuccess(response.message)
        } else {
          dispatch(equipmentSearchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(equipmentSearchRequest(false));
      })
      .catch(err => {
        console.log("help on equipment -- search ", err);
        dispatch(equipmentSearchFailure(err));
        dispatch(equipmentSearchRequest(false));
      });
  };
};


const equipmentSearchRequest = (isRequested) => {
  return {
    type: actions.HUB_EQUIPMENT_FETCH_REQUEST,
    isRequested
  }
}

const equipmentSearchSuccess = (data, totalPage, totalRecord, limit) => {
  return {
    type: actions.HUB_EQUIPMENT_FETCH_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit,
  }
}


const equipmentSearchFailure = (message) => {
  return {
    type: actions.HUB_EQUIPMENT_FETCH_FAILURE,
    message
  }
}

export const initialize = () => {
  return dispatch => {
    dispatch(initializeEquipmentData())
  }
}

const initializeEquipmentData = () => {
  return {
    type: actions.HUB_EQUIPMENT_INITIALIZE
  }
}

export const saveReceiptDtl = (params) => {
  return (dispatch, getState) => {
    let { hubReceiptLoadReducer: { receiptresult } } = getState()
    dispatch(receiptRequest(true))
    return Api.post(`/hub/vehicleSeal/saveReceiptDtl`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(receiptRequestSuccess('', []));
          _.each(response.result, (item) => {
            const recordIndex = _.findIndex(receiptresult, (row) => row.hmresd_seal_line_no === item.hmresd_seal_line_no)
            if (recordIndex >= 0) {
              receiptresult[recordIndex] = item
            } else {
              receiptresult.push(item)
            }
          })
          dispatch(receiptRequestSuccess(response.message, receiptresult));
          AlertSuccess(response.message)
        } else {
          dispatch(receiptRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(receiptRequest(false));
      })
      .catch(err => {
        dispatch(receiptRequestFailure(err));
        dispatch(receiptRequest(false));
      })
  }
}

const receiptRequest = isSaveRequested => {
  return {
    type: actions.RECEIPT_SEAL_RECORDS_SAVE_REQUEST,
    isSaveRequested
  }
}

const receiptRequestSuccess = (message, data) => {
  return {
    type: actions.RECEIPT_SEAL_RECORDS_SAVE_SUCCESS,
    message,
    data
  }
}

const receiptRequestFailure = message => {
  return {
    type: actions.RECEIPT_SEAL_RECORDS_SAVE_FAILURE,
    message
  }
}

export const fetchReceiptSeal = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(receiptDetailsRequest(true))
    return Api.get(`/hub/vehicleSeal/fetchReceiptSeal?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(receiptDetailsSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(receiptDetailsFailure(response.message))
          AlertError(response.message)
        }
        dispatch(receiptDetailsRequest(false))
      }).catch((err) => {
        dispatch(receiptDetailsRequest(false))
        dispatch(receiptDetailsFailure(err))
      })
  }
}

export const initializeRS = () => {
  return dispatch => {
    dispatch(initializeReceiptSealDetails())
  }
}

const initializeReceiptSealDetails = () => {
  return {
    type: actions.RECEIPT_SEAL_DETAILS_INITIALIZE
  }
}
const receiptDetailsRequest = (isRequested) => {
  return {
    type: actions.RECEIPT_SEAL_DETAILS_REQUEST,
    isRequested
  }
}

const receiptDetailsSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.RECEIPT_SEAL_DETAILS_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const receiptDetailsFailure = (message) => {
  return {
    type: actions.RECEIPT_SEAL_DETAILS_FAILURE,
    message
  }
}

export const saveLoadingDtl = (params) => {
  return (dispatch, getState) => {
    let { hubReceiptLoadReducer: { loadingresult } } = getState()
    dispatch(loadingRequest(true))
    return Api.post(`/hub/vehicleSeal/saveLoadingDtl`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(loadingRequestSuccess('', []));
          _.each(response.result, (item) => {
            const recordIndex = _.findIndex(loadingresult, (row) => row.hmlesd_seal_line_no === item.hmlesd_seal_line_no)
            if (recordIndex >= 0) {
              loadingresult[recordIndex] = item
            } else {
              loadingresult.push(item)
            }
          })
          dispatch(loadingRequestSuccess(response.message, loadingresult));
          AlertSuccess(response.message)
        } else {
          dispatch(loadingRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(loadingRequest(false));
      })
      .catch(err => {
        dispatch(loadingRequestFailure(err));
        dispatch(loadingRequest(false));
      })
  }
}

const loadingRequest = isSaveRequested => {
  return {
    type: actions.LOADING_SEAL_RECORDS_SAVE_REQUEST,
    isSaveRequested
  }
}

const loadingRequestSuccess = (message, data) => {
  return {
    type: actions.LOADING_SEAL_RECORDS_SAVE_SUCCESS,
    message,
    data
  }
}

const loadingRequestFailure = message => {
  return {
    type: actions.LOADING_SEAL_RECORDS_SAVE_FAILURE,
    message
  }
}

export const fetchLoadingSeal = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(loadingDetailsRequest(true))
    return Api.get(`/hub/vehicleSeal/fetchLoadingSeal?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(loadingDetailsSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(loadingDetailsFailure(response.message))
          AlertError(response.message)
        }
        dispatch(loadingDetailsRequest(false))
      }).catch((err) => {
        dispatch(loadingDetailsRequest(false))
        dispatch(loadingDetailsFailure(err))
      })
  }
}

export const initializeLS = () => {
  return dispatch => {
    dispatch(initializeLoadingSealDetails())
  }
}

const initializeLoadingSealDetails = () => {
  return {
    type: actions.LOADING_SEAL_DETAILS_INITIALIZE
  }
}
const loadingDetailsRequest = (isRequested) => {
  return {
    type: actions.LOADING_SEAL_DETAILS_REQUEST,
    isRequested
  }
}

const loadingDetailsSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.LOADING_SEAL_DETAILS_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const loadingDetailsFailure = (message) => {
  return {
    type: actions.LOADING_SEAL_DETAILS_FAILURE,
    message
  }
}

export const deleteReceiptSeal = (params) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer: { receiptresult } } = getState()
    dispatch(receiptRequest(true))
    return Api.delete(`/hub/vehicleSeal/deleteReceiptSeal?hmresd_seal_line_no=${params.hmresd_seal_line_no}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(receiptRequestSuccess('', []));
          const records = _.filter(receiptresult, (row) => !_.includes(params.hmresd_seal_line_no, row.hmresd_seal_line_no))
          dispatch(receiptRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(receiptRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(receiptRequest(false));
      })
      .catch(err => {
        dispatch(receiptRequestFailure(err));
        dispatch(receiptRequest(false));
      })
  }
}

export const deleteLoadingSeal = (params) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer: { loadingresult } } = getState()
    dispatch(loadingRequest(true))
    return Api.delete(`/hub/vehicleSeal/deleteLoadingSeal?hmlesd_seal_line_no=${params.hmlesd_seal_line_no}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(loadingRequestSuccess('', []));
          const records = _.filter(loadingresult, (row) => !_.includes(params.hmlesd_seal_line_no, row.hmlesd_seal_line_no))
          dispatch(loadingRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(loadingRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(loadingRequest(false));
      })
      .catch(err => {
        dispatch(loadingRequestFailure(err));
        dispatch(loadingRequest(false));
      })
  }
}

export const deleteHlRecords = (params) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer: { gridLoadResult } } = getState()
    dispatch(deleteHlHrRequest(true))
    return Api.delete(`/hub/tripPlanLoad/delete`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(deleteHlHrRequestSuccess('', []));
          const records = _.filter(gridLoadResult, (row) => !_.includes(params.ddh_dispatch_doc_no, row.ddh_dispatch_doc_no))
          dispatch(deleteHlHrRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(deleteHlHrRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(deleteHlHrRequest(false));
      })
      .catch(err => {
        dispatch(deleteHlHrRequestFailure(err));
        dispatch(deleteHlHrRequest(false));
      })
  }
}

export const deleteHrRecords = (params) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer: { gridReceiptResult } } = getState()
    dispatch(deleteHlHrRequest(true))
    return Api.delete(`/hub/tripPlanReceipt/delete`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(deleteHlHrRequestSuccess('', []));
          const records = _.filter(gridReceiptResult, (row) => !_.includes(params.ddh_dispatch_doc_no, row.ddh_dispatch_doc_no))
          dispatch(deleteHlHrRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(deleteHlHrRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(deleteHlHrRequest(false));
      })
      .catch(err => {
        dispatch(deleteHlHrRequestFailure(err));
        dispatch(deleteHlHrRequest(false));
      })
  }
}

const deleteHlHrRequest = isRequested => {
  return {
    type: actions.OPTIONS_FETCH_REQUEST,
    isRequested
  }
}

const deleteHlHrRequestSuccess = (message, data) => {
  return {
    type: actions.LOADING_DISPATCH_DOCUMENT_RECORDS,
    message,
    data
  }
}

const deleteHlHrRequestFailure = message => {
  return {
    type: actions.LOADING_RECORDS_SAVE_FAILURE,
    message
  }
}