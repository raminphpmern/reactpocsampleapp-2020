import Api from 'lib/api'
import * as types from 'types/thuInventory.type'
import { AlertSuccess, AlertError } from 'lib/Alert'

export const getStatus = (values) => {
  return dispatch => {
    dispatch(searchDropdownRequest(true));
    return Api.get(`/thuInventory/getStatus`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchStatusSuccess(response.result))
        } else {
          dispatch(searchDropdownFailure(response.message));
        }
        dispatch(searchDropdownRequest(false));
      })
      .catch(err => {
        console.log("Status -- search ", err);
        dispatch(searchDropdownFailure(err));
        dispatch(searchDropdownRequest(false));
      });
  };
};

const searchDropdownRequest = (isRequested) => {
  return {
    type: types.THUINVENTORY_DROPDOWN_REQUEST,
    isRequested
  }
}

const searchDropdownFailure = (message) => {
  return {
    type: types.THUINVENTORY_DROPDOWN_FAILURE,
    message
  }
}

const searchStatusSuccess = (data) => {
  return {
    type: types.THUINVENTORY_STATUS_SUCCESS,
    data
  }
}

export const getAvailabilityStatus = (values) => {
  return dispatch => {
    dispatch(searchDropdownRequest(true));
    return Api.get(`/thuInventory/getAvailabilityStatus`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchAvailabilitySuccess(response.result))
        } else {
          dispatch(searchDropdownFailure(response.message));
        }
        dispatch(searchDropdownRequest(false));
      })
      .catch(err => {
        console.log("Status -- search ", err);
        dispatch(searchDropdownFailure(err));
        dispatch(searchDropdownRequest(false));
      });
  };
};

const searchAvailabilitySuccess = (data) => {
  return {
    type: types.THUINVENTORY_AVAILABILITY_SUCCESS,
    data
  }
}

export const getAllocationLevel = (values) => {
  return dispatch => {
    dispatch(searchDropdownRequest(true));
    return Api.get(`/thuInventory/getAllocationLevel`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchAllocationSuccess(response.result))
        } else {
          dispatch(searchDropdownFailure(response.message));
        }
        dispatch(searchDropdownRequest(false));
      })
      .catch(err => {
        console.log("Status -- search ", err);
        dispatch(searchDropdownFailure(err));
        dispatch(searchDropdownRequest(false));
      });
  };
};

const searchAllocationSuccess = (data) => {
  return {
    type: types.THUINVENTORY_ALLOCATION_SUCCESS,
    data
  }
}

export const search = (values, pageNo, limit) => {
  return dispatch => {
    dispatch(searchRequest(true));
    return Api.post(`/thuInventory/search?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchSuccess(response.result, response.totalPage, response.totalRecord, limit, values.periodic_filter))
          AlertSuccess(response.message)
        } else {
          dispatch(searchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(searchRequest(false));
      })
      .catch(err => {
        console.log("THU inventory Actions -- search ", err);
        dispatch(searchFailure(err));
        dispatch(searchRequest(false));
      });
  };
}

export const initializeInventory = () => {
  return {
    type: types.THUINVENTORY_INITIALIZE
  }
}

const searchRequest = (isRequested) => {
  return {
    type: types.THUINVENTORY_SEARCH_REQUEST,
    isRequested
  }
}

const searchSuccess = (data, totalPage, totalRecord, limit, filterType) => {
  return {
    type: types.THUINVENTORY_SEARCH_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit,
    filterType
  }
}

const searchFailure = (message) => {
  return {
    type: types.THUINVENTORY_SEARCH_FAILURE,
    message
  }
}

export const allocate = (values) => {
  return dispatch => {
    dispatch(searchRequest(true))
    dispatch(validateSerialNumberAllocate(true))
    return Api.post(`/thuInventory/allocate`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(validateSerialNumberAllocate(true))
          AlertSuccess(response.message)
        } else {
          dispatch(validateSerialNumberAllocate(false))
          AlertError(response.message)
        }
        dispatch(searchRequest(false))
      }).catch((err) => {
        dispatch(searchFailure(err))
      })
  }
}

const validateSerialNumberAllocate = (isValid) => {
  return {
    type: types.SERIALNUMBER_IS_ALLOCATE,
    isValid
  }
}


const validateSerialNumberCompleted = (isValid) => {
  return {
    type: types.SERIALNUMBER_IS_VALID,
    isValid
  }
}

export const validateSerialNumber = (action, serialNumber) => {
  return dispatch => {
    dispatch(searchRequest(true))
    dispatch(validateSerialNumberCompleted(true))
    return Api.post(`/thuInventory/${action}?serialNumber=${serialNumber}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(validateSerialNumberCompleted(true))
          AlertSuccess(response.message)
        } else {
          dispatch(validateSerialNumberCompleted(false))
          AlertError(response.message)
        }
        dispatch(searchRequest(false))
      }).catch((err) => {
        dispatch(searchFailure(err))
      })
  }
}

export const deallocate = (values) => {
  return dispatch => {
    dispatch(searchRequest(true))
    dispatch(validateSerialNumberDeAllocate(true))
    return Api.post(`/thuInventory/deallocate`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(validateSerialNumberDeAllocate(true))
          AlertSuccess(response.message)
        } else {
          dispatch(validateSerialNumberDeAllocate(false))
          AlertError(response.message)
        }
        dispatch(searchRequest(false))
      }).catch((err) => {
        dispatch(searchFailure(err))
      })
  }
}

const validateSerialNumberDeAllocate = (isValid) => {
  return {
    type: types.SERIALNUMBER_IS_DEALLOCATE,
    isValid
  }
}

export const getSerialDetails = (values, pageNo, limit) => {
  return dispatch => {
    dispatch(searchRequest(true));
    return Api.post(`/thuInventory/getSerialDetails?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchSerialNumberSuccess(response.result, response.totalPage, response.totalRecord, limit))
          AlertSuccess(response.message)
        } else {
          dispatch(searchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(searchRequest(false));
      })
      .catch(err => {
        console.log("THU inventory Actions -- search ", err);
        dispatch(searchFailure(err));
        dispatch(searchRequest(false));
      });
  };
}

const searchSerialNumberSuccess = (data, totalPage, totalRecord, limit) => {
  return {
    type: types.THUINVENTORY_SEARCH_SERIALNUMBER_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit
  }
}

export const initializeSerialNumber = () => {
  return {
    type: types.THUINVENTORY_SERIALNUMBER_INITIALIZE
  }
}