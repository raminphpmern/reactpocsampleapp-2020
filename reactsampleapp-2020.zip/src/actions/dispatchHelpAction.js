import Api from "lib/api";
import * as actions from "types/dispatchsearch.type"
import { AlertSuccess, AlertError } from 'lib/Alert'

// Help On Customer
export const helpOnCustomerAction = (params, pageNo, limit) => {
  return dispatch => {
    dispatch(helpSearchRequest(true));
    return Api.post(`/dispatch/customerCode?pageNo=${pageNo}&limit=${limit}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(helpfetchSuccess(response));
        } else {
          dispatch(helpfetchFailure(response.message));
        }
        dispatch(helpSearchRequest(false));
      })
      .catch(err => {
        dispatch(helpfetchFailure(err));
        dispatch(helpSearchRequest(false));
      });
  };
};


export const helpSearchRequest = isSearching => {
  return {
    type: actions.DISPATCH_HELP_SEARCH_REQUEST,
    isSearching
  };
};

export const helpfetchSuccess = data => {
  return {
    type: actions.DISPATCH_HELP_CUSTOMER_RESULT_SUCCESS,
    data
  };
};

export const helpfetchFailure = err => {
  return {
    type: actions.HELP_FETCH_FAILURE,
    err
  };
};

//Help On Trip Plan by Search
export const helpOnTripPlan = (params, pageNo, limit) => {
  return dispatch => {
    dispatch(helpOnTripRequest(true));
    return Api.post(`/dispatch/tripLog?pageNo=${pageNo}&limit=${limit}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(helpOnTripSuccess(response));
          AlertSuccess(response.message);
        } else {
          dispatch(helpOnTripFailure(response.message));
          AlertError(response.message);
        }
        dispatch(helpOnTripRequest(false));
      })
      .catch(err => {
        dispatch(helpOnTripFailure(err));
        dispatch(helpOnTripRequest(false));
      });
  };
};


export const helpOnTripRequest = isSearching => {
  return {
    type: actions.TRIP_HELP_SEARCH_REQUEST,
    isSearching
  };
};

export const helpOnTripSuccess = data => {
  return {
    type: actions.TRIP_HELP_ID_FETCH_SUCCESS,
    data
  };
};

export const helpOnTripFailure = err => {
  return {
    type: actions.TRIP_HELP_ID_FETCH_FAILURE,
    err
  };
};

// Help On Trip Plan by ID
export const helpOnTripPlanByID = (params, pageNo, limit) => {
  return dispatch => {
    dispatch(helpOnTripByIDRequest(true));
    return Api.post(`/dispatch/tripLog?pageNo=${pageNo}&limit=${limit}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(helpOnTripByIDSuccess(response));
          AlertSuccess(response.message)
        } else {
          dispatch(helpOnTripByIDFailure(response.message));
          AlertError(response.message)
        }
        dispatch(helpOnTripByIDRequest(false));
      })
      .catch(err => {
        dispatch(helpOnTripByIDFailure(err));
        dispatch(helpOnTripByIDRequest(false));
      });
  };
};

export const helpOnTripByIDRequest = isSearching => {
  return {
    type: actions.TRIP_HELP_SEARCH_REQUEST_BY_ID,
    isSearching
  };
};

export const helpOnTripByIDSuccess = data => {
  return {
    type: actions.TRIP_HELP_ID_FETCH_SUCCESS_BY_ID,
    data
  };
};

export const helpOnTripByIDFailure = err => {
  return {
    type: actions.TRIP_HELP_ID_FETCH_FAILURE_BY_ID,
    err
  };
};