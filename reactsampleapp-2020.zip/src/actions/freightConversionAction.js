import Api from "lib/api";
import * as actions from "types/freightConversion.type"
import { AlertSuccess, AlertError } from 'lib/Alert'
import _ from 'lodash';
import i18n from 'i18n';

export const freightConversionSearch = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(freightConversionSearchRequest(true));
    return Api.post(`/hub/freightConversion/search/?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(freightConversionSearchSuccess(response, response.fcStatus));
          AlertSuccess(response.message)
        } else {
          dispatch(freightConversionSearchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(freightConversionSearchRequest(false));
      })
      .catch(err => {
        dispatch(freightConversionSearchFailure(err));
        dispatch(freightConversionSearchRequest(false));
      });
  };
};

const freightConversionSearchRequest = isRequested => {
  return {
    type: actions.FREIGHT_CONVERSION_FETCH_REQUEST,
    isRequested
  }
}

const freightConversionSearchSuccess = (data, count) => {
  return {
    type: actions.FREIGHT_CONVERSION_FETCH_SUCCESS,
    data,
    count
  }
}

const freightConversionSearchFailure = msg => {
  return {
    type: actions.FREIGHT_CONVERSION_FETCH_FAILURE,
    msg
  }
}

export const resetRecords = () => {
  return {
    type: actions.RESET_FC_SEARCH_RECORDS,
  }
}

export const deleteFcDeConRecords = () => {
  return {
    type: actions.DELETE_FC_DECONSOLIDATION_RECORD,
  }
}

export const resetHelpScreenRecords = () => {
  return {
    type: actions.RESET_FC_HELP_SCREEN_SEARCH_RECORDS,
  }
}

export const getFCViewHeader = (fc_No) => {
  return (dispatch) => {
    dispatch(getFCViewHeaderRequest(true));
    return Api.get(`/hub/freightConversion/getFCViewHeader?fcExecNo=${fc_No}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(getFCViewHeaderSuccess(response.result[0]))
          AlertSuccess(response.message)
        } else {
          dispatch(getFCViewHeaderFailure(response))
          AlertError(response.message)
        }
        dispatch(getFCViewHeaderRequest(false));
      })
      .catch(err => {
        dispatch(getFCViewHeaderFailure(err));
        dispatch(getFCViewHeaderRequest(false));
      });
  };
};

const getFCViewHeaderFailure = err => {
  return {
    type: actions.FC_RECORDS_FETCH_FAILURE,
    err
  };
};

const getFCViewHeaderSuccess = (result) => {
  return {
    type: actions.FC_RECORDS_FETCH_SUCCESS,
    result
  }
};

const getFCViewHeaderRequest = isSearching => {
  return {
    type: actions.FC_RECORDS_FETCH_REQUEST,
    isSearching
  };
};

export const getFCViewInputThu = (fc_No, pageNo, limit, decon) => {
  return (dispatch, getState) => {
    const { freightConversionReducer } = getState()
    dispatch(getFCViewInputThuRequest(true));
    return Api.get(`/hub/freightConversion/getFCViewInputTHU?fcExecNo=${fc_No}&pageNo=${pageNo}&limit=${limit}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          if (decon) {
            let notScannedRecords = _.forEach(response.result, (item) => {
              return item.hmitd_ip_qty = 0;
            })
            dispatch(getFCViewOutputThuSuccess(notScannedRecords, response.totalPage, response.totalRecord, "Expand"))
          }
          else {
            dispatch(getFCViewInputThuSuccess(response.result, response.totalPage, response.totalRecord))
          }
        } else {
          dispatch(getFCViewInputThuFailure(response))
          AlertError(response.message)
        }
        dispatch(getFCViewInputThuRequest(false));
      })
      .catch(err => {
        dispatch(getFCViewInputThuFailure(err));
        dispatch(getFCViewInputThuRequest(false));
      });
  };
};

const getFCViewInputThuFailure = err => {
  return {
    type: actions.FC_INPUT_THU_RECORDS_FETCH_FAILURE,
    err
  };
};

const getFCViewInputThuSuccess = (result, totalPage, totalRecord) => {
  return {
    type: actions.FC_INPUT_THU_RECORDS_FETCH_SUCCESS,
    result,
    totalPage,
    totalRecord
  }
};

const getFCViewInputThuRequest = isSearching => {
  return {
    type: actions.FC_INPUT_THU_RECORDS_FETCH_REQUEST,
    isSearching
  };
};

export const getFCViewOutputThu = (fc_No, pageNo, limit) => {
  return (dispatch) => {
    dispatch(getFCViewOutputThuRequest(true));
    return Api.get(`/hub/freightConversion/getFCViewOutputTHU?fcExecNo=${fc_No}&pageNo=${pageNo}&limit=${limit}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(getFCViewOutputThuSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(getFCViewOutputThuFailure(response))
          AlertError(response.message)
        }
        dispatch(getFCViewOutputThuRequest(false));
      })
      .catch(err => {
        dispatch(getFCViewOutputThuFailure(err));
        dispatch(getFCViewOutputThuRequest(false));
      });
  };
};

const getFCViewOutputThuFailure = err => {
  return {
    type: actions.FC_OUTPUT_THU_RECORDS_FETCH_FAILURE,
    err
  };
};

const getFCViewOutputThuSuccess = (result, totalPage, totalRecord, expand) => {
  return {
    type: actions.FC_OUTPUT_THU_RECORDS_FETCH_SUCCESS,
    result,
    totalPage,
    totalRecord,
    expand
  }
};

const getFCViewOutputThuRequest = isSearching => {
  return {
    type: actions.FC_OUTPUT_THU_RECORDS_FETCH_REQUEST,
    isSearching
  };
};

export const fcOutputThuFetch = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(fcOutputThuFetchRequest(true));
    return Api.post(`/hub/freightConversion/search_by_output_thu/?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(fcOutputThuFetchSuccess(response.result, response.totalPage, response.totalRecord));
          AlertSuccess(response.message)
        } else {
          dispatch(fcOutputThuFetchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(fcOutputThuFetchRequest(false));
      })
      .catch(err => {
        dispatch(fcOutputThuFetchFailure(err));
        dispatch(fcOutputThuFetchRequest(false));
      });
  };
};

export const scanDeconRecords = (data, pageNo, limit) => {
  return (dispatch, getState) => {
    const { freightConversionReducer } = getState();
    dispatch(fcOutputThuFetchRequest(true));
    return Api.post(`/hub/freightConversion/dispatchScan/?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(i18n.t("fcValidation:scanSuccess"))
          let combinedRecord = _.concat(freightConversionReducer.output_Thu_result, response.result)
          dispatch(fcOutputThuFetchSuccess(combinedRecord, response.totalPage, response.totalRecord));
        } else {
          dispatch(fcOutputThuFetchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(fcOutputThuFetchRequest(false));
      })
      .catch(err => {
        dispatch(fcOutputThuFetchFailure(err));
        dispatch(fcOutputThuFetchRequest(false));
      });
  };
};

export const scanSuccesDecon = (data) => {
  return (dispatch, getState) => {
    const { freightConversionReducer } = getState();
    let scannedRecords = _.forEach(freightConversionReducer.output_Thu_result, (item) => {
      return data.hmitd_ip_qty = 1;
    })
    dispatch(fcOutputThuFetchSuccess(scannedRecords))
  }
};

const fcOutputThuFetchRequest = isRequested => {
  return {
    type: actions.FC_OUTPUT_THU_FETCH_REQUEST,
    isRequested
  }
}

const fcOutputThuFetchSuccess = (result, totalPage, totalRecord) => {
  return {
    type: actions.FC_OUTPUT_THU_FETCH_SUCCESS,
    result,
    totalPage,
    totalRecord
  }
}

const fcOutputThuFetchFailure = msg => {
  return {
    type: actions.FC_OUTPUT_THU_FETCH_FAILURE,
    msg
  }
}

export const fcInputThuFetch = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(fcInputThuFetchRequest(true));
    return Api.post(`/hub/freightConversion/search_by_input_thu/?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          const fc_No = data.fcexecutionno
          return Api.get(`/hub/freightConversion/getFCViewInputTHU?fcExecNo=${fc_No}`)
            .then(response => response.json())
            .then(response => {
              dispatch(getFCViewInputThuSuccess(response.result, response.totalPage, response.totalRecord))
            }
            )
        } else {
          dispatch(fcInputThuFetchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(fcInputThuFetchRequest(false));
      })
      .catch(err => {
        dispatch(fcInputThuFetchFailure(err));
        dispatch(fcInputThuFetchRequest(false));
      });
  };
};

const fcInputThuFetchRequest = isRequested => {
  return {
    type: actions.FC_INPUT_THU_FETCH_REQUEST,
    isRequested
  }
}

const fcInputThuFetchFailure = msg => {
  return {
    type: actions.FC_INPUT_THU_FETCH_FAILURE,
    msg
  }
}

export const fcRecordsSave = (data) => {
  return dispatch => {
    dispatch(fcRecordsSaveRequest(true));
    return Api.post(`/hub/freightConversion/save_fc`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          const fc_No = response.result
          return Api.get(`/hub/freightConversion/getFCViewHeader?fcExecNo=${fc_No}`)
            .then(response => response.json())
            .then(response => {
              dispatch(getFCViewHeaderSuccess(response.result[0]))
            }
            )
        } else {
          dispatch(fcRecordsSaveFailure(response.message));
          AlertError(response.message)
        }
        dispatch(fcRecordsSaveRequest(false));
      })
      .catch(err => {
        dispatch(fcRecordsSaveFailure(err));
        dispatch(fcRecordsSaveRequest(false));
      });
  };
};

const fcRecordsSaveRequest = isRequested => {
  return {
    type: actions.FC_RECORDS_SAVE_REQUEST,
    isRequested
  }
}

const fcRecordsSaveFailure = msg => {
  return {
    type: actions.FC_RECORDS_SAVE_FAILURE,
    msg
  }
}

export const getFcMasterDetails = (action, queryString, stateName) => {
  return (dispatch, getState) => {
    const { freightConversionReducer } = getState();
    const options = freightConversionReducer.options;
    dispatch(fcMasterFetchRequest(true));
    return Api.get(`/hub/freightConversion/${action}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.data;
          } else {
            responseData[action] = response.data;
          }
          dispatch(fcMasterFetchSuccess(responseData, options, false));
        } else {
          dispatch(fcMasterFetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(fcMasterFetchRequest(false));
      })
      .catch(err => {
        dispatch(fcMasterFetchFailure(err));
      });
  };
};

export const fcMasterFetchRequest = isRequested => {
  return {
    type: actions.FC_MASTER_FETCH_REQUEST,
    isRequested
  };
};

export const fcMasterFetchSuccess = (data, existingState, isMerge) => {
  _.map(data, (value, key) => {
    existingState[key] = isMerge ? existingState[key].concat(value) : value;
  });

  data = existingState;
  return {
    type: actions.FC_MASTER_FETCH_SUCCESS,
    data: data
  };
};

export const fcMasterFetchFailure = err => {
  return {
    type: actions.FC_MASTER_FETCH_FAILURE,
    err
  };
};

export const computeThu = (data) => {
  return dispatch => {
    dispatch(computeThuRequest(true));
    return Api.post(`/hub/freightConversion/compute`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(computeThuSuccess(response.result));
        } else {
          dispatch(computeThuFailure(response.message));
          AlertError(response.message)
        }
        dispatch(computeThuRequest(false));
      })
      .catch(err => {
        dispatch(computeThuFailure(err));
        dispatch(computeThuRequest(false));
      });
  };
};

const computeThuRequest = isRequested => {
  return {
    type: actions.FC_INPUT_THU_COMPUTE_REQUEST,
    isRequested
  }
}

const computeThuSuccess = (result) => {
  return {
    type: actions.FC_INPUT_THU_COMPUTE_SUCCESS,
    result
  }
}

const computeThuFailure = msg => {
  return {
    type: actions.FC_INPUT_THU_COMPUTE_FAILURE,
    msg
  }
}

export const helpOfFcScreens = (action, params, pageNo, limit) => {
  return dispatch => {
    dispatch(helpOfFcScreensSearchRequest(true));
    return Api.post(`/hub/freightConversion/${action}?pageNo=${pageNo}&limit=${limit}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (action === 'helpDispatch') {
            dispatch(helpOnDispatchDocNoSuccess(response.result, response.totalPage, response.totalRecord));
          }
          if (action === 'helpSerialNo') {
            dispatch(helpOnSerialNoSuccess(response.result, response.totalPage, response.totalRecord));
          }
          AlertSuccess(response.message)
        } else {
          dispatch(helpOfFcScreensSearchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(helpOfFcScreensSearchRequest(false));
      })
      .catch(err => {
        dispatch(helpOfFcScreensSearchFailure(err));
        dispatch(helpOfFcScreensSearchRequest(false));
      });
  };
};


export const helpOfFcScreensSearchRequest = isSearching => {
  return {
    type: actions.FC_HELP_SCREENS_SEARCH_REQUEST,
    isSearching
  };
};

export const helpOnDispatchDocNoSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.DDNO_HELP_SEARCH_SUCCESS,
    data,
    totalPage,
    totalRecord
  };
};

export const helpOnSerialNoSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.SERIAL_NO_HELP_SEARCH_SUCCESS,
    data,
    totalPage,
    totalRecord
  };
};

export const helpOfFcScreensSearchFailure = err => {
  return {
    type: actions.FC_HELP_SCREENS_SEARCH_FAILURE,
    err
  };
};

export const fetchConsolidationSeal = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(fetchConsSealDetailsRequest(true))
    return Api.get(`/hub/fcSeal/fetchConsSeal?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(fetchConsSealDetailsSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(fetchConsSealDetailsFailure(response.message))
          AlertError(response.message)
        }
        dispatch(fetchConsSealDetailsRequest(false))
      }).catch((err) => {
        dispatch(fetchConsSealDetailsRequest(false))
        dispatch(fetchConsSealDetailsFailure(err))
      })
  }
}

const fetchConsSealDetailsRequest = (isRequested) => {
  return {
    type: actions.FC_CONSOLIDATION_SEAL_DETAILS_REQUEST,
    isRequested
  }
}

const fetchConsSealDetailsSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.FC_CONSOLIDATION_SEAL_DETAILS_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const fetchConsSealDetailsFailure = (message) => {
  return {
    type: actions.FC_CONSOLIDATION_SEAL_DETAILS_FAILURE,
    message
  }
}

export const saveConsolidationSeal = (params) => {
  return (dispatch, getState) => {
    let { freightConversionReducer: { cons_seal_result } } = getState()
    dispatch(consSealRequest(true))
    return Api.post(`/hub/fcSeal/saveConsSealDtl`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(consSealRequestSuccess('', []));
          _.each(response.result, (item) => {
            const recordIndex = _.findIndex(cons_seal_result, (row) => row.thssd_seal_no === item.thssd_seal_no)
            if (recordIndex >= 0) {
              cons_seal_result[recordIndex] = item
            } else {
              cons_seal_result.push(item)
            }
          })
          dispatch(consSealRequestSuccess(response.message, cons_seal_result, "saved"));
          AlertSuccess(response.message)
        } else {
          dispatch(consSealRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(consSealRequest(false));
      })
      .catch(err => {
        dispatch(consSealRequestFailure(err));
        dispatch(consSealRequest(false));
      })
  }
}

export const deleteConsolidationSeal = (params) => {
  return (dispatch, getState) => {
    let { freightConversionReducer: { cons_seal_result } } = getState()
    dispatch(consSealRequest(true))
    return Api.delete(`/hub/fcSeal/deleteConsSeal?thssd_seal_no=${params.thssd_seal_no}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(consSealRequestSuccess('', []));
          const records = _.filter(cons_seal_result, (row) => !_.includes(params.thssd_seal_no, row.thssd_seal_no))
          dispatch(consSealRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(consSealRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(consSealRequest(false));
      })
      .catch(err => {
        dispatch(consSealRequestFailure(err));
        dispatch(consSealRequest(false));
      })
  }
}

const consSealRequest = isSaveRequested => {
  return {
    type: actions.FC_CONSOLIDATION_SEAL_RECORDS_SAVE_REQUEST,
    isSaveRequested
  }
}

const consSealRequestSuccess = (message, data, status) => {
  return {
    type: actions.FC_CONSOLIDATION_SEAL_RECORDS_SAVE_SUCCESS,
    message,
    data,
    status
  }
}

const consSealRequestFailure = message => {
  return {
    type: actions.FC_CONSOLIDATION_SEAL_RECORDS_SAVE_FAILURE,
    message
  }
}

export const fetchDeconsolidationSeal = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(fetchDeconsSealDetailsRequest(true))
    return Api.get(`/hub/fcSeal/fetchDeconsSeal?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(fetchDeconsSealDetailsSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(fetchDeconsSealDetailsFailure(response.message))
          AlertError(response.message)
        }
        dispatch(fetchDeconsSealDetailsRequest(false))
      }).catch((err) => {
        dispatch(fetchDeconsSealDetailsRequest(false))
        dispatch(fetchDeconsSealDetailsFailure(err))
      })
  }
}

const fetchDeconsSealDetailsRequest = (isRequested) => {
  return {
    type: actions.FC_DECONSOLIDATION_SEAL_DETAILS_REQUEST,
    isRequested
  }
}

const fetchDeconsSealDetailsSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.FC_DECONSOLIDATION_SEAL_DETAILS_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const fetchDeconsSealDetailsFailure = (message) => {
  return {
    type: actions.FC_DECONSOLIDATION_SEAL_DETAILS_FAILURE,
    message
  }
}

export const saveDeconsolidationSeal = (params) => {
  return (dispatch, getState) => {
    let { freightConversionReducer: { decons_seal_result } } = getState()
    dispatch(deconsSealRequest(true))
    return Api.post(`/hub/fcSeal/saveDeconsSealDtl`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(deconsSealRequestSuccess('', []));
          _.each(response.result, (item) => {
            const recordIndex = _.findIndex(decons_seal_result, (row) => row.thssd_seal_no === item.thssd_seal_no)
            if (recordIndex >= 0) {
              decons_seal_result[recordIndex] = item
            } else {
              decons_seal_result.push(item)
            }
          })
          dispatch(deconsSealRequestSuccess(response.message, decons_seal_result, "saved"));
          AlertSuccess(response.message)
        } else {
          dispatch(deconsSealRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(deconsSealRequest(false));
      })
      .catch(err => {
        dispatch(deconsSealRequestFailure(err));
        dispatch(deconsSealRequest(false));
      })
  }
}

export const deleteDeconsolidationSeal = (params) => {
  return (dispatch, getState) => {
    let { freightConversionReducer: { cons_seal_result } } = getState()
    dispatch(deconsSealRequest(true))
    return Api.delete(`/hub/fcSeal/deleteDeconsSeal?thssd_seal_no=${params.thssd_seal_no}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(deconsSealRequestSuccess('', []));
          const records = _.filter(cons_seal_result, (row) => !_.includes(params.thssd_seal_no, row.thssd_seal_no))
          dispatch(deconsSealRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(deconsSealRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(deconsSealRequest(false));
      })
      .catch(err => {
        dispatch(deconsSealRequestFailure(err));
        dispatch(deconsSealRequest(false));
      })
  }
}

const deconsSealRequest = isSaveRequested => {
  return {
    type: actions.FC_DECONSOLIDATION_SEAL_RECORDS_SAVE_REQUEST,
    isSaveRequested
  }
}

const deconsSealRequestSuccess = (message, data, status) => {
  return {
    type: actions.FC_DECONSOLIDATION_SEAL_RECORDS_SAVE_SUCCESS,
    message,
    data,
    status
  }
}

const deconsSealRequestFailure = message => {
  return {
    type: actions.FC_DECONSOLIDATION_SEAL_RECORDS_SAVE_FAILURE,
    message
  }
}

export const deleteFcInputRecords = (params) => {
  return (dispatch, getState) => {
    const { freightConversionReducer: { input_Thu_result } } = getState()
    dispatch(deleteFcInputRecordsRequest(true))
    return Api.delete(`/hub/freightConversion/delete`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          dispatch(deleteFcInputRecordsRequestSuccess('', []));
          const records = _.filter(input_Thu_result, (row) => !((params.hmitd_despat_doc_no.includes(row.hmitd_despat_doc_no) && (params.hmitd_thu_serial_no.includes(row.hmitd_thu_serial_no)))))
          dispatch(deleteFcInputRecordsRequestSuccess(response.message, records));
        } else {
          dispatch(deleteFcInputRecordsRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(deleteFcInputRecordsRequest(false));
      })
      .catch(err => {
        dispatch(deleteFcInputRecordsRequestFailure(err));
        dispatch(deleteFcInputRecordsRequest(false));
      })
  }
}

const deleteFcInputRecordsRequest = isRequested => {
  return {
    type: actions.FC_INPUT_THU_RECORDS_FETCH_REQUEST,
    isRequested
  }
}

const deleteFcInputRecordsRequestSuccess = (message, result) => {
  return {
    type: actions.FC_INPUT_THU_RECORDS_FETCH_SUCCESS,
    message,
    result
  }
}

const deleteFcInputRecordsRequestFailure = message => {
  return {
    type: actions.FC_INPUT_THU_RECORDS_FETCH_FAILURE,
    message
  }
}