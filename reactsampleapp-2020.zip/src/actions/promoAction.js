import Api from 'lib/api'
import * as types from 'types/promo.type.js'
import { AlertSuccess, AlertError } from 'lib/Alert'
import _ from 'lodash'

const success = (currentBooking, tariffResponse) => {
  return {
    type: types.PROMOCODE_SUCCESS,
    currentBooking,
    result: tariffResponse.result,
    data: tariffResponse.data,
  }
}

const failure = (isValid) => {
  return {
    type: types.PROMOCODE_FAILURE,
    isValid
  }
}

const promoIsRequest = (isPromoRequest) => {
  return {
    type: types.PROMOCODE_REQUEST,
    isPromoRequest,
  }
}

export const validatePromoCode = (brId, values) => {
  return (dispatch, getState) => {
    dispatch(promoIsRequest(true))
    const { bookingReducer } = getState();
    return Api.post(`/qbr/promocode/${brId}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          let tms_br_booking_request_hdr = bookingInfo['tms_br_booking_request_hdr']
          _.merge(tms_br_booking_request_hdr, response.data)
          dispatch(success(bookingInfo, response.tariffResponse))
          AlertSuccess(response.message)
        } else {
          dispatch(failure(false))
          AlertError(response.message)
        }
        dispatch(promoIsRequest(false))
      }).catch((err) => {
        dispatch(promoIsRequest(false))
        dispatch(failure(false))
      })
  }
}

export const removePromoCode = (brId) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    return Api.delete(`/qbr/promocode/${brId}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          let tms_br_booking_request_hdr = bookingInfo['tms_br_booking_request_hdr']
          _.merge(tms_br_booking_request_hdr, { br_promo_code: null })
          dispatch(success(bookingInfo, response.tariffResponse))
          AlertSuccess(response.message)
        } else {
          AlertError(response.message)
        }
        dispatch(promoIsRequest(false))
      }).catch((err) => {
        dispatch(promoIsRequest(false))
      })
  }
}