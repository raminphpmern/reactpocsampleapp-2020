import Api from "lib/api";
import * as actions from "types/tripAttachments.type";
import _ from 'lodash'
import { AlertSuccess, AlertError } from 'lib/Alert'

export const getTripAttachments = (tripId, queryString, limit) => {
  return (dispatch) => {
    dispatch(attachmentsSuccess({ attachments: [], totalPage: 0, totalRecord: 0 }, limit));
    dispatch(attachmentsRequest(true));
    return Api.get(`/tripLogs/attachments/${encodeURIComponent(tripId)}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(attachmentsSuccess(response, limit));
          AlertSuccess(response.message)
        } else {
          dispatch(attachmentsFailure(response.message));
          AlertError(response.message)
        }
        dispatch(attachmentsRequest(false));
      })
      .catch(err => {
        console.log("tripAttachmentAction -- search ", err);
        dispatch(attachmentsFailure(err));
        dispatch(attachmentsRequest(false));
      });
  };
};

const attachmentsRequest = isRequested => {
  return {
    type: actions.TRIP_ATTACHMENTS_FETCH_REQUEST,
    isRequested
  };
};

const attachmentsSuccess = (data, limit) => {
  return {
    type: actions.TRIP_ATTACHMENTS_FETCH_SUCCESS,
    ...data,
    limit,
  };
};

const attachmentsFailure = msg => {
  return {
    type: actions.TRIP_ATTACHMENTS_FETCH_FAILURE,
    msg
  };
};

export const saveTripAttachments = (tripId, params) => {
  return (dispatch, getState) => {
    const { tripAttachmentsReducer } = getState();
    let attachments = tripAttachmentsReducer.attachments
    dispatch(attachmentsRequest(true));
    return Api.post(`/tripLogs/attachments/${encodeURIComponent(tripId)}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(attachmentsSaveSuccess([]));
          _.each(response.attachments, (item) => {
            const recordIndex = _.findIndex(attachments, (row) => row.tpad_line_no === item.tpad_line_no)
            if (recordIndex >= 0) {
              attachments[recordIndex] = item
            } else {
              attachments.push(item)
            }
          })
          dispatch(attachmentsSaveSuccess(attachments));
          AlertSuccess(response.message)
        } else {
          dispatch(attachmentsFailure(response.message));
          AlertError(response.message)
        }
        dispatch(attachmentsRequest(false));
      })
      .catch(err => {
        console.log("tripAttachmentAction -- save ", err);
        dispatch(attachmentsFailure(err));
        dispatch(attachmentsRequest(false));
      });
  };
};

export const deleteTripAttachments = (tripId, lineNumbers, queryString) => {
  return (dispatch, getState) => {
    const { tripAttachmentsReducer } = getState();
    let attachments = tripAttachmentsReducer.attachments;
    dispatch(attachmentsRequest(true));
    return Api.delete(`/tripLogs/attachments/${encodeURIComponent(tripId)}?${queryString}`, lineNumbers)
      .then(response => response.json())
      .then(response => {
        dispatch(attachmentsSaveSuccess([]));
        if (response.status === 200) {
          attachments = _.filter(attachments, (item) => {
            return !_.includes(lineNumbers, item.tpad_line_no)
          })
          dispatch(attachmentsSaveSuccess(attachments));
          AlertSuccess(response.message)
        } else {
          dispatch(attachmentsFailure(response.message));
          AlertError(response.message)
        }
        dispatch(attachmentsRequest(false));
      })
      .catch(err => {
        console.log("tripAttachmentAction -- delete ", err);
        dispatch(attachmentsFailure(err));
        dispatch(attachmentsRequest(false));
      });
  };
};

const attachmentsSaveSuccess = (attachments) => {
  return {
    type: actions.TRIP_ATTACHMENTS_SAVE_SUCCESS,
    attachments
  };
}

export const getTypeOptions = (type) => {
  return (dispatch) => {
    dispatch(optionsRequest(true));
    return Api.get(`/tripLogs/attachments/typeOptions?type=${type}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(optionsSuccess(response.result));
        } else {
          AlertError(response.message)
        }
        dispatch(optionsRequest(false));
      })
      .catch(err => {
        console.log("tripAttachmentAction -- options ", err);
        dispatch(optionsRequest(false));
      });
  };
};

const optionsRequest = isRequested => {
  return {
    type: actions.TRIP_OPTIONS_FETCH_REQUEST,
    isRequested
  };
};

const optionsSuccess = (typeOptions) => {
  return {
    type: actions.TRIP_OPTIONS_FETCH_SUCCESS,
    typeOptions,
  };
};
