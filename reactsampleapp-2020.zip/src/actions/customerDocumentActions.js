import Api from "lib/api";
import * as actions from "types/customerDocument.type";
import { AlertSuccess, AlertError } from 'lib/Alert'

export const getcustomerDocument = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(custDocDtlRequest(true))
    return Api.get(`/tripLogs/getcustomerDocument?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        const message = response.message
        if (response.status === 200) {
          dispatch(custDocDtlSuccess(response, limit))
          AlertSuccess(message)
        } else {
          dispatch(custDocDtlFailure(message))
          AlertError(response.message)
        }
        dispatch(custDocDtlRequest(false))
      }).catch((err) => {
        dispatch(custDocDtlRequest(false))
        dispatch(custDocDtlFailure(err))
      })
  }
}

const custDocDtlRequest = (isRequested) => {
  return {
    type: actions.CUSTOMER_DOCUMENT_REQUEST,
    isRequested
  }
}

const custDocDtlSuccess = (response, limit) => {
  return {
    type: actions.CUSTOMER_DOCUMENT_SUCCESS,
    ...response,
    limit
  }
}

const custDocDtlFailure = (customerMessage) => {
  return {
    type: actions.CUTOMER_DOCUMENT_FAILURE,
    customerMessage
  }
}