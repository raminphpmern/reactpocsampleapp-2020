import Api from "lib/api";
import * as actions from "types/dispatchsearch.type"
import { AlertSuccess, AlertError } from 'lib/Alert'
import history from 'routes/history';
import { setValue } from 'lib/LocalStorage'
import _ from 'lodash'

export const search = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(searchRequest(true));
    return Api.post(`/dispatch/dispatchDocument/search/?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchSuccess(response));
          AlertSuccess(response.message)
        } else {
          dispatch(searchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(searchRequest(false));
      })
      .catch(err => {
        dispatch(searchFailure(err));
        dispatch(searchRequest(false));
      });
  };
};

const searchRequest = isRequested => {
  return {
    type: actions.DISPATCH_FETCH_REQUEST,
    isRequested
  }
}

const searchSuccess = (data) => {
  return {
    type: actions.DISPATCH_FETCH_SUCCESS,
    data
  }
}

const searchFailure = msg => {
  return {
    type: actions.DISPATCH_FETCH_FAILURE,
    msg
  }
}

export const resetSearchData = () => {
  return {
    type: actions.RESET_DISPATCH_FETCH_DATA,
  }
}

export const loadMasterDefaults = (action, stateName) => {
  return (dispatch, getState) => {
    const { dispatchReducer } = getState();
    const options = dispatchReducer.options;
    dispatch(loadfetchRequest(true));
    return Api.get(`/search/${action}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.result;
          } else {
            responseData[action] = response.result;
          }
          dispatch(loadfetchSuccess(responseData, options, false));
        } else {
          dispatch(loadfetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(loadfetchRequest(false));
      })
      .catch(err => {
        dispatch(loadfetchFailure(err));
      });
  };
};

export const loadDispatchDefaults = (action, stateName) => {
  return (dispatch, getState) => {
    const { dispatchReducer } = getState();
    const options = dispatchReducer.options;
    dispatch(loadfetchRequest(true));
    return Api.get(`/dispatch/loadMasterValues/${action}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.result;
          } else {
            responseData[action] = response.result;
          }
          dispatch(loadfetchSuccess(responseData, options, false));
        } else {
          dispatch(loadfetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(loadfetchRequest(false));
      })
      .catch(err => {
        dispatch(loadfetchFailure(err));
      });
  };
};

const loadfetchFailure = err => {
  return {
    type: actions.LOAD_FETCH_FAILURE,
    err
  };
};

export const loadfetchSuccess = (data, existingState) => {
  _.map(data, (value, key) => {
    existingState[key] = existingState[key].concat(value);
  });
  data = existingState;
  return {
    type: actions.LOAD_ACTION_SUCCESS,
    data: data
  };
};

const loadfetchRequest = isLoading => {
  return {
    type: actions.LOAD_FETCH_REQUEST,
    isLoading
  };
};

// House View
export const loadSelectedView = (dd_no) => {
  return (dispatch) => {
    dispatch(loadViewRequest(true));
    return Api.get(`/dispatch/dispatchDocument/viewdispatch?doc_no=${dd_no}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          setValue('dd_no', response.data.ddh_dispatch_doc_no)
          dispatch(viewSearchSuccess(response.data[0]))
          dispatch(resetData());
          AlertSuccess(response.message)
        } else {
          dispatch(loadViewFailure(response))
          AlertError(response.message)
        }
        dispatch(loadViewRequest(false));
      })
      .catch(err => {
        dispatch(loadViewFailure(err));
        dispatch(loadViewRequest(false));
      });
  };
};

const loadViewFailure = err => {
  return {
    type: actions.LOAD_VIEW_FAILURE,
    err
  };
};

const viewSearchSuccess = (result) => {
  return {
    type: actions.DISPATCH_VIEW_DATA_SUCCESS,
    result
  }
};

const loadViewRequest = isSearching => {
  return {
    type: actions.LOAD_SEARCH_REQUEST,
    isSearching
  };
};

//Master View
export const loadMasterView = (dd_no) => {
  return (dispatch) => {
    dispatch(loadMasterRequest(true));
    return Api.get(`/dispatch/dispatchDocument/masterdispatch?doc_no=${dd_no}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          setValue('dd_no', response.data.ddh_dispatch_doc_no)
          dispatch(loadMasterSuccess(response.data[0]))
          dispatch(resetData());
          AlertSuccess(response.message)
        } else {
          dispatch(loadMasterFailure(response))
          AlertError(response.message)
        }
        dispatch(loadMasterRequest(false));
      })
      .catch(err => {
        dispatch(loadMasterFailure(err));
        dispatch(loadMasterRequest(false));
      });
  };
};

const resetData = () => {
  return {
    type: actions.DISPATCH_DATA_RESET,
  }
}

const loadMasterFailure = err => {
  return {
    type: actions.LOAD_MASTER_VIEW_FAILURE,
    err
  };
};

const loadMasterSuccess = (result) => {
  return {
    type: actions.LOAD_MASTER_VIEW_SUCCESS,
    result
  }
};

const loadMasterRequest = isSearching => {
  return {
    type: actions.LOAD_MASTER_VIEW_REQUEST,
    isSearching
  };
};

export const loadViewTHUDetails = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(searchTHURequest(true));
    return Api.post(`/dispatch/viewThu?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchTHUSuccess(response));
        } else {
          dispatch(searchTHUFailure(response.message));
        }
        dispatch(searchTHURequest(false));
      })
      .catch(err => {
        dispatch(searchTHUFailure(err));
        dispatch(searchTHURequest(false));
      });
  };
};

const searchTHURequest = isRequested => {
  return {
    type: actions.DISPATCH_THU_FETCH_REQUEST,
    isRequested
  }
}

const searchTHUSuccess = (data) => {
  return {
    type: actions.DISPATCH_THU_FETCH_SUCCESS,
    data
  }
}

export const resetTHUResults = () => {
  return {
    type: actions.RESET_DISPATCH_THU_DATA,
  }
}

const searchTHUFailure = msg => {
  return {
    type: actions.DISPATCH_THU_FETCH_FAILURE,
    msg
  }
}

// To Save details from the dispatch Create
export const createDispatchAction = (data, action) => {
  return dispatch => {
    dispatch(createRequest(true));
    return Api.post(`/dispatch/dispatchDocument/${action}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(createSuccess(response));
          if (response.result[0].ddh_dispatch_doc_no) {
            history.push({
              pathname: `/dispatchDocument/create/${response.result[0].ddh_dispatch_doc_no}`,
              state: { detail: response.result[0] }
            })
          }
          AlertSuccess(response.message)
        } else {
          dispatch(createFailure(response.message));
          AlertError(response.message)
        }
        dispatch(createRequest(false));
      })
      .catch(err => {
        dispatch(createFailure(err));
        dispatch(createRequest(false));
      });
  };
};

const createRequest = isRequested => {
  return {
    type: actions.DISPATCH_CREATE_REQUEST,
    isRequested
  }
}

const createSuccess = (data) => {
  return {
    type: actions.DISPATCH_CREATE_SUCCESS,
    data
  }
}

const createFailure = msg => {
  return {
    type: actions.DISPATCH_CREATE_FAILURE,
    msg
  }
}

// Link House
export const loadLinkHouseRecords = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(linkHouseRequest(true));
    return Api.post(`/dispatch/linkHouse/view/?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(linkHouseSuccess(response));
          AlertSuccess(response.message)
        } else {
          dispatch(linkHouseFailure(response.message));
        }
        dispatch(linkHouseRequest(false));
      })
      .catch(err => {
        dispatch(linkHouseFailure(err));
        dispatch(linkHouseRequest(false));
      });
  };
};

const linkHouseRequest = isRequested => {
  return {
    type: actions.LINK_HOUSE_FETCH_REQUEST,
    isRequested
  }
}

const linkHouseSuccess = (data) => {
  return {
    type: actions.LINK_HOUSE_FETCH_SUCCESS,
    data
  }
}

const linkHouseFailure = msg => {
  return {
    type: actions.LINK_HOUSE_FETCH_FAILURE,
    msg
  }
}

export const resetLHRecords = () => {
  return {
    type: actions.RESET_DISPATCH_LINK_HOUSE_RECORDS,
  }
}

//Assign& Unassign
export const changeMasterNumber = (data, action) => {
  return dispatch => {
    dispatch(changeMasterNumberRequest(true));
    return Api.post(`/dispatch/linkHouse/${action}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(changeMasterNumberSuccess(response));
          AlertSuccess(response.message)
        } else {
          dispatch(changeMasterNumberFailure(response.message));
          AlertError(response.message)
        }
        dispatch(changeMasterNumberRequest(false));
      })
      .catch(err => {
        dispatch(changeMasterNumberFailure(err));
        dispatch(changeMasterNumberRequest(false));
      });
  };
};

const changeMasterNumberRequest = isRequested => {
  return {
    type: actions.CHANGE_MASTER_NUMBER_REQUEST,
    isRequested
  }
}

const changeMasterNumberSuccess = (data) => {
  return {
    type: actions.CHANGE_MASTER_NUMBER_SUCCESS,
    data
  }
}

const changeMasterNumberFailure = msg => {
  return {
    type: actions.CHANGE_MASTER_NUMBER_FAILURE,
    msg
  }
}

export const getDispatchMasterValues = loadDispatchDefaults;
export const getDetails = loadSelectedView;
