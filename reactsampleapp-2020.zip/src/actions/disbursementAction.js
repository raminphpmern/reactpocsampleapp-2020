
import Api from 'lib/api'
import * as types from 'types/disbursement.type'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { apiErrorMsg } from 'lib/CommonHelper'
import _ from 'lodash'

export const create = (values, brId) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(createRequest(true))
    return Api.post(`/qbr/disbursements/${brId}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          _.merge(bookingInfo, { disbursement_detail: response.data })
          dispatch(createSuccess(bookingInfo))
          AlertSuccess(response.message)
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      }).catch((err) => {
        console.log("Disbursement Actions -- create -- Error", err)
        dispatch(createRequest(false))
        dispatch(createFailure(err))
      })
  }
}

export const update = (values, brId) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(createRequest(true))
    return Api.put(`/qbr/disbursements/${brId}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          _.merge(bookingInfo, { disbursement_detail: response.data })
          dispatch(createSuccess(bookingInfo))
          AlertSuccess(response.message)
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      }).catch((err) => {
        console.log("Disbursement Actions -- create -- Error", err)
        dispatch(createRequest(false))
        dispatch(createFailure(err))
      })
  }
}

const createRequest = (isRequested) => {
  return {
    type: types.CREATE_DISBURSEMENT_REQUEST,
    isRequested
  }
}

const createSuccess = (data) => {
  return {
    type: types.CREATE_DISBURSEMENT_SUCCESS,
    data,
  }
}

const createFailure = (msg) => {
  return {
    type: types.CREATE_DISBURSEMENT_FAILURE,
    msg
  }
}
