import Api from 'lib/api.js'
import * as actions from 'types/customer.type.js'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { setValue, getValue } from 'lib/LocalStorage'
import { apiErrorMsg } from 'lib/CommonHelper'
import _ from 'lodash'
import { updateStep } from 'actions/bookingActions';

function putInLocalStorage(step, response) {
  if (step === 1) {
    setValue('br_id', response.br_id)
  }
  let currentStep = parseInt(getValue('currentStep'))
  let activeStep = parseInt(getValue('activeStep'))

  step = step + 1
  if (activeStep < 4 || !activeStep) {
    setValue('activeStep', step)
    setValue('currentStep', step)
  } else {
    setValue('currentStep', currentStep > step ? currentStep : step)
  }
  return step
}

export const create = (params, step, status) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(createRequest(true))
    if (params['tms_br_booking_request_hdr'])
      delete params['tms_br_booking_request_hdr']['br_consign_note']
    delete params['tracking_no']
    return Api.post(`/qbr/customer?status=${status}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (params.tms_br_booking_request_hdr.br_recurring_flag === 'Y') {
            setValue('br_id', response.br_id)
            if (bookingReducer.copyBooking) {
              let bookingInfo = _.cloneDeep(bookingReducer.copyBooking)
              _.merge(bookingInfo, response.data)
              dispatch(createSuccess(bookingInfo, step, step))
            } else {
              dispatch(createSuccess(response.data, step, step))
            }
            return false;
          } else {
            step = putInLocalStorage(step, response)
            if (bookingReducer.copyBooking) {
              let bookingInfo = _.cloneDeep(bookingReducer.copyBooking)
              delete response.data.tms_br_booking_request_hdr.br_cod
              delete response.data.tms_br_booking_request_hdr.br_cop
              delete response.data.tms_br_booking_request_hdr.br_declared_value
              delete response.data.cd_declared_value_of_goods
              delete response.data.certificate_detail
              delete response.data.disbursement_detail
              delete response.cd_declared_value_of_goods
              delete bookingInfo.tax_details
              _.merge(bookingInfo, response.data)
              dispatch(createSuccess(bookingInfo, step, step, response.configResponse))
            } else {
              dispatch(createSuccess(response.data, step, step, response.configResponse))
            }
          }
          AlertSuccess(response.message)
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      })
      .catch((err) => {
        console.log("customerActions -- create -- Error", err)
        dispatch(createFailure(err))
        dispatch(createRequest(false))
      })
  }
}

export const update = (params, br_id, step, status) => {
  if (params && params.tms_br_booking_request_hdr && params.tms_br_booking_request_hdr.br_status !== 'Incomplete') {
    return dispatch => {
      dispatch(updateStep(step + 1))
      AlertSuccess("Booking is in confirmed status, please amend if you need to update the BR")
    }
  } else {
    return dispatch => {
      dispatch(createRequest(true))
      return Api.put(`/qbr/customer/${br_id}?status=${status}`, params)
        .then(response => response.json())
        .then(response => {
          if (response.status === 200) {
            if (params.tms_br_booking_request_hdr.br_recurring_flag === 'Y') {
              setValue('br_id', response.br_id)
              dispatch(createSuccess(response.data, 1, 1))
              AlertSuccess(response.message)
              return false;
            }
            step = putInLocalStorage(step, response)
            dispatch(createSuccess(response.data, parseInt(getValue('activeStep')), parseInt(getValue('currentStep')), response.configResponse))
            AlertSuccess(response.message)
          } else {
            dispatch(createFailure(response.message))
            AlertError(apiErrorMsg(response))
          }
          dispatch(createRequest(false))
        })
        .catch((err) => {
          console.log("customerActions -- update -- Error", err)
          dispatch(createFailure(err))
          dispatch(createRequest(false))
        })
    }
  }

}


export const updatePickupBranch = (params, brId) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(updatePickupBranchRequest(true))
    return Api.put(`/qbr/customer/pickup_branch/${brId}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          _.merge(bookingInfo['tms_brsd_shipment_details'], response.data)
          dispatch(updatePickupBranchSuccess(bookingInfo))
          AlertSuccess(response.message)
        } else {
          dispatch(updatePickupBranchFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
      })
  }
}

const createRequest = (isRequested) => {
  return {
    type: actions.CUSTOMER_CREATE_REQUEST,
    isRequested
  }
}

const createSuccess = (data, activeStep, currentStep, configResponse) => {
  return {
    type: actions.CUSTOMER_CREATE_SUCCESS,
    data,
    activeStep,
    currentStep,
    configResponse
  }
}

const createFailure = (msg) => {
  return {
    type: actions.CUSTOMER_CREATE_FAILURE,
    msg
  }
}


const updatePickupBranchRequest = (isRequested) => {
  return {
    type: actions.CUSTOMER_PICKUP_BRANCH_REQUEST,
    isRequested
  }
}

const updatePickupBranchSuccess = (data) => {
  return {
    type: actions.CUSTOMER_PICKUP_BRANCH_SUCCESS,
    data
  }
}

const updatePickupBranchFailure = (msg) => {
  return {
    type: actions.CUSTOMER_PICKUP_BRANCH_FAILURE,
    msg
  }
}

export const getTaxDetails = (id) => {
  return (dispatch) => {
    dispatch(taxSearchRequest(true))
    return Api.get(`/qbr/tax/${id}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(taxSearchSuccess(response.data))
          AlertSuccess(response.message)
        } else {
          dispatch(taxSearchFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
      })
      .catch((err) => {
        console.log("customerActions -- Tax create -- Error", err)
        dispatch(taxSearchFailure(err))
      })
  }
}


const taxSearchRequest = (isRequested) => {
  return {
    type: actions.CUSTOMER_TAX_REQUEST,
    isRequested
  }
}

const taxSearchSuccess = (data) => {
  return {
    type: actions.CUSTOMER_TAX_SUCCESS,
    data
  }
}

const taxSearchFailure = (message) => {
  return {
    type: actions.CUSTOMER_TAX_FAILURE,
    message
  }
}