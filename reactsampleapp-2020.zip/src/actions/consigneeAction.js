import * as actions from 'types/consignee.type';
import Api from 'lib/api';
import { e500 } from 'lib/messages';
import { AlertSuccess, AlertError } from 'lib/Alert'

export const Success = (consignee) => {
  return {
    type: actions.CREATE_CONSIGNEE_SUCCESS,
    consignee: consignee
  }
}

export const Failure = (error) => {
  return {
    type: actions.CREATE_CONSIGNEE_FAILURE,
    message: error
  }
}

export const Request = (isLoading) => {
  return {
    type: actions.CREATE_CONSIGNEE_REQUEST,
    isLoading
  }
}

export const create = (data) => {
  return dispatch => {
    dispatch(Request(true));
    return Api.post('/consignee', data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          dispatch(Success(response.data));
        } else {
          AlertError(response.message)
          dispatch(Failure(response.message));
        }
        dispatch(Request(false));
      })
      .catch((error) => {
        dispatch(Failure(e500));
        dispatch(Request(false));
      });
  }
}

export const initialize = () => {
  return {
    type: actions.CREATE_CONSIGNEE_INITIALIZE
  }
}

export const initializeForm = () => {
  return dispatch => {
    dispatch(initialize())
  }
}

export const fetchConsignee = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(consigneeSearchRequest(true))
    return Api.get(`/consignee/fetchLatest?${queryString}&pageNo=${pageNo}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(consigneeSearchSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(consigneeSearchFailure(response.message))
          AlertError(response.message)
        }
        dispatch(consigneeSearchRequest(false))
      }).catch((err) => {
        dispatch(consigneeSearchRequest(false))
        dispatch(consigneeSearchFailure(err))
      })
  }
}

export const initializeCON = () => {
  return dispatch => {
    dispatch(initializeConsignee())
  }
}

const initializeConsignee = () => {
  return {
    type: actions.CONSIGNEE_INITIALIZE
  }
}

const consigneeSearchRequest = (isRequested) => {
  return {
    type: actions.CONSIGNEE_REQUEST,
    isRequested
  }
}

const consigneeSearchSuccess = (data, totalPage, totalRecord) => {
  return {
    type: actions.CONSIGNEE_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const consigneeSearchFailure = (message) => {
  return {
    type: actions.CONSIGNEE_FAILURE,
    message
  }
}