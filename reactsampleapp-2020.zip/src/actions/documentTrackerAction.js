import Api from "lib/api";
import * as actions from "types/documentTracker.type";
import _ from 'lodash'
import { AlertSuccess, AlertError } from 'lib/Alert'

export const docTrackerDtl = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(docTrackerDtlRequest(true))
    return Api.get(`/trip/docTracker?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(docTrackerDtlSuccess(response.result, response.totalPage, response.totalRecord, limit, response.selectedRows))
          AlertSuccess(response.message)
        } else {
          dispatch(docTrackerDtlFailure(response.message))
          AlertError(response.message)
        }
        dispatch(docTrackerDtlRequest(false))
      }).catch((err) => {
        dispatch(docTrackerDtlRequest(false))
        dispatch(docTrackerDtlFailure(err))
      })
  }
}

export const initializeDT = () => {
  return dispatch => {
    dispatch(initializeDocTrackerDtl())
  }
}

const initializeDocTrackerDtl = () => {
  return {
    type: actions.DOCUMENT_TRACKER_INITIALIZE
  }
}
const docTrackerDtlRequest = (isRequested) => {
  return {
    type: actions.DOCUMENT_TRACKER_REQUEST,
    isRequested
  }
}

const docTrackerDtlSuccess = (data, totalPage, totalRecord, limit, selectedRows) => {
  return {
    type: actions.DOCUMENT_TRACKER_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit,
    selectedRows,
  }
}

const docTrackerDtlFailure = (message) => {
  return {
    type: actions.DOCUMENT_TRACKER_FAILURE,
    message
  }
}

export const saveDocTrackerRecords = (params) => {
  return (dispatch, getState) => {
    let { documentTrackerReducer: { result } } = getState()
    dispatch(saveDTRequest(true))
    return Api.post(`/trip/saveDocDtl`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(saveDTRequestSuccess('', []));
          _.each(params.selectedRecords, (item) => {
            const recordIndex = _.findIndex(result, (row) => row.serial_no === item.serial_no)
            if (recordIndex >= 0) {
              result[recordIndex] = item
            } else {
              delete item['new']
              delete item['id']
              item['createddate'] = new Date()
              result.push(item)
            }
          })
          dispatch(saveDTRequestSuccess(response.message, result));
          AlertSuccess(response.message)
        } else {
          dispatch(saveDTRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(saveDTRequest(false));
      })
      .catch(err => {
        dispatch(saveDTRequestFailure(err));
        dispatch(saveDTRequest(false));
      })
  }
}

const saveDTRequest = isSaveRequested => {
  return {
    type: actions.DOCUMENT_TRACKER_SAVE_REQUEST,
    isSaveRequested
  }
}

const saveDTRequestSuccess = (message, data) => {
  return {
    type: actions.DOCUMENT_TRACKER_SAVE_SUCCESS,
    message,
    data
  }
}

const saveDTRequestFailure = message => {
  return {
    type: actions.DOCUMENT_TRACKER_SAVE_FAILURE,
    message
  }
}

export const deleteDocTrackerRecords = (params) => {
  return (dispatch, getState) => {
    const { documentTrackerReducer: { result } } = getState()
    dispatch(saveDTRequest(true))
    return Api.delete(`/trip/deleteDocDtl`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(saveDTRequestSuccess('', []));
          const records = _.filter(result, (row) => !_.includes(_.map(params.selectedRecords, 'serial_no'), row.serial_no))
          dispatch(saveDTRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(saveDTRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(saveDTRequest(false));
      })
      .catch(err => {
        dispatch(saveDTRequestFailure(err));
        dispatch(saveDTRequest(false));
      })
  }
}