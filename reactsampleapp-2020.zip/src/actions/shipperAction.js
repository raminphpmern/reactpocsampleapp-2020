import * as actions from 'types/shipper.type';
import Api from 'lib/api';
import { e500 } from 'lib/messages';
import { AlertSuccess, AlertError } from 'lib/Alert'
import _ from 'lodash'

export const Success = (shipper) => {
  return {
    type: actions.CREATE_SHIPPER_SUCCESS,
    shipper: shipper
  }
}

export const Failure = (error) => {
  return {
    type: actions.CREATE_SHIPPER_FAILURE,
    message: error
  }
}

export const Request = (isLoading) => {
  return {
    type: actions.CREATE_SHIPPER_REQUEST,
    isLoading
  }
}

export const create = (data) => {
  return dispatch => {
    dispatch(Request(true));
    return Api.post('/shipper', data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          dispatch(Success(response.data));
        } else {
          dispatch(Failure(response.message));
          let message;
          if (response.error && response.error.code === 400) {
            message = JSON.parse(response.error.message)
            message = _.values(message).join(',')
          } else {
            message = response.message
          }
          AlertError(message)
        }
        dispatch(Request(false));
      })
      .catch((error) => {
        dispatch(Failure(e500));
        dispatch(Request(false));
      });
  }
}

export const initialize = () => {
  return {
    type: actions.CREATE_SHIPPER_INITIALIZE
  }
}

export const initializeForm = () => {
  return dispatch => {
    dispatch(initialize())
  }
}
