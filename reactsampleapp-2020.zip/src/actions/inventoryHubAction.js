
import Api from 'lib/api'
import * as types from 'types/inventoryHub.type'
import { AlertSuccess, AlertError } from 'lib/Alert'
import _ from 'lodash'

export const search = (values, pageNo, limit, isSearch) => {
  return (dispatch) => {
    dispatch(searchRequest(true))
    return Api.post(`/inventoryHub/search?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initialize())
          }
          dispatch(searchSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(searchFailure(response.message))
          AlertError(response.message)
        }
        dispatch(searchRequest(false))
      }).catch((err) => {
        dispatch(searchRequest(false))
        dispatch(searchFailure(err))
      })
  }
}

export const initializeIH = () => {
  return dispatch => {
    dispatch(initialize())
  }
}

const initialize = () => {
  return {
    type: types.IH_INITIALIZE
  }
}
const searchRequest = (isRequested) => {
  return {
    type: types.IH_FETCH_REQUEST,
    isRequested
  }
}

const searchSuccess = (data, totalPage, totalRecord, limit) => {
  return {
    type: types.IH_FETCH_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit
  }
}

const searchFailure = (message) => {
  return {
    type: types.IH_FETCH_FAILURE,
    message
  }
}

export const saveDiscrepancyRecords = (params) => {
  return (dispatch, getState) => {
    let { inventoryHubReducer: { moredetailsresult } } = getState()
    dispatch(discrepancyRequest(true))
    return Api.post(`/inventory/saveDiscrepancyDtl`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(discrepancyRequestSuccess('', []));
          _.each(response.result, (item) => {
            const recordIndex = _.findIndex(moredetailsresult, (row) => row.hub_dis_lineno === item.hub_dis_lineno)
            if (recordIndex >= 0) {
              moredetailsresult[recordIndex] = item
            } else {
              moredetailsresult.push(item)
            }
          })
          dispatch(discrepancyRequestSuccess(response.message, moredetailsresult));
          AlertSuccess(response.message)
        } else {
          dispatch(discrepancyRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(discrepancyRequest(false));
      })
      .catch(err => {
        dispatch(discrepancyRequestFailure(err));
        dispatch(discrepancyRequest(false));
      })
  }
}

const discrepancyRequest = isSaveRequested => {
  return {
    type: types.DISCREPANCY_RECORDS_SAVE_REQUEST,
    isSaveRequested
  }
}

const discrepancyRequestSuccess = (message, data) => {
  return {
    type: types.DISCREPANCY_RECORDS_SAVE_SUCCESS,
    message,
    data
  }
}

const discrepancyRequestFailure = message => {
  return {
    type: types.DISCREPANCY_RECORDS_SAVE_FAILURE,
    message
  }
}

export const getLastAttempts = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(lastAttemptRequest(true))
    return Api.get(`/inventory/lastAttempts?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(lastAttemptSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(lastAttemptFailure(response.message))
          AlertError(response.message)
        }
        dispatch(lastAttemptRequest(false))
      }).catch((err) => {
        dispatch(lastAttemptRequest(false))
        dispatch(lastAttemptFailure(err))
      })
  }
}

export const initializeLA = () => {
  return dispatch => {
    dispatch(initializeLastAttempt())
  }
}

const initializeLastAttempt = () => {
  return {
    type: types.IH_LAST_ATTEMPT_INITIALIZE
  }
}
const lastAttemptRequest = (isRequested) => {
  return {
    type: types.IH_LAST_ATTEMPT_REQUEST,
    isRequested
  }
}

const lastAttemptSuccess = (data, totalPage, totalRecord, limit) => {
  return {
    type: types.IH_LAST_ATTEMPT_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit
  }
}

const lastAttemptFailure = (message) => {
  return {
    type: types.IH_LAST_ATTEMPT_FAILURE,
    message
  }
}


export const getSerialNumbers = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(serialNoRequest(true))
    return Api.get(`/inventory/serialNumbers?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(serialNoSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(serialNoFailure(response.message))
          AlertError(response.message)
        }
        dispatch(serialNoRequest(false))
      }).catch((err) => {
        dispatch(serialNoRequest(false))
        dispatch(serialNoFailure(err))
      })
  }
}

export const initializeSN = () => {
  return dispatch => {
    dispatch(initializeSerialNo())
  }
}

const initializeSerialNo = () => {
  return {
    type: types.IH_SERIAL_NO_INITIALIZE
  }
}
const serialNoRequest = (isRequested) => {
  return {
    type: types.IH_SERIAL_NO_REQUEST,
    isRequested
  }
}

const serialNoSuccess = (data, totalPage, totalRecord, limit) => {
  return {
    type: types.IH_SERIAL_NO_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit
  }
}

const serialNoFailure = (message) => {
  return {
    type: types.IH_SERIAL_NO_FAILURE,
    message
  }
}

export const fetchDiscrepancyDetails = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(discrepancyDetailsRequest(true))
    return Api.get(`/inventory/discrepancyDetails?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(discrepancyDetailsSuccess(response.result, response.totalPage, response.totalRecord, response.serialNumbers))
          AlertSuccess(response.message)
        } else {
          dispatch(discrepancyDetailsFailure(response.message))
          AlertError(response.message)
        }
        dispatch(discrepancyDetailsRequest(false))
      }).catch((err) => {
        dispatch(discrepancyDetailsRequest(false))
        dispatch(discrepancyDetailsFailure(err))
      })
  }
}

export const initializeMD = () => {
  return dispatch => {
    dispatch(initializeDiscrepancyDetails())
  }
}

const initializeDiscrepancyDetails = () => {
  return {
    type: types.IH_DISCREPANCY_DETAILS_INITIALIZE
  }
}
const discrepancyDetailsRequest = (isRequested) => {
  return {
    type: types.IH_DISCREPANCY_DETAILS_REQUEST,
    isRequested
  }
}

const discrepancyDetailsSuccess = (data, totalPage, totalRecord, serialNumbers, limit) => {
  return {
    type: types.IH_DISCREPANCY_DETAILS_SUCCESS,
    data,
    totalPage,
    totalRecord,
    serialNumbers,
    limit
  }
}

const discrepancyDetailsFailure = (message) => {
  return {
    type: types.IH_DISCREPANCY_DETAILS_FAILURE,
    message
  }
}

export const buttonAction = (params, action) => {
  return (dispatch, getState) => {
    const { inventoryHubReducer } = getState();
    const result = inventoryHubReducer.result;
    dispatch(buttonActionRequest(true));
    return Api.post(`/inventory/${action}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          const values = params['selectedRows']
          let formattedResponse = []
          if (params['bay_type'] === 'Virtual') {
            formattedResponse = _.reduce(result, (arr, item) => {
              let ihItem = _.find(values, (v) => v.hmhid_thu_id === item.hmhid_thu_id)
              if (ihItem) {
                item = _.merge(item, ihItem)
                item.ccd_receipt_status = response.crStatus
              }
              arr.push(item)
              return arr;
            }, []);
          } else {
            formattedResponse = _.reduce(result, (arr, item) => {
              let ihItem = _.find(response.brInfo, (v) => v.ddh_reference_doc_no === item.ddh_reference_doc_no)
              if (ihItem) {
                item.return_br_id = ihItem.return_br_id
              }
              arr.push(item)
              return arr;
            }, []);
          }
          dispatch(buttonActionReset());
          dispatch(searchSuccess(formattedResponse, inventoryHubReducer.totalPage, inventoryHubReducer.totalRecord));
          AlertSuccess(response.message)
        } else {
          dispatch(buttonActionFailure(response.message));
          AlertError(response.message)
        }
        dispatch(buttonActionRequest(false));
      })
      .catch(err => {
        dispatch(buttonActionFailure(err));
        dispatch(buttonActionRequest(false));
      })
  }
}

const buttonActionRequest = isRequested => {
  return {
    type: types.IH_STATUS_UPDATE_REQUEST,
    isRequested
  };
}

const buttonActionFailure = (message) => {
  return {
    type: types.IH_STATUS_UPDATE_FAILURE,
    message
  };
};

const buttonActionReset = () => {
  return {
    type: types.IH_STATUS_UPDATE_RESET,
  }
}

export const updateRow = (row, updateKey) => {
  return (dispatch, getState) => {
    const { inventoryHubReducer } = getState();
    const result = inventoryHubReducer.result;
    const response = _.reduce(result, (arr, item) => {
      if (item.ccd_br_no === row.ccd_br_no) {
        _.merge(item, updateKey)
      }
      arr.push(item)
      return arr
    }, [])
    dispatch(searchSuccess(response, inventoryHubReducer.totalPage, inventoryHubReducer.totalRecord, inventoryHubReducer.limit))
  }
}


export const deleteDiscrepancy = (params) => {
  return (dispatch, getState) => {
    const { inventoryHubReducer: { moredetailsresult } } = getState()
    dispatch(discrepancyRequest(true))
    return Api.delete(`/inventory/deleteDiscrepancyDtl?hub_dis_linenos=${params.hub_dis_linenos}&transactionType=${params.transactionType}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(discrepancyRequestSuccess('', []));
          const records = _.filter(moredetailsresult, (row) => !_.includes(params.hub_dis_linenos, row.hub_dis_lineno))
          dispatch(discrepancyRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(discrepancyRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(discrepancyRequest(false));
      })
      .catch(err => {
        dispatch(discrepancyRequestFailure(err));
        dispatch(discrepancyRequest(false));
      })
  }
}