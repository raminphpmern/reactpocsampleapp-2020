import Api from 'lib/api'
import * as types from 'types/charges.type.js'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { apiErrorMsg } from 'lib/CommonHelper'
import _ from 'lodash'
import { initializeBooking } from 'actions/bookingActions';

export const create = (params, brId, status) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(createRequest(true))
    const updateStatus = status === 'Print & Confirmed' ? 'Confirmed' : status
    return Api.post(`/qbr/charges/${brId}?status=${updateStatus}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          if (response.data && response.data.tms_ccd_collections_cashreceipt_dtl)
            _.merge(response.data.tms_ccd_collections_cashreceipt_dtl, params)
          _.merge(bookingInfo, response.data)
          if (status === 'Confirmed') {
            _.merge(bookingInfo, { tms_br_booking_request_hdr: { br_status: 'Confirmed' } })
            dispatch(initializeBooking())
          } else {
            if (status === 'Print & Confirmed') {
              _.merge(bookingInfo, { tms_br_booking_request_hdr: { br_status: 'Confirmed' } })
            } else {
              _.merge(bookingInfo, response.data)
            }
          }
          dispatch(createSuccess(bookingInfo))
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      }).catch((err) => {
        console.log("Charges Actions -- create -- Error", err)
        dispatch(createRequest(false))
        dispatch(createFailure(err))
      })
  }
}

export const update = (params, brId, status) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(createRequest(true))
    const updateStatus = status === 'Print & Confirmed' ? 'Confirmed' : status
    return Api.put(`/qbr/charges/${brId}?status=${updateStatus}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          _.merge(response.data.tms_ccd_collections_cashreceipt_dtl, params)
          _.merge(bookingInfo, response.data)
          if (status === 'Confirmed') {
            _.merge(bookingInfo, { tms_br_booking_request_hdr: { br_status: 'Confirmed' } })
            dispatch(initializeBooking())
          } else {
            if (status === 'Print & Confirmed') {
              _.merge(bookingInfo, { tms_br_booking_request_hdr: { br_status: 'Confirmed' } })
            } else {
              _.merge(bookingInfo, response.data)
            }
          }
          dispatch(createSuccess(bookingInfo))
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      }).catch((err) => {
        console.log("Charges Actions -- create -- Error", err)
        dispatch(createRequest(false))
        dispatch(createFailure(err))
      })
  }
}

const createRequest = (isRequested) => {
  return {
    type: types.CREATE_CHARGES_REQUEST,
    isRequested
  }
}

const createSuccess = (data) => {
  return {
    type: types.CREATE_CHARGES_SUCCESS,
    data
  }
}

const createFailure = (msg) => {
  return {
    type: types.CREATE_CHARGES_FAILURE,
    msg
  }
}

export const getCalculatedCharges = (brId) => {
  return dispatch => {
    dispatch(calculateRequest(true));
    return Api.get(`/qbr/charges/compute/${brId}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(calculateSuccess(response.result, response.data))
        } else {
          dispatch(calculateFailure(response))
          AlertError(response.message)
        }
      })
      .catch((err) => {
        dispatch(calculateFailure(err))
        dispatch(calculateRequest(false));
      })
  }
}

const calculateRequest = (isRequested) => {
  return {
    type: types.CALCULATE_CHARGES_REQUEST,
    isRequested
  }
}

const calculateSuccess = (result, data) => {
  return {
    type: types.CALCULATE_CHARGES_SUCCESS,
    result,
    data
  }
}

const calculateFailure = (msg) => {
  return {
    type: types.CALCULATE_CHARGES_FAILURE,
    msg
  }
}