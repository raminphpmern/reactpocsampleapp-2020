import Api from 'lib/api.js'
import * as actions from 'types/booking.type.js'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { setValue, getValue, removeKey } from 'lib/LocalStorage'
import _ from 'lodash'
import history from 'routes/history';
import { isCurrentBranchCcm } from 'lib/CommonHelper'
import { BR_INITIALIZE } from "types/brHub.type";
import { inilailizeBROptions } from 'actions/masterAction';

export const search = (id, queryString, isRefresh) => {
  return (dispatch, getState) => {
    const { form: { CustomerDetailsForm } } = getState()
    dispatch(searchRequest(true));
    return Api.get(`/qbr/customer/search/${encodeURIComponent(id)}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let hasRecurring = response.result && response.result.tms_br_booking_request_hdr && response.result.tms_br_booking_request_hdr.br_recurring_flag
          let br_recurring_flag = 'N'
          if (hasRecurring) {
            br_recurring_flag = response.result.tms_br_booking_request_hdr.br_recurring_flag
            if (isCurrentBranchCcm() && br_recurring_flag === 'N') {
              AlertError("This booking can't be opened at this branch")
              history.push('/acceptance')
              return false;
            }
            if (!isCurrentBranchCcm() && br_recurring_flag === 'Y') {
              AlertError("This booking can't be opened at this branch")
              history.push('/acceptance')
              return false;
            }
          }
          if (isRefresh) {
            if (hasRecurring) {
              dispatch(changeRecurring(br_recurring_flag))
            }
            let currentStep = parseInt(getValue('currentStep'))
            let activeStep = parseInt(getValue('activeStep'))
            if (response.result.tms_ccd_collections_cashreceipt_dtl) {
              activeStep = 4
            } else if (response.result.document_attachments && response.result.document_attachments.length > 0) {
              activeStep = 3
            } else if (response.result.shipment_details && response.result.shipment_details.length > 0) {
              activeStep = 2
            } else {
              activeStep = 1
            }
            dispatch(refreshSearchSuccess(response.result, currentStep, activeStep, response.configResponse))
          } else {
            if (!queryString.includes('customer_ref_no')) {
              setValue('br_id', response.result.tms_br_booking_request_hdr.br_request_id)
              dispatch(searchSuccess(response.result, response.configResponse))
            } else {
              const existingHash = CustomerDetailsForm.values
              const shipmentDtl = existingHash['tms_brsd_shipment_details']
              let result = response.result
              result['customer_company_name'] = shipmentDtl.shipper_company_name
              if (shipmentDtl.brsd_from_country) {
                let hash = response.result['tms_brsd_shipment_details']
                hash['brsd_from_ship_point_id'] = shipmentDtl.brsd_from_ship_point_id
                hash['brsd_from_address_line1'] = shipmentDtl.brsd_from_address_line1
                hash['brsd_from_country'] = shipmentDtl.brsd_from_country
                hash['brsd_from_state'] = shipmentDtl.brsd_from_state
                hash['brsd_from_city'] = shipmentDtl.brsd_from_city
                hash['brsd_from_suburb'] = shipmentDtl.brsd_from_suburb
                hash['brsd_from_postal_code'] = shipmentDtl.brsd_from_postal_code
                hash['shipper_company_name'] = hash.shipper_company_name && hash.shipper_company_name.length > 0 ? hash.shipper_company_name : shipmentDtl.shipper_company_name
                result = _.merge(response.result, hash)
              }
              dispatch(searchSuccess(result, response.configResponse))
              dispatch(initializeCopy(result))
            }
            AlertSuccess(response.message)
          }
        } else {
          dispatch(searchFailure(response))
          AlertError(response.message)
        }
        dispatch(searchRequest(false));
      })
      .catch((err) => {
        dispatch(searchFailure(err))
        dispatch(searchRequest(false));
      })
  }
}

const refreshSearchSuccess = (data, currentStep, activeStep, configResponse) => {
  return {
    type: actions.BOOKING_REFRESH_SEARCH_SUCCESS,
    data,
    currentStep,
    activeStep,
    configResponse
  }
}

const searchRequest = (isSearching) => {
  return {
    type: actions.BOOKING_SEARCH_REQUEST,
    isSearching
  }
}

const searchSuccess = (data, configResponse) => {
  return {
    type: actions.BOOKING_SEARCH_SUCCESS,
    data,
    configResponse
  }
}

const searchFailure = (err) => {
  return {
    type: actions.BOOKING_SEARCH_FAILURE,
    message: err.message
  }
}

export const updateStep = (step) => {
  return dispatch => {
    setValue('currentStep', step)
    dispatch(setStep(step))
  }
}

const setStep = (step) => {
  return {
    type: actions.BOOKING_STEP_CHANGE,
    step
  }
}

export const initializeBooking = () => {
  removeKey('br_id')
  removeKey('orders')
  removeKey('charges')
  setValue('currentStep', 1)
  let recurring = isCurrentBranchCcm() ? 'Y' : 'N'
  return dispatch => {
    dispatch(initialize(recurring))
    dispatch(initializeBrRecords())
    dispatch(inilailizeBROptions())
  }
}

export const initialize = (recurring) => {
  return {
    type: actions.BOOKING_INITIALIZE,
    recurring
  }
}

const initializeBrRecords = () => {
  return {
    type: BR_INITIALIZE
  }
}


export const initializeCopyBooking = () => {
  removeKey('br_id')
  setValue('currentStep', 1)
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
    delete bookingInfo['tms_ccd_collections_cashreceipt_dtl']
    delete bookingInfo['certificate_detail']
    delete bookingInfo['disbursement_detail']
    delete bookingInfo['tms_ddh_dispatch_document_hdr']
    delete bookingInfo['tracking_no']
    delete bookingInfo['cod_cop_amount']
    delete bookingInfo['cd_declared_value_of_goods']
    delete bookingInfo['ethu_tracking_no']

    if (bookingInfo['tms_br_booking_request_hdr']) {
      delete bookingInfo['tms_br_booking_request_hdr']['br_consign_note']
      delete bookingInfo['tms_br_booking_request_hdr']['br_request_id']
      delete bookingInfo['tms_br_booking_request_hdr']['br_declared_value']
      delete bookingInfo['tms_br_booking_request_hdr']['br_promo_code']
      delete bookingInfo['tms_br_booking_request_hdr']['br_promo_dis_amount']
    }

    bookingInfo['shipment_details'] = []
    bookingInfo['content_details'] = []
    bookingInfo['document_attachments'] = []
    bookingInfo['tms_brvd_booking_request_vas_details'] = []

    dispatch(initializeCopy(bookingInfo))
  }
}


export const initializeCopy = (bookingInfo) => {
  return {
    type: actions.COPY_BOOKING_INITIALIZE,
    copyBooking: bookingInfo
  }
}

export const updateBrStatus = (data) => {
  return {
    type: actions.BOOKING_SEARCH_SUCCESS,
    data
  }
}

export const changeRecurring = data => {
  return dispatch => {
    dispatch(Recurring(data));
  };
};

export const Recurring = data => {
  return {
    type: actions.CHANGE_RECURRING,
    data
  };
};