import Api from "lib/api";
import * as actions from "types/brHub.type";
import _ from 'lodash'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { updateBrStatus } from 'actions/bookingActions'
import history from 'routes/history';
import { pendingTask, begin, end } from 'react-redux-spinner';

export const search = (data, pageNo, limit) => {
  return dispatch => {
    dispatch(searchRequest(true));
    return Api.post(`/br/search?pageNo=${pageNo}&limit=${limit}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchSuccess(response, limit));
          AlertSuccess(response.message)
        } else {
          dispatch(searchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(searchRequest(false));
      })
      .catch(err => {
        console.log("brHubActions -- search ", err);
        dispatch(searchFailure(err));
        dispatch(searchRequest(false));
      });
  };
};

export const brActions = (ids, values, action, actionType) => {
  return (dispatch, getState) => {
    const { brhubReducer, bookingReducer } = getState();
    const result = brhubReducer.result;
    dispatch(statusRequest(true));
    return Api.post(`/br/${action}`, { brIds: ids, ...values })
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (!response.brStatus) {
            AlertError(response.message)
            return;
          }
          const responseStatus = response.brStatus.wms_code_desc
          if (actionType === 'BR') {
            let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
            _.merge(bookingInfo, { tms_br_booking_request_hdr: { br_status: responseStatus } })
            dispatch(updateBrStatus(bookingInfo))
          } else {
            dispatch(statusReset());
            const data = _.reduce(result, (arr, item) => {
              if (ids.includes(item.br_request_id)) {
                item.brstatus = responseStatus
                if (action === 'reject' || action === 'void') {
                  item.br_original_br_id = null
                }
              }
              arr.push(item)
              return result;
            }, []);
            dispatch(statusSuccess(data));
          }
          AlertSuccess(response.message)
        } else {
          dispatch(statusFailure(response.message));
          AlertError(response.message)
        }
        dispatch(statusRequest(false));
      })
      .catch(err => {
        console.log("brHub status update--- ", err);
        dispatch(statusFailure(err));
        dispatch(statusRequest(false));
      })

  }
}

const searchRequest = isRequested => {
  return {
    type: actions.BRHUB_FETCH_REQUEST,
    [pendingTask]: isRequested ? begin : end,
    isRequested
  };
};

const searchSuccess = (data, limit) => {
  return {
    type: actions.BRHUB_FETCH_SUCCESS,
    data,
    limit
  };
};

const searchFailure = msg => {
  return {
    type: actions.BRHUB_FETCH_FAILURE,
    msg
  };
};

const statusRequest = isRequested => {
  return {
    type: actions.BRHUB_ACTION_REQUEST,
    isRequested
  };
}

const statusSuccess = (data) => {
  return {
    type: actions.BRHUB_ACTION_SUCCESS,
    result: data
  };
};

const statusFailure = msg => {
  return {
    type: actions.BRHUB_ACTION_FAILURE,
    msg
  };
};

const statusReset = () => {
  return {
    type: actions.BRHUB_ACTION_RESET,
  }
}

export const initializeBR = () => {
  return dispatch => {
    if (!history.location.pathname.includes('/acceptance/')) {
      dispatch(initialize())
    } else {
      dispatch(function () {
        return false
      })
    }
  }
}

const initialize = () => {
  return {
    type: actions.BR_INITIALIZE
  }
}