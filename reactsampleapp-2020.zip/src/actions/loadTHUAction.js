
import Api from 'lib/api'
import * as types from 'types/loadTHU.type'
import { AlertSuccess, AlertError } from 'lib/Alert'

export const save = (params) => {
  return (dispatch) => {
    dispatch(saveLoadTHURecordsRequest(true))
    return Api.post(`/loadTHU/save`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(saveLoadTHURecordsSuccess(response.message));
          AlertSuccess(response.message)
        } else {
          dispatch(saveLoadTHURecordsFailure(response));
          AlertError(response.message)
        }
        dispatch(saveLoadTHURecordsRequest(false));
      })
      .catch(err => {
        dispatch(saveLoadTHURecordsFailure(err));
        dispatch(saveLoadTHURecordsRequest(false));
      })
  }
}

const saveLoadTHURecordsRequest = isSaveRequested => {
  return {
    type: types.LOADTHU_RECORDS_SAVE_REQUEST,
    isSaveRequested
  }
}

const saveLoadTHURecordsSuccess = (message, data) => {
  return {
    type: types.LOADTHU_RECORDS_SAVE_SUCCESS,
    message,
    data
  }
}

const saveLoadTHURecordsFailure = message => {
  return {
    type: types.LOADTHU_RECORDS_SAVE_FAILURE,
    message
  }
}
