import Api from 'lib/api';
import * as types from 'types/searchTemplate.type';
import { AlertSuccess, AlertError } from 'lib/Alert';
import _ from 'lodash';

export const fetchAll = (templateType) => {
  return (dispatch) => {
    dispatch(fetchRequest(true));
    return Api.get(`/searchTemplate/${templateType}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(fetchSuccess(response.result));
        } else {
          dispatch(fetchFailure(response.message));
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const create = (params) => {
  return (dispatch, getState) => {
    dispatch(fetchRequest(true));
    const { searchTemplateReducer } = getState();
    return Api.post(`/searchTemplate`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let { templates } = searchTemplateReducer;
          templates.push(response.data[0])
          dispatch(fetchSuccess(templates));
          AlertSuccess(response.message);
        } else {
          dispatch(fetchFailure(response.message));
          AlertError(response.message);
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const update = (params, guid) => {
  return (dispatch, getState) => {
    dispatch(fetchRequest(true));
    const { searchTemplateReducer } = getState();
    return Api.put(`/searchTemplate/${guid}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          const updatedTemplate = response.data[0]
          let { templates } = searchTemplateReducer;
          templates = _.reduce(templates, (arr, template) => {
            if (template.value === updatedTemplate.value) {
              template = updatedTemplate
            }
            arr.push(template)
            return arr
          }, [])
          dispatch(fetchSuccess(templates));
          AlertSuccess(response.message);
        } else {
          dispatch(fetchFailure(response.message));
          AlertError(response.message);
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const fetchRequest = isLoading => {
  return {
    type: types.SEARCH_TEMPLATE_FETCH_REQUEST,
    isLoading
  };
};


export const fetchSuccess = (data) => {
  return {
    type: types.SEARCH_TEMPLATE_FETCH_SUCCESS,
    data
  };
};

export const fetchFailure = err => {
  return {
    type: types.SEARCH_TEMPLATE_FETCH_FAILURE,
    err
  };
};
