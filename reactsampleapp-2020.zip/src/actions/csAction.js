import Api from 'lib/api'
import * as types from 'types/cs.type'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { pendingTask, begin, end } from 'react-redux-spinner'
import _ from 'lodash'

export const search = (values, pageNo, limit, isSearch) => {
  return (dispatch) => {
    dispatch(searchRequest(true))
    return Api.post(`/cs/search?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initialize())
          }
          dispatch(searchSuccess(response.result, response.totalPage, response.totalRecord, limit))
          AlertSuccess(response.message)
        } else {
          dispatch(searchFailure(response.message))
          AlertError(response.message)
        }
        dispatch(searchRequest(false))
      }).catch((err) => {
        dispatch(searchRequest(false))
        dispatch(searchFailure(err))
      })
  }
}

export const initializeCS = () => {
  return dispatch => {
    dispatch(initialize())
  }
}

const initialize = () => {
  return {
    type: types.CS_INITIALIZE
  }
}


const searchRequest = (isRequested) => {
  return {
    type: types.CS_FETCH_REQUEST,
    [pendingTask]: isRequested ? begin : end,
    isRequested
  }
}

const searchSuccess = (data, totalPage, totalRecord, limit) => {
  return {
    type: types.CS_FETCH_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit,
  }
}

const searchFailure = (message) => {
  return {
    type: types.CS_FETCH_FAILURE,
    message
  }
}

export const buttonAction = (params, action) => {
  return (dispatch, getState) => {
    const { csReducer } = getState();
    const result = csReducer.result;
    dispatch(buttonActionRequest(true));
    return Api.post(`/cs/${action}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          const values = params['ccd_receipt']
          const formattedResponse = _.reduce(result, (arr, item) => {
            let brItem = _.find(values, (v) => v.ccd_br_no === item.ccd_br_no)
            if (brItem) {
              item = _.merge(item, brItem)
              item.ccd_receipt_status = response.crStatus
            }
            arr.push(item)
            return arr;
          }, []);
          dispatch(buttonActionReset());
          dispatch(searchSuccess(formattedResponse, csReducer.totalPage, csReducer.totalRecord, csReducer.limit));
          AlertSuccess(response.message)
        } else {
          dispatch(buttonActionFailure(response.message));
          AlertError(response.message)
        }
        dispatch(buttonActionRequest(false));
      })
      .catch(err => {
        dispatch(buttonActionFailure(err));
        dispatch(buttonActionRequest(false));
      })

  }
}

const buttonActionRequest = isRequested => {
  return {
    type: types.CS_STATUS_UPDATE_REQUEST,
    isRequested
  };
}

const buttonActionFailure = (message) => {
  return {
    type: types.CS_STATUS_UPDATE_FAILURE,
    message
  };
};

const buttonActionReset = () => {
  return {
    type: types.CS_STATUS_UPDATE_RESET,
  }
}

export const updateRow = (row, updateKey) => {
  return (dispatch, getState) => {
    const { csReducer } = getState();
    const result = csReducer.result;
    const response = _.reduce(result, (arr, item) => {
      if (item.ccd_br_no === row.ccd_br_no) {
        _.merge(item, updateKey)
      }
      arr.push(item)
      return arr
    }, [])
    dispatch(searchSuccess(response, csReducer.totalPage, csReducer.totalRecord, csReducer.limit))
  }
}

export const resetData = (rows) => {
  return (dispatch, getState) => {
    const { csReducer } = getState();
    dispatch(searchSuccess(rows, csReducer.totalPage, csReducer.totalRecord, csReducer.limit))
  }
}

export const searchReceipt = (values, pageNo, limit, isSearch) => {
  return (dispatch) => {
    dispatch(receiptSearchRequest(true))
    return Api.post(`/cshelp/receiptNoSearch?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initialize())
          }
          dispatch(receiptSearchSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(receiptSearchFailure(response.message))
          AlertError(response.message)
        }
        dispatch(receiptSearchRequest(false))
      }).catch((err) => {
        dispatch(receiptSearchRequest(false))
        dispatch(receiptSearchFailure(err))
      })
  }
}

export const initializeReceipt = () => {
  return dispatch => {
    dispatch(initializeReceiptNo())
  }
}

const initializeReceiptNo = () => {
  return {
    type: types.CS_RECEIPT_INITIALIZE
  }
}

const receiptSearchRequest = (isRequested) => {
  return {
    type: types.CS_RECEIPT_REQUEST,
    isRequested
  }
}

const receiptSearchSuccess = (data, totalPage, totalRecord) => {
  return {
    type: types.CS_RECEIPT_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const receiptSearchFailure = (message) => {
  return {
    type: types.CS_RECEIPT_FAILURE,
    message
  }
}

export const searchEmployeeId = (values, pageNo, limit, isSearch) => {
  return (dispatch) => {
    dispatch(employeeSearchRequest(true))
    return Api.post(`/cshelp/employeeIdSearch?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initialize())
          }
          dispatch(employeeSearchSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(employeeSearchFailure(response.message))
          AlertError(response.message)
        }
        dispatch(employeeSearchRequest(false))
      }).catch((err) => {
        dispatch(employeeSearchRequest(false))
        dispatch(employeeSearchFailure(err))
      })
  }
}

export const initializeEMP = () => {
  return dispatch => {
    dispatch(initializeEmployee())
  }
}

const initializeEmployee = () => {
  return {
    type: types.CS_EMP_INITIALIZE
  }
}

const employeeSearchRequest = (isRequested) => {
  return {
    type: types.CS_EMPLOYEE_REQUEST,
    isRequested
  }
}

const employeeSearchSuccess = (data, totalPage, totalRecord) => {
  return {
    type: types.CS_EMPLOYEE_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const employeeSearchFailure = (message) => {
  return {
    type: types.CS_EMPLOYEE_FAILURE,
    message
  }
}
