import Api from "lib/api";
import * as actions from "types/updateResource.type";
import { AlertSuccess, AlertError } from 'lib/Alert'

export const getResourceDtl = (tripId, queryString, limit) => {
  return (dispatch) => {
    dispatch(resourceRequest(true));
    return Api.get(`/tripLogs/fetchresource/${encodeURIComponent(tripId)}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(resourceSuccess(response, limit));
          AlertSuccess(response.message)
        } else {
          dispatch(resourceFailure(response.message));
          AlertError(response.message)
        }
        dispatch(resourceRequest(false));
      })
      .catch(err => {
        console.log("tripAttachmentAction -- search ", err);
        dispatch(resourceFailure(err));
        dispatch(resourceRequest(false));
      });
  };
};

const resourceRequest = isRequested => {
  return {
    type: actions.TRIP_RESOURCE_FETCH_REQUEST,
    isRequested
  };
};

const resourceSuccess = (data, limit) => {
  return {
    type: actions.TRIP_RESOURCE_FETCH_SUCCESS,
    ...data,
    limit,
  };
};

const resourceFailure = msg => {
  return {
    type: actions.TRIP_RESOURCE_FETCH_FAILURE,
    msg
  };
};

export const getTypeOptions = (type,queryString) => {
  return (dispatch) => {
    dispatch(resoptionsRequest(true));
    return Api.get(`/tripLogs/fetchresource/typeOptions?type=${type}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(resoptionsSuccess(response.result));
        } else {
          AlertError(response.message)
        }
        dispatch(resoptionsRequest(false));
      })
      .catch(err => {
        console.log("updateResourceAction -- options ", err);
        dispatch(resoptionsRequest(false));
      });
  };
};

const resoptionsRequest = isRequested => {
  return {
    type: actions.TRIP_RES_OPTIONS_FETCH_REQUEST,
    isRequested
  };
};

const resoptionsSuccess = (typeOptions) => {
  return {
    type: actions.TRIP_RES_OPTIONS_FETCH_SUCCESS,
    typeOptions,
  };
};

export const saveTripResources = (tripId, params,queryString) => {
  return (dispatch, getState) => {
    const { updateResourceReducer } = getState();
    let attachments = updateResourceReducer.attachments
    dispatch(resourceRequest(true));
    return Api.post(`/tripLogs/fetchresource/${encodeURIComponent(tripId)}?${queryString}`,params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(attachmentsSaveSuccess([]));        
          dispatch(attachmentsSaveSuccess(attachments));
          AlertSuccess(response.message)
        } else {
          dispatch(resourceFailure(response.message));
          AlertError(response.message)
        }
        dispatch(resourceRequest(false));
      })
      .catch(err => {
        console.log("tripAttachmentAction -- save ", err);
        dispatch(resourceFailure(err));
        dispatch(resourceRequest(false));
      });
  };
};

export const deleteTripResources = (tripId,params,queryString) => {
  return (dispatch, getState) => {
    const { updateResourceReducer } = getState();
    let attachments = updateResourceReducer.attachments;
    dispatch(resourceRequest(true));
    return Api.delete(`/tripLogs/fetchresource/${encodeURIComponent(tripId)}?${queryString}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(attachmentsSaveSuccess([])); 
          dispatch(attachmentsSaveSuccess(attachments));
          AlertSuccess(response.message)
        } else {
          dispatch(resourceFailure(response.message));
          AlertError(response.message)
        }
        dispatch(resourceRequest(false));
      })
      .catch(err => {
        console.log("tripAttachmentAction -- delete ", err);
        dispatch(resourceFailure(err));
        dispatch(resourceRequest(false));
      });
  };
};

const attachmentsSaveSuccess = (attachments) => {
  return {
    type: actions.TRIP_RESOURCE_SAVE_SUCCESS,
    attachments
  };
}
