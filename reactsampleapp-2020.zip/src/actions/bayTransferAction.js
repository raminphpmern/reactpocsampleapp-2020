import Api from "lib/api";
import * as actions from "types/bayTransfer.type"
import { AlertSuccess, AlertError } from 'lib/Alert'
import _ from 'lodash';

export const scanDispatchDocumentId = (action, data) => {
  return (dispatch, getState) => {
    const { bayTransferReducer } = getState();
    const result = bayTransferReducer.result;
    dispatch(getDispatchDocumentIdRequest(true));
    return Api.post(`/hub/bayTransfer/${action}`, data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (action === 'save') {
            dispatch(saveBayTransfer(response.result));
            AlertSuccess(response.message)
          }
          if (action === 'confirm') {
            dispatch(confirmBayTransfer(response.result));
            AlertSuccess(response.message)
          }
          if (action === 'dispatch') {
            let responseData = {};
            responseData = result.concat(response.result)
            dispatch(getDispatchDocumentIdSuccess(responseData));
            AlertSuccess(response.message)
          }
        } else {
          dispatch(getDispatchDocumentIdFailure(response.message));
          AlertError(response.message)
        }
        dispatch(getDispatchDocumentIdRequest(false));
      })
      .catch(err => {
        dispatch(getDispatchDocumentIdFailure(err));
        dispatch(getDispatchDocumentIdRequest(false));
      });
  };
};

const getDispatchDocumentIdRequest = isRequested => {
  return {
    type: actions.DISPATCH_DOCUMENT_SCAN_REQUEST,
    isRequested
  }
}

const saveBayTransfer = (result, msg) => {
  return {
    type: actions.SAVE_BAY_TRANSFER_SUCCESS,
    result,
    msg
  }
}

const confirmBayTransfer = (result, msg) => {
  return {
    type: actions.CONFIRM_BAY_TRANSFER_SUCCESS,
    result,
    msg
  }
}

const getDispatchDocumentIdSuccess = (result, msg) => {
  return {
    type: actions.DISPATCH_DOCUMENT_SCAN_SUCCESS,
    result,
    msg
  }
}

const getDispatchDocumentIdFailure = (msg, status) => {
  return {
    type: actions.DISPATCH_DOCUMENT_SCAN_FAILURE,
    msg,
    status
  }
}

export const getFieldDetails = (action, queryString, stateName) => {
  return (dispatch, getState) => {
    const { hubReceiptLoadReducer } = getState();
    const options = hubReceiptLoadReducer.options;
    dispatch(fetchRequest(true));
    return Api.get(`/hub/bayTransfer/${action}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.data;
          } else {
            responseData[action] = response.data;
          }
          dispatch(fetchSuccess(responseData, options, false));
        } else {
          dispatch(fetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const fetchRequest = isRequested => {
  return {
    type: actions.OPTIONS_FETCH_REQUEST,
    isRequested
  };
};

export const fetchSuccess = (data, existingState, isMerge) => {
  _.map(data, (value, key) => {
    existingState[key] = isMerge ? existingState[key].concat(value) : value;
  });

  data = existingState;
  return {
    type: actions.OPTIONS_FETCH_SUCCESS,
    data: data
  };
};

export const fetchFailure = err => {
  return {
    type: actions.OPTIONS_FETCH_FAILURE,
    err
  };
};

export const resetRecords = () => {
  return {
    type: actions.RESET_BAY_TRANSFER_RECORDS,
  }
}

export const deleteBtRecords = (params) => {
  return (dispatch, getState) => {
    const { bayTransferReducer: { result } } = getState()
    dispatch(deleteBtRequest(true))
    return Api.delete(`/hub/bayTransfer/delete`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(deleteBtRequestSuccess('', []));
          const records = _.filter(result, (data) => !((params.hmhid_despatch_doc_no.includes(data.hmhid_despatch_doc_no) && (params.hmhid_serialno.includes(data.hmhid_serialno)))))
          dispatch(deleteBtRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(deleteBtRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(deleteBtRequest(false));
      })
      .catch(err => {
        dispatch(deleteBtRequestFailure(err));
        dispatch(deleteBtRequest(false));
      })
  }
}

const deleteBtRequest = isDeleteRequested => {
  return {
    type: actions.OPTIONS_FETCH_REQUEST,
    isDeleteRequested
  }
}

const deleteBtRequestSuccess = (message, result) => {
  return {
    type: actions.DISPATCH_DOCUMENT_SCAN_SUCCESS,
    message,
    result
  }
}

const deleteBtRequestFailure = message => {
  return {
    type: actions.DISPATCH_DOCUMENT_SCAN_FAILURE,
    message
  }
}