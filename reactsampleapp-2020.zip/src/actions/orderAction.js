import Api from 'lib/api'
import * as types from 'types/order.type.js'
import { setValue, getValue } from 'lib/LocalStorage'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { apiErrorMsg } from 'lib/CommonHelper'
import _ from 'lodash'
import { updateStep } from 'actions/bookingActions';

export const create = (params, step, brId) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(createRequest(true))
    return Api.post(`/qbr/order/${brId}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          _.merge(bookingInfo, response.data)
          dispatch(createSuccess(bookingInfo, step, step))
          setValue('activeStep', step)
          setValue('currentStep', step)
          AlertSuccess(response.message)
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      }).catch((err) => {
        dispatch(createFailure(err))
      })
  }
}

export const update = (params, step, brId) => {
  if (params && params.tms_br_booking_request_hdr && params.tms_br_booking_request_hdr.br_status !== 'Incomplete') {
    return dispatch => {
      dispatch(updateStep(step))
    }
  } else {
    return (dispatch, getState) => {
      const { bookingReducer } = getState();
      dispatch(createRequest(true))
      return Api.put(`/qbr/order/${brId}`, params)
        .then(response => response.json())
        .then(response => {
          if (response.status === 200) {
            let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
            delete bookingInfo['tracking_no']
            delete bookingInfo['ethu_tracking_no']
            _.merge(bookingInfo, response.data)
            let activeStep = parseInt(getValue('activeStep'))
            if (activeStep < 4) {
              setValue('activeStep', step)
              setValue('currentStep', step)
            } else {
              setValue('currentStep', parseInt(getValue('currentStep')) > step ? parseInt(getValue('currentStep')) : step)
            }
            let currentStep = parseInt(getValue('currentStep'))
            dispatch(createSuccess(bookingInfo, activeStep, currentStep))
            AlertSuccess(response.message)
          } else {
            dispatch(createFailure(response.message))
            AlertError(apiErrorMsg(response))
          }
          dispatch(createRequest(false))
        }).catch((err) => {
          dispatch(createFailure(err))
        })
    }
  }
}

export const compute = (params, brId) => {
  return (dispatch) => {
    dispatch(computeRequest(true))
    return Api.post(`/qbr/order/compute/${brId}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          AlertSuccess(response.message)
          dispatch(computeSuccess(response.calculatedTariff.result, response.calculatedTariff.data, response.contract))
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      }).catch((err) => {
        dispatch(createFailure(err))
      })
  }
}

const createRequest = (isRequested) => {
  return {
    type: types.CREATE_ORDER_REQUEST,
    isRequested
  }
}

const computeRequest = (isRequested) => {
  return {
    type: types.V_SHIPMENT_REQUEST,
    isRequested
  }
}
const computeSuccess = (result, data, contract) => {
  return {
    type: types.V_SHIPMENT_SUCCESS,
    contract: contract,
    result: result,
    data: data
  }
}
const createSuccess = (data, activeStep, currentStep) => {
  return {
    type: types.CREATE_ORDER_SUCCESS,
    data,
    activeStep,
    currentStep
  }
}

const createFailure = (msg) => {
  return {
    type: types.CREATE_ORDER_FAILURE,
    msg
  }
}

const validateTrackingNoCompleted = (isValid) => {
  return {
    type: types.PREPRINTED_DOC_NUMBER_IS_VALID,
    isValid
  }
}

export const validateTrackingNo = (trackingNo, brId, custId) => {
  return dispatch => {
    dispatch(createRequest(true))
    dispatch(validateTrackingNoCompleted(true))
    return Api.get(`/qbr/order/preprint/validate/${brId}?tracking_no=${trackingNo}&custId=${custId}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(validateTrackingNoCompleted(true))
          AlertSuccess(response.message)
        } else {
          dispatch(validateTrackingNoCompleted(false))
          AlertError(response.message)
        }
        dispatch(createRequest(false))
      }).catch((err) => {
        dispatch(createFailure(err))
      })
  }
}

const validateEthuNoCompleted = (data, isValid) => {
  return {
    type: types.ETHU_VALID,
    isValid,
    data
  }
}

export const validateEthuNo = (serialNo, custId, serviceType) => {
  return dispatch => {
    dispatch(createRequest(true))
    dispatch(validateEthuNoCompleted([], true))
    return Api.get(`/qbr/order/ethu/validate/${custId}?serial_no=${serialNo}&service_type=${encodeURIComponent(serviceType)}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(validateEthuNoCompleted(response.data, true))
          AlertSuccess(response.message)
        } else {
          dispatch(validateEthuNoCompleted([], false))
          AlertError(response.message)
        }
        dispatch(createRequest(false))
      }).catch((err) => {
        dispatch(createFailure(err))
      })
  }
}


export const getUom = (country) => {
  return dispatch => {
    dispatch(uomSearchRequest(true))
    return Api.get(`/qbr/order/uom?country=${country}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(uomSearchSuccess(response.result, response.totalPage, response.totalRecord))
        }
        else {
          dispatch(uomSearchFailure(response.message))
        }
        dispatch(uomSearchRequest(false))
      }).catch((err) => {
        dispatch(uomSearchRequest(false))
        dispatch(uomSearchFailure(err))
      })
  }
}

const uomSearchRequest = (isRequested) => {
  return {
    type: types.UOM_FETCH_REQUEST,
    isRequested
  }
}

const uomSearchSuccess = (data) => {
  return {
    type: types.UOM_FETCH_SUCCESS,
    data
  }
}

const uomSearchFailure = (message) => {
  return {
    type: types.UOM_FETCH_FAILURE,
    message
  }
}

export const validateChildThuId = (childThu, custId) => {
  return dispatch => {
    dispatch(validateChildThuRequest(true))
    return Api.get(`/qbr/order/ethu/validate/${custId}?serial_no=${childThu}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(validateChildThuSuccess(true))
          AlertSuccess(response.message)
        } else {
          dispatch(validateChildThuError())
          AlertError(response.message)
        }
      }).catch((err) => {
        dispatch(validateChildThuError(false, err))
      })
  }
}

const validateChildThuRequest = () => {
  return {
    type: types.CHILD_THU_REQUEST,
  }
}

const validateChildThuSuccess = (isValid) => {
  return {
    type: types.CHILD_THU_VALID,
    isValid,
  }
}

const validateChildThuError = (msg) => {
  return {
    type: types.CHILD_THU_INVALID,
    msg
  }
}