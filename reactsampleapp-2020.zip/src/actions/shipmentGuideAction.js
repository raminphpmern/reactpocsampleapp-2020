import Api from 'lib/api'
import * as types from 'types/shipmentGuide.type'
import { AlertSuccess, AlertError } from 'lib/Alert'
import _ from 'lodash'

export const profileId = (values, pageNo, limit, isSearch) => {
  return (dispatch) => {
    dispatch(profileSearchRequest(true))
    return Api.post(`/shipmentGuide/profileIdSearch?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initializePRO())
          }
          dispatch(profileSearchSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(profileSearchFailure(response.message))
          AlertError(response.message)
        }
        dispatch(profileSearchRequest(false))
      }).catch((err) => {
        dispatch(profileSearchRequest(false))
        dispatch(profileSearchFailure(err))
      })
  }
}

export const initializePRO = () => {
  return dispatch => {
    dispatch(initializeProfile())
  }
}

const initializeProfile = () => {
  return {
    type: types.PROFILE_INITIALIZE
  }
}

const profileSearchRequest = (isRequested) => {
  return {
    type: types.PROFILE_REQUEST,
    isRequested
  }
}

const profileSearchSuccess = (data, totalPage, totalRecord) => {
  return {
    type: types.PROFILE_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const profileSearchFailure = (message) => {
  return {
    type: types.PROFILE_FAILURE,
    message
  }
}
export const fetchShipmentDetails = (values, pageNo, limit, isSearch) => {
  return (dispatch) => {
    dispatch(shipmentDetailsRequest(true))
    return Api.post(`/shipmentGuide/fetchShipmentDetails?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initializeSH())
          }
          dispatch(shipmentDetailsSuccess(response.result, response.totalPage, response.totalRecord, limit, response.dph_description, response.dph_profile_id))
          AlertSuccess(response.message)
        } else {
          dispatch(shipmentDetailsFailure(response.message))
          AlertError(response.message)
        }
        dispatch(shipmentDetailsRequest(false))
      }).catch((err) => {
        dispatch(shipmentDetailsRequest(false))
        dispatch(shipmentDetailsFailure(err))
      })
  }
}

export const initializeSH = () => {
  return dispatch => {
    dispatch(initializeShipmentDetails())
  }
}

const initializeShipmentDetails = () => {
  return {
    type: types.SHIPMENT_DETAILS_INITIALIZE
  }
}
const shipmentDetailsRequest = (isRequested) => {
  return {
    type: types.SHIPMENT_DETAILS_REQUEST,
    isRequested
  }
}

const shipmentDetailsSuccess = (data, totalPage, totalRecord, limit, dph_description, dph_profile_id) => {
  return {
    type: types.SHIPMENT_DETAILS_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit,
    dph_description,
    dph_profile_id,
  }
}

const shipmentDetailsFailure = (message) => {
  return {
    type: types.SHIPMENT_DETAILS_FAILURE,
    message
  }
}

export const getProfileIdSearch = (queryString, stateName) => {
  return (dispatch, getState) => {
    const { shipmentGuideReducer } = getState();
    const options = shipmentGuideReducer.options;
    dispatch(fetchRequest(true));
    return Api.get(`/shipmentGuide/getProfileId/?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.result;
          }
          dispatch(fetchSuccess(responseData, options, false));
        } else {
          dispatch(fetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const getGeoType = (values) => {
  return dispatch => {
    dispatch(searchDropdownRequest(true));
    return Api.get(`/shipmentGuide/getGeoType`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(searchGeoTypeSuccess(response.result))
        } else {
          dispatch(searchDropdownFailure(response.message));
        }
        dispatch(searchDropdownRequest(false));
      })
      .catch(err => {
        console.log("GeoType -- search ", err);
        dispatch(searchDropdownFailure(err));
        dispatch(searchDropdownRequest(false));
      });
  };
};

const getValidateDropdown = (action, queryString, stateName) => {
  return (dispatch, getState) => {
    const { shipmentGuideReducer } = getState();
    const options = shipmentGuideReducer.options;
    dispatch(fetchRequest(true));
    return Api.get(`/shipmentGuide/${action}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.result;
          } else {
            responseData[action] = response.result;
          }
          dispatch(fetchSuccess(responseData, options, false));
        } else {
          dispatch(fetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

const searchDropdownRequest = (isRequested) => {
  return {
    type: types.PROFILE_DROPDOWN_REQUEST,
    isRequested
  }
}

const searchDropdownFailure = (message) => {
  return {
    type: types.PROFILE_DROPDOWN_FAILURE,
    message
  }
}

const searchGeoTypeSuccess = (data) => {
  return {
    type: types.PROFILE_GEOTYPE_SUCCESS,
    data
  }
}

export const fetchRequest = isRequested => {
  return {
    type: types.OPTIONS_FETCH_REQUEST,
    isRequested
  };
};

export const fetchSuccess = (data, existingState, isMerge) => {
  _.map(data, (value, key) => {
    existingState[key] = isMerge ? existingState[key].concat(value) : value;
  });

  data = existingState;
  return {
    type: types.OPTIONS_FETCH_SUCCESS,
    data: data
  };
};

export const fetchFailure = err => {
  return {
    type: types.OPTIONS_FETCH_FAILURE,
    err
  };
};

export const getValidateDetatils = getValidateDropdown;