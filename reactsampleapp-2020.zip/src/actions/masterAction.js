import Api from "lib/api";
import * as types from "types/master.type";
import { AlertError } from "lib/Alert";
import _ from "lodash";

const search = (action, queryString, stateName) => {
  return (dispatch, getState) => {
    const { masterReducer } = getState();
    const options = masterReducer.options;
    dispatch(fetchRequest(true));
    return Api.get(`/search/${action}?${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          if (stateName) {
            responseData[stateName] = response.result;
          } else {
            responseData[action] = response.result;
          }
          dispatch(fetchSuccess(responseData, options, false));
        } else {
          dispatch(fetchFailure(response.message));
          if (response.status === 404) {
            AlertError("Record not found.");
          }
        }
        dispatch(fetchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const getGeoOptions = search;
export const getGeoDefaultOptions = search;
export const searchShippingInfo = search;
export const getZoneOptions = search;
export const getShipper = search;
export const getQuickCodeMaster = search;
export const getModeOfCollections = search;
export const getProducts = search;
export const getClassOfStores = search;
export const fetchProductItems = search;
export const getVas = search;
export const fetchTempUom = search;
export const getRelations = search;
export const getEventDetail = search;
export const getEventLocation = search;
export const getUsers = search;
export const getCurrency = search;
export const getBankCode = search;
export const getReasonCode = search;
export const getBayType = search;
export const getDiscrepancy = search;
export const getEmployeeStatus = search;
export const getreceiptNoStatus = search;
export const getTripPlanId = search;
export const getBayId = search;
export const getDispatchDocNo = search;
export const getTaxStatus = search;
export const getTaxExempt = search;
export const getEmployeeDetails = search;
export const getDispatchType = search;
export const getTripStatus = search;
export const getOwnerType = search;
export const getVehicleType = search;
export const getHubLocation = search;
export const getCarrierStatus = search;
export const getClassifications = search;
export const getDocumentType = search;
export const getEquipmentType = search;
export const getDisbursementMode = search;
export const getDocType = search;
export const fetchAltUom = search;

export const searchShippingHelp = (params, page, limit) => {
  return dispatch => {
    dispatch(setSearchRequest(true));
    if (page === 1) {
      dispatch(inilailizeShipperIds());
    }
    return Api.post(`/search/shipping?page=${page}&limit=${limit}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(setPaginationAttr(response.last_page, response.total));
          dispatch(ShippingfetchSuccess(response.result));
        } else {
          dispatch(fetchFailure(response.message));
        }
        dispatch(setSearchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const fetchDocuments = brId => {
  return (dispatch, getState) => {
    const { masterReducer } = getState();
    const options = masterReducer.options;
    dispatch(setSearchRequest(true));
    return Api.get(`/qbr/documents/${brId}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let responseData = {};
          responseData["document_profiles"] = response.result;
          dispatch(setPaginationAttr(response.last_page, response.total));
          dispatch(fetchSuccess(responseData, options, false));
        } else {
          dispatch(fetchFailure(response.message));
        }
        dispatch(setSearchRequest(false));
      })
      .catch(err => {
        dispatch(fetchFailure(err));
      });
  };
};

export const inilailizeShipper = () => {
  return dispatch => {
    dispatch(inilailizeShipperIds())
  }
}

export const inilailizeShipperIds = () => {
  return {
    type: types.INITIALIZE_SHIPPER_IDS
  };
};

export const ShippingfetchSuccess = data => {
  return {
    type: types.MASTER_SHIPPING_FETCH_SUCCESS,
    data
  };
};

export const fetchRequest = isLoading => {
  return {
    type: types.MASTER_FETCH_REQUEST,
    isLoading
  };
};

export const setSearchRequest = isSearching => {
  return {
    type: types.MASTER_MULTI_SEARCH_REQUEST,
    isSearching
  };
};

export const fetchSuccess = (data, existingState, isMerge) => {
  _.map(data, (value, key) => {
    existingState[key] = isMerge ? existingState[key].concat(value) : value;
  });

  data = existingState;
  return {
    type: types.MASTER_FETCH_SUCCESS,
    data: data
  };
};

export const fetchFailure = err => {
  return {
    type: types.MASTER_FETCH_FAILURE,
    err
  };
};

export const resetStateData = data => {
  return (dispatch, getState) => {
    const { masterReducer } = getState();
    const options = masterReducer.options;
    dispatch(fetchSuccess(data, options));
  };
};

export const setPaginationAttr = (lastPage, total) => {
  return {
    type: types.PAGINATION_ATTR,
    lastPage,
    total,
  };
};

export const inilailizeBROptions = () => {
  return (dispatch, getState) => {
    const { masterReducer } = getState();
    let options = masterReducer ? masterReducer.options : {};
    options['vas'] = []
    dispatch(inilailizeBrOtherOptions(options))
  }
}

const inilailizeBrOtherOptions = (options) => {
  return {
    type: types.INITIALIZE_BR_OPTIONS,
    options
  };
};