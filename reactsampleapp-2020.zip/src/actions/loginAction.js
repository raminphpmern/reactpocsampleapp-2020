import {
  LOGIN_INITIALIZE,
  LOGIN_SUCCESS,
  LOGIN_FAILURE,
  LOGIN_REQUEST,
  LOGOUT,
  ONLINE_STATUS,
  LOGIN_SELECTED_BRANCH_TYPE
} from 'types/login.type';
import history from 'routes/history';
import Api from 'lib/api';
import { setValue, removeKey } from 'lib/LocalStorage';
import { AlertSuccess, AlertError } from 'lib/Alert'
import _ from 'lodash'

const errorMsg = "Something went wrong!!!"

export const loginSuccess = (user) => {
  return {
    type: LOGIN_SUCCESS,
    user
  }
}

export const onlineStatus = (online) => {
  return {
    type: ONLINE_STATUS,
    online
  }
}

export const loginFailure = (error) => {
  return {
    type: LOGIN_FAILURE,
    message: error
  }
}

export const loginRequest = (isLoading) => {
  return {
    type: LOGIN_REQUEST,
    isLoading
  }
}

export const logout = () => {
  return {
    type: LOGOUT
  }
}

export const userLogout = () => {
  return dispatch => {
    removeKey('user');
    removeKey('currentBranch');
    setValue('activeStep', 1)
    setValue('currentStep', 1)
    removeKey('locations');
    dispatch(logout());
    history.push('/login');
  }
}

export const userLogin = (data) => {
  return dispatch => {
    dispatch(loginRequest(true));
    return Api.post('/login', data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          setValue('user', response.data);
          dispatch(loginSuccess(response.data));
          setValue('currentStep', 1)
          AlertSuccess(response.message);
        } else {
          dispatch(loginFailure(response.message));
          let message;
          if (response.error && response.error.code === 400) {
            message = JSON.parse(response.error.message)
            message = _.values(message).join(',')
          } else {
            message = response.message
          }
          AlertError(message)
        }
      })
      .catch((error) => {
        console.log("userLogin - error", error)
        dispatch(loginFailure(errorMsg));
      });
  }
}

export const createPassword = (data) => {
  return dispatch => {
    dispatch(loginRequest(true));
    return Api.post('/login/createPassword', data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let user = response.data;
          user.newUser = false
          user.loggedIn = true
          removeKey('user');
          setValue('user', user);
          dispatch(loginSuccess(user));
          AlertSuccess(response.message);
          history.push('/')
        } else {
          dispatch(loginFailure(response.message));
          let message;
          if (response.error && response.error.code === 400) {
            message = JSON.parse(response.error.message)
            message = _.values(message).join(',')
          } else {
            message = response.message
          }
          AlertError(message)
        }
      })
      .catch((error) => {
        console.log('createPassword - error', error)
        dispatch(loginFailure(errorMsg));
      });
  }
}


export const passwordLogin = (data) => {
  return dispatch => {
    dispatch(loginRequest(true));
    return Api.post('/login/passwordLogin', data)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let user = response.data;
          user.loggedIn = true
          removeKey('user');
          const locations = user.locations
          user.locations = []
          setValue('user', user);
          setValue('locations', locations)
          user.locations = locations
          dispatch(loginSuccess(user));
          AlertSuccess(response.message);
          history.push('/');
        } else {
          dispatch(loginFailure(response.message));
          let message;
          if (response.error && response.error.code === 400) {
            message = JSON.parse(response.error.message)
            message = _.values(message).join(',')
          } else {
            message = response.message
          }
          AlertError(message)
        }
      })
      .catch((error) => {
        console.log('passwordLogin - error', error)
        dispatch(loginFailure(errorMsg));
      });
  }
}

export const updateBranchType = (type) => {
  return dispatch => {
    dispatch(setBranchType(type))
  }
}

const setBranchType = (type) => {
  return {
    type: LOGIN_SELECTED_BRANCH_TYPE,
    branchType: type
  }
}

export const initialize = () => {
  return {
    type: LOGIN_INITIALIZE
  }
}

export const initializeUser = () => {
  return dispatch => {
    dispatch(initialize())
  }
}
