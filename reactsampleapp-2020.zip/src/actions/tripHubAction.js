import Api from 'lib/api'
import * as types from 'types/tripHub.type'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { pendingTask, begin, end } from 'react-redux-spinner'
import _ from 'lodash';

export const search = (values, pageNo, limit, isSearch) => {
  return dispatch => {
    dispatch(searchRequest(true));
    return Api.post(`/triphub/search?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initialize())
          }
          dispatch(searchSuccess(response.result, response.totalPage, response.totalRecord, limit, values.periodic_filter))
          AlertSuccess(response.message)
        } else {
          dispatch(searchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(searchRequest(false));
      })
      .catch(err => {
        console.log("triphubActions -- search ", err);
        dispatch(searchFailure(err));
        dispatch(searchRequest(false));
      });
  };
};

export const initializetripHub = () => {
  return dispatch => {
    dispatch(initialize())
  }
}

const initialize = () => {
  return {
    type: types.TRIPHUB_INITIALIZE
  }
}

const searchRequest = (isRequested) => {
  return {
    type: types.TRIPHUB_FETCH_REQUEST,
    [pendingTask]: isRequested ? begin : end,
    isRequested
  }
}

const searchSuccess = (data, totalPage, totalRecord, limit, filterType) => {
  return {
    type: types.TRIPHUB_FETCH_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit,
    filterType
  }
}


const searchFailure = (message) => {
  return {
    type: types.TRIPHUB_FETCH_FAILURE,
    message
  }
}


export const vehicleSearch = (values, pageNo, limit, isSearch) => {
  return dispatch => {
    dispatch(vehicleSearchRequest(true));
    return Api.post(`/triphubhelper/vehicleSearch?pageNo=${pageNo}&limit=${limit}`, values)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initialize())
          }
          dispatch(vehicleSearchSuccess(response.result, response.totalPage, response.totalRecord, limit))
          AlertSuccess(response.message)
        } else {
          dispatch(vehicleSearchFailure(response.message));
          AlertError(response.message)
        }
        dispatch(searchRequest(false));
      })
      .catch(err => {
        console.log("triphubActions -- search ", err);
        dispatch(vehicleSearchFailure(err));
        dispatch(vehicleSearchRequest(false));
      });
  };
};


const vehicleSearchRequest = (isRequested) => {
  return {
    type: types.TRIPHUB_VEHICLE_FETCH_REQUEST,
    isRequested
  }
}

const vehicleSearchSuccess = (data, totalPage, totalRecord, limit) => {
  return {
    type: types.TRIPHUB_VEHICLE_FETCH_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit,
  }
}


const vehicleSearchFailure = (message) => {
  return {
    type: types.TRIPHUB_VEHICLE_FETCH_FAILURE,
    message
  }
}

export const initializeVeh = () => {
  return dispatch => {
    dispatch(initializeVehicleData())
  }
}

const initializeVehicleData = () => {
  return {
    type: types.TRIPHUB_VEHICLE_INITIALIZE
  }
}

export const carrierSearch = (values, pageNo, limit, isSearch) => {
  return dispatch => {
    dispatch(carrierSearchRequest(true));
    return Api.post(
      `/triphubhelp/carrierIdSearch?pageNo=${pageNo}&limit=${limit}`,
      values
    )
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          if (isSearch) {
            dispatch(initialize());
          }
          dispatch(
            carrierSearchSuccess(
              response.result,
              response.totalPage,
              response.totalRecord,
              limit
            )
          );
          AlertSuccess(response.message);
        } else {
          dispatch(carrierSearchFailure(response.message));
          AlertError(response.message);
        }
        dispatch(searchRequest(false));
      })
      .catch(err => {
        console.log("triphub CarrierActions -- search ", err);
        dispatch(carrierSearchFailure(err));
        dispatch(carrierSearchRequest(false));
      });
  };
};

const carrierSearchRequest = isRequested => {
  return {
    type: types.TRIPHUB_CARRIER_FETCH_REQUEST,
    isRequested
  };
};

const carrierSearchSuccess = (data, totalPage, totalRecord, limit) => {
  return {
    type: types.TRIPHUB_CARRIER_FETCH_SUCCESS,
    data,
    totalPage,
    totalRecord,
    limit
  };
};

const carrierSearchFailure = message => {
  return {
    type: types.TRIPHUB_CARRIER_FETCH_FAILURE,
    message
  };
};

export const initializeCarrier = () => {
  return dispatch => {
    dispatch(initializeCarrierId());
  };
};

const initializeCarrierId = () => {
  return {
    type: types.TRIPHUB_CARRIER_INITIALIZE
  };
};

export const saveTripDtl = (params) => {
  return (dispatch, getState) => {
    let { triphubReducer: { tripresult } } = getState()
    dispatch(tripSealRequest(true))
    return Api.post(`/tripLogs/vehicleSeal/saveTripDtl`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(tripRequestSuccess('', []));
          _.each(response.result, (item) => {
            const recordIndex = _.findIndex(tripresult, (row) => row.tlsd_seal_line_no === item.tlsd_seal_line_no)
            if (recordIndex >= 0) {
              tripresult[recordIndex] = item
            } else {
              tripresult.push(item)
            }
          })
          dispatch(tripRequestSuccess(response.message, tripresult));
          AlertSuccess(response.message)
        } else {
          dispatch(tripRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(tripSealRequest(false));
      })
      .catch(err => {
        dispatch(tripRequestFailure(err));
        dispatch(tripSealRequest(false));
      })
  }
}

const tripSealRequest = isSaveRequested => {
  return {
    type: types.TRIP_SEAL_RECORDS_SAVE_REQUEST,
    isSaveRequested
  }
}

const tripRequestSuccess = (message, data) => {
  return {
    type: types.TRIP_SEAL_RECORDS_SAVE_SUCCESS,
    message,
    data
  }
}

const tripRequestFailure = message => {
  return {
    type: types.TRIP_SEAL_RECORDS_SAVE_FAILURE,
    message
  }
}

export const fetchTripSeal = (queryString, pageNo, limit) => {
  return (dispatch) => {
    dispatch(tripDetailsRequest(true))
    return Api.get(`/tripLogs/vehicleSeal/fetchTripSeal?pageNo=${pageNo}&limit=${limit}&${queryString}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(tripDetailsSuccess(response.result, response.totalPage, response.totalRecord))
          AlertSuccess(response.message)
        } else {
          dispatch(tripDetailsFailure(response.message))
          AlertError(response.message)
        }
        dispatch(tripDetailsRequest(false))
      }).catch((err) => {
        dispatch(tripDetailsRequest(false))
        dispatch(tripDetailsFailure(err))
      })
  }
}

export const initializeTS = () => {
  return dispatch => {
    dispatch(initializeTripSealDetails())
  }
}

const initializeTripSealDetails = () => {
  return {
    type: types.TRIP_SEAL_DETAILS_INITIALIZE
  }
}
const tripDetailsRequest = (isRequested) => {
  return {
    type: types.TRIP_SEAL_DETAILS_REQUEST,
    isRequested
  }
}

const tripDetailsSuccess = (data, totalPage, totalRecord) => {
  return {
    type: types.TRIP_SEAL_DETAILS_SUCCESS,
    data,
    totalPage,
    totalRecord
  }
}

const tripDetailsFailure = (message) => {
  return {
    type: types.TRIP_SEAL_DETAILS_FAILURE,
    message
  }
}

export const deleteTripSeal = (params) => {
  return (dispatch, getState) => {
    const { triphubReducer: { tripresult } } = getState()
    dispatch(tripSealRequest(true))
    return Api.delete(`/tripLogs/vehicleSeal/deleteTripSeal?tlsd_seal_line_no=${params.tlsd_seal_line_no}`)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          dispatch(tripRequestSuccess('', []));
          const records = _.filter(tripresult, (row) => !_.includes(params.tlsd_seal_line_no, row.tlsd_seal_line_no))
          dispatch(tripRequestSuccess(response.message, records));
          AlertSuccess(response.message)
        } else {
          dispatch(tripRequestFailure(response));
          AlertError(response.message)
        }
        dispatch(tripSealRequest(false));
      })
      .catch(err => {
        dispatch(tripRequestFailure(err));
        dispatch(tripSealRequest(false));
      })
  }
}
