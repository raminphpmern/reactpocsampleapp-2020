import * as types from 'types/document.type.js'
import Api from 'lib/api.js'
import { AlertSuccess, AlertError } from 'lib/Alert'
import { apiErrorMsg } from 'lib/CommonHelper'
import { setValue, getValue } from 'lib/LocalStorage'
import _ from 'lodash'

export const create = (params, step, brId) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(createRequest(true))
    return Api.post(`/qbr/documents/${brId}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          _.merge(bookingInfo, response.data)
          dispatch(createSuccess(bookingInfo, step, step))
          setValue('activeStep', step)
          setValue('currentStep', step)
          AlertSuccess(response.message)
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      })
      .catch((err) => {
        console.log("Document Actions -- create -- Error", err)
        dispatch(createFailure(err))
        dispatch(createRequest(false))
      })
  }
}

export const update = (params, step, brId) => {
  return (dispatch, getState) => {
    const { bookingReducer } = getState();
    dispatch(createRequest(true))
    return Api.put(`/qbr/documents/${brId}`, params)
      .then(response => response.json())
      .then(response => {
        if (response.status === 200) {
          let bookingInfo = _.cloneDeep(bookingReducer.currentBooking)
          _.merge(bookingInfo, response.data)
          let activeStep = parseInt(getValue('activeStep'))
          if (activeStep < 4) {
            setValue('activeStep', step)
            setValue('currentStep', step)
          } else {
            setValue('currentStep', step)
            setValue('activeStep', 4)
          }
          dispatch(createSuccess(bookingInfo, step, step))
          setValue('currentStep', step)
          AlertSuccess(response.message)
        } else {
          dispatch(createFailure(response.message))
          AlertError(apiErrorMsg(response))
        }
        dispatch(createRequest(false))
      })
      .catch((err) => {
        console.log("Document Actions -- create -- Error", err)
        dispatch(createFailure(err))
        dispatch(createRequest(false))
      })
  }
}

const createRequest = (isRequested) => {
  return {
    type: types.CREATE_DOCUMENT_REQUEST,
    isRequested
  }
}

const createSuccess = (data, activeStep, currentStep) => {
  return {
    type: types.CREATE_DOCUMENT_SUCCESS,
    data,
    activeStep,
    currentStep
  }
}

const createFailure = (msg) => {
  return {
    type: types.CREATE_DOCUMENT_FAILURE,
    msg
  }
}
