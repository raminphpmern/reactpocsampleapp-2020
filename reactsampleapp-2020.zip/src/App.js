import React from 'react';
import { Provider } from 'react-redux';
import store from 'store';
import Route from 'routes';
import { getValue } from 'lib/LocalStorage';
import { loginSuccess, onlineStatus } from 'actions/loginAction';
import crashReporter from 'lib/crashReporter';
import Alert from 'react-s-alert';
import 'semantic-ui-css/semantic.css';
import 'react-tabs/style/react-tabs.css';
import 'react-s-alert/dist/s-alert-default.css';
import 'react-s-alert/dist/s-alert-default.css';
import 'react-s-alert/dist/s-alert-css-effects/slide.css';
import 'react-s-alert/dist/s-alert-css-effects/scale.css';
import 'react-s-alert/dist/s-alert-css-effects/flip.css';
import 'react-s-alert/dist/s-alert-css-effects/jelly.css';
import 'react-s-alert/dist/s-alert-css-effects/stackslide.css';
import 'react-s-alert/dist/s-alert-css-effects/genie.css';
import 'react-s-alert/dist/s-alert-css-effects/bouncyflip.css';
import "react-datepicker/dist/react-datepicker.css";
import './App.css';
import './themes/red.css';

if (getValue('user')) {
  const user = JSON.parse(getValue('user'));
  let locations = []
  if (getValue('locations')) {
    locations = JSON.parse(getValue('locations'))
  }
  user.locations = locations
  store.dispatch(loginSuccess(user));
}

if (navigator.onLine) {
  store.dispatch(onlineStatus(true))
} else {
  store.dispatch(onlineStatus(false))
}

class App extends React.Component {
  componentDidMount() {
    crashReporter.init()
  }
  render() {
    return (
      <Provider store={store}>
        <Route />
        <Alert stack={{ limit: 3 }} html={true} />
      </Provider>
    );
  }
}

export default App;
