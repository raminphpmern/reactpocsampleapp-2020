import React, { Component } from "react";
import DateTimePicker from "components/Common/DateTimePicker";
import InputSearchField from "components/Common/InputSearchField";
import InputField from "components/Common/InputField";
import * as masterActions from "actions/masterAction";
import Dropdown from "components/Common/Dropdown";
import { reduxForm, Field } from "redux-form";
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import { search } from "actions/csAction";
import { SEARCH_WORD_COUNT } from "config";
import { formatFormValues } from 'lib/CommonHelper';
import Popup from 'components/Common/Popup';
import HelpOnReceiptNo from './HelpOnReceiptNo';
import HelpOnEmployee from './HelpOnEmployee';
import HelpOnTripPlan from "../Dispatch/DispatchCreate/HelpOnTripPlan";
import HelpOnCustomer from "../Dispatch/DispatchSearch/HelpOnCustomer";
import { getValue } from 'lib/LocalStorage'
import _ from "lodash";
import "./cs.css";
import validate from './csValidation'

const agingOptions = [
  { value: '=', label: '=' },
  { value: '<>', label: '<>' },
  { value: '>', label: '>' },
  { value: '<', label: '<' },
  { value: 'between', label: 'Between' }
];

const statusOptions = [
  { value: 'DF', label: 'Draft' },
  { value: 'DP', label: 'Deposited' },
  { value: 'HLD', label: 'On Hold' },
  { value: 'RL', label: 'Released' }
];

class SearchForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      help: false,
      employeeHelp: false,
      tripHelp: false,
      customerHelp: false,
      currentHelp: ''
    }
    this.formSubmit = this.formSubmit.bind(this);
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
    this.toggle = this.toggle.bind(this);
    this.getReceiptDetails = this.getReceiptDetails.bind(this);
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this);
    this.selectTripId = this.selectTripId.bind(this);
    this.selectCusomerCode = this.selectCusomerCode.bind(this);
  }

  componentDidMount() {
    const {
      mode_of_collections,
      currencies,
      bankCodes,
      getModeOfCollections,
      getCurrency,
      getBankCode,
    } = this.props;

    if (mode_of_collections.length === 0) {
      getModeOfCollections("mode_of_collections");
    }
    if (currencies.length === 0) {
      getCurrency("currencies");
    }
    if (bankCodes.length === 0) {
      getBankCode("bankCodes");
    }
    const location = JSON.parse(getValue('currentBranch')) ? JSON.parse(getValue('currentBranch')) : null
    this.props.initialize({ br_customer_location: location.value, br_customer_location_label: location.label });
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === 'shipper') {
        queryString += "&searchField=wms_customer_id";
        this.props.getShipper("shipper", queryString, fieldName);
      }
      if (fieldName === 'employee') {
        this.props.getEmployeeDetails("employee", queryString, fieldName);
      }

      if (fieldName === 'tripPlanIds') {
        this.props.getTripPlanId("tripPlanIds", queryString, fieldName);
      }
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "shipper") {
      hash["wms_customer_id"] = option.wms_customer_id;
    }
    if (fieldName === "employee") {
      hash["wms_emp_employee_code"] = option.value;
      hash["wms_emp_description"] = option.wms_emp_description;
    }
    if (fieldName === "tripPlanIds") {
      hash["tlccd_trip_id"] = option.tlccd_trip_id;
    }
    this.props.initialize(hash);
  }

  formSubmit(values) {
    this.props.csSearch(formatFormValues(values), 1, this.props.limit, true);
  }


  toggle(modelType, modelName) {
    if (modelName.match(/ccd_receipt_no/))
      this.setState({ [modelType]: !this.state[modelType], currentHelp: modelName })
    else
      this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  getReceiptDetails(data, name) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash[name] = data[0]["ccd_receipt_no"]
      this.props.initialize(hash)
    }
  }

  getEmployeeDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["wms_emp_employee_code"] = data[0]["wms_emp_employee_code"]
      hash["wms_emp_description"] = data[0]["wms_emp_description"]
      this.props.initialize(hash)
    }
  }

  selectTripId(selectedTripId) {
    if (selectedTripId && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["tlccd_trip_id"] = selectedTripId["plpth_trip_plan_id"]
      this.props.initialize(hash)
    }
  }

  selectCusomerCode(selectedCustomerCode) {
    if (selectedCustomerCode && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["wms_customer_id"] = selectedCustomerCode
      this.props.initialize(hash)
    }
  }

  render() {
    const { handleSubmit, currentUser, mode_of_collections, shipper, employee, currencies, bankCodes, isRequested, t, tripPlanIds } = this.props;
    const user = (currentUser && currentUser.username);
    const { help, employeeHelp, currentHelp, tripHelp, customerHelp } = this.state;
    return (
      <div>
        <Popup size="fullscreen" open={help} close={() => { this.toggle('help', 'ccd_receipt_no') }} header={t('receiptHelp')} description={<HelpOnReceiptNo getReceiptDetails={this.getReceiptDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={employeeHelp} close={() => { this.toggle('help', 'employeeHelp') }} header={t('employeeHelp')} description={<HelpOnEmployee
          getEmployeeDetails={this.getEmployeeDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={tripHelp} close={() => { this.toggle('help', 'tripHelp') }}
          header={t('tripHelp')} description={<HelpOnTripPlan close={this.toggle}
            handleOnSelect={this.selectTripId} name={currentHelp} />} />

        <Popup size="fullscreen" open={customerHelp} close={() => { this.toggle('help', 'customerHelp') }} header={t('customerHelp')} description={<HelpOnCustomer close={this.toggle} handleOnSelect={this.selectCusomerCode} />} />

        <form onSubmit={handleSubmit(this.formSubmit)} className='cs-search-form'>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="ccd_created_by"
                  component={InputField}
                  label={t('ccd_created_by')}
                  placeholder={user}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="br_customer_location_label"
                  component={InputField}
                  label={t('br_customer_location')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={8}></Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="br_consign_note"
                  component={InputField}
                  label={t('br_consign_note')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="wms_customer_id"
                  component={InputSearchField}
                  label={t('br_customer_id')}
                  findByCompanyAndFLMName={this.search}
                  options={shipper.slice(0, 5)}
                  id="shipper"
                  fillNameValues={this.setValue}
                  iconName="search"
                  childName="customerHelp"
                  handleClick={this.toggle}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="wms_emp_employee_code"
                  component={InputSearchField}
                  label={t('wms_emp_employee_code')}
                  iconName="search"
                  findByCompanyAndFLMName={this.search}
                  id="employee"
                  options={employee.slice(0, 5)}
                  fillNameValues={this.setValue}
                  childName="employeeHelp"
                  handleClick={this.toggle}
                  clearable={true}
                />

              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="wms_emp_description"
                  component={InputField}
                  label={t('wms_emp_description')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="tlccd_trip_id"
                  component={InputSearchField}
                  label={t('tlccd_trip_id')}
                  iconName="search"
                  findByCompanyAndFLMName={this.search}
                  id="tripPlanIds"
                  options={tripPlanIds.slice(0, 5)}
                  fillNameValues={this.setValue}
                  childName="tripHelp"
                  handleClick={this.toggle}
                  clearable={true}

                />
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="aging">
                  <Field
                    name="aging"
                    component={Dropdown}
                    label={t('aging')}
                    options={agingOptions}
                    clearable={true}
                  />
                  <Field
                    name="aging_from"
                    component={InputField}
                    type="number"

                  />
                  <Field
                    name="aging_to"
                    component={InputField}
                    type="number"
                  />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ccd_receipt_no"
                  component={InputField}
                  label={t('ccd_receipt_no_from')}
                  iconName="search"
                  handleClick={this.toggle}
                  childName='ccd_receipt_no'
                  clearable={true}

                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ccd_receipt_no_to"
                  component={InputField}
                  label={t('ccd_receipt_no_to')}
                  iconName="search"
                  handleClick={this.toggle}
                  childName='ccd_receipt_no_to'
                  clearable={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="br_collection_mode"
                  component={Dropdown}
                  label={t('br_collection_mode')}
                  options={mode_of_collections}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ccd_bankcode"
                  component={Dropdown}
                  label={t('ccd_bankcode')}
                  options={bankCodes}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ccd_receipt_date_from"
                  component={DateTimePicker}
                  label={t('ccd_receipt_date_from')}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ccd_receipt_date_to"
                  component={DateTimePicker}
                  label={t('ccd_receipt_date_to')}
                  clearable={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="ccd_currency"
                  component={Dropdown}
                  label={t('ccd_currency')}
                  options={currencies}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ccd_receipt_status"
                  component={Dropdown}
                  label={t('ccd_receipt_status')}
                  options={statusOptions}
                  clearable={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='search' type="submit" className="primary" disabled={isRequested}>
                    {t('searchBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    );
  }
}

SearchForm = reduxForm({
  form: "SearchForm",
  validate
})(SearchForm);

const mapDispatchToProps = dispatch => ({
  getModeOfCollections: (type, queryStr) =>
    dispatch(masterActions.getModeOfCollections(type, queryStr)),
  getShipper: (action, queryStr) =>
    dispatch(masterActions.getShipper(action, queryStr)),
  getCurrency: (type, queryStr) =>
    dispatch(masterActions.getCurrency(type, queryStr)),
  getBankCode: (type, queryStr) =>
    dispatch(masterActions.getBankCode(type, queryStr)),
  getTripPlanId: (type, queryStr) =>
    dispatch(masterActions.getTripPlanId(type, queryStr)),
  getEmployeeDetails: (type, queryStr) =>
    dispatch(masterActions.getEmployeeDetails(type, queryStr)),
  csSearch: (values, pageNo, pageLimit, isSearch) => dispatch(search(values, pageNo, pageLimit, isSearch))
});

const mapStateToProps = state => ({
  mode_of_collections: state.masterReducer.options.mode_of_collections,
  currentUser: state.loginReducer.user,
  shipper: state.masterReducer.options.shipper,
  formValues: state.form.SearchForm,
  employee: state.masterReducer.options.employee,
  currencies: state.masterReducer.options.currencies,
  bankCodes: state.masterReducer.options.bankCodes,
  tripPlanIds: state.masterReducer.options.tripPlanIds,
  isRequested: state.csReducer.isRequested,
  limit: state.csReducer.limit,
});

export default compose(withTranslation('csSearch'), connect(mapStateToProps, mapDispatchToProps))(SearchForm);
