import React from 'react';
import { generateBlobUrl } from 'lib/CommonHelper';
import DatePickerEditor from '../Common/DataGrid/DatePickerEditor';
import InputSearchEditor from '../Common/DataGrid/InputSearchEditor';
import DropDownEditor from '../Common/DataGrid/DropDownEditor';
import i18n from 'i18n';


export const gridJsonRule = {
  "and": [
    { "!==": [{ "var": 'ccd_receipt_status' }, "Deposited"] },
    { "!==": [{ "var": 'ccd_receipt_status' }, "Held"] },
    { "!==": [{ "var": 'ccd_receipt_status' }, "Released"] }

  ]
}

const LinkFormatter = ({ dependentValues }) => {
  if (dependentValues.tran_attachement) {
    const imageInfo = generateBlobUrl(dependentValues.tran_attachement)
    return <a href={imageInfo.imageUrl} target="_blank">{dependentValues.tran_document_name}</a>;
  } else {
    return ''
  }
};

const statusCond = (row) => row.ccd_receipt_status !== 'Deposited'

export const columns = [
  { key: "br_consign_note", name: i18n.t('csGrid:br_consign_note'), frozen: true },
  { key: "ccd_br_no", name: i18n.t('csGrid:ccd_br_no'), frozen: true },
  { key: "ccd_receipt_no", name: i18n.t('csGrid:ccd_receipt_no'), frozen: true },
  { key: "ccd_receipt_date", name: i18n.t('csGrid:ccd_receipt_date') },
  { key: "ccd_receipt_amount", name: i18n.t('csGrid:ccd_receipt_amount') },
  { key: "receiptmode", name: i18n.t('csGrid:receiptmode') },
  { key: "wms_customer_id", name: i18n.t('csGrid:wms_customer_id') },
  { key: "wms_customer_name", name: i18n.t('csGrid:wms_customer_name') },
  { key: "wms_customer_description", name: i18n.t('csGrid:wms_customer_description') },
  { key: "currency", name: i18n.t('csGrid:currency') },
  { key: "wms_consignee_desc", name: i18n.t('csGrid:wms_consignee_desc') },
  { key: "ccd_depositdate", name: i18n.t('csGrid:ccd_depositdate'), editor: DatePickerEditor, editable: statusCond },
  { key: "ccd_reasoncode", name: i18n.t('csGrid:ccd_reasoncode') },
  { key: "cd_amount_collected", name: i18n.t('csGrid:tlccd_amount_to_be_collected') },//amount to be collected from br
  { key: "tlccd_amount_collected", name: i18n.t('csGrid:tlccd_amount_collected') },//amount collected from triplog
  { key: "ccd_cashreceived", name: i18n.t('csGrid:ccd_cashreceived'), editable: statusCond },
  { key: "reason_code_1", name: i18n.t('csGrid:reason_code_1'), editor: <InputSearchEditor propName='reason_code' />, editable: statusCond },
  { key: "mode_of_collection", name: i18n.t('csGrid:mode_of_collection') },
  { key: "aging", name: i18n.t('csGrid:aging') },
  { key: "ccd_depositrefdocno", name: i18n.t('csGrid:ccd_depositrefdocno'), editable: statusCond },
  { key: "deposit_def_doc", name: i18n.t('csGrid:deposit_def_doc'), formatter: LinkFormatter, getRowMetaData: (row) => row },
  { key: "ccd_receipt_status", name: i18n.t('csGrid:ccd_receipt_status') },
  { key: "ccd_instrumentno", name: i18n.t('csGrid:ccd_instrumentno'), editable: statusCond },
  { key: "ccd_instrumentdate", name: i18n.t('csGrid:ccd_instrumentdate'), editor: DatePickerEditor, editable: statusCond },
  { key: "ccd_bankcode", name: i18n.t('csGrid:ccd_bankcode'), editor: <DropDownEditor propName="bankCodes" />, editable: statusCond },
  { key: "ccd_reasoncode3", name: i18n.t('csGrid:ccd_reasoncode3') }
]

export const statusValidationMsg = {
  save: i18n.t('csValidMsg:saveMsg'),
  confirm: i18n.t('csValidMsg:confirmMsg'),
  hold: i18n.t('csValidMsg:holdMsg'),
  release: i18n.t('csValidMsg:releaseMsg')
}