import i18n from 'i18n';

const Validation = (values) => {
  const errors = {};
  if (values.aging) {
    if (!values.ccd_receipt_status || values.ccd_receipt_status.value !== 'DF')
      errors.ccd_receipt_status = i18n.t('csForm:validation_ccd_receipt_status')
  }
  return errors
}

export default Validation;
