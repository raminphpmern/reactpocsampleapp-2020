import i18n from 'i18n';

export const gridHeaders = [
  { key: "wms_emp_employee_code", name: i18n.t('csHelp:wms_emp_employee_code') },
  { key: "wms_emp_group", name: i18n.t('csHelp:wms_emp_group') },
  { key: "wms_emp_description", name: i18n.t('csHelp:wms_emp_description') },
  { key: "empstatus", name: i18n.t('csHelp:empstatus') },
  { key: "wms_emp_first_name", name: i18n.t('csHelp:wms_emp_first_name') },
  { key: "wms_emp_middle_name", name: i18n.t('csHelp:wms_emp_middle_name') },
  { key: "wms_emp_last_name", name: i18n.t('csHelp:wms_emp_last_name') },
  { key: "given_name", name: i18n.t('csHelp:given_name') },
  { key: "location", name: i18n.t('csHelp:location') }
];

export const basicFields = [
  { label: i18n.t('csHelp:wms_emp_employee_code'), value: 'wms_emp_employee_code', type: 'inputBox' },
  { label: i18n.t('csHelp:wms_emp_group'), value: 'wms_emp_group', type: 'inputBox' },
  { label: i18n.t('csHelp:wms_emp_description'), value: 'wms_emp_description', type: 'inputBox' },
  { label: i18n.t('csHelp:wms_emp_first_name'), value: 'wms_emp_first_name', type: 'inputBox' },
  { label: i18n.t('csHelp:wms_emp_middle_name'), value: 'wms_emp_middle_name', type: 'inputBox' },
  { label: i18n.t('csHelp:wms_emp_last_name'), value: 'wms_emp_last_name', type: 'inputBox' },
  {
    label: i18n.t('csHelp:empstatus'), value: 'empstatus', type: 'dropDown',
    values: {
      props: {
        options: 'employeeStatus',
        clearable: true,
      }
    }
  }
]