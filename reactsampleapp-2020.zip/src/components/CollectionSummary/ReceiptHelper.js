import i18n from 'i18n';

export const gridHeaders = [
  { key: "ccd_receipt_no", name: i18n.t('csReceipt:ccd_receipt_no') },
  { key: "ccd_receipt_date", name: i18n.t('csReceipt:ccd_receipt_date') },
  { key: "ccd_currency", name: i18n.t('csReceipt:ccd_currency') },
  { key: "ccd_receipt_amount", name: i18n.t('csReceipt:ccd_receipt_amount') },
  { key: "wms_code_desc", name: i18n.t('csReceipt:wms_code_desc') }
];

export const basicFields = [
  { label: i18n.t('csReceipt:ccd_receipt_no_from'), value: 'ccd_receipt_no_from', type: 'inputBox' },
  { label: i18n.t('csReceipt:ccd_receipt_no_to'), value: 'ccd_receipt_no_to', type: 'inputBox' },
  {
    label: i18n.t('csReceipt:wms_code_desc'), value: 'wms_code_desc', type: 'dropDown',
    values: {
      props: {
        options: 'receiptNoStatus',
        clearable: true,
      }
    }
  },
  { label: i18n.t('csReceipt:ccd_receipt_date_from'), value: 'ccd_receipt_date_from', type: 'dateTime' },
  { label: i18n.t('csReceipt:ccd_receipt_date_to'), value: 'ccd_receipt_date_to', type: 'dateTime' },
  {
    label: i18n.t('csReceipt:ccd_currency'), value: 'ccd_currency', type: 'dropDown',
    values: {
      props: {
        options: 'currencies',
        clearable: true,
      }
    }
  }
]
