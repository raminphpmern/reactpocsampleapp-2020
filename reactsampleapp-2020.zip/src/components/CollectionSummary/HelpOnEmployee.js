import React, { Component } from 'react'
import { reduxForm } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { gridHeaders, basicFields } from './EmployeeIdHelper';
import { searchEmployeeId, initializeEMP } from "actions/csAction";
import DynamicFields from 'components/Common/DynamicFields';
import DataGrid from 'components/Common/DataGrid';
import { formatFormValues } from 'lib/CommonHelper';
import { getEmployeeStatus } from "actions/masterAction";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';

class HelpOnEmployee extends Component {
  constructor(props) {
    super(props);
    this.state = {
      filterFields: basicFields,
      selectedRecord: null,
      defaultValues: null,
      error: '',
      page: 1
    };
    this.formSubmit = this.formSubmit.bind(this);
    this.paginationHandler = this.paginationHandler.bind(this);
    this.selectedRows = this.selectedRows.bind(this);
    this.changeLimit = this.changeLimit.bind(this);
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this);
  }

  componentDidMount() {
    const {
      employeeStatus,
      getEmployeeStatus } = this.props;
    if (employeeStatus.length === 0) {
      getEmployeeStatus("employeeStatus");
    }
  }

  formSubmit(values) {
    this.props.employeeSearch(formatFormValues(values), 1, 10, true);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  changeLimit(pageNo, limit) {
    this.props.employeeSearch(formatFormValues(this.props.HelpOnEmployee.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.employeeSearch(formatFormValues(this.props.HelpOnEmployee.values), pageNo, limit);
  }

  getEmployeeDetails() {
    const { selectedIds } = this.state
    const { close } = this.props
    if (selectedIds !== null) {
      this.props.getEmployeeDetails(selectedIds)
      close('help', 'employeeHelp')
    }
  }

  render() {
    const { error, filterFields, defaultValues } = this.state
    const { isRequested, handleSubmit, result, totalPage, totalRecord, employeeStatus, initializeEMP, t } = this.props
    const disabled = this.state.selectedIds && this.state.selectedIds.length > 0
    return (
      <div>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable>
            {error && <span className='error-msg'>{error}</span>}
            <Grid.Row>
              <DynamicFields
                filterFields={filterFields}
                employeeStatus={employeeStatus}
                cols={3}
              />
            </Grid.Row>
          </Grid>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='search' type="submit" className="primary" disabled={isRequested}>
                    {t('searchBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={gridHeaders}
                rows={result}
                rowKey="wms_emp_employee_code"
                totalPages={totalPage}
                width={140}
                paginationHandler={this.paginationHandler}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                defaultValues={defaultValues}
                totalRecord={totalRecord}
                enableExport={true}
                singleSelect={true}
                initialize={initializeEMP}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='details' onClick={this.getEmployeeDetails} type="button" className="primary" disabled={!disabled}>
                  {t('okBtn')}
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

HelpOnEmployee = reduxForm({
  form: 'HelpOnEmployee'
})(HelpOnEmployee);

const mapStateToProps = state => ({
  employee_id: state.masterReducer.options.wms_emp_employee_code,
  isRequested: state.csReducer.isRequested,
  result: state.csReducer.employeeResult,
  totalPage: state.csReducer.totalPage,
  totalRecord: state.csReducer.totalRecord,
  HelpOnEmployee: state.form.HelpOnEmployee,
  employeeStatus: state.masterReducer.options.employeeStatus
})

const mapDispatchToProps = (dispatch) => ({
  employeeSearch: (values, pageNo, pageLimit, isSearch) => dispatch(searchEmployeeId(values, pageNo, pageLimit, isSearch)),
  getEmployeeStatus: type =>
    dispatch(getEmployeeStatus(type)),
  initializeEMP: () => dispatch(initializeEMP())
})

export default compose(withTranslation('csHelp'), connect(mapStateToProps, mapDispatchToProps))(HelpOnEmployee)
