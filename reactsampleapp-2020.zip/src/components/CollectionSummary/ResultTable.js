import React, { Component } from 'react';
import DataGrid from 'components/Common/DataGrid';
import DateTimePicker from 'components/Common/DateTimePicker';
import InputField from 'components/Common/InputField';
import InputSearchField from "components/Common/InputSearchField";
import FieldUpload from "components/Common/FileUpload";
import Dropdown from 'components/Common/Dropdown';
import { columns, gridJsonRule, statusValidationMsg } from './Helper';
import jsonLogic from 'json-logic-js';
import { getReasonCode } from "actions/masterAction";
import { reduxForm, Field } from 'redux-form';
import { Grid } from "semantic-ui-react";
import { SEARCH_WORD_COUNT } from "config";
import { connect } from "react-redux";
import * as csAction from "actions/csAction";
import { formatFormValues } from 'lib/CommonHelper';
import { AlertSuccess, AlertError } from 'lib/Alert';
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import _ from 'lodash';
import './cs.css';

const validate = values => {
  const errors = {};
  if (!values.ccd_reasoncode3) {
    errors.ccd_reasoncode3 = "Reason code is required."
  }
  if (!values.isValid) {
    errors.ccd_reasoncode3 = "Reason code is not valid"
  }
  return errors
}

class ResultTable extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selectedIds: null,
      defaultValues: null,
      reasonHelp: false,
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.compute = this.compute.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.setDefaults = this.setDefaults.bind(this)
    this.setSave = this.setSave.bind(this)
    this.setConfirm = this.setConfirm.bind(this)
    this.setHold = this.setHold.bind(this)
    this.setRelease = this.setRelease.bind(this)
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
    this.setFileName = this.setFileName.bind(this);
    this.onButtonAction = this.onButtonAction.bind(this)
  }

  componentDidMount() {
    this.props.initialize({ isValid: false });
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  changeLimit(pageNo, limit) {
    this.props.search(formatFormValues(this.props.searchForm.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.search(formatFormValues(this.props.searchForm.values), pageNo, limit);
  }

  setDefaults(values) {
    delete values['isValid']
    const { selectedIds } = this.state
    const allRecptStatus = _.map(selectedIds, 'ccd_receipt_status')
    if (allRecptStatus.includes("Draft") || allRecptStatus.includes(null)) {
      let obj = {
        ccd_depositrefdocno: values && values.ccd_depositrefdocno,
        ccd_bankcode: values && values.ccd_bankcode && values.ccd_bankcode.bank_desc,
        ccd_depositdate: values && values.ccd_depositdate,
        ccd_reasoncode3: values && values.ccd_reasoncode3,
        ccd_depositamount: values && values.ccd_depositamount,
        tran_attachement: values && values.tran_attachement,
        tran_document_name: values && values.tran_document_name,
      }
      this.setState({ defaultValues: obj })
      AlertSuccess("Selected row updated successfully!!!")
    }
    else {
      AlertError("Selected row is not in Draft to default the value!!!")
    }
  }

  setConfirm() {
    const { selectedIds } = this.state
    let err = false
    _.map(selectedIds, (row) => {
      if (row["ccd_depositdate"] && row["ccd_depositrefdocno"] && row["ccd_bankcode"] && row["ccd_depositamount"] !== null) {
      }
      else {
        err = true
      }
    });
    if (err) {
      AlertError("Default values are missing!!!")
    } else {
      this.props.confirm({ ccd_receipt: selectedIds })
    }
  }


  setHold() {
    const { selectedIds } = this.state
    if (selectedIds.length > 0) {
      this.props.hold({ ccd_receipt: selectedIds })
    }
  }

  setRelease() {
    const { selectedIds } = this.state
    if (selectedIds.length > 0) {
      this.props.release({ ccd_receipt: selectedIds })
    }
  }

  setSave() {
    const { selectedIds } = this.state
    if (selectedIds.length > 0) {
      this.props.save({ ccd_receipt: selectedIds })
    }
  }

  search(value, action) {
    if (value.length >= SEARCH_WORD_COUNT) {
      this.props.getReasonCode(
        action,
        `keyword=${value}`,
        action
      );
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "reason_code") {
      hash["ccd_reasoncode3"] = option.value;
      hash["wms_code_desc"] = option.wms_code_desc;
      hash['isValid'] = true
    }
    this.props.initialize(hash);
  }

  setFileName(fileName, url, base64) {
    let hash = {}
    if (this.props.formValues && this.props.formValues.values) {
      hash = _.cloneDeep(this.props.formValues.values);
    }
    hash['tran_document_name'] = fileName
    url['tran_document_name'] = fileName
    url['tran_attachement'] = base64
    hash['tran_attachement'] = base64
    this.props.initialize(hash);
  }

  formSubmit(values) {
    // TODO: Need to wire action
  }

  onButtonAction(action, status) {
    status = status || ['Draft', '', null]
    const { selectedIds } = this.state
    const allRecptStatus = _.map(selectedIds, 'ccd_receipt_status')
    const statusArr = _.differenceWith(allRecptStatus, status)
    if (statusArr.length > 0) {
      if (_.uniq(allRecptStatus).length === 1) {
        AlertError(`${_.uniq(allRecptStatus)[0]} status line item cannot be ${action}.`)
      } else {
        AlertError(statusValidationMsg[action.toLowerCase()])
      }
    } else {
      eval(`this.set${action}()`)
    }
  }

  compute() {
    if (this.state.selectedIds && this.state.selectedIds.length > 0) {
      let obj = _.cloneDeep(this.props.formValues.values)
      let data = _.reduce(this.state.selectedIds, (hash, pv) => {
        if (jsonLogic.apply(gridJsonRule, pv)) {
          hash['tlccd_amount_to_be_collected'] += parseInt(pv.cd_amount_collected) || 0
          hash['tlccd_amount_collected'] += parseInt(pv.tlccd_amount_collected) || 0
          hash['ccd_receipt_amount'] += parseInt(pv.ccd_receipt_amount) || 0
          hash['ccd_cashreceived'] += parseInt(pv.ccd_cashreceived) || 0
        }
        return hash
      }, { tlccd_amount_to_be_collected: 0, tlccd_amount_collected: 0, ccd_receipt_amount: 0, ccd_cashreceived: 0 })
      this.props.initialize(_.merge(obj, data))
    }
  }

  onUpdateRow(row, updateValue) {
    this.props.updateRow(row, updateValue)
    const response = _.reduce(this.state.selectedIds, (arr, item) => {
      if (item.ccd_br_no === row.ccd_br_no) {
        _.merge(item, updateValue)
      }
      arr.push(item)
      return arr
    }, [])
    this.setState({ selectedIds: response })
  }

  resetRows(rows) {
    this.props.resetRows(rows)
  }

  render() {
    const { handleSubmit, result, totalPage, bankCodes, reason_code, totalRecord, initializeCS, pageLimit, t } = this.props
    const disabled = this.state.selectedIds && this.state.selectedIds.length > 0
    const { defaultValues } = this.state
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid columns={columns}
                  rows={result}
                  rowKey="ccd_br_no"
                  totalPages={totalPage}
                  width={150}
                  paginationHandler={this.paginationHandler}
                  selectedRows={this.selectedRows}
                  changeLimit={this.changeLimit}
                  defaultValues={defaultValues}
                  defaultUptRule={gridJsonRule}
                  totalRecord={totalRecord}
                  enableExport={true}
                  rowEdit={this.onUpdateRow.bind(this)}
                  singleSelect={false}
                  exportName='CS'
                  initialize={initializeCS}
                  resetRows={this.resetRows.bind(this)}
                  pageLimit={pageLimit}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row>
              <Grid.Column width={5}>
                <button disabled={!disabled} type="button" onClick={() => this.compute()} className="primary btn-small">{t('computeBtn')}</button>
              </Grid.Column>
              <Grid.Column width={5}>
                <button id='save' type="button" disabled={!disabled} onClick={() => this.onButtonAction('Save')} className="primary btn-small">{t('saveBtn')}</button>
              </Grid.Column>
              <Grid.Column width={6}>
                <button id='default' type="button" disabled={!disabled} onClick={handleSubmit(values => this.setDefaults(values))} className="primary btn-small">{t('defaultBtn')}</button>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={4} className="small-width">
                <Field name="tlccd_amount_to_be_collected" component={InputField} label={t('tlccd_amount_to_be_collected')} readOnly={true} />
                <Field name="tlccd_amount_collected" component={InputField} label={t('tlccd_amount_collected')} readOnly={true} />
                <Field name="ccd_cashreceived" component={InputField} label={t('ccd_cashreceived')} readOnly={true} />
                <Field name="ccd_receipt_amount" component={InputField} label={t('ccd_receipt_amount')} readOnly={true} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="ccd_depositrefdocno" component={InputField} label={t('ccd_depositrefdocno')} />
                <Field name="ccd_bankcode" component={Dropdown} label={t('ccd_bankcode')} options={bankCodes} clearable={true} />
                <Field name="deposit_def_doc" component={FieldUpload} label={t('deposit_def_doc')} showInput={true} getFileName={this.setFileName} />
              </Grid.Column>
              <Grid.Column width={3}>
                <Field name="ccd_depositdate" component={DateTimePicker} label={t('ccd_depositdate')} />
                <Field id="reason_code" name="ccd_reasoncode3" component={InputSearchField} label={t('ccd_reasoncode3')} options={reason_code} fillNameValues={this.setValue} findByCompanyAndFLMName={this.search} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="ccd_depositamount" component={InputField} label={t('ccd_depositamount')} />
                <Field name="wms_code_desc" component={InputField} label={t('wms_code_desc')} readOnly={true} />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={11}>
                <div className="text-center">
                  <button id='confirm' disabled={!disabled} onClick={() => this.onButtonAction('Confirm', ['Draft'])} type="submit" className="primary btn-small">{t('confirmBtn')}</button>
                </div>
              </Grid.Column>
              <Grid.Column width={2}>
                <button id='hold' disabled={!disabled} onClick={() => this.onButtonAction('Hold', ['Deposited'])} type="button" className="primary btn-small">{t('holdBtn')}</button>
              </Grid.Column>
              <Grid.Column width={2}>
                <button id='release' disabled={!disabled} onClick={() => this.onButtonAction('Release', ['Deposited', 'Held'])} type="button" className="primary btn-small">{t('releaseBtn')}</button>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    )
  }
}

ResultTable = reduxForm({
  form: 'ResultTableForm',
  validate
})(ResultTable);

const mapDispatchToProps = (dispatch) => ({
  search: (values, pageNo, limit) => dispatch(csAction.search(values, pageNo, limit)),
  getReasonCode: (action, queryStr) =>
    dispatch(getReasonCode(action, queryStr)),
  save: (values) => dispatch(csAction.buttonAction(values, 'save')),
  confirm: (values) => dispatch(csAction.buttonAction(values, 'confirm')),
  hold: (values) => dispatch(csAction.buttonAction(values, 'hold')),
  release: (values) => dispatch(csAction.buttonAction(values, 'release')),
  updateRow: (row, updateValue) => dispatch(csAction.updateRow(row, updateValue)),
  initializeCS: () => dispatch(csAction.initializeCS()),
  resetRows: (rows) => dispatch(csAction.resetData(rows)),
})

const mapStateToProps = state => ({
  result: state.csReducer.result,
  totalPage: state.csReducer.totalPage,
  totalRecord: state.csReducer.totalRecord,
  searchForm: state.form.SearchForm,
  formValues: state.form.ResultTableForm,
  bankCodes: state.masterReducer.options.bankCodes,
  reason_code: state.masterReducer.options.reason_code,
  pageLimit: state.csReducer.limit,
})

export default compose(withTranslation('csForm'), connect(mapStateToProps, mapDispatchToProps))(ResultTable)
