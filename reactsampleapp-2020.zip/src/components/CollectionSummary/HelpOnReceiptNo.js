import React, { Component } from 'react'
import { reduxForm } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { gridHeaders, basicFields } from './ReceiptHelper';
import { searchReceipt, initializeReceipt } from "actions/csAction";
import { formatFormValues } from 'lib/CommonHelper';
import DynamicFields from 'components/Common/DynamicFields';
import DataGrid from 'components/Common/DataGrid';
import { getCurrency, getreceiptNoStatus } from "actions/masterAction";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';

class HelpOnReceiptNo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      filterFields: basicFields,
      selectedRecord: null,
      error: '',
      page: 1,
      defaultValues: null,
      selectedIds: null
    }
    this.formSubmit = this.formSubmit.bind(this);
    this.paginationHandler = this.paginationHandler.bind(this);
    this.selectedRows = this.selectedRows.bind(this);
    this.changeLimit = this.changeLimit.bind(this);
    this.getReceiptDetails = this.getReceiptDetails.bind(this);
  }

  componentDidMount() {

    const { getCurrency, currencies, receiptNoStatus, getreceiptNoStatus } = this.props;
    if (currencies.length === 0) {
      getCurrency("currencies");
    }
    if (receiptNoStatus.length === 0) {
      getreceiptNoStatus("receiptNoStatus")
    }
  }

  formSubmit(values) {
    this.props.search(formatFormValues(values), 1, 10, true);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  changeLimit(pageNo, limit) {
    this.props.search(formatFormValues(this.props.HelpOnReceiptNo.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.search(formatFormValues(this.props.HelpOnReceiptNo.values), pageNo, limit);
  }

  getReceiptDetails() {
    const { selectedIds } = this.state
    const { close, name } = this.props
    if (selectedIds !== null) {
      this.props.getReceiptDetails(selectedIds, name)
      close('help', 'ccd_receipt_no')
    }
  }

  render() {
    const { error, filterFields, defaultValues } = this.state
    const { currencies, isRequested, handleSubmit, result, totalPage, totalRecord, receiptNoStatus, initializeReceipt, t } = this.props
    const disabled = this.state.selectedIds && this.state.selectedIds.length > 0
    return (
      <div>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable>
            {error && <span className='error-msg'>{error}</span>}
            <Grid.Row>
              <DynamicFields
                filterFields={filterFields}
                currencies={currencies}
                receiptNoStatus={receiptNoStatus}
                cols={3}
              />
            </Grid.Row>
          </Grid>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='search' type="submit" className="primary" disabled={isRequested}>
                    {t('searchBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={gridHeaders}
                rows={result}
                rowKey="ccd_receipt_no"
                totalPages={totalPage}
                width={250}
                paginationHandler={this.paginationHandler}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                defaultValues={defaultValues}
                totalRecord={totalRecord}
                enableExport={true}
                singleSelect={true}
                initialize={initializeReceipt}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='details' onClick={this.getReceiptDetails} type="button" className="primary" disabled={!disabled}>
                  {t('okBtn')}
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

HelpOnReceiptNo = reduxForm({
  form: 'HelpOnReceiptNo'
})(HelpOnReceiptNo);

const mapDispatchToProps = (dispatch) => ({
  search: (values, pageNo, pageLimit, isSearch) => dispatch(searchReceipt(values, pageNo, pageLimit, isSearch)),

  getCurrency: (type, queryStr) =>
    dispatch(getCurrency(type, queryStr)),

  getreceiptNoStatus: type =>
    dispatch(getreceiptNoStatus(type)),
  initializeReceipt: () => dispatch(initializeReceipt())

})

const mapStateToProps = state => ({
  result: state.csReducer.receiptResult,
  totalPage: state.csReducer.totalPage,
  totalRecord: state.csReducer.totalRecord,
  currencies: state.masterReducer.options.currencies,
  receipt_no_from: state.masterReducer.options.ccd_receipt_no_from,
  receipt_no_to: state.masterReducer.options.ccd_receipt_no_to,
  isRequested: state.csReducer.isRequested,
  receiptNoStatus: state.masterReducer.options.receiptNoStatus,
  HelpOnReceiptNo: state.form.HelpOnReceiptNo,
})

export default compose(withTranslation('csHelp'), connect(mapStateToProps, mapDispatchToProps))(HelpOnReceiptNo)
