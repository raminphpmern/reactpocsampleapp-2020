import React, { Component } from 'react';
import Wrapper from "components/LandingPage/Wrapper";
import ResultTable from './ResultTable';
import SearchForm from './SearchForm';
import { withTranslation } from 'react-i18next';
import { Icon } from 'semantic-ui-react'
import './cs.css';

class CollectionSummary extends Component {

  componentDidMount() {
    this.AddShortcuts()
  }

  AddShortcuts() {
    document.addEventListener("keydown", e => {
      if (e.altKey) {
        switch (e.keyCode) {
          case 67:
            e.preventDefault();
            document.getElementById('confirm').click()
            break;
          case 70:
            e.preventDefault();
            document.getElementById('search').click()
            break;

          default:
            break;
        }
      }
    });
  }


  render() {
    const { t } = this.props
    return (
      <Wrapper DisableBranch={true}>
        <div className="collection-head">
          <h3>{t('title')}</h3>
          <div className="back-link">
            <a href="javascript: false" onClick={this.props.history.goBack}>
              <Icon disabled name='arrow left' />
              {t('translation:back')}</a>
          </div>
        </div>
        <div className="collection-wrapper">
          <SearchForm />
          <ResultTable />
        </div>
      </Wrapper>
    )
  }
}

export default withTranslation('csForm')(CollectionSummary)