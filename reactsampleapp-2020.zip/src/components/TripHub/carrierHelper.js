import i18n from 'i18n';

export const gridHeaders = [
  { key: "wms_vendor_id", name: i18n.t('helpOnCarrierGrid:wms_vendor_id') },
  { key: "wms_vendor_name", name: i18n.t('helpOnCarrierGrid:wms_vendor_name') },
  { key: "classification", name: i18n.t('helpOnCarrierGrid:classification') },
  { key: "wms_vendor_address1", name: i18n.t('helpOnCarrierGrid:wms_vendor_address1') },
  { key: "wms_vendor_address2", name: i18n.t('helpOnCarrierGrid:wms_vendor_address2') },
  { key: "wms_vendor_address3", name: i18n.t('helpOnCarrierGrid:wms_vendor_address3') },
  { key: "wms_geo_city_code", name: i18n.t('helpOnCarrierGrid:wms_geo_city_code') },
  { key: "wms_geo_state_code", name: i18n.t('helpOnCarrierGrid:wms_geo_state_code') },
  { key: "wms_geo_country_code", name: i18n.t('helpOnCarrierGrid:wms_geo_country_code') },
  { key: "wms_geo_postal_code", name: i18n.t('helpOnCarrierGrid:wms_geo_postal_code') },
  { key: "wms_vendor_phone1", name: i18n.t('helpOnCarrierGrid:wms_vendor_phone1') },
  { key: "wms_vendor_phone2", name: i18n.t('helpOnCarrierGrid:wms_vendor_phone2') },
  { key: "wms_vendor_email", name: i18n.t('helpOnCarrierGrid:wms_vendor_email') },
  { key: "wms_vendor_currency", name: i18n.t('helpOnCarrierGrid:wms_vendor_currency') },
  { key: "wms_vendor_payterm", name: i18n.t('helpOnCarrierGrid:wms_vendor_payterm') },
  { key: "carrierstatus", name: i18n.t('helpOnCarrierGrid:carrierstatus') }
];

export const basicFields = [
  { label: i18n.t('helpOnCarrierForm:wms_vendor_id'), value: "wms_vendor_id", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_name'), value: "wms_vendor_name", type: "inputBox" },

  {
    label: i18n.t('helpOnCarrierForm:wms_paramcode'),
    value: "wms_paramcode",
    type: "dropDown",
    values: {
      props: {
        options: "carrierStatus",
        clearable: true
      }
    }
  },

  {
    label: i18n.t('helpOnCarrierForm:classification'),
    value: "classification",
    type: "dropDown",
    values: {
      props: {
        options: "classifications",
        clearable: true
      }
    }
  },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_currency'), value: "wms_vendor_currency", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_payterm'), value: "wms_vendor_payterm", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_address1'), value: "wms_vendor_address1", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_address2'), value: "wms_vendor_address2", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_address3'), value: "wms_vendor_address3", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_geo_city_code'), value: "wms_geo_city_code", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_geo_state_code'), value: "wms_geo_state_code", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_geo_country_code'), value: "wms_geo_country_code", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_geo_postal_code'), value: "wms_geo_postal_code", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_phone1'), value: "wms_vendor_phone1", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_email'), value: "wms_vendor_email", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_code'), value: "wms_vendor_code", type: "inputBox" },

  { label: i18n.t('helpOnCarrierForm:wms_vendor_code'), value: "wms_vendor_code", type: "inputBox" }
];
