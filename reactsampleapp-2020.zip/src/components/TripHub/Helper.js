import React from 'react';
import { Link } from 'react-router-dom';
import i18n from 'i18n';

const LinkFormatter = ({ value }) => {
  return (<Link to={`/tripLog/${encodeURIComponent(value)}`}>{value}</Link>)
};

export const gridHeaders = [
  { key: "plpth_trip_plan_id", name: i18n.t('tripHubGrid:plpth_trip_plan_id'), formatter: LinkFormatter },
  { key: "plpth_trip_plan_date", name: i18n.t('tripHubGrid:plpth_trip_plan_date') },
  { key: "plpth_trip_plan_status_desc", name: i18n.t('tripHubGrid:wms_code_desc') },
  { key: "wms_emp_employee_code", name: i18n.t('tripHubGrid:wms_emp_employee_code') },
  { key: "wms_veh_id", name: i18n.t('tripHubGrid:wms_veh_id') },
  { key: "tdtbd_feedback_level", name: i18n.t('tripHubGrid:tdtbd_feedback_level') },
  { key: "plpth_trip_plan_from", name: i18n.t('tripHubGrid:plpth_trip_plan_from') },
  { key: "plpth_trip_plan_to", name: i18n.t('tripHubGrid:plpth_trip_plan_to') }
];

export const basicFields = [
  {
    label: i18n.t('tripHubForm:plpth_trip_plan_id'), value: 'plpth_trip_plan_id', type: 'inputSearch', iconName: 'search',
    methods: {
      handleClick: 'toggle',
    },
    values: {
      props: {
        childName: "tripHelp",
      }
    }
  },

  {
    label: i18n.t('tripHubForm:wms_emp_employee_code'), value: 'wms_emp_employee_code', type: 'inputSearch', id: 'driverIds', iconName: 'search',
    methods: {
      handleClick: 'toggle',
    },
    values: {
      props: {
        childName: "employeeHelp",
      }
    }
  },

  {
    label: i18n.t('tripHubForm:planningDate'), value: 'planningDate', type: 'customDropDownDatePicker',
    values: {
      options: [
        {
          label: 'Earlier Than', value: 'earlier'
        },
        {
          label: 'Between', value: 'between'
        },
        {
          label: 'Later Than', value: 'later'
        }
      ],
    },
    datePicker: {
      fields: [
        { value: 'plpth_trip_plan_date_from' },
        { value: 'plpth_trip_plan_date_to' }
      ]
    }
  },

  {
    label: i18n.t('tripHubForm:wms_veh_id'), value: 'wms_veh_id', type: 'inputSearch', id: 'vehicleIds', iconName: 'search',
    methods: {
      handleClick: 'toggle',
    },
    values: {
      props: {
        childName: "vehicleHelp",
      }
    }
  },

  {
    label: i18n.t('tripHubForm:ddh_dispatch_doc_type'), value: 'doc_type', type: 'dropDown',
    values: {
      props: {
        options: 'dispatch_type',
        clearable: true,
      }
    }
  },

  { label: i18n.t('tripHubForm:ddh_dispatch_doc_no'), value: 'ddh_dispatch_doc_no', type: 'inputBox' },

  {
    label: i18n.t('tripHubForm:wms_code_desc'), value: 'plpth_trip_plan_status', type: 'dropDown',
    values: {
      props: {
        options: 'tripStatus',
        clearable: true,
      }
    }
  }

]

export const advancesFields = [
  {
    label: i18n.t('tripHubForm:br_customer_id'), value: 'br_customer_id', type: 'inputSearch', iconName: 'search',
    methods: {
      handleClick: 'toggle',
    },
    values: {
      props: {
        childName: "customerHelp",
      }
    }
  },

  {
    label: i18n.t('tripHubForm:wms_vendor_id'), value: 'wms_vendor_id', type: 'inputSearch', id: 'carrierIds', iconName: 'search',
    methods: {
      handleClick: 'toggle',
    },
    values: {
      props: {
        childName: "carrierHelp",
      }
    }
  },

  {
    label: i18n.t('tripHubForm:plptd_bk_req_id'), value: 'plptd_bk_req_id', type: 'inputBox',
  },

  {
    label: i18n.t('tripHubForm:plpth_vehicle_id'), value: 'plpth_vehicle_id', type: 'inputSearch', id: 'vehicleRegIds', iconName: 'search',
    methods: {
      handleClick: 'toggle',
    },
    values: {
      props: {
        childName: "vehicleHelp",
      }
    }
  },

  {
    label: i18n.t('tripHubForm:plpth_trip_plan_from'), value: 'plpth_trip_plan_from', type: 'inputSearch', id: 'hubLocationsFrom',
    methods: {
      findByCompanyAndFLMName: 'search',
      fillNameValues: 'fillData'
    },
    values: {
      props: {
        options: 'hubLocationsFrom'
      }
    }
  },

  {
    label: i18n.t('tripHubForm:plpth_trip_plan_to'), value: 'plpth_trip_plan_to', type: 'inputSearch', id: 'hubLocationsTo',
    methods: {
      findByCompanyAndFLMName: 'search',
      fillNameValues: 'fillData'
    },
    values: {
      props: {
        options: 'hubLocationsTo'
      }
    }
  },

  {
    label: i18n.t('tripHubForm:br_service_type'), value: 'br_service_type', type: 'dropDown',
    values: {
      props: {
        options: 'service_mode',
        clearable: true
      }
    }
  },
  {
    label: i18n.t('tripHubForm:br_sub_service_type'), value: 'br_sub_service_type', type: 'dropDown',
    values: {
      props: {
        options: 'shipment_type',
        clearable: true

      }
    }
  },
]

