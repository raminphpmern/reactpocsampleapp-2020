import React, { Component } from 'react';
import Wrapper from 'components/LandingPage/Wrapper';
import { Grid, Icon, Menu } from 'semantic-ui-react';
import SearchTemplate from 'components/Common/SearchTemplate';
import { basicFields, advancesFields, gridHeaders } from './Helper';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import Popup from 'components/Common/Popup';
import { fetchAll } from 'actions/searchTemplateActions';
import * as masterActions from 'actions/masterAction';
import DynamicFields from 'components/Common/DynamicFields';
import { loadDispatchDefaults } from "actions/dispatchDocumentAction";
import { search, initializetripHub } from "actions/tripHubAction";
import HelpOnTripPlan from "../Dispatch/DispatchCreate/HelpOnTripPlan";
import HelpOnCustomer from "../Dispatch/DispatchSearch/HelpOnCustomer";
import HelpOnEmployee from '../CollectionSummary/HelpOnEmployee';
import { SEARCH_WORD_COUNT } from 'config';
import { formatFormValues } from "lib/TripHubHelper";
import HelpOnVehicle from './HelpOnVehicle';
import HelpOnCarrier from "./HelpOnCarrier";
import DataGrid from 'components/Common/DataGrid';
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import history from 'routes/history'
import LinkPopUp from '../Common/DataGrid/LinkPopUp';
import DocumentTracker from 'components/TripPlan/DocumentTracker';
import { getValue } from "lib/LocalStorage";
import './triphub.css'
import _ from 'lodash';

class tripHub extends Component {
  constructor(props) {
    super(props)
    this.state = {
      hideForm: false,
      selectedOptions: [],
      selectedTemplate: {},
      options: [],
      filterFields: basicFields,
      activeItem: 'all',
      tripHelp: false,
      customerHelp: false,
      currentHelp: '',
      employeeHelp: false,
      vehicleHelp: false,
      carrierHelp: false,
      searchTags: null,
      selectedIds: null,
      showMe: true
    }
    this.search = this.search.bind(this)
    this.fillData = this.fillData.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.addFilter = this.addFilter.bind(this)
    this.onFilterSelect = this.onFilterSelect.bind(this)
    this.handleItemClick = this.handleItemClick.bind(this)
    this.toggleForm = this.toggleForm.bind(this)
    this.toggle = this.toggle.bind(this)
    this.selectTripId = this.selectTripId.bind(this)
    this.selectCusomerCode = this.selectCusomerCode.bind(this)
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
    this.onTemplateChange = this.onTemplateChange.bind(this)
    this.removeTagFilter = this.removeTagFilter.bind(this)
    this.editTagInput = this.editTagInput.bind(this)
    this.getVehicleDetails = this.getVehicleDetails.bind(this)
    this.getCarrierDetails = this.getCarrierDetails.bind(this);
  }

  componentDidMount() {
    const { fetchAllTemplates, tripStatus, getTripStatus, shipment_type, service_mode, getQuickCodeMaster, dispatch_type, getDispatchMasterValues } = this.props;

    fetchAllTemplates()
    if (dispatch_type.length === 0) {
      getDispatchMasterValues()
    }
    if (tripStatus.length === 0) {
      getTripStatus()
    }
    if (shipment_type.length === 0) {
      getQuickCodeMaster("shipment_type");
    }
    if (service_mode.length === 0) {
      getQuickCodeMaster("service_mode");
    }
    this.setState({ options: advancesFields })
  }

  componentWillReceiveProps(nextProps) {
    const { templates } = this.props
    if (templates !== nextProps.templates) {
      const template = nextProps.templates[0]
      if (template && Object.keys(this.state.selectedTemplate).length === 0) {
        const filters = basicFields.concat(template.tostd_search_fields)
        this.setState({ filterFields: filters, selectedTemplate: template, selectedOptions: filters })
      }
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === "hubLocationsTo" || fieldName === "hubLocationsFrom") {
        let field = fieldName.match(/hubLocations/)[0];
        this.props.getHubLocation(field, queryString, fieldName);
      }
    }
    if (value.length === 0) {
      document.getElementById("hubLocationsTo").value = "";
      document.getElementById("hubLocationsTo").readOnly = false;
      document.getElementById("hubLocationsFrom").value = "";
      document.getElementById("hubLocationsFrom").readOnly = false;
    }
  }

  fillData(option, fieldName) {
    const location = JSON.parse(getValue("currentBranch"))
      ? JSON.parse(getValue("currentBranch"))
      : null;
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "hubLocationsTo") {
      hash["plpth_trip_plan_to"] = option.value;
      hash["plpth_trip_plan_from"] = location.wms_loc_code;
      document.getElementById("hubLocationsFrom").readOnly = true;
    }
    if (fieldName === "hubLocationsFrom") {
      hash["plpth_trip_plan_from"] = option.value;
      hash["plpth_trip_plan_to"] = location.wms_loc_code;
      document.getElementById("hubLocationsTo").readOnly = true;
    }
    this.props.initialize(hash);
  }

  removeTagFilter(value, key) {
    const values = this.props.formValues.values
    let { searchTags } = this.state
    delete values[key]
    delete searchTags[key]
    let { filter } = formatFormValues(values, this.state.filterFields)
    this.setState({ searchTags })
    this.props.search(filter, 1, this.props.limit);
  }

  editTagInput(key) {
    this.setState({ hideForm: false })
  }

  handleItemClick(e, { name }) {
    const { formValues } = this.props
    this.setState({ activeItem: name })
    let { filter } = formatFormValues(formValues.values, this.state.filterFields)
    _.merge(filter, { periodic_filter: name })
    this.props.search(filter, 1, this.props.limit);
  }

  addFilter() {
    this.setState({ filterFields: basicFields.concat(this.state.selectedOptions) })
  }

  onFilterSelect(option) {
    this.setState({ selectedOptions: option })
  }

  formSubmit(values) {
    const { tags, filter } = formatFormValues(values, this.state.filterFields)
    this.setState({ searchTags: tags, hideForm: true, showMe: false })
    this.props.search(filter, 1, this.props.limit, true);
  }

  toggleForm() {
    this.setState({ hideForm: !this.state.hideForm })
  }

  toggle(modalType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  selectTripId(selectedTripId) {
    if (selectedTripId && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["plpth_trip_plan_id"] = selectedTripId["plpth_trip_plan_id"]
      this.props.initialize(hash)
    }
  }

  selectCusomerCode(selectedCustomerCode) {
    if (selectedCustomerCode && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["br_customer_id"] = selectedCustomerCode
      this.props.initialize(hash)
    }
  }

  getEmployeeDetails(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["wms_emp_employee_code"] = data[0]["wms_emp_employee_code"]
      this.props.initialize(hash)
    }
  }

  getVehicleDetails(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["wms_veh_id"] = data[0]["wms_veh_id"]
      hash["plpth_vehicle_id"] = data[0]["wms_veh_reg_no"]
      this.props.initialize(hash)
    }
  }

  getCarrierDetails(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["wms_vendor_id"] = data[0]["wms_vendor_id"]
      this.props.initialize(hash)
    }
  }

  onTemplateChange(option) {
    if (option && option.tostd_search_fields) {
      const filters = basicFields.concat(option.tostd_search_fields)
      this.setState({ filterFields: filters, selectedTemplate: option, selectedOptions: option.tostd_search_fields })
    } else {
      this.setState({ filterFields: basicFields, selectedTemplate: {}, selectedOptions: [] })
    }
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  changeLimit(pageNo, limit) {
    const values = this.props.formValues.values
    const { tags, filter } = formatFormValues(values, this.state.filterFields)
    this.setState({ searchTags: tags })
    this.props.search(filter, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    const values = this.props.formValues.values
    const { tags, filter } = formatFormValues(values, this.state.filterFields)
    this.setState({ searchTags: tags })
    this.props.search(filter, pageNo, limit);
  }


  render() {
    const { hideForm, selectedOptions, selectedTemplate, options, filterFields, tripHelp, currentHelp, customerHelp, employeeHelp, vehicleHelp, carrierHelp, activeItem, searchTags, showMe } = this.state
    const { handleSubmit, templates, tripStatus, shipment_type, service_mode, t, dispatch_type, triphubRecords, totalPage, totalRecord, initializetripHub, limit, hubLocationsFrom, hubLocationsTo, tripsToday, tripsWeek, all } = this.props
    return (
      <Wrapper DisableBranch={true}>
        <Popup size="fullscreen" open={tripHelp} close={() => { this.toggle('help', 'tripHelp') }}
          header={t('tripHubHelp:helpOnTripPlan')} description={<HelpOnTripPlan close={this.toggle} handleOnSelect={this.selectTripId} name={currentHelp} />} />

        <Popup size="fullscreen" open={customerHelp} close={() => { this.toggle('help', 'customerHelp') }} header={t('tripHubHelp:helpOnCustomerId')} description={<HelpOnCustomer close={this.toggle} handleOnSelect={this.selectCusomerCode} name={currentHelp} />} />

        <Popup size="fullscreen" open={employeeHelp} close={() => { this.toggle('help', 'employeeHelp') }} header={t('tripHubHelp:helpOnDriverId')} description={<HelpOnEmployee
          getEmployeeDetails={this.getEmployeeDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={vehicleHelp} close={() => { this.toggle('help', 'vehicleHelp') }} header={t('tripHubHelp:helpOnVehicleId')} description={<HelpOnVehicle
          getVehicleDetails={this.getVehicleDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={carrierHelp} close={() => { this.toggle("help", "carrierHelp") }} header={t('tripHubHelp:helpOnCarrierId')} description={<HelpOnCarrier
          getCarrierDetails={this.getCarrierDetails} close={this.toggle} name={currentHelp} />
        }
        />

        <div className="triphub-head">
          <div className='title'>
            <h3>{t('title')}</h3>
          </div>
          <div className="back-link">
            <a href="javascript: false" onClick={this.props.history.goBack}>
              <Icon disabled name='arrow left' />
              {t('translation:back')}</a>
            <button onClick={() => history.push('/tripLog')} type="button" className="secondary btn-small nav-btn">
              {t('trip_link')}
            </button>
          </div>
        </div>
        <div className="brhub-wrapper trip-plan-wrapper">
          <div className={(hideForm ? 'relative' : '') + ' toggle-title'}>
            <h3 onClick={this.toggleForm}>
              <Icon name={(hideForm ? 'down' : 'right') + ' caret'} size='large' />
              {t('searchTitle')}
            </h3>
          </div>
          {hideForm ? null :
            <form onSubmit={handleSubmit(this.formSubmit)}>
              <Grid stackable>
                <Grid.Row>
                  <Grid.Column width={8}>
                  </Grid.Column>
                  <Grid.Column width={8}>
                    <SearchTemplate
                      addFilter={this.addFilter}
                      selectedFieldsOptions={selectedOptions}
                      fieldOptions={options}
                      onChangeField={this.onFilterSelect}
                      templateOptions={templates}
                      selectedTemplate={selectedTemplate}
                      onTemplateChange={this.onTemplateChange}
                      templateType='TRIPHUB'
                    />
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row>
                  <DynamicFields
                    search={this.search}
                    fillData={this.fillData}
                    filterFields={filterFields}
                    toggle={this.toggle}
                    shipment_type={shipment_type}
                    service_mode={service_mode}
                    dispatch_type={dispatch_type}
                    tripStatus={tripStatus}
                    hubLocationsTo={hubLocationsTo}
                    hubLocationsFrom={hubLocationsFrom}
                  />
                </Grid.Row>
                <Grid.Row>
                  <Grid.Column width={14} className="text-center">
                    <button type="submit" className="primary btn-small btn-long">
                      {t('searchBtn')}
                    </button>
                  </Grid.Column>
                </Grid.Row>
              </Grid>
            </form>
          }
          {showMe ? null :
            <Grid stackable>
              <Grid.Row>
                <Grid.Column width={6} className='trip-hub'>
                  <Menu pointing>
                    <Menu.Item
                      name='today'
                      active={activeItem === 'today'}
                      onClick={this.handleItemClick}
                    >
                      Trips today ({tripsToday})

                    </Menu.Item>
                    <Menu.Item
                      name='week'
                      active={activeItem === 'week'}
                      onClick={this.handleItemClick}
                    >
                      Trips this Week ({tripsWeek})
                    </Menu.Item>
                    <Menu.Item
                      name='all'
                      active={activeItem === 'all'}
                      onClick={this.handleItemClick}
                    >
                      All Trips ({all})
                    </Menu.Item>
                  </Menu>
                </Grid.Column>
                <Grid.Column width={10}></Grid.Column>
              </Grid.Row>
            </Grid>
          }
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
                <DataGrid
                  columns={gridHeaders}
                  rows={triphubRecords}
                  rowKey="plpth_trip_plan_id"
                  totalPages={totalPage}
                  selectedRows={this.selectedRows}
                  width={300}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  exportName='Trip-Hub'
                  initialize={initializetripHub}
                  limit={limit}
                  enableExport={true}
                  singleSelect={false}
                  tags={searchTags}
                  removeTagFilter={this.removeTagFilter}
                  editTag={this.editTagInput}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>
          <div className='actions br-hd-footer'>
            <LinkPopUp name="Document Tracker" defaultValue="Document Tracker">   <DocumentTracker transactionType='TRIP HUB' />
            </LinkPopUp>
          </div>
        </div>
      </Wrapper >
    )
  }
}

tripHub = reduxForm({
  form: "tripHub"
})(tripHub);

const mapDispatchToProps = dispatch => ({
  fetchAllTemplates: () => dispatch(fetchAll('TRIPHUB')),
  getTripStatus: type =>
    dispatch(masterActions.getTripStatus("tripStatus")),
  getQuickCodeMaster: type =>
    dispatch(masterActions.getQuickCodeMaster(type)),
  getDispatchMasterValues: (action, stateName) =>
    dispatch(loadDispatchDefaults("document_type", "dispatch_type")),
  getHubLocation: (action, queryStr, stateName) =>
    dispatch(masterActions.getHubLocation(action, queryStr, stateName)),
  search: (data, pageNo, limit, isSearch) => dispatch(search(data, pageNo, limit, isSearch)),
  initializetripHub: () => dispatch(initializetripHub()),

});

const mapStateToProps = state => ({
  tripHub: state.form.tripHub,
  templates: state.searchTemplateReducer.templates,
  shipment_type: state.masterReducer.options.shipment_type,
  service_mode: state.masterReducer.options.service_mode,
  tripStatus: state.masterReducer.options.tripStatus,
  hubLocationsFrom: state.masterReducer.options.hubLocationsFrom,
  hubLocationsTo: state.masterReducer.options.hubLocationsTo,
  formValues: state.form.tripHub,
  dispatch_type: state.dispatchReducer.options.dispatch_type,
  triphubRecords: state.triphubReducer.result,
  totalPage: state.triphubReducer.totalPage,
  totalRecord: state.triphubReducer.totalRecord,
  tripsToday: state.triphubReducer.tripsToday,
  tripsWeek: state.triphubReducer.tripsWeek,
  all: state.triphubReducer.all,
  limit: state.triphubReducer.limit
});


export default compose(withTranslation('tripHub'), connect(mapStateToProps, mapDispatchToProps))(tripHub)