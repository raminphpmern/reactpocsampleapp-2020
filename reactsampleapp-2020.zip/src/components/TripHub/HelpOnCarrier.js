import React, { Component } from "react";
import { reduxForm } from "redux-form";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import { gridHeaders, basicFields } from "./carrierHelper";
import DynamicFields from "components/Common/DynamicFields";
import DataGrid from "components/Common/DataGrid";
import { getClassifications, getCarrierStatus } from "actions/masterAction";
import { carrierSearch } from "actions/tripHubAction";
import { formatFormValues } from 'lib/CommonHelper';
import { initializeCarrier } from "actions/tripHubAction";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';

class HelpOnCarrier extends Component {
  constructor(props) {
    super(props);
    this.state = {
      filterFields: basicFields,
      selectedRecord: null,
      error: ""
    };
    this.formSubmit = this.formSubmit.bind(this);
    this.getCarrierDetails = this.getCarrierDetails.bind(this);
    this.selectedRows = this.selectedRows.bind(this);
    this.changeLimit = this.changeLimit.bind(this);
    this.paginationHandler = this.paginationHandler.bind(this);
  }

  componentDidMount() {
    const {
      carrierStatus,
      getCarrierStatus,
      classifications,
      getClassifications
    } = this.props;
    if (carrierStatus.length === 0) {
      getCarrierStatus();
    }
    if (classifications.length === 0) {
      getClassifications();
    }
  }

  formSubmit(values) {
    this.props.carrierSearch(formatFormValues(values), 1, 10, true);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values });
  }

  changeLimit(pageNo, limit) {
    this.props.carrierSearch(
      formatFormValues(this.props.HelpOnCarrier.values),
      pageNo,
      limit
    );
  }

  paginationHandler(pageNo, limit) {
    this.props.carrierSearch(
      formatFormValues(this.props.HelpOnCarrier.values),
      pageNo,
      limit
    );
  }

  getCarrierDetails() {
    const { selectedIds } = this.state;
    const { close } = this.props;
    if (selectedIds !== null) {
      this.props.getCarrierDetails(selectedIds);
      close("help", "carrierHelp");
    }
  }

  render() {
    const { error, filterFields } = this.state;
    const {
      isRequested,
      handleSubmit,
      classifications,
      carrierStatus,
      carrierRecords,
      totalPage,
      totalRecord,
      initializeCarrier
    } = this.props;
    const disabled =
      this.state.selectedIds && this.state.selectedIds.length > 0;

    return (
      <div>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable>
            {error && <span className="error-msg">{error}</span>}
            <Grid.Row>
              <DynamicFields
                filterFields={filterFields}
                classifications={classifications}
                carrierStatus={carrierStatus}
                cols={3}
              />
            </Grid.Row>
          </Grid>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button
                    id="search"
                    type="submit"
                    className="primary"
                    disabled={isRequested}
                  >
                    Search
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={gridHeaders}
                width={150}
                rows={carrierRecords}
                rowKey="wms_vendor_id"
                totalPages={totalPage}
                paginationHandler={this.paginationHandler}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                totalRecord={totalRecord}
                enableExport={true}
                singleSelect={true}
                initialize={initializeCarrier}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button
                  id="details"
                  onClick={this.getCarrierDetails}
                  type="button"
                  className="primary"
                  disabled={!disabled}
                >
                  OK
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    );
  }
}

HelpOnCarrier = reduxForm({
  form: "HelpOnCarrier"
})(HelpOnCarrier);

const mapStateToProps = state => ({
  HelpOnCarrier: state.form.HelpOnCarrier,
  carrierStatus: state.masterReducer.options.carrierStatus,
  classifications: state.masterReducer.options.classifications,
  carrierRecords: state.triphubReducer.carrierResult,
  totalPage: state.triphubReducer.carrierTotalPage,
  totalRecord: state.triphubReducer.carrierTotalRecord
});

const mapDispatchToProps = dispatch => ({
  getCarrierStatus: type => dispatch(getCarrierStatus("carrierStatus")),
  getClassifications: type => dispatch(getClassifications("classifications")),
  initializeCarrier: () => dispatch(initializeCarrier()),
  carrierSearch: (values, pageNo, pageLimit, isSearch) =>
    dispatch(carrierSearch(values, pageNo, pageLimit, isSearch))
});


export default compose(withTranslation('HelpOnCarrier'), connect(mapStateToProps, mapDispatchToProps))(HelpOnCarrier)