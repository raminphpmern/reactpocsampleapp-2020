import React, { Component } from 'react'
import { reduxForm } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { gridHeaders, basicFields } from './vehicleHelper';
import DynamicFields from 'components/Common/DynamicFields';
import DataGrid from 'components/Common/DataGrid';
import { getOwnerType, getEmployeeStatus, getVehicleType } from "actions/masterAction";
import { vehicleSearch, initializeVeh } from 'actions/tripHubAction';
import { formatFormValues } from 'lib/CommonHelper';
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';

class HelpOnVehicle extends Component {
  constructor(props) {
    super(props);
    this.state = {
      filterFields: basicFields
    };
    this.formSubmit = this.formSubmit.bind(this);
    this.getVehicleDetails = this.getVehicleDetails.bind(this);
    this.paginationHandler = this.paginationHandler.bind(this);
    this.changeLimit = this.changeLimit.bind(this);
    this.selectedRows = this.selectedRows.bind(this);
  }

  componentDidMount() {
    const {
      ownerType,
      getOwnerType,
      employeeStatus,
      getEmployeeStatus,
      vehicleType,
      getVehicleType } = this.props;
    if (ownerType.length === 0) {
      getOwnerType();
    }
    if (employeeStatus.length === 0) {
      getEmployeeStatus()
    }
    if (vehicleType.length === 0) {
      getVehicleType()
    }
  }

  formSubmit(values) {
    this.props.vehicleSearch(formatFormValues(values), 1, 10, true);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  changeLimit(pageNo, limit) {
    this.props.vehicleSearch(formatFormValues(this.props.HelpOnVehicle.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.vehicleSearch(formatFormValues(this.props.HelpOnVehicle.values), pageNo, limit);
  }

  getVehicleDetails() {
    const { selectedIds } = this.state
    const { close } = this.props
    if (selectedIds !== null) {
      this.props.getVehicleDetails(selectedIds)
      close('help', 'vehicleHelp')
    }
  }

  render() {
    const { filterFields } = this.state
    const { isRequested, handleSubmit, ownerType, employeeStatus, vehicleType, vehcileRecords, totalPage, totalRecord, initializeVeh } = this.props
    const disabled = this.state.selectedIds && this.state.selectedIds.length > 0
    return (
      <div>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable>
            <Grid.Row>
              <DynamicFields
                filterFields={filterFields}
                ownerType={ownerType}
                employeeStatus={employeeStatus}
                vehicleType={vehicleType}
                cols={3}

              />
            </Grid.Row>
          </Grid>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='search' type="submit" className="primary" disabled={isRequested}>
                    Search
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={gridHeaders}
                width={200}
                rows={vehcileRecords}
                rowKey="wms_veh_id"
                totalPages={totalPage}
                totalRecord={totalRecord}
                paginationHandler={this.paginationHandler}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                enableExport={true}
                singleSelect={true}
                initialize={initializeVeh}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='details' onClick={this.getVehicleDetails} type="button" className="primary" disabled={!disabled}>
                  OK
                  </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

HelpOnVehicle = reduxForm({
  form: 'HelpOnVehicle'
})(HelpOnVehicle);

const mapStateToProps = state => ({
  HelpOnVehicle: state.form.HelpOnVehicle,
  employeeStatus: state.masterReducer.options.employeeStatus,
  ownerType: state.masterReducer.options.ownerType,
  vehicleType: state.masterReducer.options.vehicleType,
  vehcileRecords: state.triphubReducer.vehicleResult,
  totalPage: state.triphubReducer.vehicleTotalPage,
  totalRecord: state.triphubReducer.vehicleTotalRecord,
  isRequested: state.triphubReducer.isRequested,
})

const mapDispatchToProps = (dispatch) => ({
  getOwnerType: type =>
    dispatch(getOwnerType("ownerType")),
  getEmployeeStatus: type =>
    dispatch(getEmployeeStatus("employeeStatus")),
  getVehicleType: type =>
    dispatch(getVehicleType("vehicleType")),
  vehicleSearch: (values, pageNo, pageLimit, isSearch) => dispatch(vehicleSearch(values, pageNo, pageLimit, isSearch)),
  initializeVeh: () => dispatch(initializeVeh())
})

export default compose(withTranslation('HelpOnVehicle'), connect(mapStateToProps, mapDispatchToProps))(HelpOnVehicle)
