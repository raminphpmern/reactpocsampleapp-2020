import i18n from 'i18n';

export const gridHeaders = [
  { key: "wms_veh_id", name: i18n.t('helpOnVehicleGrid:wms_veh_id') },
  { key: "wms_veh_desc", name: i18n.t('helpOnVehicleGrid:wms_veh_desc') },
  { key: "veh_type", name: i18n.t('helpOnVehicleGrid:veh_type') },
  { key: "own_type", name: i18n.t('helpOnVehicleGrid:own_type') },
  { key: "veh_status", name: i18n.t('helpOnVehicleGrid:veh_status') },
  { key: "wms_veh_agency_id", name: i18n.t('helpOnVehicleGrid:wms_veh_agency_id') },
  { key: "wms_vendor_name", name: i18n.t('helpOnVehicleGrid:wms_vendor_name') },
  { key: "wms_veh_reg_no", name: i18n.t('helpOnVehicleGrid:wms_veh_reg_no') },
  { key: "wms_veh_issuing_date", name: i18n.t('helpOnVehicleGrid:wms_veh_id') },
  { key: "category", name: i18n.t('helpOnVehicleGrid:category') },
  { key: "wms_veh_def_loc", name: i18n.t('helpOnVehicleGrid:wms_veh_def_loc') },
  { key: "wms_veh_cur_loc", name: i18n.t('helpOnVehicleGrid:wms_veh_cur_loc') },
  { key: "wms_veh_vin", name: i18n.t('helpOnVehicleGrid:wms_veh_vin') },
  { key: "wms_veh_model", name: i18n.t('helpOnVehicleGrid:wms_veh_model') },
  { key: "wms_veh_exp_date", name: i18n.t('helpOnVehicleGrid:wms_veh_exp_date') }
];

export const basicFields = [
  { label: i18n.t('helpOnVehicleForm:wms_veh_id'), value: 'wms_veh_id', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:wms_veh_desc'), value: 'wms_veh_desc', type: 'inputBox' },

  {
    label: i18n.t('helpOnVehicleForm:veh_status'), value: 'veh_status', type: 'dropDown',
    values: {
      props: {
        options: 'employeeStatus',
        clearable: true,
      }
    }
  },

  {
    label: i18n.t('helpOnVehicleForm:veh_typ'), value: 'veh_typ', type: 'dropDown',
    values: {
      props: {
        options: 'vehicleType',
        clearable: true,
      }
    }
  },

  { label: i18n.t('helpOnVehicleForm:wms_veh_reg_no'), value: 'wms_veh_reg_no', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:wms_veh_issuing_date'), value: 'wms_veh_issuing_date', type: 'dateTime' },

  {
    label: i18n.t('helpOnVehicleForm:veh_own'), value: 'veh_own', type: 'dropDown',
    values: {
      props: {
        options: 'ownerType',
        clearable: true,
      }
    }
  },

  { label: i18n.t('helpOnVehicleForm:wms_veh_agency_id'), value: 'wms_veh_agency_id', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:wms_vendor_name'), value: 'wms_vendor_name', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:wms_veh_vin'), value: 'wms_veh_vin', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:wms_veh_model'), value: 'wms_veh_model', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:wms_veh_exp_date'), value: 'wms_veh_exp_date', type: 'dateTime' },

  { label: i18n.t('helpOnVehicleForm:category'), value: 'category', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:referenceid'), value: 'referenceid', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:mfgname'), value: 'mfgname', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:wms_veh_def_loc'), value: 'wms_veh_def_loc', type: 'inputBox' },

  { label: i18n.t('helpOnVehicleForm:wms_veh_cur_loc'), value: 'wms_veh_cur_loc', type: 'inputBox' },
]
