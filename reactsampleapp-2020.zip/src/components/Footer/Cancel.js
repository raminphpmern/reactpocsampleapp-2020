import React, { Component } from 'react'
import { reduxForm, Field } from "redux-form";
import { connect } from 'react-redux';
import InputSearchField from "components/Common/InputSearchField";
import { SEARCH_WORD_COUNT } from "config";
import * as masterActions from "actions/masterAction";
import * as brHubActions from "actions/brHubActions";
import { getValue } from "lib/LocalStorage";
import _ from "lodash";
import InputField from "components/Common/InputField";

const validate = values => {
  const errors = {};
  if (!values.br_reason_code) {
    errors.br_reason_code = "Reason code is required."
  }
  if (!values.isValid) {
    errors.br_reason_code = "Reason code is not valid"
  }

  if (!values.br_control_id) {
    errors.br_control_id = "Control ID is required."
  }
  return errors
}

class Cancel extends Component {
  constructor(props) {
    super(props)
    this.formSubmit = this.formSubmit.bind(this)
    this.search = this.search.bind(this)
    this.fillData = this.fillData.bind(this)
  }

  componentDidMount() {
    this.props.initialize({ isValid: false });
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === "reason_code") {
        queryString += "&searchField=br_reason_code";
        this.props.getReasonCode("reason_code", queryString, fieldName)
        this.setState({ reason_code: this.props.reason_code })
      }
    }
  }

  fillData(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === 'reason_code') {
      hash['br_reason_code'] = option && option.wms_code_desc
      hash['isValid'] = true
    }
    this.props.initialize(hash);
  }


  formSubmit(values) {
    delete values['isValid']
    const { selectedIds } = this.props
    let br_id = []
    let id = getValue("br_id") ? getValue("br_id") : null
    if (id) {
      br_id.push(id)
      this.props.void(br_id, values, 'void', 'BR')
    } else if (selectedIds && selectedIds.length > 0) {
      this.props.void(selectedIds, values, 'void')
    }
    this.props.closePopup('cancel')
  }

  render() {
    const { handleSubmit, handleClose, reason_code } = this.props;
    return (
      <form onSubmit={handleSubmit(this.formSubmit)}>
        <Field name="br_reason_code" component={InputSearchField} findByCompanyAndFLMName={this.search}
          required={true}
          fillNameValues={this.fillData} options={reason_code} id="reason_code" label="Reason Code" />
        <Field name="br_control_id" component={InputField}
          required={true}
          id="control_id"
          label="Control Id" />
        <div className="actions">
          <button className="secondary" type="button" onClick={handleClose}>Cancel</button>
          <button type="submit">Proceed</button>
        </div>
      </form>
    )
  }
}

Cancel = reduxForm({
  form: 'CancelForm',
  validate
})(Cancel);

const mapDispatchToProps = (dispatch) => ({
  getReasonCode: (action, queryStr, stateName) =>
    dispatch(masterActions.getReasonCode(action, queryStr, stateName)),
  void: (ids, values, action, isbr) => dispatch(brHubActions.brActions(ids, values, action, isbr)),
})

const mapStateToProps = state => ({
  reason_code: state.masterReducer.options.reason_code,
  formValues: state.form.CancelForm,
  currentBooking: state.bookingReducer.currentBooking,
})

export default connect(mapStateToProps, mapDispatchToProps)(Cancel)