import React, { Component } from 'react'
import Popup from './../Common/Popup'
import Cancel from './Cancel'
import Amend from './Amend'
import { Icon } from "semantic-ui-react"
import { isMobile } from "config"
import './footer.css'

export default class Footer extends Component {
  constructor(props) {
    super(props)
    this.state = {
      cancel: false,
      amend: false,
      showFtMenu: false
    }
    this.toggelPopup = this.toggelPopup.bind(this)
  }

  toggelPopup(stateName) {
    this.setState({ [stateName]: !this.state[stateName] })
  }

  triggerMenu() {
    this.setState(prevState => ({
      showFtMenu: !prevState.showFtMenu
    }));
  }

  renderMobileView() {
    return (
      <div className="footer">
        <div className={this.state.showFtMenu ? "popupMenu active" : "popupMenu"}>
          <Popup trigger={<button className="secondary">Print POD</button>} header="Print POD"
            description={<h1>Add Description</h1>} />
          <Popup trigger={<button className="secondary">Print Label</button>} header="Print Label"
            description={<h1>Add Description</h1>} />
          <Popup size="mini" open={this.state.amend} close={() => { this.toggelPopup('amend') }}
            trigger={<button onClick={() => { this.toggelPopup('amend') }} className="secondary">Amend</button>}
            header="Amend" description={<Amend handleClose={() => { this.toggelPopup('amend') }} />} />
        </div>

        <div className="actions">
          <button type="button" className="secondary" onClick={() => this.triggerMenu()}><Icon name="ellipsis horizontal" /></button>
          <Popup size="mini" open={this.state.cancel} close={() => { this.toggelPopup('cancel') }}
            trigger={<button onClick={() => { this.toggelPopup('cancel') }} className="secondary">Void</button>}
            header="Cancel" description={<Cancel handleClose={() => { this.toggelPopup('cancel') }} />} />
          <button className="primary">Confirm Amendment</button>
        </div>
      </div>
    );
  }

  renderDesktopView() {
    const { currentBooking } = this.props
    const status = currentBooking && currentBooking.tms_br_booking_request_hdr && currentBooking.tms_br_booking_request_hdr.br_status
    const type = currentBooking && currentBooking.tms_br_booking_request_hdr && currentBooking.tms_br_booking_request_hdr.br_recurring_flag

    let brid = currentBooking && currentBooking.tms_br_booking_request_hdr && currentBooking.tms_br_booking_request_hdr.br_request_id
    let brids = []
    brids.push(brid)
    return (
      <div className="footer">
        <div className="actions">
          <div className="back-link">
            <a onClick={this.props.history.goBack}>
              <Icon disabled name='arrow left' />
              Back
            </a>
          </div>
          <Popup trigger={<button className="secondary">Print POD</button>} header="Print POD"
            description={<h1>Add Description</h1>} />
          <Popup trigger={<button className="secondary">Print Label</button>} header="Print Label"
            description={<h1>Add Description</h1>} />
          {type === 'Y' && <Popup size="mini" open={this.state.amend} close={() => { this.toggelPopup('amend') }}
            trigger={<button disabled={status !== 'Confirmed'} onClick={() => { this.toggelPopup('amend') }} className="secondary">Amend</button>}
            header="Amend" description={<Amend selectedIds={brids} handleClose={() => { this.toggelPopup('amend') }} from='BR' />} />}
          <Popup size="mini" open={this.state.cancel} close={() => { this.toggelPopup('cancel') }}
            trigger={<button onClick={() => { this.toggelPopup('cancel') }} className="secondary">Void</button>}
            header="Cancel" description={<Cancel selectedIds={brids} handleClose={() => { this.toggelPopup('cancel') }} closePopup={this.toggelPopup} />} />
          <button className="primary">Confirm Amendment</button>
        </div>
      </div>
    );
  }

  render() {
    if (isMobile)
      return this.renderMobileView();
    else return this.renderDesktopView();
  }
}
