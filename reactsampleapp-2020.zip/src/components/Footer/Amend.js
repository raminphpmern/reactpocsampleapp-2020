import React, { Component } from 'react'
import { reduxForm, Field } from "redux-form";
import { connect } from 'react-redux';
import * as brHubActions from "actions/brHubActions";
import * as masterActions from "actions/masterAction";
import InputSearchField from "components/Common/InputSearchField";
import { SEARCH_WORD_COUNT } from "config";
import _ from "lodash";

const validate = values => {
  const errors = {};
  if (!values.br_reason_code) {
    errors.br_reason_code = "Reason code is required."
  }
  if (!values.isValid) {
    errors.br_reason_code = "Reason code is not valid"
  }
  return errors
}


class Amend extends Component {
  constructor(props) {
    super(props)
    this.formSubmit = this.formSubmit.bind(this)
    this.search = this.search.bind(this)
    this.fillData = this.fillData.bind(this)
  }

  componentDidMount() {
    this.props.initialize({ isValid: false });
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      this.props.getReasonCode("reason_code", queryString, fieldName)
    }
  }

  fillData(option) {
    let hash = _.cloneDeep(this.props.formValues.values);
    hash['br_reason_code'] = option.wms_code_desc
    hash['isValid'] = true
    this.props.initialize(hash);
  }


  formSubmit(values) {
    delete values['isValid']
    if (this.props.selectedIds) {
      this.props.amend(this.props.selectedIds, values, 'amend', this.props.from)
      this.props.handleClose()
    }
  }

  render() {
    const { handleSubmit, handleClose, amend_reason_code } = this.props;
    return (
      <form onSubmit={handleSubmit(this.formSubmit)}>
        <Field name="br_reason_code" component={InputSearchField} findByCompanyAndFLMName={this.search} required={true}
          fillNameValues={this.fillData} options={amend_reason_code} id="amend_reason_code" label="Reason Code" />
        <div className="actions">
          <button className="secondary" type="button" onClick={handleClose}>Cancel</button>
          <button type="submit" >Proceed</button>
        </div>
      </form>
    )
  }
}

Amend = reduxForm({
  form: 'amendForm',
  validate
})(Amend);

const mapDispatchToProps = (dispatch) => ({
  amend: (ids, values, action, type) => dispatch(brHubActions.brActions(ids, values, action, type)),
  getReasonCode: (action, queryStr, stateName) =>
    dispatch(masterActions.getReasonCode(action, queryStr, stateName))
})

const mapStateToProps = state => ({
  amend_reason_code: state.masterReducer.options.amend_reason_code,
  formValues: state.form.amendForm,
})

export default connect(mapStateToProps, mapDispatchToProps)(Amend)