import React, { Component } from 'react'
import Wrapper from './../LandingPage/Wrapper'
import { Link } from 'react-router-dom';
import { Grid } from 'semantic-ui-react';

import './utilities.css'

export default class Utilities extends Component {
  render() {
    return (
      <Wrapper>
        <div className="utilities-wrapper">
          <h3 className="head">Utilities</h3>
          <Grid stackable>
            <Grid.Row >
              <Grid.Column width={4} className="utilities-link">
                <Link to="/">BR Hub</Link>
                <Link to="/">Change Password</Link>
                <Link to="/">Change Printer</Link>
                <Link to="/">DB Tools</Link>
                <Link to="/">DB Tools</Link>
                <Link to="/">Rate Calculator</Link>
                <Link to="/">Reprint</Link>
                <Link to="/">Shipment Guidelines</Link>
              </Grid.Column>
              <Grid.Column width={4} className="utilities-link">
                <Link to="/">Sync</Link>
                <Link to="/">Version</Link>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </div>
      </Wrapper>
    )
  }
}

