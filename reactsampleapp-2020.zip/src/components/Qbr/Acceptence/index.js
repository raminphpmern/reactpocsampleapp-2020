import React, { Component } from "react";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import OrderDetails from "components/Qbr/OrderDetails";
import DocumentAttachment from "components/Qbr/DocumentAttachment";
import CustomerDetails from "components/Qbr/CustomerDetails";
import Footer from "components/Footer";
import Charges from "components/Qbr/ChargeDetails";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import * as bookingActions from "actions/bookingActions";
import { updateBranchType } from "actions/loginAction";
import { getValue, setValue } from "lib/LocalStorage";
import Wrapper from "components/LandingPage/Wrapper";
import { isMobile, commonDateDisplayFormat } from "config";
import { Icon } from 'semantic-ui-react'
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import moment from 'moment';

class index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      initialize: false
    }
    this.displayBookingInfo = this.displayBookingInfo.bind(this);
    this.initializeBooking = this.initializeBooking.bind(this)
  }

  componentDidMount() {
    const currentStep = parseInt(getValue('currentStep'))
    const { match: { params } } = this.props;
    document.addEventListener("keydown", e => {
      if (e.altKey) {
        this.navigateTab(e);
      }
    });
    let br_id = getValue("br_id");
    if (params && params.brId) {
      this.props.initializeBooking()
      br_id = params.brId
      setValue('br_id', br_id)
    }
    setValue('currentStep', currentStep)
    if (br_id) {
      this.props.getBooking(br_id, 'type=booking_no', true);
    }
    const branch = getValue("currentBranch")
      ? JSON.parse(getValue("currentBranch"))
      : null;
    if (branch) this.props.updateBranchType(branch.wms_div_type);
  }

  componentWillUnmount() {
    this.props.initializeBooking()
  }

  navigateTab(e) {
    let tab = document.getElementsByClassName("react-tabs__tab-list")[0]
      .children;
    switch (e.keyCode) {
      case 49:
        e.preventDefault();
        if (tab[0].getAttribute("aria-disabled") === "false")
          this.onTabChange(0);
        break;
      case 50:
        e.preventDefault();
        if (tab[1].getAttribute("aria-disabled") === "false")
          this.onTabChange(1);
        break;
      case 51:
        e.preventDefault();
        if (tab[2].getAttribute("aria-disabled") === "false")
          this.onTabChange(2);
        break;
      case 52:
        e.preventDefault();
        if (tab[3].getAttribute("aria-disabled") === "false")
          this.onTabChange(3);
        break;
      default:
        break;
    }
  }

  displayBookingInfo(field) {
    const { currentBooking } = this.props;
    if (currentBooking) {
      return currentBooking["tms_br_booking_request_hdr"][field];
    }
  }

  onTabChange(tabIndex) {
    const { currentStep } = this.props;
    if (tabIndex > currentStep - 1) {
      let button = window.document.querySelector('[type="submit');
      if (button.disabled) {
        alert("Some of the mandatory fields are not filled!!!");
      } else {
        button.click();
        this.props.updateStep(tabIndex + 1);
      }
    } else {
      this.props.updateStep(tabIndex + 1);
    }
  }

  initializeBooking() {
    this.props.history.push('/acceptance')
    this.props.initializeBooking()
    this.setState({
      initialize: true
    }, () => {
      this.setState({ initialize: false })
    });
  }

  getDispatchEthuNo(type) {
    const { currentBooking } = this.props
    if (type === 'ethu')
      return currentBooking.ethu_tracking_no
    return currentBooking.tracking_no
  }

  render() {
    const { activeStep, currentStep, currentBooking, history, recurring, t } = this.props;
    let serviceType = this.displayBookingInfo("br_service_type")
    let subServiceType = this.displayBookingInfo("br_sub_service_type")


    return (
      <Wrapper DisableBranch={true}>
        <div className={`acceptance-wrapper page-${currentStep}`}>
          <Grid stackable className="fixed-grid fixed">
            <Grid.Row className={`${isMobile ? '' : 'no-padding'} ${currentStep === 1 ? 'bottom-border' : ''}`}>
              <Grid.Column width={5}>
                <div className="acceptance-head">
                  <label>{t('acceptance:bookingRequestID')} :</label>
                  <strong>{this.displayBookingInfo("br_request_id")}</strong>
                </div>
              </Grid.Column>
              <Grid.Column width={3}>
                <div className="acceptance-head">
                  <label>{t('acceptance:status')}:</label>
                  <strong>{this.displayBookingInfo("br_status")}</strong>
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="acceptance-head">
                  <label>{t('acceptance:brRemittanceDate')}:</label>
                  <strong></strong>
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="acceptance-head">
                  <label>{t('acceptance:referenceNo')}:</label>
                  <strong>
                    {this.displayBookingInfo("br_customer_ref_no")}
                  </strong>
                </div>
              </Grid.Column>
            </Grid.Row>
            {currentStep === 2 && <Grid.Row className={isMobile ? 'bottom-border' : 'bottom-border no-padding '}>
              <Grid.Column width={4}>
                <div className="acceptance-head">
                  <label>{t('acceptance:serviceType')}:</label>
                  <strong>{serviceType && serviceType.value}</strong>
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="acceptance-head">
                  <label>{t('acceptance:subServiceType')}:</label>
                  <strong>{subServiceType && subServiceType.value}</strong>
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="acceptance-head">
                  <label> {t('acceptance:brDate')}</label>
                  <strong>{moment(this.displayBookingInfo("br_requested_date")).format(commonDateDisplayFormat)}</strong>
                </div>
              </Grid.Column>
              <Grid.Column width={3}>
                <div className="acceptance-head">
                  <label>{t('acceptance:recurring')}:</label>
                  <div className="input_field">
                    <div className="input_holder">
                      <div className="radio">
                        <div className="radio-items">
                          <input id="radio_static_1" name="tms_br_booking_request_hdr.br_recurring_flag" type="radio" className="form-check-input" value="Y" disabled={true} />
                          <label htmlFor="radio_static_1">{t('acceptance:yes')}</label>
                        </div><div className="radio-items">
                          <input id="radio_static_2" name="tms_br_booking_request_hdr.br_recurring_flag" type="radio" className="form-check-input" value="N" checked={true} readOnly />
                          <label htmlFor="radio_static_2">{t('acceptance:no')}</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Grid.Column>
            </Grid.Row>}
            {currentStep > 2 && <Grid.Row className={isMobile ? 'bottom-border' : 'bottom-border no-padding '}>
              <Grid.Column width={5}>
                <div className="acceptance-head">
                  <label> {t('acceptance:dispatchDocumentNo')}:</label>
                  <strong>{this.getDispatchEthuNo('dispatch')}</strong>
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="acceptance-head">
                  <label>{t('acceptance:ethuNo')}:</label>
                  <strong>{this.getDispatchEthuNo('ethu')}</strong>
                </div>
              </Grid.Column>
            </Grid.Row>}
          </Grid>
          <Grid
            stackable
            className={`${!isMobile ? 'content-top-margin' : ''}`} style={{ height: `${!isMobile ? '100%' : '100%'}` }}>
            <Grid.Row className="no-padding">
              <Grid.Column width={16} style={{ paddingRight: 0 }}>
                <Tabs
                  onSelect={tabIndex => this.onTabChange(tabIndex)}
                  selectedIndex={currentStep - 1}
                >
                  {recurring === 'N' && <TabList>
                    <div className="new-booking">
                      <button type="button" onClick={() => this.initializeBooking()} className="secondary btn-small nav-btn">
                        <Icon name='add' /> {t('acceptance:quickBookingRequest')}
                      </button>
                    </div>
                    <Tab>{t('acceptance:customerDetails')}</Tab>
                    <Tab disabled={activeStep <= 1}>{t('acceptance:orderDetails')}</Tab>
                    <Tab disabled={activeStep <= 2}>{t('acceptance:documentAttachment')}</Tab>
                    <Tab disabled={activeStep <= 3}>{t('acceptance:charges')}</Tab>
                  </TabList>}
                  {recurring === 'Y' && <TabList>
                    <div className="new-booking">
                      <button type="button" onClick={() => this.initializeBooking()} className="secondary btn-small nav-btn">
                        <Icon name='add' /> {t('acceptance:quickBookingRequest')}
                      </button>
                    </div>
                    <Tab>{t('acceptance:customerDetails')}</Tab>
                  </TabList>}
                  <TabPanel>
                    <CustomerDetails initializeState={this.state.initialize} />
                  </TabPanel>
                  {recurring === 'N' && <TabPanel>
                    <OrderDetails />
                  </TabPanel>}
                  {recurring === 'N' && <TabPanel>
                    <DocumentAttachment />
                  </TabPanel>}
                  {recurring === 'N' && <TabPanel>
                    <Charges />
                  </TabPanel>
                  }
                </Tabs>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                <Footer currentBooking={currentBooking} history={history} />
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </div>
      </Wrapper>
    );
  }
}

const mapDispatchToProps = dispatch => ({
  getBooking: (bookingID, queryString, isRefresh) =>
    dispatch(bookingActions.search(bookingID, queryString, isRefresh)),
  updateBranchType: type => dispatch(updateBranchType(type)),
  updateStep: step => dispatch(bookingActions.updateStep(step)),
  initializeBooking: () => dispatch(bookingActions.initializeBooking())
});

const mapStateToProps = state => ({
  activeStep: state.bookingReducer.activeStep,
  currentStep: state.bookingReducer.currentStep,
  currentBooking: state.bookingReducer.currentBooking,
  recurring: state.bookingReducer.recurring
});

export default compose(withTranslation('acceptance'), connect(mapStateToProps, mapDispatchToProps))(index)