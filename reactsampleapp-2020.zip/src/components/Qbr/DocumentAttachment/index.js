import React, { Component } from 'react';
import { Table, Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { reduxForm, FieldArray } from 'redux-form';
import OrderHeader from './../OrderDetails/OrderHeader';
import DocumentList from './List';
import * as bookingActions from 'actions/bookingActions';
import * as documentActions from 'actions/documentAction';
import { fetchDocuments, getDocumentType, getDocType } from 'actions/masterAction';
import { getValue } from 'lib/LocalStorage';
import { buildDefaultProfiles } from 'lib/documentHelper';
import './document.css'
import _ from 'lodash'
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

const validate = values => {
  const errors = {};
  if (values.document_attachments) {
    const docErrors = []
    values.document_attachments.forEach((value, key) => {
      const memberErrors = {}
      if (value.applicable) {
        if (!value.vdd_doc_no_ml) {
          memberErrors.vdd_doc_no_ml = "Document number is required"
          docErrors[key] = memberErrors
        }
      }
    })
    if (docErrors.length) {
      errors.document_attachments = docErrors
    }
  }
  return errors
}

class DocumentAttachment extends Component {
  constructor(props) {
    super(props)
    this.formSubmit = this.formSubmit.bind(this)
    this.stepBack = this.stepBack.bind(this)
    this.setAttachmentDtl = this.setAttachmentDtl.bind(this)
  }

  componentDidMount() {
    const brId = getValue('br_id')
    const { currentBooking, document_profiles, documentType, getDocumentType, docType, getDocType } = this.props
    if (currentBooking && currentBooking['document_attachments'].length !== 0) {
      this.props.initialize({
        document_attachments: currentBooking['document_attachments']
      })
    }
    if (documentType.length === 0) {
      getDocumentType()
    }
    if (docType.length === 0) {
      getDocType();
    }
    if (document_profiles.length === 0) {
      this.props.fetchDocuments(brId)
    } else {
      this.props.initialize({
        document_attachments: buildDefaultProfiles(document_profiles, currentBooking)
      })
    }
  }

  componentWillReceiveProps(nextProps) {
    const { currentBooking, document_profiles } = this.props
    if (nextProps.document_profiles !== document_profiles) {
      this.props.initialize({
        document_attachments: buildDefaultProfiles(nextProps.document_profiles, currentBooking)
      })
    }
  }

  formSubmit(values) {
    const brId = getValue('br_id')
    const { currentBooking } = this.props
    if (currentBooking && currentBooking.tms_br_booking_request_hdr && currentBooking.tms_br_booking_request_hdr.br_status !== 'Incomplete') {
      this.props.updateStep(4)
    } else {
      if (currentBooking && currentBooking['document_attachments'].length !== 0) {
        this.props.updateDocument(values, 4, brId)
      } else {
        this.props.createDocument(values, 4, brId)
      }
    }
  }

  stepBack() {
    this.props.updateStep(2)
  }

  setAttachmentDtl(name, base64, index) {
    const { formValues, initialize } = this.props
    let hash = formValues ? _.cloneDeep(formValues.values) : { document_attachments: [] }
    let tempHash = {
      tran_document_name: name,
      tran_attachement: base64,
      vdd_doc_attachment: name,
    }
    _.merge(hash['document_attachments'][index], tempHash)
    initialize(hash)
  }

  render() {
    const { handleSubmit, documentType, formValues, isRequested, t, docType } = this.props;
    return (
      <div className="document-main">
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <OrderHeader>
            <Grid.Row className="document_wrapper add-min-width">
              <Grid.Column width={16}>
                <Table celled striped>
                  <Table.Header>
                    <Table.Row>
                      <Table.HeaderCell colSpan='11'>Customer Document Section</Table.HeaderCell>
                    </Table.Row>
                  </Table.Header>
                  <Table.Header>
                    <Table.Row>
                      <Table.HeaderCell>{t('documentAttachment:docuType')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('documentAttachment:docuNo')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('documentAttachment:expCopies')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('documentAttachment:docuDate')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('documentAttachment:docuAction')}</Table.HeaderCell>
                      <Table.HeaderCell >{t('documentAttachment:collectedCopies')}</Table.HeaderCell>
                      <Table.HeaderCell >{t('documentAttachment:attachment')}</Table.HeaderCell>
                      <Table.HeaderCell colSpan="2" />
                    </Table.Row>
                  </Table.Header>
                  <FieldArray name="document_attachments" component={DocumentList} documentType={documentType} bindAttachments={this.setAttachmentDtl} formValues={formValues} docType={docType} />
                </Table>
                <div className="doc-action">
                  <button className="link-button secondary" type="button" onClick={this.stepBack}>Back</button>
                  <button disabled={isRequested} type="submit" className="primary left-margin">Next</button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </OrderHeader>
        </form>
      </div>
    )
  }
}


DocumentAttachment = reduxForm({
  form: 'DocumentAttachmentForm',
  validate
})(DocumentAttachment);


const mapDispatchToProps = (dispatch) => ({
  updateStep: (step) => dispatch(bookingActions.updateStep(step)),
  createDocument: (params, step, brId) => dispatch(documentActions.create(params, step, brId)),
  updateDocument: (params, step, brId) => dispatch(documentActions.update(params, step, brId)),
  fetchDocuments: (brId) => dispatch(fetchDocuments(brId)),
  getDocumentType: type =>
    dispatch(getDocumentType("documentType")),
  getDocType: type => dispatch(getDocType("docType"))
})

const mapStateToProps = state => ({
  currentBooking: state.bookingReducer.currentBooking,
  document_profiles: state.masterReducer.options.document_profiles,
  documentType: state.masterReducer.options.documentType,
  formValues: state.form.DocumentAttachmentForm,
  isRequested: state.bookingReducer.isRequested,
  docType: state.masterReducer.options.docType
})

export default compose(withTranslation('documentAttachment'), connect(mapStateToProps, mapDispatchToProps))(DocumentAttachment)