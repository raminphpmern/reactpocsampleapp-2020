import React, { Component } from 'react'
import { Table } from 'semantic-ui-react';
import { Field } from 'redux-form';
import InputField from 'components/Common/InputField';
import DateTimePicker from 'components/Common/DateTimePicker';
import FileUpload from 'components/Common/FileUpload';
import DropDown from 'components/Common/Dropdown';

class DocumentList extends Component {
  constructor(props) {
    super(props)
    this.setFileInformations = this.setFileInformations.bind(this)
  }

  componentDidMount() {
    if (this.props.fields.length === 0) {
      this.props.fields.push({})
    }
  }

  setFileInformations(name, base64, index) {
    this.props.bindAttachments(name, base64, index)
  }

  render() {
    let { fields, documentType, formValues, docType } = this.props;
    const documents = formValues ? formValues.values['document_attachments'] : []
    return (
      <Table.Body>
        {fields.map((elem, index) => {
          const readOnly = documents[index] && documents[index].vdd_doc_prof_id
          return (
            <Table.Row key={index}>
              <Table.Cell>
                <Field name={`${elem}.vdd_doc_type_ml`} component={DropDown} options={docType} readOnly={readOnly} />
              </Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.vdd_doc_name_ml`} component={InputField} />
              </Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.vdd_no_copies_exp`} component={InputField} readOnly={readOnly} />
              </Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.vdd_doc_date_ml`} component={DateTimePicker} />
              </Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.vdd_doc_action`} component={DropDown} options={documentType} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.vdd_no_copies_recv`} component={InputField} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.tran_attachement`} component={FileUpload} getFileName={(name, tempUrl, base64) => { this.setFileInformations(name, base64, index) }} savedFileName={documents[index] ? documents[index].vdd_doc_attachment : null} />
              </Table.Cell>
              <Table.Cell>
                {fields.length - 1 === index &&
                  <i className="plus circle icon" onClick={() => fields.push({})}></i>
                }
              </Table.Cell>
              <Table.Cell>
                {index > 0 && <i className="minus circle icon" onClick={() => fields.remove(index)} ></i>}
              </Table.Cell>
            </Table.Row>
          )
        })}
      </Table.Body>
    )
  }
}

export default DocumentList;
