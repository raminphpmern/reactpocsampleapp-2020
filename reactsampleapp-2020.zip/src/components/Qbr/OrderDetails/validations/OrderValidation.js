const OrderValidation = values => {
  const errors = {};
  errors.tms_br_booking_request_hdr = {}
  errors.tms_brsd_shipment_details = {}
  if (!values.tracking_no && !values.ethu_tracking_no) {
    errors.tracking_no = "Dispatch Doc.No is required."
    errors.ethu_tracking_no = "ETHU Tracking no is required."
  }

  if (!values.child_thu) {
    errors.child_thu = "Child ETHU Tracking no is required."
  }

  if (values.tracking_no && values.tracking_no.length > 18) {
    errors.tracking_no = "Dispatch Doc.No can't be more than 18 character."
  }

  if (values.ethu_tracking_no && values.ethu_tracking_no.length > 18) {
    errors.ethu_tracking_no = "ETHU Tracking no can't be more than 18 character."
  }

  if (!values.re_enter) {
    errors.re_enter = "Re Enter Tracking no is required."
  }

  if (values.re_enter && values.re_enter.length > 18) {
    errors.re_enter = "ReEnter can't be more than 18 character."
  }
  if (values.re_enter && (values.tracking_no || values.ethu_tracking_no)) {
    if (values.re_enter !== values.tracking_no && values.re_enter !== values.ethu_tracking_no) {
      errors.re_enter = "ReEnter Mismatch."
    }
  }
  if (values.tms_br_booking_request_hdr) {
    if (values.tms_br_booking_request_hdr.br_cod || values.tms_br_booking_request_hdr.br_cop) {
      if (!values.tms_br_booking_request_hdr.br_declared_value) {
        errors.tms_br_booking_request_hdr.br_declared_value = "Declared Value is required."
      }
      if (!values.cod_cop_amount) {
        errors.cod_cop_amount = "COD/COP amount is required."
      }
      if (Object.keys(values.tms_br_booking_request_hdr.br_include).length === 0 || !values.tms_br_booking_request_hdr.br_include) {
        errors.tms_br_booking_request_hdr.br_include = "COP Include is required"
      }
    }
    if (!values.tms_br_booking_request_hdr.br_payment_type || Object.keys(values.tms_br_booking_request_hdr.br_payment_type).length === 0) {
      errors.tms_br_booking_request_hdr.br_payment_type = "Payment mode is required."
    }
  } else {
    errors.tms_br_booking_request_hdr.br_payment_type = "Payment mode is required."
  }
  if (values.tms_brsd_shipment_details) {
    if (!values.tms_brsd_shipment_details.brsd_to_delivery_date) {
      errors.tms_brsd_shipment_details.brsd_to_delivery_date = "Delivery Date is required."
    }
  } else {
    errors.tms_brsd_shipment_details.brsd_to_delivery_date = "Delivery Date is required."
  }

  // Reefer details section validation
  const reefer = 'tms_brcds_consgt_additional_services'
  if (values[reefer]) {
    if (values[reefer].cds_temp_controlled) {
      errors[reefer] = {}
      if (!values[reefer].cds_min_temp) {
        errors[reefer].cds_min_temp = 'Min temp is required.'
      }
      if (!values[reefer].cds_max_temp) {
        errors[reefer].cds_max_temp = 'Max temp is required.'
      }
      if (!values[reefer].cds_temp_uom) {
        errors[reefer].cds_temp_uom = 'Temp UOM is required.'
      }
    }
  }

  const vas = 'value_added_services'
  const vas_appl = 'vas_applicable'
  if (values[vas]) {
    const vasErrors = []
    values[vas].forEach((value, key) => {
      const memberErrors = {}
      let vas_description = value.tms_brvd_booking_request_vas_details.brvd_vas_description
      if (value.tms_brvd_booking_request_vas_details.brvd_applicable) {
        values[vas_appl].forEach((obj, err) => {
          if (obj.label === vas_description && obj.cus_vas_map_appl === '1') {
            if (value.tms_brvd_booking_request_vas_details.brvd_vas_qty) {
              value.tms_brvd_booking_request_vas_details.brvd_vas_qty = null
            }
          }
          else {
            if (!value.tms_brvd_booking_request_vas_details.brvd_vas_qty) {
              memberErrors.tms_brvd_booking_request_vas_details = {}
              memberErrors.tms_brvd_booking_request_vas_details.brvd_vas_qty = 'Quantity is Required'
              vasErrors[key] = memberErrors
            }
          }
        })
      }
      else {
        values[vas_appl].forEach((obj, err) => {
          if (obj.cus_vas_map_appl === '1' && obj.label === vas_description) {
            value.tms_brvd_booking_request_vas_details.brvd_applicable = true
          }
        })
      }
    })
    if (vasErrors.length) {
      errors.value_added_services = vasErrors
    }
  }

  if (values.shipment_details) {
    const productsErrors = []
    values.shipment_details.forEach((value, key) => {

      const memberErrors = {}
      memberErrors.tms_brcd_consgt_details = {}
      memberErrors.tms_brctd_consgt_thu_serial_details = {}

      if (!value.tms_brcd_consgt_details) {
        memberErrors.tms_brcd_consgt_details = tms_brcd_consgt_details
        productsErrors[key] = memberErrors
      }
      else {
        if (!value.tms_brcd_consgt_details.cd_thu_id) {
          memberErrors.tms_brcd_consgt_details.cd_thu_id = 'Product is required.'
          productsErrors[key] = memberErrors
        }
        if (!value.tms_brcd_consgt_details.cd_thu_qty) {
          memberErrors.tms_brcd_consgt_details.cd_thu_qty = 'Quantity is required.'
          productsErrors[key] = memberErrors
        } else {
          if (value.tms_brcd_consgt_details.cd_thu_qty < 1) {
            memberErrors.tms_brcd_consgt_details.cd_thu_qty = 'Quantity is Invalid.'
            productsErrors[key] = memberErrors
          }
          if (value.tms_brcd_consgt_details.cd_thu_qty > 1000) {
            memberErrors.tms_brcd_consgt_details.cd_thu_qty = 'Quantity is not allowed.'
            productsErrors[key] = memberErrors
          }
        }
        if (!value.tms_brcd_consgt_details.cd_gross_weight) {
          memberErrors.tms_brcd_consgt_details.cd_gross_weight = 'Gross weight is required.'
          productsErrors[key] = memberErrors
        } else {
          if (value.tms_brcd_consgt_details.cd_gross_weight < 1) {
            memberErrors.tms_brcd_consgt_details.cd_gross_weight = 'Gross weight is Invalid.'
            productsErrors[key] = memberErrors
          }
        }
      }
      if (value.tms_brctd_consgt_thu_serial_details) {
        if (value.tms_brctd_consgt_thu_serial_details.ctsd_length && value.tms_brctd_consgt_thu_serial_details.ctsd_length < 1) {
          memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_length = 'Length is Invalid.'
          productsErrors[key] = memberErrors
        }
        if (value.tms_brctd_consgt_thu_serial_details.ctsd_breadth && value.tms_brctd_consgt_thu_serial_details.ctsd_breadth < 1) {
          memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_breadth = 'Width is Invalid.'
          productsErrors[key] = memberErrors
        }
        if (value.tms_brctd_consgt_thu_serial_details.ctsd_height && value.tms_brctd_consgt_thu_serial_details.ctsd_height < 1) {
          memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_height = 'Height is Invalid.'
          productsErrors[key] = memberErrors
        }
        //validate only when the servicetype is moneyRemittance
        if (values.tms_br_booking_request_hdr.br_service_type.value.toUpperCase().match(/MONEY REMITTANCE/g)) {
          if (!value.tms_brctd_consgt_thu_serial_details.ctsd_altqty) {
            memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_altqty = 'AltQty is required.'
            productsErrors[key] = memberErrors
          } else {
            if (value.tms_brctd_consgt_thu_serial_details.ctsd_altqty < 1) {
              memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_altqty = 'AltQty is Invalid.'
              productsErrors[key] = memberErrors
            }
          }
          if (!value.tms_brctd_consgt_thu_serial_details.ctsd_altqty_uom) {
            memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_altqty_uom = 'AltUOM is required.'
            productsErrors[key] = memberErrors
          }
        }
      }

      if (!value.cbm) {
        if (!value.tms_brctd_consgt_thu_serial_details) {
          memberErrors.tms_brctd_consgt_thu_serial_details = tms_brctd_consgt_thu_serial_details
          productsErrors[key] = memberErrors
        } else {
          if (!value.tms_brctd_consgt_thu_serial_details.ctsd_length) {
            memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_length = 'Length is required.'
            productsErrors[key] = memberErrors
          }
          if (!value.tms_brctd_consgt_thu_serial_details.ctsd_breadth) {
            memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_breadth = 'Width is required.'
            productsErrors[key] = memberErrors
          }
          if (!value.tms_brctd_consgt_thu_serial_details.ctsd_height) {
            memberErrors.tms_brctd_consgt_thu_serial_details.ctsd_height = 'Height is required.'
            productsErrors[key] = memberErrors
          }
        }
      }
    })
    if (productsErrors.length) {
      errors.shipment_details = productsErrors
    }
  }
  return errors;
}

export default OrderValidation;


const tms_brcd_consgt_details = {
  cd_thu_id: 'Product is required.',
  cd_thu_qty: 'Quantity is required.',
  cd_gross_weight: 'Gross weight is required.'
}

const tms_brctd_consgt_thu_serial_details = {
  ctsd_length: 'Length is required.',
  ctsd_breadth: 'Width is required',
  ctsd_height: 'Height is required.',
  ctsd_altqty: 'AltQty is required.',
  ctsd_altqty_uom: 'AltUOM is required.'
}
