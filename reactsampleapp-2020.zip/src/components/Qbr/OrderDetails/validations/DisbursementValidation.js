const DisbursementValidation = values => {
  const errors = {};

  if (!values.brdm_disbursement_mode)
    errors.brdm_disbursement_mode = 'Disbursement mode is required.'

  if (values.brdm_disbursement_mode) {
    if (values.brdm_disbursement_mode.value === 'BT') {
      if (!values.brdm_bank_name)
        errors.brdm_bank_name = 'Bank name is required.'

      if (!values.re_brdm_account_no)
        errors.re_brdm_account_no = 'Confirm Account no is required.'

      if (!values.brdm_account_no)
        errors.brdm_account_no = 'Account no is required.'

      if (values.re_brdm_account_no !== values.brdm_account_no)
        errors.re_brdm_account_no = 'Account no mismatch.'

      if (!values.brdm_bank_code)
        errors.brdm_bank_code = 'Bank code is required.'

      if (!values.brdm_accountholder_name)
        errors.brdm_accountholder_name = 'Account holder name is required.'
    } else if (values.brdm_disbursement_mode.value === 'EW') {
      if (!values.brdm_ewalletid)
        errors.brdm_ewalletid = 'E-wallet id is required.'
    }
  }
  return errors
}
export default DisbursementValidation;
