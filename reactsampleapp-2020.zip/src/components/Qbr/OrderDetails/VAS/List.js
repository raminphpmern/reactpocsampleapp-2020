import React, { Component } from 'react';
import { Table } from 'semantic-ui-react';
import { Field } from 'redux-form';
import InputField from 'components/Common/InputField';
import Checkbox from 'components/Common/Checkbox';
import { reduxForm } from 'redux-form';
import { connect } from 'react-redux';

class List extends Component {

  render() {
    let { fields } = this.props;
    return (
      <Table.Body>
        {fields.map((elem, index) => {
          return (
            <Table.Row key={index}>
              <Table.Cell>
                <Field name={`${elem}.tms_brvd_booking_request_vas_details.brvd_vas_code`} component={InputField} readOnly={true} /></Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.tms_brvd_booking_request_vas_details.brvd_vas_description`} component={InputField} readOnly={true} />
              </Table.Cell>
              <Table.Cell className="small-width text-center">
                <Field name={`${elem}.tms_brvd_booking_request_vas_details.brvd_applicable`} type="checkbox" component={Checkbox} />
              </Table.Cell>
              <Table.Cell className="medium-width">
                <Field name={`${elem}.tms_brvd_booking_request_vas_details.brvd_vas_qty`} component={InputField} type='number' max="99" /></Table.Cell>
            </Table.Row>
          )
        })}
      </Table.Body>
    )
  }
}


List = reduxForm({
  form: 'OrderDetailsForm'
})(List);

export default connect(null, null)(List)