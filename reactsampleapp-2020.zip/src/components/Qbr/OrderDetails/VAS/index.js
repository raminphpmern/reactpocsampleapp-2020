import React, { Component } from 'react';
import { Table } from 'semantic-ui-react';
import { FieldArray, reduxForm } from 'redux-form';
import List from './List';
import _ from 'lodash';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class VAS extends Component {

  componentDidMount() {
    const { vas, formValues, currentBooking } = this.props
    if (vas && formValues && formValues.values) {
      let formHash = this.props.formValues.values
      const value_added_services = _.reduce(vas, (arr, obj) => {
        let brVas = _.find(currentBooking.tms_brvd_booking_request_vas_details, (row) => {
          return row.brvd_vas_code === obj.value
        })
        let hash = {
          tms_brvd_booking_request_vas_details: {
            brvd_vas_code: obj.value,
            brvd_vas_description: obj.label,
            brvd_created_date: brVas ? brVas.brvd_created_date : null,
            brvd_created_by: brVas ? brVas.brvd_created_by : null
          }
        }
        if (obj.cus_vas_map_appl === '1') {
          hash['tms_brvd_booking_request_vas_details'].brvd_applicable = Boolean(true)
          hash['tms_brvd_booking_request_vas_details'].brvd_vas_qty = null
        } else {
          hash['tms_brvd_booking_request_vas_details'].brvd_applicable = Boolean(brVas ? brVas.brvd_applicable : false)
          hash['tms_brvd_booking_request_vas_details'].brvd_vas_qty = brVas ? brVas.brvd_vas_qty : null
        }
        arr.push(hash)
        return arr
      }, [])
      const vas_applicable = _.filter(vas, function (vas_code) {
        return vas_code.cus_vas_map_appl === '1'
      })
      formHash['value_added_services'] = value_added_services
      formHash['vas_applicable'] = vas_applicable
      this.props.initialize(formHash)
    }
  }

  render() {
    const { t } = this.props
    return (
      <Table celled className='vas-table'>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>{t('vas:code')}</Table.HeaderCell>
            <Table.HeaderCell>{t('vas:desc')}</Table.HeaderCell>
            <Table.HeaderCell>{t('vas:appl')}</Table.HeaderCell>
            <Table.HeaderCell>{t('vas:qty')}</Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <FieldArray name="value_added_services" component={List} />
      </Table>
    )
  }
}


VAS = reduxForm({
  form: 'OrderDetailsForm'
})(VAS);

const mapStateToProps = state => ({
  currentBooking: state.bookingReducer.currentBooking,
})

export default compose(withTranslation('vas'), connect(mapStateToProps, null))(VAS)

