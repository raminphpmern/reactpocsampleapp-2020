import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field } from 'redux-form';
import InputField from 'components/Common/InputField';
import { Grid, Accordion, Icon } from 'semantic-ui-react';
import Dropdown from 'components/Common/Dropdown';
import Checkbox from 'components/Common/Checkbox';
import DisbursementDetails from './DisbursementDetails';
import Popup from 'components/Common/Popup';
import './order.css';
import OrderHeader from './OrderHeader';
import ShipmentDetails from './ShipmentDetails';
import ContentDetails from './ContentDetails';
import PickUpBranch from './../CustomerDetails/HelpOnShipPoint';
import Certificate from './Certificates';
import * as bookingActions from 'actions/bookingActions';
import * as orderActions from 'actions/orderAction';
import * as masterActions from 'actions/masterAction';
import * as customerActions from 'actions/customerActions';
import TextArea from 'components/Common/TextArea';
import { calVolumeticWeight, calChargeableWeight, calCbm } from 'lib/logicHelper';
import _ from 'lodash';
import { getValue } from 'lib/LocalStorage';
import { geoParamsBuilder } from 'lib/CommonHelper';
import Barcode from './ShipmentDetails/Barcode';
import Vas from './VAS';
import ReeferDetails from './ReeferDetails';
import validate from './validations/OrderValidation';
import { isMobile } from 'config'
import DateTimePicker from 'components/Common/DateTimePicker';
import { AlertError } from 'lib/Alert'
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import LinkPopUp from 'components/Common/DataGrid/LinkPopUp';
import ShipmentGuide from 'components/ShipmentGuide';

class OrderDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      disbursement: false,
      help: false,
      certificate: false,
      barcode: false,
      index: null,
      qty: null,
      barcodes: {},
      products: [],
      activeIndex: -1,
      codIncludes: false,
      isDisbursementPreset: false,
      conversion: 1,
      noType: 'text'
    }
    this.toggle = this.toggle.bind(this)
    this.stepBack = this.stepBack.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.initializeShipmentDtl = this.initializeShipmentDtl.bind(this)
    this.calculateShipmentDtlCharge = this.calculateShipmentDtlCharge.bind(this)
    this.computeCharges = this.computeCharges.bind(this)
    this.dropDownonSelect = this.dropDownonSelect.bind(this)
    this.updatePickupBranch = this.updatePickupBranch.bind(this)
    this.setIndexAndValue = this.setIndexAndValue.bind(this)
    this.setBarcodes = this.setBarcodes.bind(this)
    this.setOrderDetails = this.setOrderDetails.bind(this)
    this.setAccordionState = this.setAccordionState.bind(this)
    this.accordionClick = this.accordionClick.bind(this)
    this.validateTrackingNo = this.validateTrackingNo.bind(this)
    this.inputCheckboxChange = this.inputCheckboxChange.bind(this)
    this.clearTotalCopCod = this.clearTotalCopCod.bind(this)
    this.setWrapperRef = this.setWrapperRef.bind(this)
    this.getCopCodAmount = this.getCopCodAmount.bind(this)
    this.changeDisbursementStatus = this.changeDisbursementStatus.bind(this)
    this.initializeHash = this.initializeHash.bind(this)
    this.validateReEntered = this.validateReEntered.bind(this)
    this.clearReEnter = this.clearReEnter.bind(this)
    this.handleClickOutside = this.handleClickOutside.bind(this)
  }

  componentWillUnmount() {
    window.onbeforeunload = () => true
    document.removeEventListener('mousedown', this.handleClickOutside);
  }

  componentDidMount() {
    document.addEventListener('mousedown', this.handleClickOutside);
    let currentBooking = this.props.currentBooking
    if (document.getElementsByClassName('content-top-margin')[0])
      document.getElementsByClassName('content-top-margin')[0].scrollTop = 0
    const { getQuickCodeMaster, getGeoDefaultOptions, getModeOfCollections, fetchTempUom, shipment_type, service_mode, payment_type, mode_of_collections, countries, temp_uom, getUom, codIncludes } = this.props

    if (currentBooking && currentBooking.tms_brsd_shipment_details) {
      getUom(currentBooking.tms_brsd_shipment_details.brsd_to_country.value)
    }
    if (currentBooking.disbursement_detail) {
      this.setState({ isDisbursementPreset: true })
    }
    if (shipment_type.length === 0)
      getQuickCodeMaster('shipment_type')

    if (service_mode.length === 0)
      getQuickCodeMaster('service_mode')

    if (payment_type.length === 0)
      getQuickCodeMaster('payment_type')

    if (mode_of_collections.length === 0)
      getModeOfCollections('mode_of_collections')

    if (countries.length === 0) {
      getGeoDefaultOptions('countries')
    }

    if (temp_uom.length === 0) {
      fetchTempUom()
    }

    if (codIncludes.length === 0) {
      getQuickCodeMaster('codIncludes')
    }

    if (currentBooking.shipment_details && currentBooking.shipment_details.length > 0) {
      this.setOrderDetails()
    } else {
      this.setInitialValues()
    }

    let node = document.getElementById('trackingID')
    node.addEventListener("keydown", e => {
      if (e.target.value.length === 0) {
        this.setState({ noType: 'text' })
      }
      if (e.keyCode === 9) {
        this.setState({ noType: 'text-security' })
      }
    })
    let ethuNode = document.getElementById('EthuTrackingID')
    ethuNode.addEventListener("keydown", e => {
      if (e.target.value.length === 0) {
        this.setState({ noType: 'text' })
      }
      if (e.keyCode === 9) {
        this.setState({ noType: 'text-security' })
      }
    })
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.prePrintedIsValid !== this.props.prePrintedIsValid && !nextProps.prePrintedIsValid) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash['tracking_no'] = ''
      hash['re_enter'] = ''
      this.setState({ noType: 'text-security' })
      this.props.initialize(hash)
    } else {
      if (nextProps.trackingValid) {
        this.setState({ noType: 'text' })
      }
    }
    if (nextProps.prePrintedIsValidEthu !== this.props.prePrintedIsValidEthu && !nextProps.prePrintedIsValidEthu) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash['ethu_tracking_no'] = ''
      hash['re_enter'] = ''
      this.setState({ noType: 'text-security' })
      this.props.initialize(hash)
    }
    else {
      if (nextProps.ethuTrackingValid) {
        this.setState({ noType: 'text' })
      }
    }
    if (this.props.ethuProduct !== nextProps.ethuProduct) {
      if (nextProps.ethuProduct.length > 0) {
        this.setState({
          products: []
        }, () => {
          this.initializeShipmentDtl(nextProps.ethuProduct[0], 0)
        });
      }
    }

    if (nextProps.contract !== this.props.contract && nextProps.contract.tariff) {
      this.deriveVolumetricWeight(nextProps.contract.tariff)
    }

    if (nextProps.chargesData && this.props.chargesData !== nextProps.chargesData) {
      let hash = _.cloneDeep(this.props.formValues.values);
      let total = 0
      _.forOwn(nextProps.chargesData, function (value, key) {
        if (key !== 'discount') {
          total = total + parseInt(value)
        }
      });
      if (!hash['v_shipment']) {
        hash['v_shipment'] = nextProps.vShipment
      }
      this.getCopCodAmount(hash, total);
    }
  }

  deriveVolumetricWeight(tariff) {
    const { formValues } = this.props
    if (tariff && tariff.tariffs && tariff.tariffs.length > 0) {
      let factor = _.find(tariff.tariffs, (item) => item.wms_cont_tariff_id === tariff.baseTariff)
      if (formValues.values && formValues.values.shipment_details && formValues.values.shipment_details.length > 0) {
        const hash = _.cloneDeep(this.props.formValues.values);
        this.setState({ conversion: factor.wms_tf_tp_vol_conversion })
        hash['shipment_details'][0]['vwt'] = calVolumeticWeight(hash['shipment_details'][0]['cbm'], factor.wms_tf_tp_vol_conversion)
        this.props.initialize(hash)
      }
    }
  }

  getCopCodAmount(hash, total) {
    if (hash.tms_br_booking_request_hdr && hash.tms_br_booking_request_hdr.br_include && hash.tms_br_booking_request_hdr.br_include.value === 'shipping_fee') {
      hash['cod_cop_amount'] = total
    }
    if (hash.tms_br_booking_request_hdr && hash.tms_br_booking_request_hdr.br_include && hash.tms_br_booking_request_hdr.br_include.value === 'both') {
      hash['cod_cop_amount'] = parseInt(total) + parseInt(hash.tms_br_booking_request_hdr.br_declared_value)
    }
    if (hash.tms_br_booking_request_hdr && hash.tms_br_booking_request_hdr.br_include && hash.tms_br_booking_request_hdr.br_include.value === 'product_value') {
      hash['cod_cop_amount'] = parseInt(hash.tms_br_booking_request_hdr.br_declared_value)
    }
    this.props.initialize(hash)
  }

  setInitialValues() {
    const { currentBooking } = this.props
    let tms_br_booking_request_hdr = currentBooking.tms_br_booking_request_hdr
    tms_br_booking_request_hdr.br_requested_date = this.setTransactionDate()
    let obj = {
      shipment_details: [{}],
      content_details: [{}, {}, {}],
      tms_br_booking_request_hdr: tms_br_booking_request_hdr,
      tms_brsd_shipment_details: currentBooking.tms_brsd_shipment_details
    }
    this.props.initialize(obj)
  }

  setOrderDetails() {
    const { currentBooking, getVas } = this.props
    let orders = getValue('orders')
    orders = orders ? JSON.parse(orders) : null
    let barcodes = {}
    let productsArr = []
    currentBooking.shipment_details.map((item, key) => {
      barcodes[item.tms_brcd_consgt_details.cd_thu_id.value] = item.barcodes
      productsArr.push(item.tms_brcd_consgt_details.cd_thu_id)
      this.setState({ barcodes: { ...this.state.barcodes, ...barcodes } })
      this.setState({ products: [...this.state.products, ...productsArr] })
    })
    let tms_br_booking_request_hdr = currentBooking.tms_br_booking_request_hdr
    tms_br_booking_request_hdr.br_requested_date = currentBooking.tms_br_booking_request_hdr.br_requested_date ? currentBooking.tms_br_booking_request_hdr.br_requested_date : this.setTransactionDate()
    let obj = {
      shipment_details: currentBooking.shipment_details && currentBooking.shipment_details.length > 0 ? currentBooking.shipment_details : [{}],
      content_details: currentBooking.content_details && currentBooking.content_details.length > 0 ? currentBooking.content_details : [{}, {}, {}],
      tms_br_booking_request_hdr: tms_br_booking_request_hdr,
      tms_brsd_shipment_details: currentBooking.tms_brsd_shipment_details,
      tms_brcds_consgt_additional_services: currentBooking.tms_brcds_consgt_additional_services,
      total_value: orders && orders.total_value,
      cod_cop_amount: currentBooking.cod_cop_amount,
      cd_declared_value_of_goods: currentBooking.cd_declared_value_of_goods,
      ethu_tracking_no: currentBooking.ethu_tracking_no,
      tracking_no: currentBooking.tracking_no,
      child_thu: currentBooking.child_thu,
      v_shipment: currentBooking.v_shipment,
      re_enter: currentBooking.tracking_no ? currentBooking.tracking_no : currentBooking.ethu_tracking_no
    }
    const cust_id = currentBooking.tms_br_booking_request_hdr.br_customer_id;
    const brId = currentBooking.tms_br_booking_request_hdr.br_request_id
    const thuId = currentBooking.shipment_details[0].tms_brcd_consgt_details.cd_thu_id.value
    const serviceType = currentBooking.tms_br_booking_request_hdr.br_service_type.value;
    const queryString = `cust_id=${cust_id}&brid=${brId}&serviceType=${serviceType}&thuType=${thuId}`;
    getVas('vas', queryString)
    this.props.initialize(obj)
  }

  setTransactionDate() {
    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    if (month < 10) {
      month = `0${month}`
    }
    let day = dateObj.getUTCDate();
    if (day < 10) {
      day = `0${day}`
    }
    let year = dateObj.getUTCFullYear();
    return `${year}-${month}-${day}`
  }

  dropDownonSelect(data, childName) {
    if (data && data.value && childName) {
      this.props.getGeoOptions(childName, geoParamsBuilder(data, childName))
    }
  }

  toggle(modalType) {
    this.setState({ [modalType]: !this.state[modalType] })
  }

  changeDisbursementStatus() {
    this.setState({ isDisbursementPreset: true })
  }

  stepBack() {
    this.props.updateStep(1)
  }

  updatePickupBranch(address, name) {
    let params = {
      brsd_to_ship_point_id: address.wms_shp_pt_id,
      brsd_to_address_line1: address.wms_shp_pt_address1,
      brsd_to_country: address.wms_geo_country_code,
      brsd_to_state: address.wms_geo_state_code,
      brsd_to_city: address.wms_geo_city_code,
      brsd_to_suburb: address.wms_geo_suburb_code,
      brsd_to_postal_code: address.wms_shp_pt_zipcode,
    }
    this.props.updatePickupBranch(params, getValue('br_id'))
  }

  initializeShipmentDtl(data, index) {
    const { getVas } = this.props
    if (data) {
      let hash = _.cloneDeep(this.props.formValues.values)
      let shipment_details = hash['shipment_details']
      const cbm = calCbm(data.wms_thu_ext_length, data.wms_thu_ext_width, data.wms_thu_ext_height)
      const wt = calVolumeticWeight(cbm)
      const currentShipment = {
        tms_brcd_consgt_details: {
          cd_thu_id: data,
          cd_gross_weight: null,
          cd_thu_qty: 1
        },
        tms_brctd_consgt_thu_serial_details: {
          ctsd_length: data.wms_thu_ext_length,
          ctsd_breadth: data.wms_thu_ext_width,
          ctsd_height: data.wms_thu_ext_height
        },
        cbm: cbm,
        vwt: wt,
        cwt: wt
      }
      let barcodes = {}
      barcodes[data.value] = [{
        value: 'XXX-XXX-XXX',
        label: 'XXX-XXX-XXX'
      }]
      if (!data.hmtid_thu_serial_no) {
        currentShipment['barcodes'] = barcodes
      }
      shipment_details[index] = currentShipment
      hash['shipment_details'] = shipment_details
      this.props.initialize(hash)

      let productsArr = []
      productsArr.push(data)

      this.setState({ barcodes: { ...this.state.barcodes, ...barcodes } })
      this.setState({ products: productsArr })
      let cust_id = hash.tms_br_booking_request_hdr.br_customer_id;
      const brId = getValue('br_id')
      const thuType = data.value
      const serviceType = hash.tms_br_booking_request_hdr.br_service_type.value;
      const queryString = `cust_id=${cust_id}&brid=${brId}&serviceType=${serviceType}&thuType=${thuType}`;
      getVas('vas', queryString)
    } else {
      var array = [...this.state.products]; // make a separate copy of the array
      if (index !== -1) {
        array.splice(index, 1);
        this.setState({ products: array });
      }
    }
  }

  calculateShipmentDtlCharge(data, index, field, parentKey) {
    let hash = _.cloneDeep(this.props.formValues.values)
    let shipment_details = hash['shipment_details']
    let { uomResult } = this.props
    let currentShipment = shipment_details[index]
    if (currentShipment[parentKey]) {
      currentShipment[parentKey][field] = data
    } else {
      currentShipment[parentKey] = { [field]: data }
    }
    if (field === 'cd_gross_weight' && currentShipment['vwt']) {
      currentShipment['cwt'] = calChargeableWeight(data, currentShipment['vwt'])
    }
    const calFields = ['ctsd_length', 'ctsd_breadth', 'ctsd_height', 'cd_thu_qty']
    if (_.includes(calFields, field) && currentShipment.tms_brctd_consgt_thu_serial_details && currentShipment.tms_brcd_consgt_details) {
      const length = currentShipment.tms_brctd_consgt_thu_serial_details[`ctsd_length`]
      const breadth = currentShipment.tms_brctd_consgt_thu_serial_details[`ctsd_breadth`]
      const height = currentShipment.tms_brctd_consgt_thu_serial_details[`ctsd_height`]
      if (currentShipment['vwt'] >= 0) {
        currentShipment['cwt'] = calChargeableWeight(currentShipment.tms_brcd_consgt_details['cd_gross_weight'] || 0, currentShipment['vwt'])
      }
      currentShipment['cbm'] = parseFloat(currentShipment.tms_brcd_consgt_details['cd_thu_qty']) * calCbm(length, breadth, height)
      currentShipment['vwt'] = calVolumeticWeight(currentShipment['cbm'], this.state.conversion)
    }
    if (currentShipment.tms_brcd_consgt_details && currentShipment.tms_brctd_consgt_thu_serial_details) {
      currentShipment.tms_brcd_consgt_details.cd_thu_qty_uom = uomResult.QT
      currentShipment.tms_brcd_consgt_details.cd_volume_uom = uomResult.VL
      currentShipment.tms_brcd_consgt_details.cd_weight_uom = uomResult.WT
      currentShipment.tms_brctd_consgt_thu_serial_details.ctsd_lbh_uom = uomResult.DM
      currentShipment.tms_brctd_consgt_thu_serial_details.ctsd_gross_weight_uom = uomResult.WT
    }
    shipment_details[index] = currentShipment
    hash['shipment_details'] = shipment_details
    this.props.initialize(hash)
  }

  computeCharges() {
    const hash = this.props.formValues.values
    const brId = getValue('br_id')
    const { currentBooking } = this.props
    const tms_br_booking_request_hdr = currentBooking.tms_br_booking_request_hdr
    if (tms_br_booking_request_hdr.br_status !== 'Incomplete') {
      AlertError("You can't compute at this status.")
    }
    else
      this.props.computeOrder(hash, brId)
  }

  formSubmit(values) {
    const { online } = this.props
    if (values.tms_br_booking_request_hdr.br_cod || values.tms_br_booking_request_hdr.br_cop) {
      if (!online) {
        AlertError('When COD is enabled make sure, Application is in online status to proceed with')
        return false
      }
      if (!this.state.isDisbursementPreset) {
        AlertError("Disbursement Details are required !")
        return false;
      }
    }
    const vas = 'value_added_services'
    values[vas].forEach((value, key) => {
      if (value.tms_brvd_booking_request_vas_details.brvd_vas_qty === '') {
        value.tms_brvd_booking_request_vas_details.brvd_vas_qty = null
      }
    })
    let currentBooking = this.props.currentBooking
    const brId = getValue('br_id')
    if (!currentBooking.tms_br_booking_request_hdr.br_consign_note) {
      this.props.createOrder(values, 3, brId)
    } else {
      this.props.updateOrder(values, 3, brId)
    }
  }

  inputChange(e) {
    let hash = this.props.formValues.values
    if (hash.tms_br_booking_request_hdr && hash.tms_br_booking_request_hdr.br_include && hash.tms_br_booking_request_hdr.br_include.value === 'product_value') {
      hash.cod_cop_amount = e.value
    }
  }

  clearTotalCopCod() {
    let hash = this.props.formValues.values
    hash.cod_cop_amount = null
  }

  onKeyPress = (event) => {
    if (event.key === 'Enter') {
      if (window.document.querySelector('[type="submit') !== document.activeElement)
        event.preventDefault();
    }
  }

  setIndexAndValue(index, qty) {
    this.setState({ index: index, qty: qty })
    this.toggle('barcode')
  }

  setBarcodes(values, index) {
    let hash = _.cloneDeep(this.props.formValues.values)
    let shipment_details = hash['shipment_details']
    let currentShipment = shipment_details[index]
    let { barcodes, products } = this.state
    if (!products[index]) {
      AlertError('Please select product')
      return false
    }
    let key = products[index].value
    let codes = []
    _.mapKeys(values, (val) => {
      codes.push({
        label: val,
        value: val
      })
    })
    barcodes[key] = codes
    currentShipment['barcodes'] = codes
    shipment_details[index] = currentShipment
    hash['shipment_details'] = shipment_details
    this.props.initialize(hash)
    this.setState({ barcodes: barcodes })
  }

  setAccordionState(e, titleProps) {
    const { index } = titleProps
    const { activeIndex } = this.state
    const newIndex = activeIndex === index ? -1 : index
    this.setState({ activeIndex: newIndex })
  }

  accordionClick(e, index) {
    if (e.keyCode === 13) {
      if (index === this.state.activeIndex) {
        this.setState({ activeIndex: -1 })
      } else {
        this.setState({ activeIndex: index })
      }
    }
  }

  validateTrackingNo() {
    const { formValues, currentBooking } = this.props
    const values = formValues && formValues.values
    let trackingNo = formValues && formValues.values ? formValues.values.tracking_no : null
    let customerId = values && values.tms_br_booking_request_hdr && values.tms_br_booking_request_hdr.br_customer_id
    if (trackingNo && currentBooking.tms_br_booking_request_hdr.br_consign_note !== trackingNo) {
      this.props.validatePreprinted(trackingNo, getValue('br_id'), customerId)
    }
  }

  validateEthuTrackingNo() {
    const { formValues, currentBooking } = this.props
    const values = formValues && formValues.values
    const serialNo = values ? values.ethu_tracking_no : null
    const customerId = values && values.tms_br_booking_request_hdr && values.tms_br_booking_request_hdr.br_customer_id
    const serviceType = values && values.tms_br_booking_request_hdr && values.tms_br_booking_request_hdr.br_service_type.value
    if (serialNo && currentBooking.tms_br_booking_request_hdr.br_consign_note !== serialNo) {
      this.props.validateEthuSerailNo(serialNo, customerId, serviceType)
    }
  }

  inputCheckboxChange(e) {
    let hash = _.cloneDeep(this.props.formValues.values)
    let br_cop = hash.tms_br_booking_request_hdr.br_cop
    let br_cod = hash.tms_br_booking_request_hdr.br_cod
    if (e.id === 'COP') {
      br_cop = e.value === 'true' ? false : true
    }
    if (e.id === 'COD') {
      br_cod = e.value === 'true' ? false : true
    }

    if (br_cop && !br_cod) {
      hash.tms_br_booking_request_hdr.br_include = { value: 'shipping_fee', label: 'Shipping Fee' }
      this.setState({ codIncludes: true })
    } else {
      this.setState({ codIncludes: false })
    }
    if (br_cod) {
      this.setState({ codIncludes: false })
    }
    this.props.initialize(hash)
  }

  setWrapperRef(node) {
    this.wrapperRef = node;
  }

  initializeHash(hash) {
    this.props.initialize(hash)
  }

  handleClickOutside(event) {
    if (this.wrapperRef && !this.wrapperRef.contains(event.target)) {
      const { ethuTrackingValid, trackingValid } = this.props
      let hash = this.props.formValues.values
      if ((hash['tracking_no'] || hash['ethu_tracking_no']) && (!ethuTrackingValid && !trackingValid)) {
        if (!hash.tms_br_booking_request_hdr.br_consign_note)
          this.setState({ noType: 'text-security' })
      }
    }
  }

  validateReEntered(e, values) {
    if (e.target.value.length <= 18) {
      if (values && values.tracking_no && e.target.value === values.tracking_no) {
        this.setState({ noType: 'text' })
        this.validateTrackingNo()
      } else if (values && values.ethu_tracking_no && e.target.value === values.ethu_tracking_no) {
        this.setState({ noType: 'text' })
        this.validateEthuTrackingNo()
      } else {
        this.setState({ noType: 'text-security' })
      }
    }
  }

  clearReEnter() {
    let hash = _.cloneDeep(this.props.formValues.values)
    if (hash['re_enter'] !== hash['tracking_no'] && hash['re_enter'] !== hash['ethu_tracking_no']) {
      hash['re_enter'] = ''
      this.props.initialize(hash)
    }
  }

  render() {
    const { handleSubmit, payment_type, mode_of_collections, options, temp_uom, vas, currentBooking, isRequested, t, codIncludes } = this.props;
    let values = this.props.formValues && this.props.formValues.values ? this.props.formValues.values : {}
    const { index, qty, products, barcodes, activeIndex, isDisbursementPreset, noType } = this.state
    let tms_br_booking_request_hdr = values && values.tms_br_booking_request_hdr;
    let br_cod_cop_required = false
    if (values) {
      if ((tms_br_booking_request_hdr && tms_br_booking_request_hdr.br_cod) || (tms_br_booking_request_hdr && tms_br_booking_request_hdr.br_cop)) {
        br_cod_cop_required = true
      }
    }
    let br_service_type = currentBooking && currentBooking.tms_br_booking_request_hdr && currentBooking.tms_br_booking_request_hdr.br_service_type

    return (
      <div>
        <Popup open={this.state.certificate} close={() => { this.toggle('certificate') }}
          header="Certificates" description={<Certificate close={this.toggle} />} />
        <Popup size="fullscreen" open={this.state.help} close={() => { this.toggle('help') }}
          header="Pick-up Branch" description={<PickUpBranch {...options}
            dropDownonSelect={this.dropDownonSelect}
            handleOnSelect={this.updatePickupBranch}
            close={this.toggle} name='brsd_to' />} />
        <Popup size="tiny" open={this.state.disbursement} close={() => { this.toggle('disbursement') }}
          header="Disbursement Detail" description={<DisbursementDetails changeDisbursementStatus={this.changeDisbursementStatus} isDisbursementPreset={isDisbursementPreset} close={this.toggle} />} />
        <Popup size="tiny" open={this.state.barcode} close={() => { this.toggle('barcode') }}
          header="Barcode" description={<Barcode selected={products[index] && products[index].value} close={this.toggle}
            index={index} qty={qty} setBarcodes={this.setBarcodes} barcodes={barcodes} />} />
        <form onSubmit={handleSubmit(this.formSubmit)} className="order-details-wrapper" onKeyPress={this.onKeyPress}>
          <OrderHeader >
            <Grid.Row>
              <Grid.Column width={12}>
                <h3 className="sub-head"><strong>ORDER DETAILS</strong></h3>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <div ref={this.setWrapperRef}>
                  <Field id="trackingID" readOnly={!!values.ethu_tracking_no} name="tracking_no" component={InputField} label={t('orderDetail:tracking_no')} onBlur={() => this.clearReEnter()} required={true} strong={true} addClass={noType} />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="tms_brsd_shipment_details.brsd_from_pick_date" component={DateTimePicker} label={t('orderDetail:brsd_from_pick_date')} readOnly={false} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="tms_brsd_shipment_details.brsd_from_picktime_slot_from" component={InputField} type="time" min="09:00" max="18:00" label={t('orderDetail:brsd_from_picktime_slot_from')} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="tms_brsd_shipment_details.brsd_from_picktime_slot_to" component={InputField} type="time" min="09:00" max="18:00" label={t('orderDetail:brsd_from_picktime_slot_to')} />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <div ref={this.setWrapperRef}>
                  <Field id="EthuTrackingID" readOnly={!!values.tracking_no} name="ethu_tracking_no" component={InputField} label={t('orderDetail:ethu_tracking_no')} onBlur={() => this.clearReEnter()} strong={true} required={true} addClass={noType} />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="tms_brsd_shipment_details.brsd_to_delivery_date" component={DateTimePicker} label={t('orderDetail:brsd_to_delivery_date')} readOnly={false} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="tms_brsd_shipment_details.brsd_to_deliverytime_slot_from" component={InputField} type="time" min="09:00" max="18:00" label={t('orderDetail:brsd_to_deliverytime_slot_from')} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="tms_brsd_shipment_details.brsd_to_deliverytime_slot_to" component={InputField} type="time" min="09:00" max="18:00" label={t('orderDetail:brsd_to_deliverytime_slot_to')} />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field name="re_enter" readOnly={!values.tracking_no && !values.ethu_tracking_no} component={InputField} label="ReEnter" onChange={(e) => { this.validateReEntered(e, values) }} required={true} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="tms_br_booking_request_hdr.br_payment_type" component={Dropdown} label={t('orderDetail:br_payment_type')} options={payment_type} required={true} />
              </Grid.Column>
              {br_service_type && br_service_type.value === 'Order Padala - PSA' && <Grid.Column width={4} className="align-center">
                <button type="button" className="link-button" onClick={() => { this.toggle('certificate') }}>{t('orderDetail:certificateDetail')}</button>
              </Grid.Column>}
            </Grid.Row>
            <Grid.Row className="ash-background align-center top-margin no-padding">
              <Grid.Column width={1}></Grid.Column>
              <Grid.Column width={2}>
                <Field name="tms_br_booking_request_hdr.br_cod" component={Checkbox} type="checkbox" label={t('orderDetail:cod')} htmlFor="COD" onChange={(e) => { this.inputCheckboxChange(e.target) }} />
              </Grid.Column>
              {/*<Grid.Column width={2}>
                <Field name="tms_br_booking_request_hdr.br_cop" component={Checkbox} type="checkbox" label={t('orderDetail:cop')} htmlFor="COP" onChange={(e) => { this.inputCheckboxChange(e.target) }} />
              </Grid.Column>*/}
              <Grid.Column width={6} className={`${!isMobile ? 'checkbox-label' : ''}`}>
                <Field name="tms_br_booking_request_hdr.br_include" component={Dropdown} label={t('orderDetail:br_include')} options={codIncludes} onChange={() => { this.clearTotalCopCod() }} readOnly={!!this.state.codIncludes} />
              </Grid.Column>
              {tms_br_booking_request_hdr && (tms_br_booking_request_hdr.br_cod || tms_br_booking_request_hdr.br_cop) && <Grid.Column width={4}>
                <Field name="tms_br_booking_request_hdr.br_collection_mode" component={Dropdown} label={t('orderDetail:br_collection_mode')} options={mode_of_collections} />
              </Grid.Column>}
              <Grid.Column width={3}>
                {tms_br_booking_request_hdr && (tms_br_booking_request_hdr.br_cop || tms_br_booking_request_hdr.br_cod) && <button type="button" className="link-button" onClick={() => { this.toggle('disbursement') }}>{t('orderDetail:disbursementDtl')}</button>}
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={16}>
                <Accordion>
                  <Accordion.Title
                    active={true}
                    tabIndex="0">
                    <div className='shipmentDtl-wrapper'>
                      <div>
                        <h3 className="sub-head">
                          <strong>
                            <Icon name='dropdown' />
                            {t('orderDetail:shipmentDtl')}
                          </strong>
                        </h3>
                      </div>
                      <LinkPopUp name="Shipment Guide" defaultValue="Shipment Guide"> <ShipmentGuide /> </LinkPopUp>
                    </div>
                  </Accordion.Title>
                  <Accordion.Content active={true}>
                    <ShipmentDetails initializeHash={this.initializeHash} setIndexAndValue={this.setIndexAndValue} initializeShipmentDtl={this.initializeShipmentDtl}
                      calculateChargeable={this.calculateShipmentDtlCharge} uomResult={this.props.uomResult} serviceType={br_service_type} />
                  </Accordion.Content>
                </Accordion>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={16}>
                <Accordion>
                  <Accordion.Title
                    active={activeIndex === 1}
                    index={1}
                    onClick={this.setAccordionState}
                    onKeyUp={(e) => { this.accordionClick(e, 1) }}
                    tabIndex="0">
                    <h3 className="sub-head">
                      <strong>
                        <Icon name='dropdown' />{t('orderDetail:content')}
                      </strong>
                    </h3>
                  </Accordion.Title>
                  <Accordion.Content active={activeIndex === 1}>
                    <ContentDetails products={products} barcodes={barcodes} />
                  </Accordion.Content>
                </Accordion>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={16}>
                <Accordion>
                  <Accordion.Title
                    active={activeIndex === 0}
                    index={0}
                    onClick={this.setAccordionState}
                    onKeyUp={(e) => { this.accordionClick(e, 0) }}
                    tabIndex="0">
                    <h3 className="sub-head">
                      <strong>
                        <Icon name='dropdown' />
                        {t('orderDetail:vas')}
                      </strong>
                    </h3>
                  </Accordion.Title>
                  <Accordion.Content active={activeIndex === 0}>
                    {values && values.tms_br_booking_request_hdr && vas && vas.length > 0 && <Vas vas={vas} formValues={this.props.formValues} {...this.props} />}
                  </Accordion.Content>
                </Accordion>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={16}>
                <Accordion>
                  <Accordion.Title
                    active={br_service_type && br_service_type.value === 'coldchain' ? true : activeIndex === 2}
                    index={2}
                    onClick={this.setAccordionState}
                    onKeyUp={(e) => { this.accordionClick(e, 2) }}
                    tabIndex="0">
                    <h3 className="sub-head">
                      <strong>
                        <Icon name='dropdown' />
                        {t('orderDetail:reeferDtl')}
                      </strong>
                    </h3>
                  </Accordion.Title>
                  <Accordion.Content active={br_service_type && br_service_type.value === 'coldchain' ? true : activeIndex === 2}>
                    <ReeferDetails temp_uom={temp_uom} />
                  </Accordion.Content>
                </Accordion>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={12}>
                <div className="content-footer">
                  <Field label={t('orderDetail:v_shipment')} name="v_shipment" type="checkbox" component={Checkbox} />
                  <Field label={t('orderDetail:br_hazardous')} name="tms_br_booking_request_hdr.br_hazardous" type="checkbox" component={Checkbox} />
                </div>
                <div className="special-instruction">
                  <Field name="tms_brcds_consgt_additional_services.cds_special_instructions" col="100" row="4" component={TextArea} label={t('orderDetail:cds_special_instructions')} />
                </div>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={6}>
                <Field name="tms_br_booking_request_hdr.br_declared_value" onChange={(e) => { this.inputChange(e.target) }} component={InputField} label={t('orderDetail:br_declared_value')} required={br_cod_cop_required} />
                {tms_br_booking_request_hdr && (tms_br_booking_request_hdr.br_cod || tms_br_booking_request_hdr.br_cop) && <Field name="cod_cop_amount" readOnly={true} component={InputField} label={t('orderDetail:cod_cop_amount')} required={br_cod_cop_required} />}
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="doc-action">
                  <button type="button" className="link-button" onClick={this.stepBack}>Back</button>
                  <button disabled={isRequested} type="button" className="primary" onClick={this.computeCharges}>Compute</button>
                  <button disabled={isRequested} type="submit" className="primary left-margin">{t('orderDetail:next')} </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </OrderHeader>
        </form>
      </div>
    )
  }
}

OrderDetails = reduxForm({
  form: 'OrderDetailsForm',
  validate,
  enableReinitialize: true,
  keepDirtyOnReinitialize: true
})(OrderDetails);

const mapDispatchToProps = (dispatch) => ({
  updateStep: (step) => dispatch(bookingActions.updateStep(step)),
  createOrder: (params, step, brId) => dispatch(orderActions.create(params, step, brId)),
  updateOrder: (params, step, brId) => dispatch(orderActions.update(params, step, brId)),
  computeOrder: (params, brId) => dispatch(orderActions.compute(params, brId)),
  getQuickCodeMaster: (type) => dispatch(masterActions.getQuickCodeMaster(type, '')),
  getModeOfCollections: (type, queryStr) => dispatch(masterActions.getModeOfCollections(type, queryStr)),
  // updateTotalCopCod: (data) => dispatch(masterActions.updateTotalCopCod(data)),
  getGeoDefaultOptions: (action) => dispatch(masterActions.getGeoDefaultOptions(action, '')),
  getGeoOptions: (action, queryStr) => dispatch(masterActions.getGeoOptions(action, queryStr)),
  updatePickupBranch: (params, brId) => dispatch(customerActions.updatePickupBranch(params, brId)),
  fetchTempUom: () => dispatch(masterActions.fetchTempUom('temp_uom', '')),
  validatePreprinted: (trackingNo, brId, customerId) => dispatch(orderActions.validateTrackingNo(trackingNo, brId, customerId)),
  getVas: (action, queryString) => dispatch(masterActions.getVas(action, queryString)),
  getUom: (country) => dispatch(orderActions.getUom(country)),
  validateEthuSerailNo: (serialNo, id, serviceType) => dispatch(orderActions.validateEthuNo(serialNo, id, serviceType)),
})

const mapStateToProps = state => ({
  service_mode: state.masterReducer.options.service_mode,
  payment_type: state.masterReducer.options.payment_type,
  shipment_type: state.masterReducer.options.shipment_type,
  mode_of_collections: state.masterReducer.options.mode_of_collections,
  formValues: state.form.OrderDetailsForm,
  countries: state.masterReducer.options.countries,
  province: state.masterReducer.options.province,
  city: state.masterReducer.options.city,
  barangay: state.masterReducer.options.barangay,
  zip: state.masterReducer.options.zip,
  options: state.masterReducer.options,
  temp_uom: state.masterReducer.options.temp_uom,
  currentBooking: state.bookingReducer.currentBooking,
  prePrintedIsValid: state.bookingReducer.prePrintedIsValid,
  prePrintedIsValidEthu: state.bookingReducer.prePrintedIsValidEthu,
  trackingValid: state.bookingReducer.trackingValid,
  ethuTrackingValid: state.bookingReducer.ethuTrackingValid,
  vas: state.masterReducer.options.vas,
  uomResult: state.bookingReducer.uomResult,
  ethuProduct: state.bookingReducer.ethuProduct,
  vShipment: state.bookingReducer.vShipment,
  chargesData: state.bookingReducer.chargesData,
  tariff: state.bookingReducer.tariff,
  contract: state.bookingReducer.contract,
  isRequested: state.bookingReducer.isRequested,
  online: state.loginReducer.online,
  codIncludes: state.masterReducer.options.codIncludes,
})

export default compose(withTranslation('orderDetail'), connect(mapStateToProps, mapDispatchToProps))(OrderDetails)
