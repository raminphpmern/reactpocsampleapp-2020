import React, { Component } from 'react'
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { renderAddressDtl } from 'lib/CommonHelper';

class OrderHeader extends Component {
  render() {

    const { currentBooking } = this.props
    return (
      <Grid stackable>
        <Grid.Row className="order-header-wrapper">
          <Grid.Column width={8}>
            <div className="order-header-item">
              <strong>Shipper - Address</strong>
              <span>:</span>
              <span>{renderAddressDtl('from', currentBooking)}</span>
            </div>
          </Grid.Column>
          <Grid.Column width={8}>

          </Grid.Column>
          <Grid.Column width={8}>
            <div className="order-header-item">
              <strong>Consignee - Address</strong>
              <span>:</span>
              <span>{renderAddressDtl('to', currentBooking)}</span>
            </div>
          </Grid.Column>
          <Grid.Column width={4}>

          </Grid.Column>
          <Grid.Column width={3} className="recurring-br">

          </Grid.Column>
        </Grid.Row>
        {this.props.children}
      </Grid>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
})

const mapStateToProps = state => ({
  currentBooking: state.bookingReducer.currentBooking,
  total_cop: state.masterReducer.total_cop,
  total_cod: state.masterReducer.total_cod,
})

export default connect(mapStateToProps, mapDispatchToProps)(OrderHeader)
