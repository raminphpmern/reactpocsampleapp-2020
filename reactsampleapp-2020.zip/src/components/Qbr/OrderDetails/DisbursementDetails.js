import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Field } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import Dropdown from 'components/Common/Dropdown';
import InputField from 'components/Common/InputField';
import PhoneInputField from 'components/Common/PhoneInput';
import { getValue } from 'lib/LocalStorage';
import * as masterActions from "actions/masterAction";
import { create, update } from 'actions/disbursementAction';
import { renderAddressDtl } from 'lib/CommonHelper';
import validate from './validations/DisbursementValidation';
import _ from 'lodash';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class DisbursementDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isBank: false,
      isWallet: false,
      bankCollect: false
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.onModeSelect = this.onModeSelect.bind(this)
    this.setInitialValue = this.setInitialValue.bind(this)
  }

  componentDidMount() {
    const { currentBooking, getBankCode, bankCode, disbursementMode, getDisbursementMode } = this.props
    if (bankCode.length === 0) {
      getBankCode();
    }

    if (disbursementMode.length === 0) {
      getDisbursementMode()
    }
    if (currentBooking && currentBooking.disbursement_detail) {
      if (currentBooking.disbursement_detail.brdm_disbursement_mode.value === 'BC') {
        this.setState({ bankCollect: true })
      }
      this.props.initialize(currentBooking.disbursement_detail)
    }
  }

  setInitialValue(data) {
    if (this.props.formValues && this.props.formValues.values) {
      let hash = this.props.formValues.values
      hash['brdm_disbursement_mode'] = { value: data.value, label: data.label }
      hash['brdm_account_no'] = ""
      hash['brdm_accountholder_name'] = ""
      hash['brdm_bank_code'] = ""
      hash['brdm_bank_name'] = {}
      hash['brdm_ewalletid'] = ""
      hash['brdm_kyc_id'] = ""
      hash['re_brdm_account_no'] = ""
      this.props.initialize(hash)
    }
  }

  onModeSelect(data) {
    const { currentBooking } = this.props
    this.setInitialValue(data)
    if (data.value === 'BC') {
      this.setState({ bankCollect: true })
      const hash = this.props.formValues.values ? _.cloneDeep(this.props.formValues.values) : {}
      hash['brdm_disbursement_mode'] = { value: data.value, label: data.label }
      hash['brdm_account_no'] = currentBooking.tms_brsd_shipment_details.brsd_from_primary_phone
      hash['re_brdm_account_no'] = currentBooking.tms_brsd_shipment_details.brsd_from_primary_phone
      this.props.initialize(hash)
    } else {
      this.setState({ bankCollect: false })
    }
    if (data.value === 'BT') {
      this.setState({ isBank: true, isWallet: false })
    } else if (data.value === 'EW') {
      this.setState({ isBank: false, isWallet: true })
    } else {
      this.setState({ isBank: false, isWallet: false })
    }
  }

  formSubmit(values) {
    const brId = getValue('br_id')
    const { currentBooking } = this.props
    let hash = _.cloneDeep(values)
    hash['brdm_disbursement_mode'] = hash['brdm_disbursement_mode'].value
    if (hash['brdm_bank_name'])
      hash['brdm_bank_name'] = hash['brdm_bank_name'].value
    if (!currentBooking.disbursement_detail) {
      this.props.create(hash, brId)
    } else {
      this.props.update(hash, brId)
    }
    this.props.changeDisbursementStatus()
    this.props.close('disbursement')
  }

  displayBookingInfo(field) {
    const { currentBooking } = this.props
    if (currentBooking) {
      return currentBooking['tms_br_booking_request_hdr'][field]
    }
  }

  render() {
    const { handleSubmit, currentBooking, bankCode, disbursementMode, t } = this.props
    const { isBank, isWallet, bankCollect } = this.state
    return (
      <Grid stackable>
        <Grid.Row className="no-padding charge-details" >
          <Grid.Column width={16}>
            <div className="input_field" >
              <label className="tracking-no"><strong>{t('disbursementDetail:trackingno')} :</strong></label>
              <div className="input_holder">
                <strong></strong>
              </div>
            </div>
            <div className="input_field" >
              <label>{t('disbursementDetail:shipper')}</label>
              <div className="input_holder">
                {renderAddressDtl('from', currentBooking)}
              </div>
            </div>
            <div className="input_field" >
              <label>{t('disbursementDetail:consignee')}</label>
              <div className="input_holder">
                {renderAddressDtl('to', currentBooking)}
              </div>
            </div>
            <div className="input_field" >
              <label>{t('disbursementDetail:br_id')}</label>
              <div className="input_holder">
                {this.displayBookingInfo('br_request_id')}
              </div>
            </div>
          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <form onSubmit={handleSubmit(this.formSubmit)} className="order-details-wrapper">
            <Grid.Column width={16}>
              <h3 className="disb-head">{t('disbursementDetail:title')}</h3>
              <Field name="brdm_disbursement_mode" component={Dropdown} label={t('disbursementDetail:brdm_disbursement_mode')} options={disbursementMode} required={true} handleOnSelect={this.onModeSelect} clearable={true} />
              <Field name="brdm_bank_name" component={Dropdown} label={t('disbursementDetail:brdm_bank_name')} options={bankCode} required={isBank} clearable={true} />
              {bankCollect && <div>
                <Field name="brdm_account_no" component={PhoneInputField} label={t('disbursementDetail:brdm_account_no')} />
                <Field name="re_brdm_account_no" component={PhoneInputField} label={t('disbursementDetail:re_brdm_account_no')} />
              </div>}
              {!bankCollect && <div>
                <Field name="brdm_account_no" component={InputField} label={t('disbursementDetail:brdm_account_no')} required={isBank} type='number' min="1" pattern="[0-9]*" />
                <Field name="re_brdm_account_no" component={InputField} label={t('disbursementDetail:re_brdm_account_no')} required={isBank} min="1" type='number' pattern="[0-9]*" />
              </div>}
              <Field name="brdm_bank_code" component={InputField} label={t('disbursementDetail:brdm_bank_code')} required={isBank} />
              <Field name="brdm_accountholder_name" component={InputField} label={t('disbursementDetail:brdm_accountholder_name')} required={isBank} />
              <Field name="brdm_kyc_id" component={InputField} label={t('disbursementDetail:brdm_kyc_id')} />
              <Field name="brdm_ewalletid" component={InputField} label={t('disbursementDetail:brdm_ewalletid')} required={isWallet} />
            </Grid.Column>
            <Grid.Column width={4}></Grid.Column>
            <Grid.Column width={12}>
              <div className="disbursement-action">
                <button className="primary">{currentBooking.disbursement_detail ? 'Update' : 'Save'}</button>
              </div>
            </Grid.Column>
          </form>
        </Grid.Row>
      </Grid>
    )
  }
}

DisbursementDetails = reduxForm({
  form: 'DisbursementDetailsForm',
  validate
})(DisbursementDetails)

const mapStateToProps = state => ({
  currentBooking: state.bookingReducer.currentBooking,
  bankCode: state.masterReducer.options.bankCodes,
  disbursementMode: state.masterReducer.options.disbursementMode,
  formValues: state.form.DisbursementDetailsForm,
})

const mapDispatchToProps = (dispatch) => ({
  create: (params, brId) => dispatch(create(params, brId)),
  update: (params, brId) => dispatch(update(params, brId)),
  getBankCode: () => dispatch(masterActions.getBankCode('bankCodes')),
  getDisbursementMode: () => dispatch(masterActions.getDisbursementMode('disbursementMode')),
})

export default compose(withTranslation('disbursementDetail'), connect(mapStateToProps, mapDispatchToProps))(DisbursementDetails)