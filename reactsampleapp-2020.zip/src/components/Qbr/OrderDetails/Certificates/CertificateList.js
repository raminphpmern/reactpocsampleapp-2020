import React, { Component } from 'react';
import { Table } from 'semantic-ui-react';
import { Field } from 'redux-form';
import InputField from 'components/Common/InputField'
import FileUpload from 'components/Common/FileUpload';
import _ from 'lodash';

class CertificateList extends Component {
  constructor(props) {
    super(props)
    this.setFileInformations = this.setFileInformations.bind(this)
  }

  componentDidMount() {
    if (this.props.fields.length === 0) {
      this.props.fields.push({})
    }
  }

  setFileInformations(name, base64, index) {
    this.props.bindAttachments(name, base64, index)
  }

  render() {
    let { fields } = this.props;
    return (
      <Table.Body>
        {fields.map((elem, index) => {
          return (
            <Table.Row key={index} className="tax-raw">
              <Table.Cell>
                <Field name={`${elem}.tran_document_name`} component={InputField} readOnly={true} />
              </Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.tran_attachement`} component={FileUpload} getFileName={(name, tempUrl, base64) => { this.setFileInformations(name, base64, index) }} />
              </Table.Cell>
              <Table.Cell>
                {fields.length - 1 === index &&
                  <i className="plus circle icon" onKeyUp={(e) => this.addRow(e)} onClick={() => fields.push({})} tabIndex="0"></i>
                }
              </Table.Cell>
              <Table.Cell>
                {index > 0 && <i className="minus circle icon" onClick={() => fields.remove(index)} onKeyUp={(e) => this.removeRow(e, index)} tabIndex="0"></i>}
              </Table.Cell>

            </Table.Row>
          )
        })}
      </Table.Body>
    )
  }
}

export default CertificateList;