import React, { Component } from 'react'
import { Field, FieldArray } from 'redux-form';
import InputField from 'components/Common/InputField';
import Dropdown from 'components/Common/Dropdown';
import DateTimePicker from 'components/Common/DateTimePicker';
import CertificateList from './CertificateList';
import Radio from 'components/Common/RadioFiled'
import { Grid, Table } from 'semantic-ui-react';
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';

class MarriageCertificate extends Component {
  render() {
    const { countries, province, cities, copies, relations, dropDownonSelect, t } = this.props
    return (
      <Grid stackable>
        <Grid.Row className="padding-botom">
          <Grid.Column width={16}>
            <h4 className="bottom-border">{t('marriageCertificate:mrgeDtl')}</h4>
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="no-padding">
          <Grid.Column width={8}>
            <Field name="lbc_mrg_date" component={DateTimePicker} label={t('marriageCertificate:lbc_mrg_date')} required={true} />
            <Field name="lbc_mrg_country_code" component={Dropdown} label={t('marriageCertificate:lbc_mrg_country_code')}
              options={countries} handleOnSelect={dropDownonSelect} childName='province'
              required={true} />
          </Grid.Column>

          <Grid.Column width={8}>
            <Field name="lbc_mrg_state_code" component={Dropdown} label={t('marriageCertificate:lbc_mrg_state_code')}
              options={province} handleOnSelect={dropDownonSelect} childName='city'
              required={true} />
            <Field name="lbc_mrg_city_code" component={Dropdown} label={t('marriageCertificate:lbc_mrg_city_code')} options={cities}
              required={true} />
          </Grid.Column>
        </Grid.Row>
        <Grid.Row className="padding-bottom">
          <Grid.Column width={16}>
            <h4 className="bottom-border">{t('marriageCertificate:husbandDtl')}</h4>
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="no-padding">
          <Grid.Column width={8}>
            <Field name="lbc_mrg_hus_first_name" component={InputField} placeholder="First Name" label={t('marriageCertificate:lbc_mrg_hus_first_name')} required={true} />
          </Grid.Column>
          <Grid.Column width={4} className="no-padding-left">
            <Field name="lbc_mrg_hus_mid_name" component={InputField} placeholder="Middle Name" />
          </Grid.Column>
          <Grid.Column width={4} className="no-padding-left">
            <Field name="lbc_mrg_hus_last_name" component={InputField} placeholder="Last Name" required={true} />
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="padding-bottom">
          <Grid.Column width={16}>
            <h4 className="bottom-border">{t('marriageCertificate:')}Wife's Details</h4>
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="no-padding">
          <Grid.Column width={8}>
            <Field name="lbc_mrg_wife_first_name" component={InputField} placeholder="First Name" label={t('marriageCertificate:lbc_mrg_wife_first_name')} required={true} />
          </Grid.Column>
          <Grid.Column width={4} className="no-padding-left">
            <Field name="lbc_mrg_wife_mid_name" component={InputField} placeholder="Middle Name" />
          </Grid.Column>
          <Grid.Column width={4} className="no-padding-left">
            <Field name="lbc_mrg_wife_last_name" component={InputField} placeholder="Last Name" required={true} />
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="padding-bottom">
          <Grid.Column width={16}>
            <h4 className="bottom-border">{t('marriageCertificate:')}Others</h4>
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="no-padding">
          <Grid.Column width={8}>
            <Field name="lbc_othr_relationship_code" component={Dropdown} label={t('marriageCertificate:lbc_othr_relationship_code')} options={relations} />
            <Field name="lbc_othr_details" component={InputField} label={t('marriageCertificate:lbc_othr_details')} />
          </Grid.Column>
          <Grid.Column width={8}>
            <Field name="lbc_othr_reg_late_date" component={DateTimePicker} label={t('marriageCertificate:lbc_othr_reg_late_date')} />
            <Field name="lbc_othr_noofcopies" component={Dropdown} label="No of copies" options={copies} />
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="no-padding">
          <Grid.Column width={3}>
            <label className="custom-label">{t('marriageCertificate:regLate')}</label>
          </Grid.Column>
          <Grid.Column width={2}>
            <Field name="lbc_othr_reg_late_yes" type="radio" value="Y" component={Radio} label={t('marriageCertificate:yes')} />
          </Grid.Column>
          <Grid.Column width={2}>
            <Field name="lbc_othr_reg_late_yes" type="radio" value="N" component={Radio} label={t('marriageCertificate:no')} />
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="padding-bottom">
          <Grid.Column width={16}>
            <h4 className="bottom-border">{t('certificateType:attachment')}</h4>
          </Grid.Column>
        </Grid.Row>

        <Grid.Row className="no-padding">
          <Grid.Column width={16}>
            <Table celled striped size='small' stackable>
              <Table.Header>
                <Table.Row>
                  <Table.HeaderCell>{t('certificateType:documentName')}</Table.HeaderCell>
                  <Table.HeaderCell>{t('certificateType:attachment')}</Table.HeaderCell>
                  <Table.HeaderCell colSpan="2" />
                </Table.Row>
              </Table.Header>
              <FieldArray name="attachments" component={CertificateList} bindAttachments={this.props.setAttachmentDtl.bind(this)} />
            </Table>
          </Grid.Column>
        </Grid.Row>

        <Grid.Row>
          <Grid.Column width={16}>
            <div className="actions">
              <button className="primary">{t('marriageCertificate:')}Submit</button>
            </div>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    )
  }
}

export default compose(withTranslation('marriageCertificate'))(MarriageCertificate)