import React, { Component } from 'react'
import { reduxForm, Field } from 'redux-form';
import { connect } from 'react-redux';
import Dropdown from 'components/Common/Dropdown';
import BirthCertificate from './BirthCertificate';
import MarriageCertificate from './MarriageCertificate';
import DeathCertificate from './DeathCertificate'
import CenomarCertificate from './CenomarCertificate'
import { Grid } from 'semantic-ui-react';
import { getGeoOptions, getRelations, getQuickCodeMaster } from 'actions/masterAction';
import { getCertificateCopies, geoParamsBuilder } from 'lib/CommonHelper';
import * as certificateActions from 'actions/certificateAction';
import { getValue } from 'lib/LocalStorage';
import validate from './Validation';
import _ from 'lodash';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

const optionFields = [
  'lbc_certi_type_code', 'lbc_certi_purpose_code',
  'lbc_bir_gender', 'lbc_bir_state_code',
  'lbc_bir_country_code', 'lbc_bir_city_code',
  'lbc_othr_relationship_code',
  'lbc_othr_noofcopies', 'lbc_mrg_city_code',
  'lbc_mrg_state_code', 'lbc_mrg_country_code',
  'lbc_cen_city_code', 'lbc_cen_state_code',
  'lbc_cen_country_code', 'lbc_cen_gender',
  'lbc_dth_city_code', 'lbc_dth_state_code',
  'lbc_dth_country_code', 'lbc_dth_gender'
]

class Certificates extends Component {
  constructor(props) {
    super(props)
    this.state = {
      certificateType: false
    }
    this.dropDownonSelect = this.dropDownonSelect.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.resetForm = this.resetForm.bind(this)
    this.setAttachmentDtl = this.setAttachmentDtl.bind(this)
  }

  componentDidMount() {
    const { currentBooking, countries, relations, getGeoOptions, getRelations, certificate_type, certificateTypes, certificate_purpose, certificatePurpose, province, cities } = this.props

    if (countries.length === 0) {
      getGeoOptions('countries', '')
    }

    if (certificate_type.length === 0) {
      certificateTypes("certificate_type")
    }

    if (certificate_purpose.length === 0) {
      certificatePurpose("certificate_purpose")
    }

    if (relations.length === 0) {
      getRelations()
    }

    if (currentBooking && currentBooking.certificate_detail) {
      this.setState({ certificateType: true })
      this.props.initialize(currentBooking.certificate_detail)

      if (province.length === 0) {
        getGeoOptions('province', `wms_geo_country_code=${currentBooking.certificate_detail.country_code}`)
      }

      if (cities.length === 0) {
        getGeoOptions('city', `wms_geo_country_code=${currentBooking.certificate_detail.country_code}&wms_geo_state_code=${currentBooking.certificate_detail.state_code}`)
      }
    }
    else {
      this.props.initialize({ lbc_certi_type_code: { value: "BC", label: "Birth Certificate" } })
    }
  }

  setAttachmentDtl(name, base64, index) {
    const { CertificatesForm, initialize } = this.props
    let hash = CertificatesForm ? _.cloneDeep(CertificatesForm.values) : { attachments: [] }
    let tempHash = {
      tran_document_name: name,
      tran_attachement: base64
    }
    _.merge(hash['attachments'][index], tempHash)
    initialize(hash)
  }

  dropDownonSelect(data, childName) {
    if (data && data.value && childName) {
      this.props.getGeoOptions(childName, geoParamsBuilder(data, childName))
    }
  }

  resetForm(data) {
    const { currentBooking } = this.props
    if (!currentBooking.certificate_detail) {
      this.props.reset();
      this.props.initialize({ lbc_certi_type_code: { value: data.value, label: data.label } });
    }
  }

  formSubmit(values) {
    const brId = getValue('br_id')
    const { currentBooking } = this.props
    let obj = {}
    _.each(values, function (value, key) {
      if (_.includes(optionFields, key) && value) {
        obj[key] = value.value
        if (key === 'lbc_othr_noofcopies')
          obj[key] = parseInt(value.value)
      }
      else
        obj[key] = value;
    });
    if (!currentBooking.certificate_detail) {
      this.props.create(obj, brId)
    } else {
      this.props.update(obj, brId)
    }
    this.props.close('certificate')
  }
  render() {
    const values = this.props.CertificatesForm && this.props.CertificatesForm.values
    const certificateType = values && values.lbc_certi_type_code && values.lbc_certi_type_code.value
    const { handleSubmit, countries, province, cities, relations, certificate_type, certificate_purpose, t } = this.props
    const options = {
      certificateType: certificateType, countries: countries, province: province,
      cities: cities, copies: getCertificateCopies(), dropDownonSelect: this.dropDownonSelect, relations: relations, setAttachmentDtl: this.setAttachmentDtl
    }
    return (
      <div className="certificates-wrapper">
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable>
            <Grid.Row className="no-padding">
              <Grid.Column width={8}>
                <Field name="lbc_certi_type_code" component={Dropdown} handleOnSelect={this.resetForm} label={t('certificateType:lbc_certi_type_code')} options={certificate_type} required={true} readOnly={this.state.certificateType} />
              </Grid.Column>
              <Grid.Column width={8}>
                <Field name="lbc_certi_purpose_code" component={Dropdown} label={t('certificateType:lbc_certi_purpose_code')} options={certificate_purpose} required={true} />
              </Grid.Column>
            </Grid.Row>
          </Grid>
          {certificateType === 'MC' && <MarriageCertificate {...options} />}
          {certificateType === 'BC' && <BirthCertificate {...options} />}
          {certificateType === 'DC' && <DeathCertificate {...options} />}
          {certificateType === 'CC' && <CenomarCertificate {...options} />}
        </form>
      </div>
    )
  }
}
Certificates = reduxForm({
  form: 'CertificatesForm',
  validate
})(Certificates);

const mapDispatchToProps = (dispatch) => ({
  getGeoOptions: (action, queryStr) => dispatch(getGeoOptions(action, queryStr)),
  create: (params, brId) => dispatch(certificateActions.create(params, brId)),
  update: (params, brId) => dispatch(certificateActions.update(params, brId)),
  getRelations: () => dispatch(getRelations('relations')),
  certificateTypes: type => dispatch(getQuickCodeMaster(type, "")),
  certificatePurpose: type => dispatch(getQuickCodeMaster(type, ""))
})

const mapStateToProps = state => ({
  countries: state.masterReducer.options.countries,
  province: state.masterReducer.options.province,
  cities: state.masterReducer.options.city,
  CertificatesForm: state.form.CertificatesForm,
  currentBooking: state.bookingReducer.currentBooking,
  relations: state.masterReducer.options.relations,
  certificate_type: state.masterReducer.options.certificate_type,
  certificate_purpose: state.masterReducer.options.certificate_purpose
})

export default compose(withTranslation('certificateType'), connect(mapStateToProps, mapDispatchToProps))(Certificates)
