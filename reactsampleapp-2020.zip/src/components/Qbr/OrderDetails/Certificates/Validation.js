const Validation = values => {
  const errors = {};
  if (!values.lbc_certi_type_code)
    errors.lbc_certi_type_code = 'Certificate type is required.'

  if (!values.lbc_certi_purpose_code || (values.lbc_certi_purpose_code && Object.keys(values.lbc_certi_purpose_code).length === 0)) {
    errors.lbc_certi_purpose_code = 'Purpose is required.'
  }

  if (values.lbc_certi_type_code) {
    const certType = values.lbc_certi_type_code.value
    if (certType === 'MC') {
      if (!values.lbc_mrg_date)
        errors.lbc_mrg_date = 'Marriage date is required.'

      if (!values.lbc_mrg_hus_first_name)
        errors.lbc_mrg_hus_first_name = 'Husband first name is required.'

      if (!values.lbc_mrg_hus_last_name)
        errors.lbc_mrg_hus_last_name = 'Husband last name is required.'

      if (!values.lbc_mrg_wife_first_name)
        errors.lbc_mrg_wife_first_name = 'Wife first name is required.'

      if (!values.lbc_mrg_wife_last_name)
        errors.lbc_mrg_wife_last_name = 'Wife last name is required.'

      if (!values.lbc_mrg_country_code || (values.lbc_mrg_country_code && Object.keys(values.lbc_mrg_country_code).length === 0))
        errors.lbc_mrg_country_code = 'Country is required.'

      if (!values.lbc_mrg_state_code || (values.lbc_mrg_state_code && Object.keys(values.lbc_mrg_state_code).length === 0))
        errors.lbc_mrg_state_code = 'State is required.'

      if (!values.lbc_mrg_city_code || (values.lbc_mrg_city_code && Object.keys(values.lbc_mrg_city_code).length === 0))
        errors.lbc_mrg_city_code = 'City is required.'
    }
    if (certType === 'BC') {
      if (!values.lbc_bir_first_name)
        errors.lbc_bir_first_name = 'Name on birth certificate first is required.'

      if (!values.lbc_bir_birth_date)
        errors.lbc_bir_birth_date = 'Birth date is required.'

      if (!values.lbc_bir_last_name)
        errors.lbc_bir_last_name = 'Name on birth certificate last name is required.'

      if (!values.lbc_bir_fathers_first_name)
        errors.lbc_bir_fathers_first_name = 'Father"s first name is required.'

      if (!values.lbc_bir_fathers_last_name)
        errors.lbc_bir_fathers_last_name = 'Father"s last name is required.'

      if (!values.lbc_bir_mothers_first_name)
        errors.lbc_bir_mothers_first_name = 'Mother"s first name is required.'

      if (!values.lbc_bir_mothers_last_name)
        errors.lbc_bir_mothers_last_name = 'Mother"s last name is required.'

      if (!values.lbc_bir_gender)
        errors.lbc_bir_gender = 'Gender is required.'

      if (!values.lbc_bir_country_code || (values.lbc_bir_country_code && Object.keys(values.lbc_bir_country_code).length === 0))
        errors.lbc_bir_country_code = 'Country is required.'

      if (!values.lbc_bir_state_code || (values.lbc_bir_state_code && Object.keys(values.lbc_bir_state_code).length === 0))
        errors.lbc_bir_state_code = 'State is required.'

      if (!values.lbc_bir_city_code || (values.lbc_bir_city_code && Object.keys(values.lbc_bir_city_code).length === 0))
        errors.lbc_bir_city_code = 'City is required.'
    }
    if (certType === 'DC') {
      if (!values.lbc_dth_first_name)
        errors.lbc_dth_first_name = 'Name on death certificate first is required.'

      if (!values.lbc_dth_last_name)
        errors.lbc_dth_last_name = 'Name on death certificate last name is required.'

      if (!values.lbc_dth_fathers_first_name)
        errors.lbc_dth_fathers_first_name = 'Father"s first name is required.'

      if (!values.lbc_dth_fathers_last_name)
        errors.lbc_dth_fathers_last_name = 'Father"s last name is required.'

      if (!values.lbc_dth_mothers_first_name)
        errors.lbc_dth_mothers_first_name = 'Mother"s first name is required.'

      if (!values.lbc_dth_mothers_last_name)
        errors.lbc_dth_mothers_last_name = 'Mother"s last name is required.'

      if (!values.lbc_dth_gender)
        errors.lbc_dth_gender = 'Gender is required.'

      if (!values.lbc_dth_country_code || (values.lbc_dth_country_code && Object.keys(values.lbc_dth_country_code).length === 0))
        errors.lbc_dth_country_code = 'Country is required.'

      if (!values.lbc_dth_state_code || (values.lbc_dth_state_code && Object.keys(values.lbc_dth_state_code).length === 0))
        errors.lbc_dth_state_code = 'State is required.'

      if (!values.lbc_dth_city_code || (values.lbc_dth_city_code && Object.keys(values.lbc_dth_city_code).length === 0))
        errors.lbc_dth_city_code = 'City is required.'
    }
    if (certType === 'CC') {
      if (!values.lbc_cen_first_name)
        errors.lbc_cen_first_name = 'Name on birth certificate first is required.'

      if (!values.lbc_cen_birth_date)
        errors.lbc_cen_birth_date = 'Birth date is required'

      if (!values.lbc_cen_last_name)
        errors.lbc_cen_last_name = 'Name on birth certificate last name is required.'

      if (!values.lbc_cen_fathers_first_name)
        errors.lbc_cen_fathers_first_name = 'Father"s first name is required.'

      if (!values.lbc_cen_fathers_last_name)
        errors.lbc_cen_fathers_last_name = 'Father"s last name is required.'

      if (!values.lbc_cen_mothers_first_name)
        errors.lbc_cen_mothers_first_name = 'Mother"s first name is required.'

      if (!values.lbc_cen_mothers_last_name)
        errors.lbc_cen_mothers_last_name = 'Mother"s last name is required.'

      if (!values.lbc_cen_gender)
        errors.lbc_cen_gender = 'Gender is required.'

      if (!values.lbc_cen_country_code || (values.lbc_cen_country_code && Object.keys(values.lbc_cen_country_code).length === 0))
        errors.lbc_cen_country_code = 'Country is required.'

      if (!values.lbc_cen_state_code || (values.lbc_cen_state_code && Object.keys(values.lbc_cen_state_code).length === 0))
        errors.lbc_cen_state_code = 'State is required.'

      if (!values.lbc_cen_city_code || (values.lbc_cen_city_code && Object.keys(values.lbc_cen_city_code).length === 0))
        errors.lbc_cen_city_code = 'City is required.'
    }
  }
  return errors;
}

export default Validation;
