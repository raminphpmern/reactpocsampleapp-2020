import React, { Component } from 'react';
import { Table } from 'semantic-ui-react';
import { Field } from 'redux-form';
import InputField from 'components/Common/InputField';
import Checkbox from 'components/Common/Checkbox';
import Dropdown from 'components/Common/Dropdown';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class ReeferDetails extends Component {

  render() {
    const { temp_uom, t } = this.props
    return (
      <Table celled striped>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>{t('reeferDetails:cds_temp_controlled')}</Table.HeaderCell>
            <Table.HeaderCell>{t('reeferDetails:cds_min_temp')}</Table.HeaderCell>
            <Table.HeaderCell>{t('reeferDetails:cds_max_temp')}</Table.HeaderCell>
            <Table.HeaderCell>{t('reeferDetails:cds_temp_uom')}</Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          <Table.Row>
            <Table.Cell className="small-width text-center"><Field name="tms_brcds_consgt_additional_services.cds_temp_controlled" type="checkbox" component={Checkbox} /></Table.Cell>
            <Table.Cell className="small-width"><Field name="tms_brcds_consgt_additional_services.cds_min_temp" component={InputField} /></Table.Cell>
            <Table.Cell className="small-width"><Field name="tms_brcds_consgt_additional_services.cds_max_temp" component={InputField} /></Table.Cell>
            <Table.Cell className="small-width"><Field name="tms_brcds_consgt_additional_services.cds_temp_uom" component={Dropdown} options={temp_uom} /></Table.Cell>
          </Table.Row>
        </Table.Body>
      </Table>
    )
  }
}

export default compose(withTranslation('reeferDetails'))(ReeferDetails)