import React, { Component } from 'react';
import { Table, Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { Field, FieldArray } from 'redux-form';
import InputField from 'components/Common/InputField';
import ContentList from './ContentList';
import { getClassOfStores } from 'actions/masterAction';
import { Icon } from 'semantic-ui-react';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class ContentDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      more: false
    }
    this.toggle = this.toggle.bind(this)
  }

  componentDidMount() {
    if (this.props.class_of_stores.length === 0) {
      this.props.getClassOfStores()
    }
  }

  toggle() {
    this.setState(prevState => ({
      more: !prevState.more
    }));
  }

  render() {
    const { products, barcodes, class_of_stores, t } = this.props;
    const { more } = this.state
    return (
      <div>
        <Grid stackable>
          <Grid.Row className="document_wrapper">
            <Grid.Column width={16} >
              <div>
                <Table celled striped className="">
                  <Table.Header>
                    <Table.Row>
                      <Table.HeaderCell>{t('contentDetail:product')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('contentDetail:barcode')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('contentDetail:content')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('contentDetail:description')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('contentDetail:commodity')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('contentDetail:price')} </Table.HeaderCell>
                      <Table.HeaderCell>{t('contentDetail:qty')}</Table.HeaderCell>
                      <Table.HeaderCell>{t('contentDetail:declaredValue')}</Table.HeaderCell>
                      {more && <Table.HeaderCell>{t('contentDetail:batchID')}</Table.HeaderCell>}
                      {more && <Table.HeaderCell>{t('contentDetail:mfgDate')}</Table.HeaderCell>}
                      {more && <Table.HeaderCell colSpan="2">{t('contentDetail:expDate')}</Table.HeaderCell>}
                      <Table.HeaderCell className="hide" />
                      {!more && <Table.HeaderCell colSpan="2"><span onClick={() => this.toggle()}> <Icon disabled name='arrow alternate circle right' /></span></Table.HeaderCell>}
                      {more && <Table.HeaderCell colSpan="2"><span onClick={() => this.toggle()}> <Icon disabled name='arrow alternate circle left' /></span></Table.HeaderCell>}
                    </Table.Row>
                  </Table.Header>
                  <FieldArray products={products} more={more} barcodes={barcodes} name="content_details" component={ContentList} class_of_stores={class_of_stores} />
                </Table>
              </div>
              <div className="total-value">
                <Field name="cd_declared_value_of_goods" component={InputField} label={t('contentDetail:total')} />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  getClassOfStores: () => dispatch(getClassOfStores('class_of_stores'))
})

const mapStateToProps = state => ({
  class_of_stores: state.masterReducer.options.class_of_stores
})

export default compose(withTranslation('contentDetail'), connect(mapStateToProps, mapDispatchToProps))(ContentDetails)
