import React, { Component } from 'react'
import { reduxForm, Field } from 'redux-form';
import { connect } from 'react-redux';
import InputField from 'components/Common/InputField';
import Radio from 'components/Common/RadioFiled';
import _ from 'lodash';
import { getValue } from 'lib/LocalStorage'
import moment from 'moment';

const validate = values => {
  const errors = {};
  const arr = []
  let length = 0
  let duplicateKey = 'brcsd_serial_no_1'
  _.map(values, (item, key) => {
    length++
    if (!arr.includes(item)) {
      arr.push(item)
    } else {
      duplicateKey = key
    }
  })
  if (arr.length !== length) {
    errors[duplicateKey] = "Serial no should be Unique"
  }
  return errors
}


class Barcode extends Component {
  constructor(props) {
    super(props)
    this.state = {
      disableBtn: false
    }
    this.formSubmit = this.formSubmit.bind(this);
    this.generateBarcode = this.generateBarcode.bind(this)
  }

  formSubmit(values) {
    delete values["barcode"]
    this.props.setBarcodes(values, this.props.index)
    this.props.close('barcode')
  }

  generateBarcode() {
    const { qty } = this.props
    let branch = getValue('currentBranch')
    branch = JSON.parse(branch)
    let obj = {}
    let time = parseInt(moment.utc().format('YYMMDDHHmmss'))
    _.times(qty, (key) => {
      obj[`brcsd_serial_no_${key + 1}`] = branch.BRCODE + "0" + (time + (key + 1)).toString()
    })
    obj.barcode = 'number'
    this.props.initialize(obj)
  }

  componentDidMount() {
    const { barcodes, selected } = this.props
    if (barcodes[selected] && barcodes[selected].length > 0) {
      let obj = {}
      barcodes[selected].map((item, key) => {
        if (item.value === 'XXX-XXX-XXX') {
          obj.barcode = 'number'
        } else {
          obj[`brcsd_serial_no_${key + 1}`] = barcodes[selected][key].value
          obj.barcode = 'manual'
        }
      })
      this.props.initialize(obj)
    }
    if ((barcodes[selected].length) === this.props.qty) {
      this.setState({ disableBtn: true })
    }
  }

  render() {
    const { handleSubmit, qty } = this.props
    const { disableBtn } = this.state
    let values = this.props.formValues && this.props.formValues.values ? this.props.formValues.values : {}
    return (
      <div className="barcode-wrapper">
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <div className="barcode-type ">
            <div className="type-label">
              <Field htmlFor="one" label="Use Numbering Type" name="barcode" type="radio" component={Radio} value="number" />
              <Field htmlFor="two" label="Scan or Manual Entry" name="barcode" type="radio" component={Radio} value="manual" />
            </div>
            <button disabled={values && values.barcode === 'manual' || disableBtn} className="primary" type="button" onClick={this.generateBarcode}>Generate</button>
          </div>
          {_.times(qty, (key) => {
            return (
              <Field id={`brcsd_serial_no_${key + 1}`} readOnly={values && values.barcode === 'number'} name={`brcsd_serial_no_${key + 1}`} component={InputField} label={`Serail No ${key + 1}`} key={key} />
            )
          })
          }
          <div className="actions">
            <button className="primary" type="submit">Save</button>
          </div>
        </form>
      </div>
    )
  }
}
Barcode = reduxForm({
  form: 'formValues',
  initialValues: {
    barcode: 'number'
  },
  validate
})(Barcode);

const mapDispatchToProps = (dispatch) => ({

})

const mapStateToProps = state => ({
  countries: state.masterReducer.options.countries,
  formValues: state.form.formValues,
})

export default connect(mapStateToProps, mapDispatchToProps)(Barcode)
