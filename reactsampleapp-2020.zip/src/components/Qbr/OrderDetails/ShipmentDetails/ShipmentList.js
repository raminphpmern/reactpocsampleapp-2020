import React, { Component } from 'react';
import { Table } from 'semantic-ui-react';
import { Field } from 'redux-form';
import InputField from 'components/Common/InputField';
import Dropdown from 'components/Common/Dropdown';

class ShipmentList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      barcode: false
    }
    this.toggle = this.toggle.bind(this)
  }

  componentDidMount() {
    if (this.props.fields.length === 0) {
      this.props.fields.push({})
    }
  }

  toggle() {
    this.setState({ barcode: !this.state.barcode })
  }

  addRow(e) {
    if (e.keyCode === 13) {
      this.props.fields.push({})
    }
  }

  removeRow(e, index) {
    if (e.keyCode === 13) {
      this.props.fields.remove(index)
    }
  }

  render() {
    let { fields, products, handleSearchChange, dropDownonSelect, inputChange, setIndexAndValue, uomResult, alt_uom, showAltQty } = this.props;
    let values = {}
    let ethuTrackingNo = false
    if (this.props.formValues) {
      values = this.props.formValues.shipment_details
      if (this.props.formValues.ethu_tracking_no)
        ethuTrackingNo = true
    }
    let haveValue = values && values.length ? true : false
    return (
      <Table.Body>
        {fields.map((elem, index) => {
          let qty = haveValue && values[index] && values[index].tms_brcd_consgt_details && values[index].tms_brcd_consgt_details.cd_thu_qty
          const tms_brctd_consgt_thu_serial_details = haveValue && values[index] && values[index].tms_brctd_consgt_thu_serial_details
          const showCbm = tms_brctd_consgt_thu_serial_details && (tms_brctd_consgt_thu_serial_details.ctsd_length || tms_brctd_consgt_thu_serial_details.ctsd_breadth || tms_brctd_consgt_thu_serial_details.ctsd_height)
          const showlwh = values[index] && values[index].cbm && (!tms_brctd_consgt_thu_serial_details.ctsd_length || !tms_brctd_consgt_thu_serial_details.ctsd_breadth || !tms_brctd_consgt_thu_serial_details.ctsd_height)
          if (qty)
            qty = parseInt(qty)
          return (
            <Table.Row key={index}>
              <Table.Cell className="table-dropdown small-width">
                <Field readOnly={ethuTrackingNo} name={`${elem}.tms_brcd_consgt_details.cd_thu_qty`} placeholder={uomResult.QT}
                  component={InputField} type='number' min="1" max="1000"
                  onChange={(e) => { inputChange(e.target.value, index, 'cd_thu_qty', 'tms_brcd_consgt_details') }} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field className="medium-width" name={`${elem}.tms_brcd_consgt_details.cd_thu_id`} component={Dropdown} options={products}
                  handleSearchChange={handleSearchChange} handleOnSelect={dropDownonSelect}
                  childName={index} clearable={!ethuTrackingNo} /></Table.Cell>
              <Table.Cell className="small-width">
                <Field name={`${elem}.tms_brcd_consgt_details.cd_gross_weight`} min="1" component={InputField} type='number' placeholder={uomResult.WT}
                  onChange={(e) => { inputChange(e.target.value, index, 'cd_gross_weight', 'tms_brcd_consgt_details') }}
                />
                <Field name={`${elem}.tms_brcd_consgt_details.cd_weight_uom`} component={InputField} type='hidden' />
              </Table.Cell>
              <Table.Cell className="small-width">
                <Field name={`${elem}.tms_brctd_consgt_thu_serial_details.ctsd_length`} readOnly={showlwh} min="1" type='number'
                  component={InputField} placeholder={uomResult.DM}
                  onChange={(e) => { inputChange(e.target.value, index, 'ctsd_length', 'tms_brctd_consgt_thu_serial_details') }} />
              </Table.Cell>
              <Table.Cell className="small-width">
                <Field name={`${elem}.tms_brctd_consgt_thu_serial_details.ctsd_breadth`} readOnly={showlwh} min="1" component={InputField} type='number' placeholder={uomResult.DM}
                  onChange={(e) => { inputChange(e.target.value, index, 'ctsd_breadth', 'tms_brctd_consgt_thu_serial_details') }} />
              </Table.Cell>
              <Table.Cell className="small-width">
                <Field name={`${elem}.tms_brctd_consgt_thu_serial_details.ctsd_height`} readOnly={showlwh} min="1" component={InputField} type='number' placeholder={uomResult.DM}
                  onChange={(e) => { inputChange(e.target.value, index, 'ctsd_height', 'tms_brctd_consgt_thu_serial_details') }} />
              </Table.Cell>
              <Table.Cell className="medium2-width">
                <Field name={`${elem}.vwt`} component={InputField} readOnly={true} />
              </Table.Cell>
              <Table.Cell className="medium2-width">
                <Field name={`${elem}.cbm`} component={InputField} type='number' readOnly={showCbm} />
              </Table.Cell>
              <Table.Cell className="small-width">
                <Field name={`${elem}.cwt`} component={InputField} readOnly={true} />
              </Table.Cell>
              <Table.Cell className="small-width"><button type="button" disabled={qty === 1 || !qty || ethuTrackingNo} className="link-button"
                onClick={() => { setIndexAndValue(index, qty) }}>Bar Code</button></Table.Cell>
              {showAltQty &&
                [
                  <Table.Cell className="small-width" key='1'>
                    <Field name={`${elem}.tms_brctd_consgt_thu_serial_details.ctsd_altqty`} min="1" component={InputField} type='number'
                      onChange={(e) => { inputChange(e.target.value, index, 'ctsd_altqty', 'tms_brctd_consgt_thu_serial_details') }} /></Table.Cell>,
                  <Table.Cell className="table-dropdown" key='2'>
                    <Field className="medium-width" name={`${elem}.tms_brctd_consgt_thu_serial_details.ctsd_altqty_uom`} component={Dropdown} options={alt_uom} /></Table.Cell>,
                ]
              }
            </Table.Row>
          )
        })}
      </Table.Body>
    )
  }
}

export default ShipmentList
