import React, { Component } from 'react';
import { Table, Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { FieldArray, Field } from 'redux-form';
import * as masterActions from 'actions/masterAction';
import ShipmentList from './ShipmentList';
import { SEARCH_WORD_COUNT } from 'config'
import InputField from 'components/Common/InputField';
import * as orderActions from 'actions/orderAction';
import _ from 'lodash';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class ShipmentDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      check: true,
      showAltQty: false
    }
    this.handleSearchChange = this.handleSearchChange.bind(this)
    this.dropDownonSelect = this.dropDownonSelect.bind(this)
    this.validateChildThu = this.validateChildThu.bind(this)

  }

  componentDidMount() {
    const { alt_uom, fetchAltUom, serviceType } = this.props
    if (serviceType && serviceType.value.toUpperCase().match(/MONEY REMITTANCE/g)) {
      this.setState({ showAltQty: true })
    }
    if (alt_uom.length === 0) {
      fetchAltUom()
    }
  }

  handleSearchChange(data, index) {
    const { formValues } = this.props
    const serviceType = formValues.values && formValues.values.tms_br_booking_request_hdr.br_service_type.value
    if (data.length >= SEARCH_WORD_COUNT) {
      this.props.getProducts('products', `keyword=${data}&wms_sales_org_ser_type=${serviceType}`)
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.childThuValid !== nextProps.childThuValid && !nextProps.childThuValid) {
      let hash = _.cloneDeep(this.props.formValues.values)
      if (!nextProps.childThuValid) {
        hash['child_thu'] = ''
        this.props.initializeHash(hash)
      }
    }

    if (nextProps.validationProfile && this.state.check) {
      let values = this.props.formValues && this.props.formValues.values ? this.props.formValues.values : {}
      const br_service_type = values && values.tms_br_booking_request_hdr && values.tms_br_booking_request_hdr.br_service_type.value
      const childThu = nextProps.validationProfile && nextProps.validationProfile.brprh_reverse_create === br_service_type && parseInt(nextProps.validationProfile.brprh_reverse_chk) === 1
      if (childThu) {
        let node = document.getElementById('childThu')
        node && node.addEventListener("keydown", e => {
          if (e.keyCode === 9) {
            this.validateChildThu()
          }
        })
        this.setState({ check: false })
      }
    }
  }

  checkValidChildEthu(e) {
    if (e.keyCode !== 9 && e.target.value) {
      this.validateChildThu()
    }
  }

  dropDownonSelect(data, index) {
    this.props.initializeShipmentDtl(data, index)
  }

  validateChildThu() {
    const { formValues } = this.props
    let childThu = formValues && formValues.values ? formValues.values.child_thu : null
    let customerId = formValues && formValues.values && formValues.values.tms_br_booking_request_hdr && formValues.values.tms_br_booking_request_hdr.br_customer_id
    this.props.validateChildThuId(childThu, customerId)
  }


  render() {
    const { products, calculateChargeable, setIndexAndValue, uomResult, validationProfile, t, alt_uom } = this.props;
    const { showAltQty } = this.state;
    let values = this.props.formValues && this.props.formValues.values ? this.props.formValues.values : {}
    const shipmentDetails = values && values.shipment_details && values.shipment_details.length > 0 ? values.shipment_details[0] : {}
    const br_service_type = values && values.tms_br_booking_request_hdr && values.tms_br_booking_request_hdr.br_service_type.value
    const childThu = br_service_type && validationProfile && validationProfile.brprh_reverse_create && validationProfile.brprh_reverse_create.toLowerCase() === br_service_type.toLowerCase() && parseInt(validationProfile.brprh_reverse_chk) === 1
    return (
      <div>
        <Grid stackable>
          <Grid.Row className="document_wrapper">
            <Grid.Column width={16}>
              <Table celled striped>
                <Table.Header>
                  <Table.Row>
                    <Table.HeaderCell>{t('shipmentDetails:qty')}<em>*</em></Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:product')}<em>*</em></Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:actualWt')}<em>*</em></Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:len')}{!shipmentDetails.cbm && <em>*</em>}</Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:wid')}{!shipmentDetails.cbm && <em>*</em>}</Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:height')}{!shipmentDetails.cbm && <em>*</em>}</Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:volu')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:cbm')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:chargewt')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('shipmentDetails:barcode')}<em>*</em></Table.HeaderCell>
                    {showAltQty &&
                      [
                        <Table.HeaderCell key='1'>{t('shipmentDetails:altqty')}<em>*</em></Table.HeaderCell>,
                        <Table.HeaderCell key='2'>{t('shipmentDetails:altuom')}<em>*</em></Table.HeaderCell>,
                      ]
                    }
                  </Table.Row>
                </Table.Header>
                <FieldArray name="shipment_details" setIndexAndValue={setIndexAndValue} component={ShipmentList}
                  handleSearchChange={this.handleSearchChange} products={products}
                  dropDownonSelect={this.dropDownonSelect}
                  inputChange={calculateChargeable} formValues={values}
                  uomResult={uomResult} showAltQty={showAltQty}
                  alt_uom={alt_uom} />
              </Table>
              {childThu && <div className="total-value">
                <Field required={true} onBlur={(e) => this.checkValidChildEthu(e)} name="child_thu" id="childThu" component={InputField} label="Child THU" />
              </div>}
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}


const mapDispatchToProps = (dispatch) => ({
  getProducts: (type, queryStr) => dispatch(masterActions.getProducts(type, queryStr)),
  validateChildThuId: (trackingNo, customerId) => dispatch(orderActions.validateChildThuId(trackingNo, customerId)),
  fetchAltUom: () => dispatch(masterActions.fetchAltUom('alt_uom', ''))
})

const mapStateToProps = state => ({
  products: state.masterReducer.options.products,
  formValues: state.form.OrderDetailsForm,
  validationProfile: state.bookingReducer.validationProfile,
  childThuValid: state.bookingReducer.childThuValid,
  alt_uom: state.masterReducer.options.alt_uom
})

export default compose(withTranslation('shipmentDetails'), connect(mapStateToProps, mapDispatchToProps))(ShipmentDetails)