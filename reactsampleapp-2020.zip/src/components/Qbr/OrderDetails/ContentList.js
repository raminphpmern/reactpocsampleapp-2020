import React, { Component } from 'react';
import { Table } from 'semantic-ui-react';
import { reduxForm, Field } from 'redux-form';
import InputField from 'components/Common/InputField';
import Dropdown from 'components/Common/Dropdown';
import DateTimePicker from 'components/Common/DateTimePicker';
import { connect } from 'react-redux';
import { fetchProductItems } from 'actions/masterAction';
import _ from 'lodash';
import { SEARCH_WORD_COUNT } from 'config'


class ContentList extends Component {
  constructor(props) {
    super(props)
    this.onItemSelect = this.onItemSelect.bind(this)
    this.searchProductItems = this.searchProductItems.bind(this)
    this.inputChange = this.inputChange.bind(this)
  }

  componentDidMount() {
    if (this.props.fields.length === 0) {
      this.props.fields.push({})
      this.props.fields.push({})
      this.props.fields.push({})
    }
  }

  onItemSelect(data, index) {
    if (data) {
      let formHash = this.props.formValues.values
      let content_details = formHash['content_details']
      let hash = {
        tms_brcsd_consgt_sku_details: {
          brcsd_sku_id: data,
          description: data.wms_itm_long_desc
        }
      }
      content_details[index] = _.merge(content_details[index], hash)
      formHash['content_details'] = content_details
      this.props.initialize(formHash)
    }
  }

  searchProductItems(data) {
    if (data.length >= SEARCH_WORD_COUNT) {
      this.props.fetchProductItems(`keyword=${data}`)
    }
  }

  inputChange(value, field, index) {
    let hash = this.props.formValues.values;
    let content_details = hash.content_details[index]
    let tms_brcsd_consgt_sku_details = content_details.tms_brcsd_consgt_sku_details
    let sum = 0
    if (field === 'brcsd_sku_rate') {
      let brcsd_sku_quantity = tms_brcsd_consgt_sku_details && content_details.tms_brcsd_consgt_sku_details.brcsd_sku_quantity
      if (brcsd_sku_quantity) {
        sum = parseInt(brcsd_sku_quantity) * value
      }
    }
    if (field === 'brcsd_sku_quantity') {
      let brcsd_sku_rate = tms_brcsd_consgt_sku_details && content_details.tms_brcsd_consgt_sku_details.brcsd_sku_rate
      if (brcsd_sku_rate) {
        sum = parseInt(brcsd_sku_rate) * value
      }
    }

    if (hash['content_details'][index] && hash['content_details'][index].tms_brcsd_consgt_sku_details) {
      hash['content_details'][index].tms_brcsd_consgt_sku_details.brcsd_sku_value = sum
      hash.cd_declared_value_of_goods = _.sumBy(hash.content_details, function (o) {
        if (o.tms_brcsd_consgt_sku_details) {
          return parseInt(o.tms_brcsd_consgt_sku_details.brcsd_sku_value)
        }
      });
    }
    if (hash.tms_br_booking_request_hdr) {
      hash.tms_br_booking_request_hdr.br_declared_value = hash.cd_declared_value_of_goods
      if (hash.tms_br_booking_request_hdr && hash.tms_br_booking_request_hdr.br_include && hash.tms_br_booking_request_hdr.br_include.value === 'product_value') {
        hash.cod_cop_amount = hash.cd_declared_value_of_goods
      }
    }
    this.props.initialize(hash)
  }

  render() {
    let { fields, products, barcodes, class_of_stores, product_items, more } = this.props;
    let values = {}
    if (this.props.formValues && this.props.formValues.values) {
      values = this.props.formValues.values.content_details
    }
    return (
      <Table.Body>
        {fields.map((elem, index) => {
          let productIndex = values && values[index] && values[index].tms_brcd_consgt_details && values[index].tms_brcd_consgt_details.cd_thu_id && values[index].tms_brcd_consgt_details.cd_thu_id.value;
          return (
            <Table.Row key={index}>
              <Table.Cell className="table-dropdown medium-width">
                <Field name={`${elem}.tms_brcd_consgt_details.cd_thu_id`} options={products} clearable={true} component={Dropdown} />
              </Table.Cell>
              <Table.Cell className="table-dropdown medium-width">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.brcsd_serial_no`} component={Dropdown} options={barcodes && barcodes[productIndex] ? barcodes[productIndex] : []} />
              </Table.Cell>
              <Table.Cell className="table-dropdown medium-width">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.brcsd_sku_id`} component={Dropdown} options={product_items} handleOnSelect={this.onItemSelect} childName={index}
                  handleSearchChange={this.searchProductItems} />
              </Table.Cell>
              <Table.Cell>
                <Field readOnly={true} name={`${elem}.tms_brcsd_consgt_sku_details.description`} component={InputField} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.cd_class_of_stores`} component={Dropdown} options={class_of_stores} /></Table.Cell>
              <Table.Cell className="small-width">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.brcsd_sku_rate`} min="1" onChange={(e) => { this.inputChange(e.target.value, 'brcsd_sku_rate', index) }} component={InputField} type='number' /></Table.Cell>
              <Table.Cell className="small-width">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.brcsd_sku_quantity`} min="1" onChange={(e) => { this.inputChange(e.target.value, 'brcsd_sku_quantity', index) }} component={InputField} type='number' max="99" /></Table.Cell>
              <Table.Cell className="small-width">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.brcsd_sku_value`} component={InputField} /></Table.Cell>
              {more && <Table.Cell className="small-width">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.brcsd_sku_batch_id`} component={InputField} /></Table.Cell>}
              {more && <Table.Cell className="medium-width">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.brcsd_sku_mfg_date`} component={DateTimePicker} /></Table.Cell>}
              {more && <Table.Cell className="medium-width">
                <Field name={`${elem}.tms_brcsd_consgt_sku_details.brcsd_sku_expiry_date`} component={DateTimePicker} /></Table.Cell>}
              <Table.Cell>
                {fields.length - 1 === index &&
                  <i className="plus circle icon" onClick={() => fields.push({})}></i>
                }
              </Table.Cell>
              <Table.Cell>
                {index > 0 && <i className="minus circle icon" onClick={() => fields.remove(index)} ></i>}
              </Table.Cell>
            </Table.Row>
          )
        })}
      </Table.Body>
    )
  }
}

ContentList = reduxForm({
  form: 'OrderDetailsForm'
})(ContentList);

const mapDispatchToProps = (dispatch) => ({
  fetchProductItems: (queryStr) => dispatch(fetchProductItems('product_items', queryStr))
})

const mapStateToProps = state => ({
  product_items: state.masterReducer.options.product_items,
  formValues: state.form.OrderDetailsForm,
})

export default connect(mapStateToProps, mapDispatchToProps)(ContentList)
