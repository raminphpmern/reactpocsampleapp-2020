import React, { Component } from 'react';
import { reduxForm, Field } from 'redux-form';
import { connect } from 'react-redux';
import InputField from 'components/Common/InputField';
import PhoneInputField from 'components/Common/PhoneInput';
import Dropdown from 'components/Common/Dropdown';
import ShipperTaxDetails from './ShipperTaxDetails';
import * as shipperActions from 'actions/shipperAction'
import PropTypes from 'prop-types';
import validate from './ShipperValidation';
import { buildShipperData, buildShipmentData } from 'lib/ShippingHelper';
import { Grid } from 'semantic-ui-react';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class NewShipper extends Component {
  constructor(props) {
    super(props)
    this.state = {
      taxDetails: false,
      customerId: null,
      error: '',
      isNameRequired: true,
      isCompanyRequired: true
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.toggle = this.toggle.bind(this)
    this.markMandatory = this.markMandatory.bind(this)
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const { isLoading, isSuccess, shipper, initializeShipper, close, formValues } = this.props
    if (isLoading !== nextProps.isLoading && isLoading) {
      if (isSuccess && shipper) {
        const shipperHash = buildShipperData(shipper)
        const shipmentHash = buildShipmentData(shipper)
        initializeShipper(shipperHash, 'tms_br_booking_request_hdr')
        initializeShipper(shipmentHash, 'tms_brsd_shipment_details')
        let formHash = formValues.values
        this.props.initialize({ ...formHash, account_no: shipper.wms_customer_id })
        this.setState({ customerId: shipper.wms_customer_id })
        close('shipper')
      }
    }
  }

  formSubmit(values) {
    // TODO: need to add kyc_no in table
    delete values.kyc_no
    this.props.resetAccountNoShipper(values)
    const { customerId } = this.state
    if (Object.entries(values).length !== 0 && customerId === null) {
      if (values.wms_customer_firstname) {
        values['wms_customer_description'] =
          `${values.wms_customer_firstname},${values.wms_customer_middlename ? values.wms_customer_middlename : ''},${values.wms_customer_lastname}`;
      }
      delete values['account_no']
      this.props.create(values)
    } else if (customerId !== null) {
      this.setState({ error: "Customer data can't be modified." })
    }
  }

  toggle() {
    this.setState({ taxDetails: !this.state.taxDetails })
  }

  markMandatory(data, event) {
    if (event.target.name === "wms_customer_name" && data.length > 0) {
      this.setState({ isCompanyRequired: true })
      this.setState({ isNameRequired: false })
    }
    if ((event.target.name === 'wms_customer_lastname' || event.target.name === 'wms_customer_firstname') && data.length > 0) {
      this.setState({ isNameRequired: true })
      this.setState({ isCompanyRequired: false })
    }
    if (data.length === 0) {
      this.setState({ isCompanyRequired: true })
      this.setState({ isNameRequired: true })
    }
  }

  render() {
    const { error, isNameRequired, isCompanyRequired } = this.state
    const { countries, handleSubmit, province, barangay, zip, city, close, dropDownonSelect, errorMsg, t } = this.props;
    return (
      <div className="new-shipper-modal">
        <span><strong>{t('newShipper:Shipper')}</strong></span>
        {errorMsg && <span className='error-msg'>{errorMsg}</span>}
        {error && <span className='error-msg'>{error}</span>}
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={8}>
                <Field name="kyc_no" autoFocus component={InputField} label={t('newShipper:kyc_no')} />
                <Field name="account_no" component={InputField} label={t('newShipper:account_no')} readOnly={true} />
                <Field name="wms_customer_name" component={InputField} label={t('newShipper:wms_customer_name')} required={isCompanyRequired} onchange={this.markMandatory} />
                <Field name="wms_customer_lastname" component={InputField} label={t('newShipper:wms_customer_lastname')} required={isNameRequired} onchange={this.markMandatory} />
                <Field name="wms_customer_firstname" component={InputField} label={t('newShipper:wms_customer_firstname')} required={isNameRequired} onchange={this.markMandatory} />
                <Field name="wms_customer_middlename" component={InputField} label={t('newShipper:wms_customer_middlename')} />
                <Field name="wms_customer_address1" component={InputField} label={t('newShipper:wms_customer_address1')} required={true} />
                <Field name="wms_customer_country" component={Dropdown} label={t('newShipper:wms_customer_country')} options={countries}
                  handleOnSelect={dropDownonSelect} childName='province' required={true} />
              </Grid.Column>
              <Grid.Column width={8}>
                <Field name="wms_customer_state" component={Dropdown} label={t('newShipper:wms_customer_state')} options={province}
                  handleOnSelect={dropDownonSelect} childName='city' required={true} />
                <Field name="wms_customer_city" component={Dropdown} label={t('newShipper:wms_customer_city')} options={city}
                  handleOnSelect={dropDownonSelect} childName='barangay' required={true} />
                <Field name="wms_customer_suburb" component={Dropdown} label={t('newShipper:wms_customer_suburb')} options={barangay}
                  handleOnSelect={dropDownonSelect} childName='zip' required={true} />
                <Field name="wms_customer_postal_code" component={Dropdown} label={t('newShipper:wms_customer_postal_code')} options={zip}
                  required={true} />
                <Field name="wms_customer_phone1" component={PhoneInputField} label={t('newShipper:wms_customer_phone1')} required={true} />
                <Field name="wms_customer_phone2" component={PhoneInputField} label={t('newShipper:wms_customer_phone2')} />
                <Field name="wms_customer_email" component={InputField} label={t('newShipper:wms_customer_email')} />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="tax-wrapper">
              <Grid.Column width={16}>
                <ShipperTaxDetails close={this.toggle} {...this.props} />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={8}>
              </Grid.Column>
              <Grid.Column width={8}>
                <div className="input_field" >
                  <label></label>
                  <div className="input_holder actions">
                    <button className="secondary" type="button" onClick={() => { close('shipper') }}>{t('newShipper:Cancel')}</button>
                    <button className="primary" type="submit" id='new_shipper_save_btn'>{t('newShipper:Save')}</button>
                  </div>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    )
  }
}

NewShipper.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  countries: PropTypes.array.isRequired,
  province: PropTypes.array.isRequired,
  city: PropTypes.array.isRequired,
  barangay: PropTypes.array.isRequired,
  close: PropTypes.func.isRequired,
  dropDownonSelect: PropTypes.func.isRequired,
  errorMsg: PropTypes.string,
  isLoading: PropTypes.bool.isRequired,
  isSuccess: PropTypes.bool.isRequired,
  shipper: PropTypes.object
}

NewShipper = reduxForm({
  form: 'NewShipperForm',
  validate
})(NewShipper);

const mapDispatchToProps = (dispatch) => ({
  create: (data) => dispatch(shipperActions.create(data))
})

const mapStateToProps = state => ({
  countries: state.masterReducer.options.countries,
  errorMsg: state.shipperReducer.message,
  isLoading: state.shipperReducer.isLoading,
  isSuccess: state.shipperReducer.isSuccess,
  shipper: state.shipperReducer.currentShipper,
  formValues: state.form.NewShipperForm,
})

export default compose(withTranslation('newShipper'), connect(mapStateToProps, mapDispatchToProps))(NewShipper)
