import { buildError, buildPhoneNoValid } from 'lib/errorHelper'
import _ from 'lodash'
import i18n from 'i18n';
import moment from 'moment';

export default function validate(values) {
  const errors = {};

  // tms_br_booking_request_hdr
  const bookingTableErrors = {
    br_customer_id: i18n.t('custValidation:br_customer_id'),
    br_service_type: i18n.t('custValidation:br_service_type'),
    br_sub_service_type: i18n.t('custValidation:br_sub_service_type'),
    br_payment_type: i18n.t('custValidation:br_payment_type')
  }

  // tms_brsd_shipment_details
  const shippingTableErrors = {
    brsd_from_address_line1: i18n.t('custValidation:brsd_from_address_line1'),
    brsd_from_country: i18n.t('custValidation:brsd_from_country'),
    brsd_from_state: i18n.t('custValidation:brsd_from_state'),
    brsd_from_city: i18n.t('custValidation:brsd_from_city'),
    brsd_from_suburb: i18n.t('custValidation:brsd_from_suburb'),
    brsd_from_postal_code: i18n.t('custValidation:brsd_from_postal_code'),
    brsd_from_primary_phone: i18n.t('custValidation:brsd_from_primary_phone'),
    brsd_to_address_line1: i18n.t('custValidation:brsd_to_address_line1'),
    brsd_to_country: i18n.t('custValidation:brsd_to_country'),
    brsd_to_state: i18n.t('custValidation:brsd_to_state'),
    brsd_to_city: i18n.t('custValidation:brsd_to_city'),
    brsd_to_suburb: i18n.t('custValidation:brsd_to_suburb'),
    brsd_to_postal_code: i18n.t('custValidation:brsd_to_postal_code'),
    brsd_to_primary_phone: i18n.t('custValidation:brsd_to_primary_phone')
  }


  const shippingPhoneValid = {
    brsd_from_secondary_phone: i18n.t('custValidation:brsd_from_secondary_phone'),
    brsd_to_secondary_phone: i18n.t('custValidation:brsd_to_secondary_phone'),
    brsd_alternate_to_primary_phone: i18n.t('custValidation:brsd_alternate_to_primary_phone')
  }

  //tms_brccd_consgt_consignee_details
  const consigneeTableErrors = {
    ccd_consignee_id: i18n.t('custValidation:ccd_consignee_id')
  }


  if (!values.tms_brsd_shipment_details) {
    let additionalErrors = shippingTableErrors
    additionalErrors.shipper_first_name = i18n.t('custValidation:shipper_first_name')
    additionalErrors.shipper_last_name = i18n.t('custValidation:shipper_last_name')
    additionalErrors.shipper_company_name = i18n.t('custValidation:shipper_company_name')
    errors.tms_brsd_shipment_details = additionalErrors
  } else {
    let hash = {}
    const shipmentDtl = values.tms_brsd_shipment_details
    if (!shipmentDtl.shipper_company_name && !shipmentDtl.shipper_first_name && !shipmentDtl.shipper_last_name) {
      hash['shipper_first_name'] = i18n.t('custValidation:shipper_first_name')
      hash['shipper_last_name'] = i18n.t('custValidation:shipper_last_name')
      hash['shipper_company_name'] = i18n.t('custValidation:shipper_company_name')
    } else if ((shipmentDtl.shipper_last_name && !shipmentDtl.shipper_first_name) || (shipmentDtl.shipper_first_name && !shipmentDtl.shipper_last_name)) {
      if (!shipmentDtl.shipper_first_name) {
        hash['shipper_first_name'] = i18n.t('custValidation:shipper_first_name')
      }
      if (!shipmentDtl.shipper_last_name) {
        hash['shipper_last_name'] = i18n.t('custValidation:shipper_last_name')
      }
    }
    if (shipmentDtl.brsd_from_picktime_slot_to && shipmentDtl.brsd_from_picktime_slot_from)
      if (moment(shipmentDtl.brsd_from_picktime_slot_to, 'HH:mm').format() < moment(shipmentDtl.brsd_from_picktime_slot_from, 'HH:mm').format()) {
        hash['brsd_from_picktime_slot_to'] = i18n.t('custValidation:brsd_from_picktime_slot_to')
      }
    let groupErrors = _.merge(buildError(shippingTableErrors, values, 'tms_brsd_shipment_details'), hash)
    groupErrors = _.merge(groupErrors, buildPhoneNoValid(shippingPhoneValid, values))
    errors.tms_brsd_shipment_details = groupErrors
  }

  if (!values.tms_brccd_consgt_consignee_details) {
    let additionalErrors = consigneeTableErrors
    additionalErrors.consignee_company_name = i18n.t('custValidation:consignee_company_name')
    additionalErrors.consignee_first_name = i18n.t('custValidation:consignee_first_name')
    additionalErrors.consignee_last_name = i18n.t('custValidation:consignee_last_name')
    errors.tms_brccd_consgt_consignee_details = additionalErrors
  } else {
    let hash = {}
    const consigneeDtl = values.tms_brccd_consgt_consignee_details
    if (!consigneeDtl.consignee_company_name && !consigneeDtl.consignee_first_name && !consigneeDtl.consignee_last_name) {
      hash['consignee_company_name'] = i18n.t('custValidation:consignee_company_name')
      hash['consignee_first_name'] = i18n.t('custValidation:consignee_first_name')
      hash['consignee_last_name'] = i18n.t('custValidation:consignee_last_name')
    } else if ((!consigneeDtl.consignee_first_name && consigneeDtl.consignee_last_name) || (consigneeDtl.consignee_first_name && !consigneeDtl.consignee_last_name)) {
      if (!consigneeDtl.consignee_first_name) {
        hash['consignee_first_name'] = i18n.t('custValidation:consignee_first_name')
      }
      if (!consigneeDtl.consignee_last_name) {
        hash['consignee_last_name'] = i18n.t('custValidation:consignee_last_name')
      }
    }
    errors.tms_brccd_consgt_consignee_details = _.merge(buildError(consigneeTableErrors, values, 'tms_brccd_consgt_consignee_details'), hash)
  }

  if (!values.tms_br_booking_request_hdr) {
    errors.tms_br_booking_request_hdr = bookingTableErrors
  } else {
    errors.tms_br_booking_request_hdr = buildError(bookingTableErrors, values, 'tms_br_booking_request_hdr')
  }

  return errors;
}
