import React, { Component } from 'react'
import { Grid } from 'semantic-ui-react';
import { Field } from "redux-form";
import InputField from 'components/Common/InputField';
import InputSearchField from 'components/Common/InputSearchField';
import Dropdown from 'components/Common/Dropdown';
import PhoneInputField from 'components/Common/PhoneInput';
import BookingTaxDetails from './BookingTaxDetails';
import Popup from 'components/Common/Popup';

export default class ShippingFields extends Component {

  render() {
    const { options, shipper, shipperFirstName, shipperLastName, shipperNameRequired, shipperCompanyRequired, shipFromReadOnly, fillNameValues, findByCompanyAndFLMName, optionHash, open, close, handleClick, handleOnSelect, recurring, t, isRetail } = this.props
    return (
      <Grid.Column width={8} className="shipper-field">
        <span><h3>Shipper</h3></span>
        <Field name="tms_br_booking_request_hdr.br_customer_id" component={InputField} label={t('customer:accountNo')} readOnly={true} required={true} />

        <Field name="tms_brsd_shipment_details.shipper_company_name" autoFocus={true} tabindex={1} options={shipper}
          fillNameValues={fillNameValues}
          findByCompanyAndFLMName={findByCompanyAndFLMName} component={InputSearchField}
          label={t('customer:companyName')} id="shipper" required={shipperCompanyRequired} />

        <Field name="tms_brsd_shipment_details.shipper_last_name" options={shipperLastName}
          fillNameValues={fillNameValues}
          findByCompanyAndFLMName={findByCompanyAndFLMName} component={InputSearchField}
          label={t('customer:lastName')} required={shipperNameRequired} id="shipper_last_name" />

        <Field name="tms_brsd_shipment_details.shipper_first_name" component={InputSearchField}
          label={t('customer:firstName')} required={shipperNameRequired} options={shipperFirstName}
          fillNameValues={fillNameValues} id="shipper_first_name"
          findByCompanyAndFLMName={findByCompanyAndFLMName} />

        <Field name="tms_brsd_shipment_details.shipper_middle_name" component={InputField} label={t('customer:middleName')} />

        <Field id="brsd_from_ship_point_id" name="tms_brsd_shipment_details.brsd_from_ship_point_id" component={InputField} label={t('customer:shipfromID')} iconName={isRetail ? '' : 'search'} handleClick={handleClick} childName='brsd_from' readOnly={shipFromReadOnly} />

        <Field name="tms_brsd_shipment_details.brsd_from_address_line1" component={InputField}
          label={t('customer:address')} readOnly={shipFromReadOnly} required={true} />

        <Field name="tms_brsd_shipment_details.brsd_from_country" component={Dropdown} label={t('customer:country')}
          readOnly={shipFromReadOnly} required={true} options={options.countries}
          {...optionHash} childName='shipper_province' handleOnSelect={handleOnSelect} />

        <Field name="tms_brsd_shipment_details.brsd_from_state" component={Dropdown}
          label={t('customer:province')} readOnly={shipFromReadOnly} required={true} options={options.shipper_province}
          {...optionHash} childName='shipper_city' handleOnSelect={handleOnSelect} />

        <Field name="tms_brsd_shipment_details.brsd_from_city" component={Dropdown} label={t('customer:city')} options={options.shipper_city}
          {...optionHash} readOnly={shipFromReadOnly} required={true} childName='shipper_barangay' handleOnSelect={handleOnSelect} />

        <Field name="tms_brsd_shipment_details.brsd_from_suburb" readOnly={shipFromReadOnly} component={Dropdown}
          label={t('customer:suburb')} options={options.shipper_barangay} required={true} {...optionHash} handleOnSelect={handleOnSelect} childName='shipper_zip' />

        <Field name="tms_brsd_shipment_details.brsd_from_postal_code" readOnly={shipFromReadOnly} component={Dropdown}
          label={t('customer:postalCode')} required={true} options={options.shipper_zip} />

        <Field name="tms_brsd_shipment_details.brsd_from_landmark" component={InputField} label={t('customer:landmark')} />

        <Field name="tms_brsd_shipment_details.brsd_from_primary_phone" component={PhoneInputField} label={t('customer:mobileNo')} required={true} />

        <Field name="tms_brsd_shipment_details.brsd_from_secondary_phone" component={PhoneInputField} label={t('customer:contactNo')} />
        <Field name="tms_brsd_shipment_details.brsd_from_email_id" component={InputField} label={t('customer:emailAdd')} />

        {recurring === 'N' && <div className="tax-details-link">
          <Popup size="fullscreen" open={open} close={() => { close('taxDetails') }}
            trigger={<button type="button" className="link-button" onClick={() => { close('taxDetails') }}>{t('customer:taxDetails')}</button>} header={t('customer:taxDetails')} description={<BookingTaxDetails close={close} />} />
        </div>}
      </Grid.Column>
    )
  }
}
