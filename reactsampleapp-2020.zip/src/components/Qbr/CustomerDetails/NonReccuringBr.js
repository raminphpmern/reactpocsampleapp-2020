import React, { Component } from 'react'
import { Field } from "redux-form";
import InputField from 'components/Common/InputField';
import InputSearchField from 'components/Common/InputSearchField';
import DateTimePicker from 'components/Common/DateTimePicker';
import Dropdown from 'components/Common/Dropdown';
import { Grid } from 'semantic-ui-react';
import CustomRadioFiled from "components/Common/CustomRadio";
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import { getValue } from "lib/LocalStorage";
import { AlertError } from 'lib/Alert';

class NonReccuringBr extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentBranch: {},
      sericeCutOff: null
    };
    this.handleOnSelect = this.handleOnSelect.bind(this)
  }

  componentDidMount() {
    const localStrBranch = getValue("currentBranch") || '{}';
    this.setState({ currentBranch: JSON.parse(localStrBranch) });

    let arr = ['booking_no', 'dispatch_doc_no', 'customer_ref_no']
    arr.forEach((elemId) => {
      let node = document.getElementById(elemId)
      node && node.addEventListener('keypress', (event) => {
        if (event.keyCode === 13) {
          let bookingNo = null
          let customer_id = null
          let queryString = `type=${elemId}`
          let values = this.props.formValues && this.props.formValues.values
          if (elemId === 'booking_no')
            bookingNo = values && values.tms_br_booking_request_hdr && values.tms_br_booking_request_hdr.br_request_id
          if (elemId === 'dispatch_doc_no')
            bookingNo = values && values.tms_ddh_dispatch_document_hdr && values.tms_ddh_dispatch_document_hdr.ddh_dispatch_doc_no
          if (elemId === 'customer_ref_no') {
            if (values && values.tms_br_booking_request_hdr) {
              bookingNo = values.tms_br_booking_request_hdr.br_customer_ref_no
              customer_id = values.tms_br_booking_request_hdr.br_customer_id
              queryString = queryString + `&br_customer_id=${customer_id}`
            }
          }
          if (bookingNo && elemId !== 'customer_ref_no')
            this.props.getBooking(bookingNo, queryString);

          if (bookingNo && elemId === 'customer_ref_no' && customer_id) {
            this.props.getBooking(bookingNo, queryString);
          } else if (elemId === 'customer_ref_no') {
            AlertError('Customer Id is required.')
          }
          event.preventDefault()
        }
      })
    })
  }

  handleOnSelect(data) {
    if (data.wms_loc_cutoff_time) {
      this.setState({ sericeCutOff: data.wms_loc_cutoff_time })
    } else {
      this.setState({ sericeCutOff: null })
    }
  }


  render() {
    const { currentBooking, shipFromReadOnly, shipment_type, service_mode, changeRecurring, handleClick, t, shipper, fillNameValues, findByCompanyAndFLMName } = this.props
    const { currentBranch, sericeCutOff } = this.state
    return (
      <Grid stackable className="ash-background">
        <Grid.Row className="">
          <Grid.Column width={16}>
            <div className='booking-header-title'>
              <div>
                <h3>{t('nonReccuringBr:bookingDtl')}</h3></div>
              <div>
                {currentBranch.isOperationDtlConfigured === false ? <span className='error_message'>(Operation Days is not configured for this location)</span> : null}
              </div>
            </div>
          </Grid.Column>
        </Grid.Row>
        <Grid.Row className="no-padding">
          <Grid.Column width={4}>
            <Field id="booking_no" name="tms_br_booking_request_hdr.br_request_id" component={InputField} label={t('nonReccuringBr:br_request_id')} iconName="copy" handleClick={handleClick} />
            <Field name="customer_company_name" options={shipper}
              fillNameValues={fillNameValues}
              findByCompanyAndFLMName={findByCompanyAndFLMName} component={InputSearchField} label={t('customer:companyName')} id="shipper_company_name" />
            <Field name="tms_br_booking_request_hdr.br_service_type" component={Dropdown} label={t('nonReccuringBr:br_service_type')} options={shipment_type} required={true} handleOnSelect={this.handleOnSelect} />
            <Field name="tms_br_booking_request_hdr.br_sub_service_type" component={Dropdown} label={t('nonReccuringBr:br_sub_service_type')} options={service_mode} required={true} />
          </Grid.Column>
          <Grid.Column width={4}>
            <Field id="dispatch_doc_no" name="tms_ddh_dispatch_document_hdr.ddh_dispatch_doc_no" component={InputField} label={t('nonReccuringBr:ddh_dispatch_doc_no')} />
            <Field id="customer_ref_no" name="tms_br_booking_request_hdr.br_customer_ref_no" component={InputField} label={t('nonReccuringBr:br_customer_ref_no')} />
            <Field name="tms_brsd_shipment_details.brsd_from_pick_date" component={DateTimePicker} label={t('nonReccuringBr:brsd_from_pick_date')} readOnly={false} />
            <Field name="tms_brsd_shipment_details.brsd_to_delivery_date" component={DateTimePicker} label={t('nonReccuringBr:brsd_to_delivery_date')} readOnly={false} />
          </Grid.Column>
          <Grid.Column width={4}>
            <Field name="tms_br_booking_request_hdr.br_requested_date" component={DateTimePicker} label={t('nonReccuringBr:br_requested_date')} readOnly={shipFromReadOnly} />
            <Field name="tms_brsd_shipment_details.brsd_from_picktime_slot_from" component={InputField} type="time" min="09:00" max="18:00" label={t('nonReccuringBr:brsd_from_picktime_slot_from')} />
            <Field name="tms_brsd_shipment_details.brsd_to_deliverytime_slot_from" component={InputField} type="time" min="09:00" max="18:00" label={t('nonReccuringBr:brsd_to_deliverytime_slot_from')} />
            <Field name="tms_br_booking_request_hdr.br_pickupreceiptno" component={InputField} label={t('orderDetail:PurNO')} />
          </Grid.Column>
          <Grid.Column width={4}>
            <div className="input_field">
              <label>{t('nonReccuringBr:br_recurring')}</label>
              <div className="input_holder">
                <div className="radio">
                  <Field name="tms_br_booking_request_hdr.br_recurring_flag" disabled={!!currentBooking} onChange={() => changeRecurring('Y')} htmlFor="radio1" value="Y" label={t('nonReccuringBr:flag_yes')} type="radio" component={CustomRadioFiled} />
                  <Field name="tms_br_booking_request_hdr.br_recurring_flag" checked={!!currentBooking} onChange={() => changeRecurring('N')} htmlFor="radio2" value="N" label={t('nonReccuringBr:flag_no')} type="radio" component={CustomRadioFiled} />
                </div>
              </div>
            </div>
            <Field name="tms_brsd_shipment_details.brsd_from_picktime_slot_to" component={InputField} type="time" min="09:00" max="18:00" label={t('nonReccuringBr:brsd_from_picktime_slot_to')} />
            <Field name="tms_brsd_shipment_details.brsd_to_deliverytime_slot_to" component={InputField} type="time" min="09:00" max="18:00" label={t('nonReccuringBr:brsd_to_deliverytime_slot_to')} />
            <p className="cut-off-text">Booking Location Cut Off Time is <strong>{sericeCutOff ? sericeCutOff : currentBranch.wms_loc_cutoff_time}</strong></p>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    )
  }
}

export default compose(withTranslation('nonReccuringBr'))(NonReccuringBr)