import React, { Component } from 'react'
import { reduxForm } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { fetchConsignee, initializeCON } from "actions/consigneeAction";
import DataGrid from 'components/Common/DataGrid';
import { AlertError } from 'lib/Alert'

const columns = [
  { key: "wms_consignee_id", name: 'Id' },
  { key: "wms_consignee_desc", name: 'Name' },
  { key: "wms_consignee_country", name: 'Country' },
  { key: "wms_consignee_city", name: 'City' },
  { key: "wms_consignee_state", name: 'Province' },
  { key: "wms_consignee_suburb", name: 'Barangay' },
  { key: "wms_consignee_postalcode", name: 'Zip Code' },
  { key: "wms_consignee_phone1", name: 'Phone 1' },
  { key: "wms_consignee_email", name: 'Email' },
  { key: "wms_consignee_address1", name: 'Address 1' }
];

class LatestConsignee extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRecord: null,
      defaultValues: null,
      error: '',
      page: 1
    };
    this.paginationHandler = this.paginationHandler.bind(this);
    this.selectedRows = this.selectedRows.bind(this);
    this.changeLimit = this.changeLimit.bind(this);
    this.getConsigneeDetails = this.getConsigneeDetails.bind(this);
  }

  componentDidMount() {
    const { formValues } = this.props
    if (formValues && formValues.values && formValues.values.tms_br_booking_request_hdr && formValues.values.tms_br_booking_request_hdr.br_customer_id) {
      this.props.fetchConsignee(`br_customer_id=${formValues.values.tms_br_booking_request_hdr.br_customer_id}`, 1);
    } else {
      AlertError('Please select customer.')
    }
  }

  selectedRows(values) {
    this.setState({ selectedRecord: values[0] })
  }

  changeLimit(pageNo, limit) {
    this.props.fetchConsignee(pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.fetchConsignee(pageNo, limit);
  }

  getConsigneeDetails() {
    const { selectedRecord } = this.state
    const { close } = this.props
    if (selectedRecord !== null) {
      this.props.setConsigneeDetails(selectedRecord)
      close('help', 'latestConsignee')
    }
  }

  render() {
    const { defaultValues, selectedRecord } = this.state
    const { result, totalPage, totalRecord, initializeCON } = this.props
    const disabled = selectedRecord === null
    return (
      <div>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={columns}
                rows={result}
                totalPages={totalPage}
                width={150}
                paginationHandler={this.paginationHandler}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                defaultValues={defaultValues}
                totalRecord={totalRecord}
                enableExport={true}
                singleSelect={true}
                initialize={initializeCON}
                hideLimit={true}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='details' onClick={this.getConsigneeDetails} type="button" className="primary" disabled={disabled}>
                  Get Details
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

LatestConsignee = reduxForm({
  form: 'LatestConsignee'
})(LatestConsignee);

const mapStateToProps = state => ({
  formValues: state.form.LatestConsignee,
  isRequested: state.consigneeReducer.isRequested,
  result: state.consigneeReducer.consigneeResult,
  totalPage: state.consigneeReducer.totalPage,
  totalRecord: state.consigneeReducer.totalRecord,
  formValues: state.form.CustomerDetailsForm,
})

const mapDispatchToProps = (dispatch) => ({
  fetchConsignee: (pageNo, limit) => dispatch(fetchConsignee(pageNo, limit)),
  initializeCON: () => dispatch(initializeCON())
})

export default connect(mapStateToProps, mapDispatchToProps)(LatestConsignee)
