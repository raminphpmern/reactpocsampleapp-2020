import React, { Component } from 'react'
import { Grid } from 'semantic-ui-react';
import { Field } from "redux-form";
import InputField from 'components/Common/InputField';
import InputSearchField from 'components/Common/InputSearchField';
import Dropdown from 'components/Common/Dropdown';
import PhoneInputField from 'components/Common/PhoneInput';
import Popup from 'components/Common/Popup';
import LatestConsignee from './LatestConsignee';

export default class ConsigneeFields extends Component {
  constructor(props) {
    super(props);
    this.state = {
      latestConsignee: false,
      currentHelp: ''
    }
    this.toggle = this.toggle.bind(this);
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  render() {
    const { options, consignee, consigneeLastName, consigneeFirstName, handleOnSelect, consigneeNameRequired, consigneeCompanyRequired, fillNameValues, findByCompanyAndFLMName, handleClick, formValues, t, isRequested } = this.props
    const { latestConsignee, currentHelp, } = this.state

    let values = formValues && formValues.values
    let defaultCountry = values && values.tms_brsd_shipment_details && values.tms_brsd_shipment_details.brsd_to_country ? values.tms_brsd_shipment_details.brsd_to_country.label : ''
    let tms_brccd_consgt_consignee_details = values && values.tms_brccd_consgt_consignee_details
    let isCompanyName = tms_brccd_consgt_consignee_details && tms_brccd_consgt_consignee_details.consignee_company_name ? true : false
    let firstLastMiddle = (tms_brccd_consgt_consignee_details && tms_brccd_consgt_consignee_details.consignee_last_name) || (tms_brccd_consgt_consignee_details && tms_brccd_consgt_consignee_details.consignee_first_name) || (tms_brccd_consgt_consignee_details && tms_brccd_consgt_consignee_details.consignee_middle_name)
    return (
      <Grid.Column width={8} className="consignee-field">
        <Popup size="fullscreen" open={latestConsignee} close={() => { this.toggle('help', 'latestConsignee') }} header="Consignee" description={<LatestConsignee setConsigneeDetails={this.props.setConsigneeDetails} close={this.toggle} name={currentHelp} />}
        />
        <span><h3>Consignee</h3></span>
        <Field name="tms_brccd_consgt_consignee_details.ccd_consignee_id" component={InputField} label={t('customer:accountNo')} readOnly={true} required={true} />

        <Field readOnly={firstLastMiddle} name="tms_brccd_consgt_consignee_details.consignee_company_name" component={InputSearchField}
          label={t('customer:companyName')} id="consignee" required={consigneeCompanyRequired} options={consignee}
          fillNameValues={fillNameValues}
          findByCompanyAndFLMName={findByCompanyAndFLMName}
          iconName="users" handleClick={this.toggle} childName='latestConsignee' />

        <Field readOnly={isCompanyName} name="tms_brccd_consgt_consignee_details.consignee_last_name" component={InputSearchField}
          label={t('customer:lastName')} required={consigneeNameRequired} id="consignee_last_name" options={consigneeLastName}
          fillNameValues={fillNameValues}
          findByCompanyAndFLMName={findByCompanyAndFLMName} />

        <Field readOnly={isCompanyName} name="tms_brccd_consgt_consignee_details.consignee_first_name" component={InputSearchField}
          label={t('customer:firstName')} required={consigneeNameRequired} id="consignee_first_name" options={consigneeFirstName}
          fillNameValues={fillNameValues}
          findByCompanyAndFLMName={findByCompanyAndFLMName} />

        <Field readOnly={isCompanyName} name="tms_brccd_consgt_consignee_details.consignee_middle_name" component={InputField} label={t('customer:middleName')} />

        <Field id="brsd_to_ship_point_id" name="tms_brsd_shipment_details.brsd_to_ship_point_id" component={InputField} label={t('customer:shipToID')} iconName="search" handleClick={handleClick} childName='brsd_to' />

        <Field name="tms_brsd_shipment_details.brsd_to_address_line1" component={InputField}
          label={t('customer:address')} required={true} />
        <Field name="tms_brsd_shipment_details.brsd_to_country" component={Dropdown}
          label={t('customer:country')} required={true} options={options.countries}
          handleOnSelect={handleOnSelect} childName='province' />
        <Field name="tms_brsd_shipment_details.brsd_to_state" component={Dropdown} options={options.province}
          label={t('customer:province')} required={true} handleOnSelect={handleOnSelect} childName='city' />
        <Field name="tms_brsd_shipment_details.brsd_to_city" component={Dropdown} options={options.city}
          label={t('customer:city')} required={true} handleOnSelect={handleOnSelect} childName='barangay' />
        <Field name="tms_brsd_shipment_details.brsd_to_suburb" component={Dropdown}
          label={t('customer:suburb')} options={options.barangay} required={true} handleOnSelect={handleOnSelect} childName='zip' />
        <Field name="tms_brsd_shipment_details.brsd_to_postal_code" component={Dropdown}
          label={t('customer:postalCode')} options={options.zip} required={true} />
        <Field name="tms_brsd_shipment_details.brsd_to_landmark" component={InputField} label={t('customer:landmark')} />
        <Field name="tms_brsd_shipment_details.brsd_to_primary_phone" countryCode={defaultCountry} component={PhoneInputField}
          label={t('customer:mobileNo')} required={true} />
        <Field name="tms_brsd_shipment_details.brsd_to_secondary_phone" countryCode={defaultCountry} component={PhoneInputField}
          label={t('customer:contactNo')} />
        <Field name="tms_brsd_shipment_details.brsd_to_email_id" component={InputField} label={t('customer:emailAdd')} />
        <Field name="tms_brsd_shipment_details.brsd_alternate_to_contact_person" component={InputField}
          label={t('customer:altContactPerson')} />
        <Field name="tms_brsd_shipment_details.brsd_alternate_to_primary_phone" countryCode={defaultCountry} component={PhoneInputField}
          label={t('customer:contactNo')} />
        <div className="input_field">
          <label></label>
          <div className="input_holder">
            <button disabled={isRequested} className="primary btn-full-width top-margin" type="submit">{t('customer:next')}</button>
          </div>
        </div>
      </Grid.Column>
    )
  }
}
