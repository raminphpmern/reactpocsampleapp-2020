import { isValidPhoneNumber } from 'react-phone-number-input'
import i18n from 'i18n';

export default function validate(values) {
  const errors = {};
  if (!values.wms_consignee_company_name)
    errors.wms_consignee_company_name = i18n.t('consigneeValidation:wms_consignee_company_name')

  if (!values.wms_consignee_lastname)
    errors.wms_consignee_lastname = i18n.t('consigneeValidation:wms_consignee_lastname')

  if (!values.wms_consignee_firstname)
    errors.wms_consignee_firstname = i18n.t('consigneeValidation:wms_consignee_firstname')

  if (values.wms_consignee_lastname || values.wms_consignee_firstname) {
    errors.wms_consignee_company_name = null
  }

  if (values.wms_consignee_company_name) {
    errors.wms_consignee_lastname = null
    errors.wms_consignee_firstname = null
  }

  if (!values.wms_consignee_address1)
    errors.wms_consignee_address1 = i18n.t('consigneeValidation:wms_consignee_address1')

  if (!values.wms_consignee_country)
    errors.wms_consignee_country = i18n.t('consigneeValidation:wms_consignee_country')

  if (!values.wms_consignee_state)
    errors.wms_consignee_state = i18n.t('consigneeValidation:wms_consignee_state')

  if (!values.wms_consignee_city)
    errors.wms_consignee_city = i18n.t('consigneeValidation:wms_consignee_city')

  if (!values.wms_consignee_suburb)
    errors.wms_consignee_suburb = i18n.t('consigneeValidation:wms_consignee_suburb')

  if (!values.wms_consignee_postalcode)
    errors.wms_consignee_postalcode = i18n.t('consigneeValidation:wms_consignee_postalcode')

  if (values.wms_consignee_phone1 && values.wms_consignee_phone1.length >= 4) {
    let phoneNo = isValidPhoneNumber(values.wms_consignee_phone1)
    if (phoneNo === false) {
      errors.wms_consignee_phone1 = i18n.t('consigneeValidation:wms_consignee_phone1')
    }
  }

  if (values.wms_consignee_phone2 && values.wms_consignee_phone2.length >= 4) {
    let phoneNo = isValidPhoneNumber(values.wms_consignee_phone2)
    if (phoneNo === false) {
      errors.wms_consignee_phone2 = i18n.t('consigneeValidation:wms_consignee_phone2')
    }
  }

  if (values.wms_consignee_email && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.wms_consignee_email)) {
    errors.wms_consignee_email = i18n.t('consigneeValidation:wms_consignee_email')
  }

  return errors
}
