import React, { Component } from 'react'
import { Field } from "redux-form";
import InputField from 'components/Common/InputField';
import DateTimePicker from 'components/Common/DateTimePicker';
import Dropdown from 'components/Common/Dropdown';
import { connect } from 'react-redux';
import { Grid } from 'semantic-ui-react';
import CustomRadioFiled from "components/Common/CustomRadio";
import Checkbox from 'components/Common/Checkbox';
import { getValue } from 'lib/LocalStorage';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class ReccuringBr extends Component {

  componentDidMount() {
    let node = document.getElementById('booking_no')
    node && node.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let values = this.props.formValues && this.props.formValues.values
        let bookingNo = values && values.tms_br_booking_request_hdr && values.tms_br_booking_request_hdr.br_request_id
        if (bookingNo)
          this.props.getBooking(bookingNo);
        event.preventDefault()
      }
    })
  }

  render() {
    const { currentBooking, shipment_type, service_mode, payment_type, changeRecurring, handleClick, t } = this.props
    let currentBranch = getValue('currentBranch') ? JSON.parse(getValue('currentBranch')) : {}
    const location = currentBranch && currentBranch.wms_loc_code
    let recurring = false
    if (location && location.toLowerCase().includes('ccm')) {
      recurring = true
    }
    return (
      <Grid stackable className="ash-background">
        <Grid.Row>
          <Grid.Column width={16}>
            <div className='booking-header-title'>
              <div>
                <h3>{t('nonReccuringBr:bookingDtl')}</h3></div>
              <div>
                {currentBranch.isOperationDtlConfigured === false ? <span className='error_message'>(Operation Days is not configured for this location)</span> : null}
              </div>
            </div>
          </Grid.Column>
        </Grid.Row>
        <Grid.Row className="no-padding">
          <Grid.Column width={4}>
            <Field id="booking_no" name="tms_br_booking_request_hdr.br_request_id" component={InputField} label={t('reccuringBr:br_request_id')} iconName="copy" handleClick={handleClick} />
            <Field name="tms_br_booking_request_hdr.br_service_type" component={Dropdown} label={t('reccuringBr:br_service_type')} options={shipment_type} required={true} />
            <Field name="tms_br_booking_request_hdr.br_sub_service_type" component={Dropdown} label={t('reccuringBr:br_sub_service_type')} options={service_mode} required={true} />
            <Field name="tms_br_booking_request_hdr.br_payment_type" component={Dropdown} label={t('reccuringBr:br_payment_type')} options={payment_type} required={true} />
          </Grid.Column>
          <Grid.Column width={4}>
            <div className="input_field">
              <label></label>
              <div className="input_holder">
                {!currentBooking && <span className='search-status'>Status</span>}
                {currentBooking && <span className='search-status'>{currentBooking.tms_br_booking_request_hdr.br_status}</span>}
              </div>
            </div>
            <div className="empty-space"></div>
            <Field name="tms_brsd_shipment_details.brsd_from_picktime_slot_from" component={InputField} type="time" min="09:00" max="18:00" label={t('reccuringBr:brsd_from_picktime_slot_from')} />
            <Field name="tms_brrd_br_recurring_details.brrd_recurring_from_date" component={DateTimePicker} label={t('reccuringBr:brrd_recurring_from_date')} readOnly={false} />
          </Grid.Column>
          <Grid.Column width={4}>
            <Field name="tms_br_booking_request_hdr.br_requested_date" component={DateTimePicker} label={t('reccuringBr:br_requested_date')} readOnly={false} />
            <Field name="tms_brsd_shipment_details.brsd_from_pick_date" component={DateTimePicker} label={t('reccuringBr:brsd_from_pick_date')} readOnly={false} />
            <Field name="tms_brsd_shipment_details.brsd_from_picktime_slot_to" component={InputField} type="time" min="09:00" max="18:00" label={t('reccuringBr:brsd_from_picktime_slot_to')} />
            <Field name="tms_brrd_br_recurring_details.brrd_recurring_to_date" component={DateTimePicker} label={t('reccuringBr:brrd_recurring_to_date')} readOnly={false} />
          </Grid.Column>
          <Grid.Column width={3}>
            <div className="input_field">
              <label>{t('reccuringBr:title')}</label>
              <div className="input_holder">
                <div className="radio">
                  <Field name="tms_br_booking_request_hdr.br_recurring_flag" checked={!!currentBooking} onChange={() => changeRecurring('Y')} htmlFor="radio1" value="Y" label={t('reccuringBr:yes')} type="radio" component={CustomRadioFiled} />
                  <Field name="tms_br_booking_request_hdr.br_recurring_flag" onChange={() => changeRecurring('N')} htmlFor="radio2" value="N" label={t('reccuringBr:no')} type="radio" disabled={!!currentBooking || recurring} component={CustomRadioFiled} />
                </div>
              </div>
            </div>
          </Grid.Column>
        </Grid.Row>
        <Grid.Row className="padding-bottom">
          <Grid.Column width={5}></Grid.Column>
          <Grid.Column width={8}>
            <div className="group-chk-bx">
              <Field name="tms_brrd_br_recurring_details.brrd_monday" component={Checkbox} type="checkbox" label="M" htmlFor="Monday" />
              <Field name="tms_brrd_br_recurring_details.brrd_tuesday" component={Checkbox} type="checkbox" label="T" htmlFor="Monday" />
              <Field name="tms_brrd_br_recurring_details.brrd_wednesday" component={Checkbox} type="checkbox" label="W" htmlFor="Monday" />
              <Field name="tms_brrd_br_recurring_details.brrd_thursday" component={Checkbox} type="checkbox" label="Th" htmlFor="Monday" />
              <Field name="tms_brrd_br_recurring_details.brrd_friday" component={Checkbox} type="checkbox" label="F" htmlFor="Monday" />
              <Field name="tms_brrd_br_recurring_details.brrd_saturday" component={Checkbox} type="checkbox" label="S" htmlFor="Monday" />
              <Field name="tms_brrd_br_recurring_details.brrd_sunday" component={Checkbox} type="checkbox" label="Su" htmlFor="Monday" />
            </div>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
})

const mapStateToProps = state => ({
})

export default compose(withTranslation('ReccuringBr'), connect(mapStateToProps, mapDispatchToProps))(ReccuringBr)