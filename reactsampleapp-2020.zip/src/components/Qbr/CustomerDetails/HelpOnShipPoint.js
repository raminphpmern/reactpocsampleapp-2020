import React, { Component } from 'react'
import { reduxForm, Field } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import Dropdown from 'components/Common/Dropdown';
import InputField from 'components/Common/InputField';
import * as masterActions from 'actions/masterAction';
import DataGrid from 'components/Common/DataGrid';
import _ from 'lodash';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import i18n from 'i18n';

const optionFields = ['country', 'state', 'city', 'suburb_code', 'zipcode', 'zone', 'sub_zone', 'days']
const weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
const weekDaysOption = _.reduce(weekDays, (options, day) => {
  let valueTxt = `loc${day.substring(0, 3)}`
  options.push({ value: valueTxt, label: day })
  return options
}, [])

const validate = values => {
  const errors = {};

  if (Object.entries(values).length === 0) {
    errors.wms_shp_pt_country = i18n.t('helpOnShipPoint:wms_shp_pt_country')
    errors.wms_shp_pt_state = i18n.t('helpOnShipPoint:wms_shp_pt_state')
    errors.wms_shp_pt_city = i18n.t('helpOnShipPoint:wms_shp_pt_city')
    errors.wms_shp_pt_suburb_code = i18n.t('helpOnShipPoint:wms_shp_pt_suburb_code')
    errors.wms_shp_pt_zipcode = i18n.t('helpOnShipPoint:wms_shp_pt_zipcode')
    errors.wms_shp_pt_zone = i18n.t('helpOnShipPoint:wms_shp_pt_zone')
    errors.wms_shp_pt_sub_zone = i18n.t('helpOnShipPoint:wms_shp_pt_sub_zone')
    errors.working_day = i18n.t('helpOnShipPoint:working_day')
    errors.wms_shp_pt_from_time = i18n.t('helpOnShipPoint:wms_shp_pt_from_time')
    errors.wms_shp_pt_to_time = i18n.t('helpOnShipPoint:wms_shp_pt_to_time')
  }

  if (values.wms_shp_pt_from_time && !values.wms_shp_pt_to_time) {
    errors.wms_shp_pt_to_time = i18n.t('helpOnShipPoint:wms_shp_pt_to_time_required')
  }

  if (values.wms_shp_pt_to_time && !values.wms_shp_pt_from_time) {
    errors.wms_shp_pt_from_time = i18n.t('helpOnShipPoint:wms_shp_pt_from_time_required')
  }

  if (values.wms_shp_pt_to_time && values.wms_shp_pt_from_time) {
    if (values.wms_shp_pt_from_time > values.wms_shp_pt_to_time) {
      errors.wms_shp_pt_to_time = i18n.t('helpOnShipPoint:validatingTimeToFrom')
    }
  }

  return errors
}

const headers = [
  { key: "wms_shp_pt_id", name: i18n.t('helpOnShipPoint:wms_shp_pt_id') },
  { key: "wms_geo_country_desc", name: i18n.t('helpOnShipPoint:wms_geo_country_desc') },
  { key: "wms_geo_state_desc", name: i18n.t('helpOnShipPoint:wms_geo_state_desc') },
  { key: "wms_geo_city_desc", name: i18n.t('helpOnShipPoint:wms_geo_city_desc') },
  { key: "wms_geo_suburb_desc", name: i18n.t('helpOnShipPoint:wms_geo_suburb_desc') },
  { key: "wms_shp_pt_zipcode", name: i18n.t('helpOnShipPoint:zipcode') },
  { key: "wms_shp_pt_address1", name: i18n.t('helpOnShipPoint:wms_shp_pt_address1') },
]

class HelpOnShipPoint extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRecord: null,
      error: '',
      page: 1,
      pageLimit: 10,
    };

    this.search = this.search.bind(this)
    this.onSelectRow = this.onSelectRow.bind(this)
    this.loadShippingInfo = this.loadShippingInfo.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
  }

  componentDidMount() {
    if (this.props.zone.length === 0) {
      this.props.getZoneOptions('zone', '')
    }
  }

  formatFormValues(values) {
    let hash = _.cloneDeep(values)
    _.each(optionFields, (field) => {
      if (hash[`wms_shp_pt_${field}`]) {
        hash[`wms_shp_pt_${field}`] = hash[`wms_shp_pt_${field}`].value
      }
    })
    return hash
  }

  search(form) {
    const { searchShippingHelp } = this.props
    searchShippingHelp(this.formatFormValues(form.values), 1, this.state.pageLimit)
    this.setState({ error: '' })
    this.setState({ page: 1 })
  }

  onSelectRow(data) {
    this.setState({ selectedRecord: data[0] })
  }

  changeLimit(pageNo, limit) {
    const { searchShippingHelp, formValues } = this.props
    this.setState({ pageLimit: limit })
    if (formValues.values) {
      searchShippingHelp(this.formatFormValues(formValues.values), pageNo, limit)
    }
  }

  paginationHandler(pageNo) {
    const { searchShippingHelp, formValues } = this.props
    searchShippingHelp(this.formatFormValues(formValues.values), pageNo, this.state.pageLimit)
  }

  loadShippingInfo() {
    const { selectedRecord } = this.state
    const { name, close } = this.props
    if (selectedRecord !== null) {
      this.props.handleOnSelect(selectedRecord, name)
      close('help')
    }
  }

  componentWillUnmount() {
    this.props.inilailizeShipper()
  }

  render() {
    const { error, pageLimit } = this.state
    const { countries, province, city, barangay, zip, dropDownonSelect, handleSubmit, isSearching, zone, sub_zone, lastPage, shipperList, totalRecords, t } = this.props
    return (
      <form>
        <Grid stackable>
          {error && <span className='error-msg'>{error}</span>}
          <Grid.Row>
            <Grid.Column width={5}>
              <Field name="wms_shp_pt_country" component={Dropdown} clearable={true} label={t('helpOnShipPoint:country')} options={countries}
                handleOnSelect={dropDownonSelect} childName='province' />
              <Field name="wms_shp_pt_state" component={Dropdown} clearable={true} label={t('helpOnShipPoint:state')} options={province}
                handleOnSelect={dropDownonSelect} childName='city' />
              <Field name="wms_shp_pt_city" component={Dropdown} clearable={true} label={t('helpOnShipPoint:city')} options={city}
                handleOnSelect={dropDownonSelect} childName='barangay' />
              <Field name="wms_shp_pt_suburb_code" component={Dropdown} clearable={true} label={t('helpOnShipPoint:suburbCode')} options={barangay}
                handleOnSelect={dropDownonSelect} childName='zip' />
            </Grid.Column>
            <Grid.Column width={5}>
              <Field name="wms_shp_pt_zipcode" component={Dropdown} clearable={true} label={t('helpOnShipPoint:postalCode')} options={zip} />
              <Field name="wms_shp_pt_zone" component={Dropdown} clearable={true} label={t('helpOnShipPoint:zone')} options={zone}
                handleOnSelect={dropDownonSelect} childName='sub_zone' />
              <Field name="wms_shp_pt_sub_zone" component={Dropdown} clearable={true} label={t('helpOnShipPoint:subZone')} options={sub_zone} />
            </Grid.Column>
            <Grid.Column width={5}>
              <Field name="wms_shp_pt_days" component={Dropdown} clearable={true} label={t('helpOnShipPoint:workingDay')} options={weekDaysOption} />
              <Field name="wms_shp_pt_from_time" component={InputField} type="time" min="09:00" max="18:00" label={t('helpOnShipPoint:fromTime')} />
              <Field name="wms_shp_pt_to_time" component={InputField} type="time" min="09:00" max="18:00" label={t('helpOnShipPoint:timeTo')} />
              <div className="help-search">
                <button onClick={
                  handleSubmit(values =>
                    this.search({
                      values
                    }))
                } className="primary">{isSearching ? "Loading..." : "Search"}</button>
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={1}></Grid.Column>
            <Grid.Column width={14}>
              <DataGrid
                columns={headers}
                rows={shipperList}
                rowKey="wms_shp_pt_id"
                totalPages={lastPage}
                selectedRows={this.onSelectRow}
                totalRecord={totalRecords}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                enableExport={true}
                singleSelect={true}
                pageLimit={pageLimit}
              />
              <div className="get-details">
                <button type="button" className="primary"
                  onClick={this.loadShippingInfo}>{isSearching ? 'Loading...' : 'Get Details'}</button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </form>
    )
  }
}

HelpOnShipPoint = reduxForm({
  form: 'HelpOnShipPointForm',
  validate
})(HelpOnShipPoint);

const mapDispatchToProps = (dispatch) => ({
  searchShippingHelp: (params, page, limit) => dispatch(masterActions.searchShippingHelp(params, page, limit)),
  getZoneOptions: (action, queryStr) => dispatch(masterActions.getZoneOptions(action, queryStr)),
  inilailizeShipper: () => dispatch(masterActions.inilailizeShipper())
})

const mapStateToProps = state => ({
  brsd_from: state.masterReducer.options.brsd_from_ship_point_id,
  brsd_to: state.masterReducer.options.brsd_to_ship_point_id,
  isSearching: state.masterReducer.isSearching,
  zone: state.masterReducer.options.zone,
  sub_zone: state.masterReducer.options.sub_zone,
  lastPage: state.masterReducer.lastPage,
  totalRecords: state.masterReducer.totalRecords,
  shipperList: state.masterReducer.shipperList,
  formValues: state.form.HelpOnShipPointForm,
})

export default compose(withTranslation('helpOnShipPoint'), connect(mapStateToProps, mapDispatchToProps))(HelpOnShipPoint)
