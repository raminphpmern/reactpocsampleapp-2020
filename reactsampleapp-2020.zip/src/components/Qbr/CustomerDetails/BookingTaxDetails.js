import React, { Component } from 'react';
import { Table, Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { Field, FieldArray } from 'redux-form';
import InputField from 'components/Common/InputField'
import Dropdown from 'components/Common/Dropdown'
import DateTimePicker from 'components/Common/DateTimePicker'
import FileUpload from 'components/Common/FileUpload';
import PropTypes from 'prop-types';
import * as masterActions from "actions/masterAction";
import _ from 'lodash';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class BookingTaxList extends Component {
  componentDidMount() {
    if (this.props.fields.length === 0) {
      this.props.fields.push({})
    }
  }

  addRow(e) {
    if (e.keyCode === 13) {
      this.props.fields.push({})
    }
  }

  removeRow(e, index) {
    if (e.keyCode === 13) {
      this.props.fields.remove(index)
    }
  }

  render() {
    const { fields, status, exempt, dropDownonSelect } = this.props;
    return (
      <Table.Body>
        {fields.map((elem, index) => {
          return (
            <Table.Row key={index} className="tax-raw">

              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.tms_brctd_customer_registration_no`} component={InputField} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.tms_brctd_customer_reg_desc`} component={InputField} />
              </Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.tms_brctd_customer_exempt`} component={Dropdown} options={exempt} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.tms_brctd_customer_certification_no`} component={InputField} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.tms_brctd_customer_place_of_issue`} component={InputField} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.tms_brctd_customer_issue_date`} component={DateTimePicker} />
              </Table.Cell>
              <Table.Cell className="table-dropdown">
                <Field name={`${elem}.tms_brctd_customer_valid_upto_date`} component={DateTimePicker} />
              </Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.tms_brctd_customer_status`} childName={index} handleOnSelect={dropDownonSelect} component={Dropdown} options={status} />
              </Table.Cell>
              <Table.Cell>
                <Field name={`${elem}.tran_attachement`} component={FileUpload} /></Table.Cell>
              <Table.Cell>
                {fields.length - 1 === index &&
                  <i className="plus circle icon" onKeyUp={(e) => this.addRow(e)} onClick={() => fields.push({})} tabIndex="0"></i>
                }
              </Table.Cell>
              <Table.Cell>
                {index > 0 && <i className="minus circle icon" onClick={() => fields.remove(index)} onKeyUp={(e) => this.removeRow(e, index)} tabIndex="0"></i>}
              </Table.Cell>

            </Table.Row>
          )
        })}
      </Table.Body>
    )
  }
}

class BookingTaxDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      taxStatus: []
    }
    this.dropDownonSelect = this.dropDownonSelect.bind(this)
  }
  componentDidMount() {
    const { getTaxStatus, getTaxExempt, status, exempt } = this.props
    if (status.length === 0) {
      getTaxStatus("taxStatus");
    } else {
      let activeCount = 0
      _.map(this.props.formValues.values.tax_details, (item) => {
        if (item.tms_brctd_customer_status && item.tms_brctd_customer_status.value === 'ACT') {
          activeCount++
        }
      })
      if (activeCount < 1)
        this.setState({ taxStatus: status })
      else {
        let res = []
        _.map(status, (code) => {
          if (code.value === 'IA')
            res.push(code)
        })
        this.setState({ taxStatus: res })
      }
    }

    if (exempt.length === 0) {
      getTaxExempt("taxExempt");
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.status !== nextProps.status && nextProps.status.length > 0) {
      let activeCount = 0
      _.map(this.props.formValues.values.tax_details, (item) => {
        if (item.tms_brctd_customer_status && item.tms_brctd_customer_status.value === 'ACT') {
          activeCount++
        }
      })
      if (activeCount < 1)
        this.setState({ taxStatus: nextProps.status })
      else {
        let res = []
        _.map(nextProps.status, (code) => {
          if (code.value === 'IA')
            res.push(code)
        })
        this.setState({ taxStatus: res })
      }
    }
  }

  dropDownonSelect(data, index) {
    const { status, formValues } = this.props
    if (data.value === 'ACT') {
      let res = []
      _.map(status, (code) => {
        if (code.value === 'IA')
          res.push(code)
      })
      this.setState({ taxStatus: res })

    } else {
      let activeCount = 0
      let tax = formValues.values.tax_details
      tax[index].tms_brctd_customer_status = data
      _.map(tax, (item) => {
        if (item.tms_brctd_customer_status && item.tms_brctd_customer_status.value === 'ACT') {
          activeCount++
        }
      })
      if (activeCount === 0)
        this.setState({ taxStatus: status })
    }
  }

  render() {
    const { exempt, t } = this.props;
    const { taxStatus } = this.state
    return (
      <div className="document_wrapper">
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <h5 className="tax-head">{t('taxDetails:title')}</h5>
              <Table celled striped size='small' stackable>
                <Table.Header>
                  <Table.Row>
                    <Table.HeaderCell>{t('taxDetails:taxRegNo')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('taxDetails:taxRegDesc')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('taxDetails:exempt')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('taxDetails:certificateNo')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('taxDetails:issue')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('taxDetails:issuedate')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('taxDetails:valid')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('taxDetails:status')}</Table.HeaderCell>
                    <Table.HeaderCell>{t('taxDetails:attachment')}</Table.HeaderCell>
                    <Table.HeaderCell colSpan="2" />
                  </Table.Row>
                </Table.Header>
                <FieldArray dropDownonSelect={this.dropDownonSelect} status={taxStatus} exempt={exempt} name="tax_details" component={BookingTaxList} />
              </Table>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

BookingTaxDetails.propTypes = {
  close: PropTypes.func.isRequired
}

const mapDispatchToProps = (dispatch) => ({
  getTaxStatus: (type, queryStr) =>
    dispatch(masterActions.getTaxStatus(type, queryStr)),
  getTaxExempt: (type, queryStr) =>
    dispatch(masterActions.getTaxExempt(type, queryStr))
})

const mapStateToProps = state => ({
  status: state.masterReducer.options.taxStatus,
  exempt: state.masterReducer.options.taxExempt,
  formValues: state.form.CustomerDetailsForm,
})

export default compose(withTranslation('taxDetails'), connect(mapStateToProps, mapDispatchToProps))(BookingTaxDetails)
