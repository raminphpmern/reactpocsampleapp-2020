import React, { Component } from 'react'
import { Grid } from 'semantic-ui-react';
import { Field } from "redux-form";
import InputField from 'components/Common/InputField';
import PhoneInputField from 'components/Common/PhoneInput';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class RecurringConsigneeFields extends Component {
  render() {
    const { t } = this.props
    return (
      <Grid.Column width={8} className="consignee-field">
        <Field name="tms_br_booking_request_hdr.caller_name" component={InputField} label={t('recurringConsigFields:caller_name')} readOnly={false} required={false} />

        <Field name="tms_br_booking_request_hdr.caller_cont_no" component={PhoneInputField} label={t('recurringConsigFields:caller_cont_no')} />

        <Field name="tms_brrd_br_recurring_details.brrd_contact_person" component={InputField} label={t('recurringConsigFields:brrd_contact_person')} />

        <Field name="tms_brrd_br_recurring_details.brrd_primary_phone" component={PhoneInputField} label={t('recurringConsigFields:brrd_primary_phone')} />

        <Field name="tms_brrd_br_recurring_details.brrd_secondary_phone" component={PhoneInputField} label={t('recurringConsigFields:brrd_secondary_phone')} />
      </Grid.Column>
    )
  }
}

export default compose(withTranslation('recurringConsigFields'))(RecurringConsigneeFields)