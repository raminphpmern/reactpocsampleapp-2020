import { isValidPhoneNumber } from 'react-phone-number-input'
import i18n from 'i18n';

export default function validate(values) {
  const errors = {};

  if (!values.wms_customer_name)
    errors.wms_customer_name = i18n.t('shipperValidation:wms_customer_name')

  if (!values.wms_customer_lastname)
    errors.wms_customer_lastname = i18n.t('shipperValidation:wms_customer_lastname')

  if (!values.wms_customer_firstname)
    errors.wms_customer_firstname = i18n.t('shipperValidation:wms_customer_firstname')

  if (values.wms_customer_lastname || values.wms_customer_firstname) {
    errors.wms_customer_name = null
  }

  if (values.wms_customer_name) {
    errors.wms_customer_lastname = null
    errors.wms_customer_firstname = null
  }

  if (!values.wms_customer_address1)
    errors.wms_customer_address1 = i18n.t('shipperValidation:wms_customer_address1')

  if (!values.wms_customer_country)
    errors.wms_customer_country = i18n.t('shipperValidation:wms_customer_country')

  if (!values.wms_customer_state)
    errors.wms_customer_state = i18n.t('shipperValidation:wms_customer_state')

  if (!values.wms_customer_city)
    errors.wms_customer_city = i18n.t('shipperValidation:wms_customer_city')

  if (!values.wms_customer_suburb)
    errors.wms_customer_suburb = i18n.t('shipperValidation:wms_customer_suburb')

  if (!values.wms_customer_postal_code)
    errors.wms_customer_postal_code = i18n.t('shipperValidation:wms_customer_postal_code')

  if (!values.wms_customer_phone1)
    errors.wms_customer_phone1 = i18n.t('shipperValidation:wms_customer_phone1')
  else {
    let phoneNo = isValidPhoneNumber(values.wms_customer_phone1)
    if (phoneNo === false) {
      errors.wms_customer_phone1 = i18n.t('shipperValidation:invalidNo')
    }
  }

  if (values.wms_customer_phone2 && values.wms_customer_phone2.length >= 4) {
    let phoneNo = isValidPhoneNumber(values.wms_customer_phone2)
    if (phoneNo === false) {
      errors.wms_customer_phone2 = i18n.t('shipperValidation:wms_customer_phone2')
    }
  }

  if (values.wms_customer_email && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.wms_customer_email)) {
    errors.wms_customer_email = i18n.t('shipperValidation:wms_customer_email')
  }

  return errors
}
