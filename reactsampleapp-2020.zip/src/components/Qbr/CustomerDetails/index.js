import React, { Component } from 'react'
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import Certificate from 'components/Qbr/OrderDetails/Certificates';
import { reduxForm } from "redux-form";
import validate from './CustomerValidation';
import NewShipper from './NewShipper';
import NewConsignee from './NewConsignee';
import Popup from 'components/Common/Popup';
import * as masterActions from 'actions/masterAction';
import HelpOnShipPoint from './HelpOnShipPoint';
import _ from 'lodash';
import './customer.css';
import PropTypes from 'prop-types';
import { buildShipData, shippingFieldsReset, buildShipperData, buildShipmentData, buildSelectOption, buildConsignorData, formatTaxResponse } from 'lib/ShippingHelper';
import { buildConsigneeName, buildShipperName } from 'lib/CustomerDetailsHelper';
import * as customerActions from 'actions/customerActions';
import * as bookingActions from 'actions/bookingActions';
import { buildConsigneeData, buildConsigneeOtherInfo } from 'lib/ConsigneeHelper';
import { geoParamsBuilder, isCurrentBranchCcm, isCurrentBranchRetail } from 'lib/CommonHelper';
import { getValue } from 'lib/LocalStorage';
import { DIVISION, SEARCH_WORD_COUNT, SERVICE_TYPES } from 'config';
import ShippingFields from './ShipperFields'
import ConsigneeFields from './ConsigneeFields'
import NonReccuringBr from './NonReccuringBr'
import ReccuringBr from './ReccuringBr'
import RecurringConsigneeFields from './RecurringConsigneeFields'
import history from 'routes/history';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import { AlertError } from 'lib/Alert'
import moment from 'moment'

class CustomerDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      shipper: false,
      consignee: false,
      taxDetails: false,
      help: false,
      currentHelp: '',
      certificate: false,
      search: {
        consignee_search: true,
        consignee_last_name_search: true,
        consignee_first_name_search: true,
        shipper_search: true,
        shipper_first_name_search: true,
        shipper_last_name_search: true,
        shipper_company_name_search: true,
      },
      shipperCompanyRequired: true,
      shipperNameRequired: true,
      consigneeCompanyRequired: true,
      consigneeNameRequired: true,
      shipFromReadOnly: false
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.toggle = this.toggle.bind(this)
    this.dropDownonSelect = this.dropDownonSelect.bind(this)
    this.handleSearchChange = this.handleSearchChange.bind(this)
    this.initializeFormData = this.initializeFormData.bind(this)
    this.autoFill = this.autoFill.bind(this)
    this.loadOptionsManually = this.loadOptionsManually.bind(this)
    this.fillNameValues = this.fillNameValues.bind(this)
    this.findByCompanyAndFLMName = this.findByCompanyAndFLMName.bind(this)
    this.handleClick = this.handleClick.bind(this)
    this.setShipperFromAddress = this.setShipperFromAddress.bind(this)
    this.resetAccountNoShipper = this.resetAccountNoShipper.bind(this)
    this.resetAccountNoConsignee = this.resetAccountNoConsignee.bind(this)
    this.changeRecurring = this.changeRecurring.bind(this)
    this.checkOnlineForserviceType = this.checkOnlineForserviceType.bind(this)
    this.setConsigneeDetails = this.setConsigneeDetails.bind(this)
  }

  toggle(modalType, popUpName) {
    this.setState({ [modalType]: !this.state[modalType], currentHelp: popUpName })
  }

  componentWillUnmount() {
    window.onbeforeunload = () => true
  }

  setShipperFromAddress(currentBranch) {
    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    if (month < 10) {
      month = `0${month}`
    }
    let day = dateObj.getUTCDate();
    if (day < 10) {
      day = `0${day}`
    }
    let year = dateObj.getUTCFullYear();
    let recurring = 'N'
    if (isCurrentBranchCcm()) {
      this.props.changeRecurring('Y')
      recurring = 'Y'
    }
    let hash = {}
    if (currentBranch.defaultFromShipPointConfigured && currentBranch.wms_shp_pt_id && currentBranch.wms_shp_pt_id.length > 0) {
      hash = {
        brsd_from_state: buildSelectOption(currentBranch.wms_shp_pt_state, currentBranch.ship_state_desc),
        brsd_from_address_line1: currentBranch.wms_shp_pt_address1,
        brsd_from_city: buildSelectOption(currentBranch.wms_shp_pt_city, currentBranch.ship_city_desc),
        brsd_from_postal_code: buildSelectOption(currentBranch.wms_shp_pt_zipcode),
        brsd_from_country: buildSelectOption(currentBranch.wms_shp_pt_country, currentBranch.ship_country_desc),
        brsd_from_suburb: buildSelectOption(currentBranch.wms_shp_pt_suburb_code, currentBranch.ship_suburb_desc),
        brsd_from_ship_point_id: currentBranch.wms_shp_pt_id,
      }
    }
    if (isCurrentBranchRetail()) {
      let obj = {}
      if (!currentBranch.defaultFromShipPointConfigured || currentBranch.wms_shp_pt_id === '' || currentBranch.wms_shp_pt_id === null) {
        hash = {
          brsd_from_state: buildSelectOption(currentBranch.wms_state, currentBranch.wms_geo_state_desc),
          brsd_from_address_line1: currentBranch.wms_address1,
          brsd_from_city: buildSelectOption(currentBranch.wms_city, currentBranch.wms_geo_city_desc),
          brsd_from_postal_code: buildSelectOption(currentBranch.wms_zip_code),
          brsd_from_country: buildSelectOption(currentBranch.wms_country, currentBranch.wms_geo_country_desc),
          brsd_from_suburb: buildSelectOption(currentBranch.wms_suburb, currentBranch.wms_geo_suburb_desc), // just hardcode for now
          brsd_from_pick_date: `${year}-${month}-${day}`,
        }
      }
      obj.tms_brsd_shipment_details = hash
      obj.tms_br_booking_request_hdr = {}
      obj.tms_br_booking_request_hdr.br_recurring_flag = recurring
      obj.tms_br_booking_request_hdr.br_requested_date = `${year}-${month}-${day}`
      this.setState({ shipFromReadOnly: true })
      this.props.initialize(obj)
    } else {
      let obj = {}
      obj.tms_br_booking_request_hdr = {
        br_recurring_flag: recurring,
        br_requested_date: `${year}-${month}-${day}`
      }
      obj.tms_brsd_shipment_details = _.merge(hash, {
        brsd_from_pick_date: `${year}-${month}-${day}`
      })
      this.props.initialize(obj)
    }
  }

  componentDidMount() {
    let currentBranch = getValue('currentBranch') ? JSON.parse(getValue('currentBranch')) : {}
    const { service_mode, payment_type, shipment_type, getQuickCodeMaster, currentBooking } = this.props
    if (shipment_type.length === 0)
      getQuickCodeMaster('shipment_type')

    if (service_mode.length === 0)
      getQuickCodeMaster('service_mode')

    if (payment_type.length === 0)
      getQuickCodeMaster('payment_type')
    let shipperDom = document.getElementById("shipper")
    let scrollDom = document.getElementsByClassName('content-top-margin')[0]
    if (shipperDom)
      shipperDom.focus();
    if (scrollDom)
      scrollDom.scrollTop = 0
    if (currentBooking) {
      this.props.initialize(currentBooking)

      if (isCurrentBranchRetail()) {
        this.setState({ shipFromReadOnly: true })
      }
    }
    else
      this.setShipperFromAddress(currentBranch);
    let arr = ['shipper', 'consignee', 'shipper_first_name', 'shipper_last_name', 'consignee_first_name', 'consignee_last_name', 'shipper_company_name']
    arr.forEach((elemId) => {
      let element = document.getElementById(elemId)
      element && element.addEventListener('keypress', (event) => {
        if (event.keyCode === 13) {
          this.setState({ [elemId.split('_')[0]]: true })
          event.preventDefault()
        }
      })
    })
    if (this.props.countries.length === 0) {
      this.props.getGeoDefaultOptions('countries', '')
    }
    this.handleSearchChange();
  }

  handleSearchChange() {
    ['brsd_from_ship_point_id', 'brsd_to_ship_point_id'].forEach((elemId) => {
      let node = document.getElementById(elemId)
      node && node.addEventListener('keypress', (event) => {
        if (event.keyCode === 13) {
          let tms_brsd_shipment_details = this.props.formValues && this.props.formValues.values && this.props.formValues.values.tms_brsd_shipment_details
          let shipPointId = tms_brsd_shipment_details.brsd_from_ship_point_id
          if (elemId === 'brsd_to_ship_point_id') {
            shipPointId = tms_brsd_shipment_details.brsd_to_ship_point_id
          }

          this.props.searchShippingInfo(node.id, `id=${shipPointId}`)
          event.preventDefault()
        }
      })
    })
  }

  dropDownonSelect(data, childName) {
    let action = childName
    if (data && data.value && childName) {
      if (childName.split('_')[1]) {
        action = childName.split('_')[1]
      }
      this.props.getGeoOptions(action, geoParamsBuilder(data, action), childName)
    }
  }

  autoFill(data, childName) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(buildShipData(data, childName, hash))
      this.loadOptionsManually(data, `${childName === 'brsd_from' ? 'shipper_barangay' : 'barangay'}`)
      this.loadOptionsManually(data, `${childName === 'brsd_from' ? 'shipper_zip' : 'zip'}`)
    } else if (data) {
      this.props.initialize(buildShipData(data, childName, {}))
      this.loadOptionsManually(data, `${childName === 'brsd_from' ? 'shipper_barangay' : 'barangay'}`)
      this.loadOptionsManually(data, `${childName === 'brsd_from' ? 'shipper_zip' : 'zip'}`)
    } else if (!data) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(shippingFieldsReset(childName, hash))
      this.props.resetOptions({ barangay: [], shipper_barangay: [] })
    }
  }

  loadOptionsManually(data, geoType) {
    let action = geoType
    if (geoType.split('_')[1]) {
      action = geoType.split('_')[1]
    }
    this.props.getGeoOptions(action, geoParamsBuilder(data, action), geoType)
  }

  confirm(form) {
    const values = form.values
    const shipmentKey = 'tms_brsd_shipment_details'
    delete values[shipmentKey]['tax_details']
    values[shipmentKey]['brsd_from_contact_person'] = buildShipperName(values, shipmentKey)
    if (this.props.currentBooking) {
      if (this.props.currentBooking.tms_br_booking_request_hdr.br_status === 'Confirmed') {
        AlertError("Current BR already in Confirmed status")
        return;
      }
      const br_id = this.props.currentBooking.tms_br_booking_request_hdr.br_request_id
      this.props.updateBooking(values, br_id, 1, 'confirmed')
    } else {
      this.props.createBooking(values, 1, 'confirmed')
    }
  }

  checkOnlineForserviceType(tms_br_booking_request_hdr) {
    const { online } = this.props
    if (tms_br_booking_request_hdr && tms_br_booking_request_hdr.br_service_type) {
      if (SERVICE_TYPES.includes(tms_br_booking_request_hdr.br_service_type.value) && !online) {
        return true
      }
    }
    return false
  }

  formSubmit(values) {
    const { currentBooking } = this.props
    const currentBranch = getValue('currentBranch') ? JSON.parse(getValue('currentBranch')) : {}
    if (!currentBranch.isOperationDtlConfigured && (currentBooking && currentBooking.tms_br_booking_request_hdr.br_status !== 'Confirmed')) {
      AlertError('Operation Days is not configured for this location.')
      return false
    }

    if (this.checkOnlineForserviceType(values.tms_br_booking_request_hdr)) {
      AlertError('Make sure you have an active internet connection to proceed with this service type')
      return false
    }
    const shipmentKey = 'tms_brsd_shipment_details'
    const consigneeKey = 'tms_brccd_consgt_consignee_details'
    delete values[shipmentKey]['tax_details']
    values[shipmentKey]['brsd_from_contact_person'] = buildShipperName(values, shipmentKey)
    if (!!values[consigneeKey] && values.tms_br_booking_request_hdr && values.tms_br_booking_request_hdr.br_recurring_flag === 'N') {
      values[consigneeKey]['ccd_consignee_name'] = buildConsigneeName(values, consigneeKey)
    }
    if (currentBooking) {
      const br_id = currentBooking.tms_br_booking_request_hdr.br_request_id
      this.props.updateBooking(values, br_id, 1, 'save')
    } else {
      this.props.createBooking(values, 1, 'save')
    }
  }

  initializeFormData(values, parentHash) {
    let hash = this.props.formValues.values
    if (hash) {
      let tms_br_booking_request_hdr = _.merge(hash[parentHash], values)
      hash[parentHash] = tms_br_booking_request_hdr
      this.props.initialize({ ...hash, ...tms_br_booking_request_hdr })
    } else {
      let newHash = {}
      newHash[parentHash] = values
      this.props.initialize({ ...newHash })
    }
  }

  findByCompanyAndFLMName(value, type) {
    let { search } = this.state;
    const action = type.split('_')[0]

    let accNo = this.props.formValues && this.props.formValues.values && this.props.formValues.values.tms_br_booking_request_hdr && this.props.formValues.values.tms_br_booking_request_hdr.br_customer_id;
    let companyName = this.props.formValues && this.props.formValues.values && this.props.formValues.values.tms_brsd_shipment_details && this.props.formValues.values.tms_brsd_shipment_details.shipper_company_name;
    if (value && value.length >= SEARCH_WORD_COUNT) {
      if (action === 'shipper') {
        ['shipper', 'shipper_last_name', 'shipper_first_name', 'shipper_company_name'].forEach((field) => {
          if (search[`${type}_search`] && type === field) {
            let url = ((search["shipper_search"] === true && !accNo && !companyName) || (search['shipper_company_name_search'] === true)) || field === 'shipper' ? action : 'consignor'
            type = field === 'shipper_company_name' ? 'shipper' : type
            this.props.getShipper(url, `keyword=${value}&parentId=${accNo}`, type)
          }
        })
      } else if (action === 'consignee') {
        ['consignee', 'consignee_last_name', 'consignee_first_name'].forEach((field) => {
          if (search[`${type}_search`] && type === field) {
            this.props.getShipper(action, `keyword=${value}`, type)
          }
        })
      }
    } else {
      let hash = {}
      hash[type] = []
      this.props.resetOptions(hash)
      let isConsignor = false;
      if (action === 'shipper') {
        isConsignor = (accNo && companyName && type !== 'shipper') ? true : false
      }
      let typeArr = ['shipper', 'shipper_first_name', 'shipper_last_name', 'consignee', 'consignee_first_name', 'consignee_last_name', 'shipper_company_name']
      typeArr.forEach(element => {
        if (!value && type === element && !search[`${type}_search`]) {
          if (isConsignor && _.includes(['shipper_first_name', 'shipper_last_name'], element)) {

          } else {
            this.resetShipperAndConsigneeInfo(type)
            let hash = _.cloneDeep(this.props.formValues.values)
            this.props.initialize(_.merge(hash, { customer_company_name: '' }))
          }
          if (type === 'shipper_company_name') {
            search[`shipper_search`] = true
          }
          search[`${type}_search`] = true
        }
      });
    }
    this.setState({ search })
    this.markMandatory(type, value);
  }

  resetAccountNoShipper(values) {
    let { search } = this.state;
    if (values.wms_customer_name)
      search["shipper_search"] = false
    if (values.wms_customer_firstname)
      search["shipper_first_name_search"] = false
    if (values.wms_customer_lastname)
      search["shipper_last_name_search"] = false
    this.setState({ search })
  }

  resetAccountNoConsignee(values) {
    let { search } = this.state;
    if (values.wms_customer_name)
      search["wms_consignee_company_name"] = false
    if (values.wms_consignee_firstname)
      search["consignee_first_name_search"] = false
    if (values.wms_consignee_lastname)
      search["consignee_last_name_search"] = false
    this.setState({ search })
  }

  resetShipperAndConsigneeInfo(type) {
    const fromTo = type.includes('shipper') ? 'from' : 'to'
    const fieldObject = type.includes('shipper') ? 'tms_brsd_shipment_details' : 'tms_brccd_consgt_consignee_details'
    let hash = {}
    const fieldType = type.split('_')[0]
    hash[`${fieldType}_company_name`] = null
    hash[`${fieldType}_last_name`] = null
    hash[`${fieldType}_first_name`] = null
    hash[`${fieldType}_middle_name`] = null
    this.initializeFormData(hash, fieldObject)
    let tms_brsd_shipment_details = {}
    tms_brsd_shipment_details[`brsd_${fromTo}_primary_phone`] = null
    tms_brsd_shipment_details[`brsd_${fromTo}_secondary_phone`] = null
    tms_brsd_shipment_details[`brsd_${fromTo}_email_id`] = null
    this.initializeFormData(tms_brsd_shipment_details, 'tms_brsd_shipment_details')
    if (type.includes('shipper')) {
      let tms_br_booking_request_hdr = {}
      tms_br_booking_request_hdr['br_customer_id'] = null
      this.initializeFormData(tms_br_booking_request_hdr, 'tms_br_booking_request_hdr')
    } else {
      let tms_brccd_consgt_consignee_details = {}
      tms_brccd_consgt_consignee_details['ccd_consignee_id'] = null
      this.initializeFormData(tms_brccd_consgt_consignee_details, 'tms_brccd_consgt_consignee_details')
    }
  }

  markMandatory(type, value) {
    ['shipper', 'consignee'].forEach((field) => {
      if (type === field && value.length > 0) {
        this.setState({ [`${field}CompanyRequired`]: true, [`${field}NameRequired`]: false })
      }

      if (_.includes([`${field}_last_name`, `${field}_first_name`], type) && value.length > 0) {
        this.setState({ [`${field}NameRequired`]: true, [`${field}CompanyRequired`]: false })
      }
    })
  }

  fillNameValues(item, type) {
    let { search } = this.state;
    if (type.includes('shipper')) {
      const shipperHash = buildShipperData(item)
      let shipmentHash = {}
      if (item.hasOwnProperty('wms_customer_description')) {
        shipmentHash = buildShipmentData(item)
      } else {
        shipmentHash = buildConsignorData(item)
        if (item.wms_consignor_id)
          shipperHash['br_consignor_id'] = item.wms_consignor_id
      }
      if (this.props.recurring === 'N')
        this.props.getTaxDetails(item.wms_customer_id)
      this.initializeFormData(shipperHash, 'tms_br_booking_request_hdr')
      this.initializeFormData(shipmentHash, 'tms_brsd_shipment_details')
      if (type === 'shipper_company_name') {
        let hash = _.cloneDeep(this.props.formValues.values)
        this.props.initialize(_.merge(hash, { customer_company_name: item.wms_customer_description }))
        search[`shipper_search`] = false
      }
      search[`${type}_search`] = false
      this.setState({ search: search })
    } else if (type.includes('consignee')) {
      const hash = buildConsigneeData(item)
      const consigneeHash = buildConsigneeOtherInfo(item)
      this.initializeFormData(hash, 'tms_brccd_consgt_consignee_details')
      this.initializeFormData(consigneeHash, 'tms_brsd_shipment_details')
      search[`${type}_search`] = false
      this.setState({ search: search })
    }
    let hash = {}
    hash[type] = []
    this.props.resetOptions(hash)
  }

  setConsigneeDetails(values) {
    if (values) {
      let { search } = this.state;
      const hash = buildConsigneeData(values)
      const consigneeHash = buildConsigneeOtherInfo(values)
      this.initializeFormData(hash, 'tms_brccd_consgt_consignee_details')
      this.initializeFormData(consigneeHash, 'tms_brsd_shipment_details')
      search[`consignee_search`] = false
      this.setState({ search: search })
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.bookingData && this.props.bookingData !== nextProps.bookingData) {
      this.props.initialize(nextProps.bookingData)
    }
    if (this.props.copyBooking && this.props.copyBooking !== nextProps.copyBooking) {
      this.props.initialize(nextProps.copyBooking)
    }

    if (this.props.shipper_ship_from !== nextProps.shipper_ship_from) {
      this.autoFill(nextProps.shipper_ship_from, 'brsd_from')
    }
    if (this.props.shipper_ship_to !== nextProps.shipper_ship_to) {
      this.autoFill(nextProps.shipper_ship_to, 'brsd_to')
    }

    if (nextProps.taxDetails !== this.props.taxDetails) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash.tax_details = formatTaxResponse(nextProps.taxDetails)
      this.props.initialize(hash)
    }
    if (nextProps.currentBooking && (nextProps.currentBooking !== this.props.currentBooking)) {
      this.props.initialize(nextProps.currentBooking)
      const shipmentDtl = nextProps.currentBooking.tms_brsd_shipment_details
      const consigneeDtl = nextProps.currentBooking.tms_brccd_consgt_consignee_details
      const searchHash = this.state.search
      if (shipmentDtl.shipper_company_name) {
        searchHash['shipper_search'] = false
        this.setState({ search: searchHash })
        this.markMandatory('shipper', shipmentDtl.shipper_company_name)
      }
      if (consigneeDtl && consigneeDtl.consignee_company_name) {
        searchHash['consignee_search'] = false
        this.setState({ search: searchHash })
        this.markMandatory('consignee', consigneeDtl.consignee_company_name)
      }
    }
    if (nextProps.initializeState) {
      let obj = {}
      obj.tms_br_booking_request_hdr = {}
      obj.tms_br_booking_request_hdr.br_recurring_flag = isCurrentBranchCcm() ? 'Y' : 'N'
      if (isCurrentBranchRetail()) {
        let tms_brsd_shipment_details = this.props.formValues.values.tms_brsd_shipment_details
        obj.tms_brsd_shipment_details = {}
        obj.tms_brsd_shipment_details.brsd_from_state = tms_brsd_shipment_details.brsd_from_state
        obj.tms_brsd_shipment_details.brsd_from_address_line1 = tms_brsd_shipment_details.brsd_from_address_line1
        obj.tms_brsd_shipment_details.brsd_from_city = tms_brsd_shipment_details.brsd_from_city
        obj.tms_brsd_shipment_details.brsd_from_postal_code = tms_brsd_shipment_details.brsd_from_postal_code
        obj.tms_brsd_shipment_details.brsd_from_country = tms_brsd_shipment_details.brsd_from_country
        obj.tms_brsd_shipment_details.brsd_from_suburb = tms_brsd_shipment_details.brsd_from_suburb
        obj.tms_brsd_shipment_details.brsd_from_pick_date = tms_brsd_shipment_details.brsd_from_pick_date
      }
      this.props.initialize(obj)
    }
  }

  handleClick() {
    let copyCurrent = false
    const { currentBooking, bookingData, formValues } = this.props
    if (currentBooking && currentBooking.tms_br_booking_request_hdr && formValues && formValues.values) {
      copyCurrent = currentBooking.tms_br_booking_request_hdr.br_request_id === formValues.values.tms_br_booking_request_hdr.br_request_id
      if (currentBooking.tax_details.length === 0)
        this.props.getTaxDetails(currentBooking.tms_br_booking_request_hdr.br_customer_id)
    }
    if (bookingData || copyCurrent) {
      delete formValues.values['tms_ddh_dispatch_document_hdr']
      delete formValues.values['tms_br_booking_request_hdr']['br_request_id']
      delete formValues.values['tms_br_booking_request_hdr']['br_requested_date']
      delete formValues.values['cod_cop_amount']
      delete formValues.values['ethu_tracking_no']
      delete formValues.values['tms_br_booking_request_hdr']['br_promo_code']
      delete formValues.values['tms_br_booking_request_hdr']['br_promo_dis_amount']

      formValues.values['tms_brsd_shipment_details']['brsd_from_pick_date'] = moment().format('MM-DD-YYYY')
      formValues.values['tms_brsd_shipment_details']['brsd_to_delivery_date'] = moment().format('MM-DD-YYYY')
      this.props.initialize(formValues.values)
      history.push('/acceptance')
      this.props.initializeCopyBooking()
    } else {
      alert("Enter a valid BR No to Copy the booking request")
    }
  }

  onKeyPress = (event) => {
    if (event.key === 'Enter') {
      if (window.document.querySelector('[type="submit') !== document.activeElement)
        event.preventDefault();
    }
  }

  changeRecurring(val) {
    this.props.changeRecurring(val)
  }

  render() {
    const { handleSubmit, options, currentBooking, invalid, submitting, shipperFirstName, shipperLastName, consigneeFirstName, branchType, consigneeLastName, shipment_type, service_mode, payment_type, getBooking, recurring, t, isRequested } = this.props;
    const { shipperNameRequired, shipperCompanyRequired, consigneeNameRequired, consigneeCompanyRequired, shipper, consignee, currentHelp, shipFromReadOnly } = this.state
    const optionHash = branchType && branchType.includes(DIVISION.retail) ? {} : { handleOnSelect: this.dropDownonSelect }
    let br_status = false
    if (currentBooking && currentBooking.tms_br_booking_request_hdr) {
      const status = ['Cancelled', 'Confirmed']
      br_status = status.includes(currentBooking.tms_br_booking_request_hdr.br_status) ? true : false
    }
    let isRetail = (branchType && branchType.toLowerCase().includes(DIVISION.retail))

    return (
      <div className="customer-details-wrap">
        <Popup size='fullscreen' open={shipper} close={() => { this.toggle('shipper') }}
          header={t('customer:newShipper')} description={<NewShipper resetAccountNoShipper={this.resetAccountNoShipper} initializeShipper={this.initializeFormData} {...options} close={this.toggle}
            dropDownonSelect={this.dropDownonSelect} />} />

        <Popup size='tiny' open={consignee} close={() => { this.toggle('consignee') }}
          header={t('customer:newConsignee')} description={<NewConsignee resetAccountNoConsignee={this.resetAccountNoConsignee} initializeConsignee={this.initializeFormData} {...options} dropDownonSelect={this.dropDownonSelect} close={this.toggle} />} />

        <Popup size="fullscreen" open={this.state.help} close={() => { this.toggle('help') }}
          header={t('customer:helponShipPoint')} description={<HelpOnShipPoint {...options}
            dropDownonSelect={this.dropDownonSelect} close={this.toggle} name={currentHelp}
            handleOnSelect={this.autoFill} />} />

        <Popup open={this.state.certificate} close={() => { this.toggle('certificate') }}
          header={t('customer:certificates')} description={<Certificate close={this.toggle} />} />

        <form onSubmit={handleSubmit(this.formSubmit)} onKeyPress={this.onKeyPress}>

          {recurring === 'N' && <NonReccuringBr changeRecurring={this.changeRecurring} formValues={this.props.formValues} getBooking={getBooking} shipment_type={shipment_type} service_mode={service_mode} payment_type={payment_type} currentBooking={currentBooking} shipFromReadOnly={shipFromReadOnly} toggle={this.toggle} handleClick={this.handleClick} shipper={this.props.shipper} fillNameValues={this.fillNameValues} findByCompanyAndFLMName={this.findByCompanyAndFLMName} />}

          {recurring === 'Y' && <ReccuringBr changeRecurring={this.changeRecurring} formValues={this.props.formValues} getBooking={getBooking} shipment_type={shipment_type} service_mode={service_mode} payment_type={payment_type} currentBooking={currentBooking} shipFromReadOnly={shipFromReadOnly} toggle={this.toggle} handleClick={this.handleClick} />}

          <Grid stackable>
            <Grid.Row>
              <ShippingFields recurring={recurring} options={options} shipper={this.props.shipper} shipperFirstName={shipperFirstName} shipperLastName={shipperLastName} shipperNameRequired={shipperNameRequired} shipperCompanyRequired={shipperCompanyRequired} shipFromReadOnly={shipFromReadOnly} fillNameValues={this.fillNameValues} findByCompanyAndFLMName={this.findByCompanyAndFLMName} optionHash={optionHash} open={this.state.taxDetails} isRetail={isRetail}
                close={this.toggle} handleClick={this.toggle} handleOnSelect={this.dropDownonSelect}  {...this.props} />

              {recurring === 'N' && <ConsigneeFields isRequested={isRequested} formValues={this.props.formValues} options={options} consignee={this.props.consignee} consigneeFirstName={consigneeFirstName} consigneeLastName={consigneeLastName} consigneeNameRequired={consigneeNameRequired} consigneeCompanyRequired={consigneeCompanyRequired} shipFromReadOnly={shipFromReadOnly} fillNameValues={this.fillNameValues} findByCompanyAndFLMName={this.findByCompanyAndFLMName} handleOnSelect={this.dropDownonSelect} handleClick={this.toggle} invalid={invalid} submitting={submitting}  {...this.props} setConsigneeDetails={this.setConsigneeDetails} />}

              {recurring === 'Y' && <RecurringConsigneeFields />}
              {recurring === 'Y' &&
                <Grid.Column width={8}></Grid.Column>}
              {recurring === 'Y' && <Grid.Column width={6}>
                <div className="input_field">
                  <label></label>
                  <div className="input_holder rec-con-action">
                    <button disabled={br_status || isRequested} className="primary btn-full-width top-margin" type="submit">{t('customer:save')}</button>
                    <button disabled={br_status || isRequested} className="primary btn-full-width top-margin" onClick={
                      handleSubmit(values =>
                        this.confirm({
                          values
                        }))
                    } type="button">{t('customer:confirm')}</button>
                  </div>
                </div>
              </Grid.Column>
              }
            </Grid.Row>
          </Grid>
        </form>
      </div>
    )
  }
}

CustomerDetails.propTypes = {
  handleSubmit: PropTypes.func.isRequired
}

CustomerDetails = reduxForm({
  form: 'CustomerDetailsForm',
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate,
})(CustomerDetails);

const mapDispatchToProps = (dispatch) => ({
  getGeoOptions: (action, queryStr, propName) => dispatch(masterActions.getGeoOptions(action, queryStr, propName)),
  searchShippingInfo: (action, queryStr) => dispatch(masterActions.searchShippingInfo(action, queryStr)),
  getGeoDefaultOptions: (action, queryStr) => dispatch(masterActions.getGeoDefaultOptions(action, queryStr)),
  resetOptions: (data) => dispatch(masterActions.resetStateData(data)),
  getBooking: (bookingID, queryString) => dispatch(bookingActions.search(bookingID, queryString)),
  getShipper: (action, queryStr, stateName) => dispatch(masterActions.getShipper(action, queryStr, stateName)),
  createBooking: (params, step, status) => dispatch(customerActions.create(params, step, status)),
  updateBooking: (params, br_id, step, status) => dispatch(customerActions.update(params, br_id, step, status)),
  initializeCopyBooking: () => dispatch(bookingActions.initializeCopyBooking()),
  getQuickCodeMaster: (type) => dispatch(masterActions.getQuickCodeMaster(type, '')),
  changeRecurring: (val) => dispatch(bookingActions.changeRecurring(val)),
  getTaxDetails: (id) => dispatch(customerActions.getTaxDetails(id))
})

const mapStateToProps = state => ({
  countries: state.masterReducer.options.countries,
  province: state.masterReducer.options.province,
  city: state.masterReducer.options.city,
  barangay: state.masterReducer.options.barangay,
  zip: state.masterReducer.options.zip,
  shipper_ship_from: state.masterReducer.options.brsd_from_ship_point_id,
  shipper_ship_to: state.masterReducer.options.brsd_to_ship_point_id,
  formValues: state.form.CustomerDetailsForm,
  online: state.loginReducer.online,
  options: state.masterReducer.options,
  bookingData: state.bookingReducer.bookingData,
  copyBooking: state.bookingReducer.copyBooking,
  shipper: state.masterReducer.options.shipper,
  shipperFirstName: state.masterReducer.options.shipper_first_name,
  shipperLastName: state.masterReducer.options.shipper_last_name,
  consignee: state.masterReducer.options.consignee,
  consigneeFirstName: state.masterReducer.options.consignee_first_name,
  consigneeLastName: state.masterReducer.options.consignee_last_name,
  currentBooking: state.bookingReducer.currentBooking,
  branchType: state.loginReducer.branchType,
  service_mode: state.masterReducer.options.service_mode,
  payment_type: state.masterReducer.options.payment_type,
  shipment_type: state.masterReducer.options.shipment_type,
  recurring: state.bookingReducer.recurring,
  taxDetails: state.bookingReducer.taxDetails,
  isRequested: state.bookingReducer.isRequested
})

export default compose(withTranslation('customer'), connect(mapStateToProps, mapDispatchToProps))(CustomerDetails)
