import React, { Component } from 'react';
import { reduxForm, Field } from 'redux-form';
import { connect } from 'react-redux';
import InputField from 'components/Common/InputField';
import Dropdown from 'components/Common/Dropdown';
import PropTypes from 'prop-types';
import * as consigneeActions from 'actions/consigneeAction';
import validate from './ConsigneeValidation';
import { buildConsigneeData, buildConsigneeOtherInfo } from 'lib/ConsigneeHelper'
import PhoneInputField from 'components/Common/PhoneInput';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';

class NewConsignee extends Component {
  constructor(props) {
    super(props)
    this.state = {
      isNameRequired: true,
      isCompanyRequired: true
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.markMandatory = this.markMandatory.bind(this)
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const { isLoading, isSuccess, consignee, initializeConsignee, close, formValues, initialize } = this.props
    if (isLoading !== nextProps.isLoading && isLoading) {
      if (isSuccess && consignee) {
        const hash = buildConsigneeData(consignee)
        const consigneeHash = buildConsigneeOtherInfo(consignee)
        initializeConsignee(hash, 'tms_brccd_consgt_consignee_details')
        initializeConsignee(consigneeHash, 'tms_brsd_shipment_details')
        let formHash = formValues.values
        initialize({ ...formHash, consignee_acc_no: consignee.wms_consignee_id })
        close('consignee')
      }
    }
  }

  markMandatory(data, event) {
    if (event.target.name === "wms_consignee_company_name" && data.length > 0) {
      this.setState({ isCompanyRequired: true })
      this.setState({ isNameRequired: false })
    }
    if ((event.target.name === 'wms_consignee_lastname' || event.target.name === 'wms_consignee_firstname') && data.length > 0) {
      this.setState({ isNameRequired: true })
      this.setState({ isCompanyRequired: false })
    }
    if (data.length === 0) {
      this.setState({ isCompanyRequired: true })
      this.setState({ isNameRequired: true })
    }
  }

  formSubmit(values) {
    if (Object.entries(values).length !== 0) {
      if (values.wms_consignee_company_name) {
        values['wms_consignee_desc'] = values.wms_consignee_company_name
      } else {
        values['wms_consignee_desc'] =
          `${values.wms_consignee_firstname},${values.wms_consignee_middlename ? values.wms_consignee_middlename : ''},${values.wms_consignee_lastname}`;
      }
      delete values['account_no']
      this.props.create(values)
    }
    this.props.resetAccountNoConsignee(values)
  }


  render() {
    const { isNameRequired, isCompanyRequired } = this.state
    const { countries, handleSubmit, province, city, barangay, zip, dropDownonSelect, errorMsg, close, t } = this.props;
    let values = this.props.formValues && this.props.formValues.values ? this.props.formValues.values : {}
    let defaultCountry = values.wms_consignee_country ? values.wms_consignee_country.label : ''
    return (
      <form onSubmit={handleSubmit(this.formSubmit)} className="new-shipper-modal">
        <div>
          <span><strong>{t('newConsignee:consignee')}</strong></span>
          {errorMsg && <span className='error-msg'>{errorMsg}</span>}
          <Field id="consignee" name="consignee_acc_no" component={InputField} label={t('newConsignee:consignee_acc_no')} readOnly={true} />
          <Field autoFocus name="wms_consignee_company_name" component={InputField} label={t('newConsignee:wms_consignee_company_name')} required={isCompanyRequired} onchange={this.markMandatory} readOnly={values.wms_consignee_lastname || values.wms_consignee_firstname || values.wms_consignee_middlename} />
          <Field name="wms_consignee_lastname" readOnly={values.wms_consignee_company_name} component={InputField} label={t('newConsignee:wms_consignee_lastname')} required={isNameRequired} onchange={this.markMandatory} />
          <Field name="wms_consignee_firstname" readOnly={values.wms_consignee_company_name} component={InputField} label={t('newConsignee:wms_consignee_firstname')} required={isNameRequired} onchange={this.markMandatory} />
          <Field name="wms_consignee_middlename" readOnly={values.wms_consignee_company_name} component={InputField} label={t('newConsignee:wms_consignee_middlename')} />
          <Field name="wms_consignee_address1" component={InputField} label={t('newConsignee:wms_consignee_address1')} required={true} />
          <Field name="wms_consignee_country" component={Dropdown} label={t('newConsignee:wms_consignee_country')} options={countries}
            handleOnSelect={dropDownonSelect} childName='province' required={true} />
          <Field name="wms_consignee_state" component={Dropdown} label={t('newConsignee:wms_consignee_state')} options={province}
            handleOnSelect={dropDownonSelect} childName='city' required={true} />
          <Field name="wms_consignee_city" component={Dropdown} label={t('newConsignee:wms_consignee_city')} options={city}
            handleOnSelect={dropDownonSelect} childName='barangay' required={true} />
          <Field name="wms_consignee_suburb" component={Dropdown} label={t('newConsignee:wms_consignee_suburb')} options={barangay}
            handleOnSelect={dropDownonSelect} childName='zip' required={true} />
          <Field name="wms_consignee_postalcode" component={Dropdown} label={t('newConsignee:wms_consignee_postalcode')} options={zip}
            required={true} />
          <Field name="wms_consignee_phone1" countryCode={defaultCountry} component={PhoneInputField} label={t('newConsignee:wms_consignee_phone1')} />
          <Field name="wms_consignee_phone2" countryCode={defaultCountry} component={PhoneInputField} label={t('newConsignee:wms_consignee_phone2')} />
          <Field name="wms_consignee_email" component={InputField} label={t('newConsignee:wms_consignee_email')} />
        </div>
        <div className="input_field" >
          <label></label>
          <div className="input_holder actions">
            <button className="secondary" type="button" onClick={() => { close('consignee') }}>{t('newConsignee:Cancel')}</button>
            <button className="primary" type="submit">{t('newConsignee:Save')}</button>
          </div>
        </div>
      </form>
    )
  }
}

NewConsignee.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  countries: PropTypes.array.isRequired,
  province: PropTypes.array.isRequired,
  city: PropTypes.array.isRequired,
  barangay: PropTypes.array.isRequired,
  close: PropTypes.func.isRequired,
  dropDownonSelect: PropTypes.func.isRequired
}

NewConsignee = reduxForm({
  form: 'NewConsigneeForm',
  validate
})(NewConsignee);

const mapDispatchToProps = (dispatch) => ({
  create: (values) => dispatch(consigneeActions.create(values))
})

const mapStateToProps = state => ({
  consignee: state.consigneeReducer.currentConsignee,
  errorMsg: state.consigneeReducer.message,
  isLoading: state.consigneeReducer.isLoading,
  isSuccess: state.consigneeReducer.isSuccess,
  formValues: state.form.NewConsigneeForm,
})

export default compose(withTranslation('newConsignee'), connect(mapStateToProps, mapDispatchToProps))(NewConsignee)