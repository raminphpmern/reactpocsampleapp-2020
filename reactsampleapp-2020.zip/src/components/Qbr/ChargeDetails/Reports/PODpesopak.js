import React, { Component } from "react";
import { Table } from "semantic-ui-react";
import { renderAddressDtl, formatDateTime } from "lib/CommonHelper";
import Barcode from "react-barcode";
import i18n from "i18n";

const barCodeOptions = {
  format: "CODE128",
  displayValue: true,
  textAlign: "left",
  width: 3,
  height: 50,
};

class PODpesopak extends Component {
  render() {
    const { booking, currentBranch, formValues, currentUser } = this.props;
    const serialNo = currentUser.system && currentUser.system.serial;
    return (
      <Table id="a4-page">
        <Table.Header>
          <Table.Row>
            <Table.Cell>
              <p>
                {"Tracking No:"}
                {booking.tms_br_booking_request_hdr.br_consign_note}
              </p>
              <Barcode
                value={booking.tms_br_booking_request_hdr.br_consign_note}
                {...barCodeOptions}
              />
            </Table.Cell>
            <Table.Cell id="header-empty-td"></Table.Cell>
            <Table.Cell verticalAlign="top">
              <p id="topright">
                <b>{"POD REQUIRED"}</b>
              </p>
              <div className="header-ack-section">
                <div className="head-label-section">
                  <p>
                    {"Emp. No.:"}
                    {"178645383"}
                  </p>
                  <p>{"POD Copy"}</p>
                  <br />
                  <p>
                    <b>
                      {booking.tms_br_booking_request_hdr.br_service_type.label}
                    </b>
                  </p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              <b>{i18n.t("acknowledgementReceipt:lbc")}</b> <br />
              <span className="lbc-address">
                <p>
                  {currentBranch.wms_address1},{" "}
                  {currentBranch.wms_geo_state_desc},{" "}
                  {currentBranch.wms_geo_city_desc},{" "}
                  {currentBranch.wms_zip_code}{" "}
                </p>
                <p>
                  Tel. No: {currentBranch.wms_contact_no} TIN No.:
                  {currentBranch.TIN}
                </p>
              </span>
              <hr />
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="2">
              <p>{"Consignee Name"}</p>
              <p className="address-text">
                {
                  booking.tms_brccd_consgt_consignee_details
                    .consignee_company_name
                }
              </p>
              <p className="address-text">
                {i18n.t("acknowledgementReceipt:careof")}{" "}
              </p>
              {renderAddressDtl("to", booking, true)}
              {/* if regular pickup then {renderAddressDtl("from", booking.true)} */}
              <p className="address-text">
                {i18n.t("acknowledgementReceipt:brsd_to_primary_phone")}{" "}
                {booking.tms_brsd_shipment_details.brsd_to_primary_phone}
              </p>
              <hr />
            </Table.Cell>
            <Table.Cell>
              <div className="route-section">
                <div>
                  <p>{i18n.t("acknowledgementReceipt:origin")}</p>
                  <p>{i18n.t("acknowledgementReceipt:date")}</p>
                  <p id="php">
                    <b>{"PHP Amount"}</b>
                  </p>
                </div>
                <div className="colon-section">
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                </div>
                <div className="route-info">
                  <p>
                    {booking.tms_br_booking_request_hdr.br_customer_location}
                  </p>
                  <p>
                    {formatDateTime(
                      booking.tms_br_booking_request_hdr.br_creation_date,
                      false
                    )}
                  </p>
                  <p>{"amount value"}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="2">
              <p>{"Shipper:"}</p>
              <p>
                <b>
                  {booking.tms_brsd_shipment_details.brsd_from_contact_person}
                </b>
              </p>
              {renderAddressDtl("from", booking, true)}
              <p className="address-text">
                {i18n.t("acknowledgementReceipt:brsd_to_primary_phone")}
                {booking.tms_brsd_shipment_details.brsd_from_primary_phone}
              </p>
            </Table.Cell>
            <Table.Cell>
              <div className="route-section">
                <div className="total1">
                  <p>{"Consignee ID No"}</p>
                  <p>{"Expiry Date"}</p>
                  <p>{"ID Type"}</p>
                  <p>{"Amount Received"}</p>
                  <p>{"Date/Time Received"}</p>
                  <p>{"Relationship if not Consignee"}</p>
                </div>
                <div className="colon-section1">
                  <p>
                    <p>:</p>
                    <p>:</p>
                    <p>:</p>
                    <p>:</p>
                    <p>:</p>
                    <p>:</p>
                  </p>
                </div>
                <div className="route-info">
                  <p id="blank">{"__________________________"}</p>
                  <p id="blank">{"__________________________"}</p>
                  <p id="blank">{"__________________________"}</p>
                  <p id="blank">{"__________________________"}</p>
                  <p id="blank">{"__________________________"}</p>
                  <p id="blank">{"__________________________"}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell>
              <br />
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell>
              <p>{"RECEIVED BY"}</p>
              <br />
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              <div className="signature-info">
                <div>
                  <p></p>
                  <hr />
                  <p>{"PRINT NAME AND SIGN"} </p>
                </div>
                <div>
                  <p></p>
                  <hr />
                  <p>{"DELIVERED BY"}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
        </Table.Header>
      </Table>
    );
  }
}

export default PODpesopak;
