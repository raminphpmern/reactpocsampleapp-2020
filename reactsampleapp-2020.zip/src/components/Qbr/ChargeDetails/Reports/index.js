import React, { Component } from "react";
import InternalCopy from "./InternalCopy";
import POD from "./POD";
// import PODpesopak from "./PODpesopak";
import AcknowledgmentReceipt from "./AcknowledgmentReceipt";
import CustomerCopy from "./CustomerCopy";
import "./report.css";
import _ from "lodash";

class NoPrintTemplate extends Component {
  render() {
    return <h1>No template available to print.</h1>;
  }
}

class Reports extends Component {
  constructor(props) {
    super(props);
    this.renderTemplates = this.renderTemplates.bind(this);
  }

  renderTemplates(serviceType, subServiceType, certificateType) {
    const {
      booking,
      currentBranch,
      formValues,
      currentUser,
      tariff,
      chargesData,
    } = this.props;

    if (
      (_.includes(serviceType, "courier") &&
        _.includes(subServiceType, "to door")) ||
      (_.includes(serviceType, "courier") &&
        (subServiceType === "10 am pick up" ||
          subServiceType === "regular pick up")) ||
      (_.includes(serviceType, "cargo") &&
        _.includes(subServiceType, "to door")) ||
      (_.includes(serviceType, "cargo") &&
        (subServiceType === "10 am pick up" ||
          subServiceType === "regular pick up")) ||
      _.includes(serviceType, "international") ||
      serviceType === "prepaid padala with revenue" ||
      serviceType === "prepaid padala no revenue" ||
      serviceType === "order padala - island rose" ||
      subServiceType === "return to origin"
    ) {
      return (
        <div>
          <div className="pagebreak">
            <POD
              booking={booking}
              currentBranch={currentBranch}
              formValues={formValues}
              currentUser={currentUser}
            />
          </div>

          <div className="pagebreak">
            <InternalCopy
              booking={booking}
              currentBranch={currentBranch}
              formValues={formValues}
              currentUser={currentUser}
              tariff={tariff}
              chargesData={chargesData}
            />
          </div>

          <div className="pagebreak">
            <CustomerCopy
              booking={booking}
              currentBranch={currentBranch}
              formValues={formValues}
              currentUser={currentUser}
              tariff={tariff}
              chargesData={chargesData}
            />
          </div>
        </div>
      );
    } else if (
      serviceType === "dispatch" ||
      serviceType === "money remittance" ||
      serviceType === "pesopek" ||
      serviceType === "order padala-nso"
    ) {
      return (
        <div className="pagebreak">
          <POD
            booking={booking}
            currentBranch={currentBranch}
            formValues={formValues}
            currentUser={currentUser}
            tariff={tariff}
            chargesData={chargesData}
          />
        </div>
      );
    } else if (
      (serviceType === "order padala - psa" ||
        serviceType === "lazada return" ||
        serviceType === "prepaid padala with no revenue" ||
        serviceType === "drtm" ||
        subServiceType === "return to origin") &&
      certificateType &&
      certificateType["lbc_certi_type_code"].label
    ) {
      return (
        <div className="pagebreak">
          <AcknowledgmentReceipt
            booking={booking}
            currentBranch={currentBranch}
            formValues={formValues}
            currentUser={currentUser}
            tariff={tariff}
            chargesData={chargesData}
          />
        </div>
      );
    } else if (
      booking["tms_br_booking_request_hdr"]["br_status"].toLowerCase() ===
        "cancelled" ||
      serviceType === "order padala - psa"
    ) {
      return (
        <div>
          <div className="pagebreak">
            <InternalCopy
              booking={booking}
              currentBranch={currentBranch}
              formValues={formValues}
              currentUser={currentUser}
              tariff={tariff}
              chargesData={chargesData}
            />
          </div>
          <div className="pagebreak">
            <CustomerCopy
              booking={booking}
              currentBranch={currentBranch}
              formValues={formValues}
              currentUser={currentUser}
              tariff={tariff}
              chargesData={chargesData}
            />
          </div>
        </div>
      );
    } else {
      return <NoPrintTemplate ref={(el) => (this.componentRef = el)} />;
    }
  }
  render() {
    const { booking } = this.props;
    const brInfo = booking["tms_br_booking_request_hdr"];
    const certificateType = booking["certificate_detail"];
    const serviceType = brInfo["br_service_type"].value.toLowerCase();
    const subServiceType = brInfo["br_sub_service_type"].value.toLowerCase();
    return (
      <div>
        {this.renderTemplates(serviceType, subServiceType, certificateType)}
      </div>
    );
  }
}

export default Reports;
