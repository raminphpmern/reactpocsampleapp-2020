export function charges(tariff) {
  let vatExmpt = 0;
  let vatZeroRated = 0;
  let freightSum = 0;
  let pickupSum = 0;
  let discountSum = 0;
  let total = 0;
  let vat12 = 0;

  if (tariff) {
    tariff.forEach((element) => {
      if (element.brctd_tariff_id.toLowerCase().includes("frt")) {
        freightSum += element.brctd_rate_for_billable_weight;
      }
      if (element.brctd_tariff_id.toLowerCase().includes("vatempt")) {
        vatExmpt += element.brctd_rate_for_billable_weight;
      }
      if (element.brctd_tariff_id.toLowerCase().includes("frt_10am")) {
        pickupSum += element.brctd_rate_for_billable_weight;
      }
      if (element.brctd_tariff_id.toLowerCase().includes("disc")) {
        discountSum += element.brctd_rate_for_billable_weight;
      }
      if (element.brctd_tariff_id.toLowerCase().includes("vatzero")) {
        vatZeroRated += element.brctd_rate_for_billable_weight;
      }
      total += element.brctd_rate_for_billable_weight;
    });
    vat12 = total * 0.12;
  }

  return {
    vatExmpt: vatExmpt,
    vatZeroRated: vatZeroRated,
    freightSum: freightSum,
    pickupSum: pickupSum,
    discountSum: discountSum,
    total: total,
    vat12: vat12,
  };
}
