import React, { Component } from "react";
import Barcode from "react-barcode";
import { Table } from "semantic-ui-react";
import { renderAddressDtl, formatDateTime } from "lib/CommonHelper";
import classNames from "classnames";
import { charges } from "./helper";

const barCodeOptions = {
  format: "CODE128",
  displayValue: true,
  textAlign: "left",
  textPosition: "bottom",
  fontSize: 10,
  width: 2,
};
class InternalCopy extends Component {
  render() {
    const {
      booking,
      currentBranch,
      formValues,
      currentUser,
      tariff,
      chargesData,
    } = this.props;
    const serialNo = currentUser.system && currentUser.system.serial;
    const serialNoPaddingClass = classNames("", {
      "serial-padding": serialNo.length > 24,
    });
    // logic for address rendering
    let val = "";
    if (
      booking.tms_br_booking_request_hdr.br_sub_service_type.label
        .toLowerCase()
        .includes("regular")
    ) {
      val = "from";
    } else {
      val = "to";
    }

    // logic for accepted before/after cutoff
    let cutoff = "";
    if (
      booking.tms_br_booking_request_hdr.br_status.toLowerCase() ===
        "confirmed" &&
      booking.tms_br_booking_request_hdr.br_creation_date >
        currentBranch.wms_loc_cutoff_time
    ) {
      cutoff = "Accepted After Cut-off";
    } else {
      cutoff = "Accepted Before Cut-off";
    }
    //logic to get charge details
    let chargeValues = charges(tariff);

    return (
      <Table id="a4-page">
        <Table.Header>
          <Table.Row>
            <Table.Cell>
              <Barcode
                value={booking.tms_br_booking_request_hdr.br_consign_note}
                {...barCodeOptions}
              />
            </Table.Cell>
            <Table.Cell id="header-empty-td"></Table.Cell>
            <Table.Cell verticalAlign="top">
              <b>{cutoff}</b> <br />
              <b>THIS SERVES AS AN OFFICIAL RECEIPT</b>
              <div className="header-ack-section">
                <div className="head-label-section">
                  <p>{"MIN"}</p>
                  <p>{"Serial No"}</p>
                  <p>{"Official Receipt No"}</p>
                  <p>Accounting Copy</p>
                </div>
                <div>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                </div>
                <div className="header-ack-val-section">
                  <p>{currentBranch.MIN}</p>
                  <p>{serialNo}</p>
                  <p>{formValues.ccd_receipt_no}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              {"LBC EXPRESS INC."} <br />
              <span className="lbc-address">
                <p>
                  {currentBranch.wms_address1},{" "}
                  {currentBranch.wms_geo_state_desc},{" "}
                  {currentBranch.wms_geo_city_desc},{" "}
                  {currentBranch.wms_zip_code}{" "}
                </p>
                <p>
                  Tel. No: {currentBranch.wms_contact_no} TIN No.:
                  {currentBranch.TIN}
                </p>
                {/* <hr /> */}
              </span>
              {/* <hr /> */}
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="2">
              <span className="address-text">
                <p>{"Consignee"}</p>
                <p className="address-text">
                  <b>
                    {
                      booking.tms_brccd_consgt_consignee_details
                        .consignee_company_name
                    }
                  </b>
                </p>
                <p className="address-text">{"And or / care of: /"} </p>
                {renderAddressDtl(val, booking, true)}
                <p className="address-text">
                  {"Contact No.:"}{" "}
                  {booking.tms_brsd_shipment_details.brsd_to_primary_phone}
                </p>
                <hr />
              </span>
            </Table.Cell>
            <Table.Cell>
              <strong>
                {booking.tms_br_booking_request_hdr.br_service_type.label} -{" "}
                {
                  booking.shipment_details[0].tms_brcd_consgt_details.cd_thu_id
                    .label
                }
              </strong>
              <div className="route-section">
                <div>
                  <p>{"Origin"}</p>
                  <p>{"Tran Date"}</p>
                  <p>{"Delivery Date"}</p>
                  <p>{"Area Dest "}</p>
                  <p>{"Tran.type"}</p>
                  <p>{"Cut-Off"}</p>
                  <p>{"Actual-Wt (Kg.)"}</p>
                </div>
                <div className="colon-section">
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                </div>
                <div className="route-info">
                  <p>
                    {booking.tms_br_booking_request_hdr.br_customer_location}
                  </p>
                  <p>
                    {formatDateTime(
                      booking.tms_br_booking_request_hdr.br_creation_date,
                      false
                    )}
                  </p>
                  <p>
                    {formatDateTime(
                      booking.tms_brsd_shipment_details.brsd_to_delivery_date,
                      false
                    )}
                  </p>

                  <p>{booking.tms_brsd_shipment_details.brsd_to_city.label}</p>
                  <p>
                    {
                      booking.tms_br_booking_request_hdr.br_sub_service_type
                        .label
                    }
                  </p>
                  <p>{currentBranch.wms_loc_cutoff_time} PM</p>
                  <p>
                    {
                      booking.shipment_details[0].tms_brcd_consgt_details
                        .cd_gross_weight
                    }
                  </p>
                </div>
              </div>
              <hr />
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="2">
              <p>
                <b>
                  {booking.tms_brsd_shipment_details.brsd_from_contact_person}
                </b>
              </p>
              {renderAddressDtl("from", booking, true)}
              <p className="address-text">
                {"contact no:"}{" "}
                {booking.tms_brsd_shipment_details.brsd_from_primary_phone}
              </p>
              <p className="address-text">
                {"card no:"}
                {booking.tms_br_booking_request_hdr.br_customer_ref_no}
                {"TIN:"}
                {currentBranch.TIN}
              </p>
              <div className="cert-section">
                <p>{"Said to contain"} </p>
                <p>:</p>
                <p>
                  {booking.certificate_detail &&
                    booking.certificate_detail.lbc_certi_type_code.label}
                </p>
              </div>
            </Table.Cell>
            <Table.Cell>
              <div className="route-section">
                <div>
                  <p>{"VATable(Freight)"}</p>
                  <p>{"VAT-Exempt"}</p>
                  <p>{"VAT Zero-Rated"}</p>
                  <p>{"10AM Pickup Fee"}</p>
                  <p>{"Discount"}</p>
                  <p>{"Total Sales"}</p>
                  <p>{"12% VAT"}</p>
                  <br />
                  <p>
                    <b>{"Amount Due"}</b>
                  </p>
                  <p>{"Mode"}</p>
                </div>
                <div className="colon-section">
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <br />
                  <p>:</p>
                  <p>:</p>
                </div>
                <div className="route-info">
                  <p>{chargeValues.freightSum}</p>
                  <p>{chargeValues.vatExmpt}</p>
                  <p>{chargeValues.vatZeroRated}</p>
                  <p>{chargeValues.pickupSum}</p>
                  <p>{chargeValues.discountSum}</p>
                  <p>{chargeValues.total}</p>
                  <p>{chargeValues.vat12}</p>
                  <br />

                  <strong>{formValues.ccd_receipt_amount}</strong>

                  <p>
                    {booking.tms_br_booking_request_hdr.br_payment_type.label}
                  </p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              <div className="signature-section"></div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              <div className="signature-info">
                <div>
                  <p>{currentUser.fullname}</p>
                  <hr />
                  <p>{"Signature of Associate "} </p>
                </div>
                <div>
                  <p>
                    {booking.tms_brsd_shipment_details.brsd_from_contact_person}
                  </p>
                  <hr />
                  <p>{"Signature of Shipper"}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              <div className="receipt-footer">
                <p>
                  SHIPPER WARRANTS THAT THE SHIPMENT HAS NO CASH INSIDE,CLAIMS
                  OF CARGO ARE LIMITED UP TO ACTUAL DECLARED VALUE ONLY.
                </p>
                <p>
                  OR Series No. : {currentBranch.OR_SERIES_START_NO} to
                  {currentBranch.OR_SERIES_END_NO} BIR Final PTU.#
                  {currentBranch.BIR_FINAL_PTU}
                </p>
                <p>
                  BIR Accredition No. : {currentBranch.BIR_ACCR_NO} Date Issued:
                  {currentBranch.Date_BIR_Issued} valid untill
                  {currentBranch.Date_BIR_Valid_Till}
                </p>
                <p>
                  *THIS INVOICE/RECEIPT SHALL BE VALID FOR FIVE(5) YEARS FROM
                  THE DATE OF PERMIT TO USE.
                </p>
              </div>
            </Table.Cell>
          </Table.Row>
        </Table.Header>
      </Table>
    );
  }
}

export default InternalCopy;
