import React, { Component } from "react";
import { Table } from "semantic-ui-react";
import { renderAddressDtl, formatDateTime } from "lib/CommonHelper";
import Barcode from "react-barcode";
import classNames from "classnames";
import i18n from "i18n";
import { charges } from "./helper";

const barCodeOptions1 = {
  format: "CODE128",
  displayValue: true,
  textAlign: "left",
  width: 3,
};
const barCodeOptions = {
  format: "CODE128",
  displayValue: true,
  textAlign: "left",
  height: 50,
};

class POD extends Component {
  render() {
    const {
      booking,
      currentBranch,
      formValues,
      currentUser,
      tariff,
    } = this.props;
    const serialNo = currentUser.system && currentUser.system.serial;
    const serialNoPaddingClass = classNames("", {
      "serial-padding": serialNo.length > 24,
    });
    // logic for accepted after/before
    let cutoff = "";
    if (
      booking.tms_br_booking_request_hdr.br_service_type.label ===
      "courier domestic"
    ) {
      if (
        booking.tms_br_booking_request_hdr.br_status.toLowerCase() ===
          "confirmed" &&
        booking.tms_br_booking_request_hdr.br_creation_date >
          currentBranch.wms_loc_cutoff_time
      ) {
        cutoff = "Accepted After Cut-Off";
      } else {
        cutoff = "Accepted Before Cut-off";
      }
    } else {
      cutoff = "";
    }
    // logic for address rendering
    let val = "";
    if (
      booking.tms_br_booking_request_hdr.br_sub_service_type.label
        .toLowerCase()
        .includes("regular")
    ) {
      val = "from";
    } else {
      val = "to";
    }
    // logic for service type+thu id
    let disval = "";
    if (
      booking.tms_br_booking_request_hdr.br_service_type.label
        .toLowerCase()
        .includes("courier")
    ) {
      disval =
        booking.tms_br_booking_request_hdr.br_service_type.label +
        " " +
        "-" +
        " " +
        booking.shipment_details[0].tms_brcd_consgt_details.cd_thu_id.label;
    } else {
      disval =
        booking.shipment_details[0].tms_brcd_consgt_details.cd_thu_id.label;
    }

    //logic to get charge details
    let chargeValues = charges(tariff);

    //logic for island rose
    let comp = "";
    let comp2 = "";
    let comp3 = "";
    if (
      booking.tms_br_booking_request_hdr.br_service_type.label
        .toLowerCase()
        .includes("order padala - island rose")
    ) {
      comp = (
        <div className="route-section">
          <div>
            <p>{"VATable(Freight)"}</p>
            <p>{"VAT-Exempt"}</p>
            <p>{"VAT Zero-Rated"}</p>
            <p>{"Total Sales"}</p>
            <p>{"12% VAT"}</p>
            <br />
            <p>
              <b id="anount">{"Amount Due"}</b>
            </p>
            <p>{"Mode"}</p>
          </div>
          <div className="colon-section">
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <br />
            <p>:</p>
            <p>:</p>
          </div>
          <div className="route-info">
            <p>{chargeValues.freightSum}</p>
            <p>{chargeValues.vatExmpt}</p>
            <p>{chargeValues.vatZeroRated}</p>
            <p>{chargeValues.total}</p>
            <p>{chargeValues.vat12}</p>
            <br />
            <strong>{formValues.ccd_receipt_amount}</strong>

            <p>{booking.tms_br_booking_request_hdr.br_payment_type.label}</p>
          </div>
        </div>
      );

      comp2 = (
        <div className="route-section">
          <div>
            <p>{i18n.t("acknowledgementReceipt:origin")}</p>
            <p>{i18n.t("acknowledgementReceipt:date")}</p>
            <p>{"Delivery Date"}</p>
            <p>{i18n.t("acknowledgementReceipt:dest")}</p>
            <p>{i18n.t("acknowledgementReceipt:type")}</p>
            <p>{"Flower Color"}</p>
            <p>{"with Message"}</p>
            <p>{"No of Box"}</p>
          </div>
          <div className="colon-section">
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
          </div>
          <div className="route-info">
            <p>{booking.tms_br_booking_request_hdr.br_customer_location}</p>
            <p>
              {formatDateTime(
                booking.tms_br_booking_request_hdr.br_creation_date,
                false
              )}
            </p>
            {/* <p>{"Delivery date"}</p> */}
            <p>
              {formatDateTime(
                booking.tms_brsd_shipment_details.brsd_to_delivery_date,
                false
              )}
            </p>
            <p>{booking.tms_brsd_shipment_details.brsd_to_city.label}</p>
            <p>
              {booking.tms_br_booking_request_hdr.br_sub_service_type.label}
            </p>
            <p>
              {
                booking.shipment_details[0].tms_brcd_consgt_details.cd_thu_id
                  .label
              }
            </p>
            <p>{booking.tms_br_booking_request_hdr.cds_special_instructions}</p>
            <p>
              {
                booking.shipment_details[0].tms_brcd_consgt_details.cd_thu_qty
                  .label
              }
            </p>
          </div>
        </div>
      );

      comp3 = "";
    } else {
      comp = (
        <strong className="number">
          {booking.tms_br_booking_request_hdr.br_route_id}
        </strong>
      );
      comp2 = (
        <div className="route-section">
          <div>
            <p>{i18n.t("acknowledgementReceipt:origin")}</p>
            <p>{i18n.t("acknowledgementReceipt:date")}</p>
            <p>{"Delivery Date"}</p>
            <p>{i18n.t("acknowledgementReceipt:dest")}</p>
            <p>{i18n.t("acknowledgementReceipt:type")}</p>
            <p>{i18n.t("acknowledgementReceipt:cutOff")}</p>
          </div>
          <div className="colon-section">
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
            <p>:</p>
          </div>
          <div className="route-info">
            <p>{booking.tms_br_booking_request_hdr.br_customer_location}</p>
            <p>
              {formatDateTime(
                booking.tms_br_booking_request_hdr.br_creation_date,
                false
              )}
            </p>
            {/* <p>{"Delivery date"}</p> */}
            <p>
              {formatDateTime(
                booking.tms_brsd_shipment_details.brsd_to_delivery_date,
                false
              )}
            </p>
            <p>{booking.tms_brsd_shipment_details.brsd_to_city.label}</p>
            <p>
              {booking.tms_br_booking_request_hdr.br_sub_service_type.label}
            </p>
            <p>{currentBranch.wms_loc_cutoff_time} PM</p>
          </div>
        </div>
      );

      comp3 = (
        <div className="route-section">
          <div className="total">
            <pre>
              <strong className={serialNoPaddingClass}>{"Amount Due"}</strong>
            </pre>
            <p>{"Mode"}</p>
          </div>
          <div className="colon-section">
            <p>
              <strong className={serialNoPaddingClass}>:</strong>
              <p>:</p>
            </p>
          </div>
          <div className="route-info">
            <strong className={serialNoPaddingClass}>
              {formValues.ccd_receipt_amount}
            </strong>
            <p>{booking.tms_br_booking_request_hdr.br_payment_type.label}</p>
          </div>
        </div>
      );
    }

    return (
      <Table id="a4-page">
        <Table.Header>
          <Table.Row>
            <Table.Cell>
              <Barcode
                value={booking.tms_br_booking_request_hdr.br_consign_note}
                {...barCodeOptions1}
              />
            </Table.Cell>
            <Table.Cell id="header-empty-td"></Table.Cell>
            <Table.Cell verticalAlign="top">
              <b>{cutoff}</b>
              <div className="header-ack-section">
                <div className="head-label-section">
                  <p>{i18n.t("acknowledgementReceipt:min")}</p>
                  <p className={serialNoPaddingClass}>
                    {i18n.t("acknowledgementReceipt:SN")}
                  </p>
                  <p>{i18n.t("acknowledgementReceipt:O.R. No.")}</p>
                  <p>{"Employee"}</p>
                  <br />
                  <p>{"POD Copy"}</p>
                </div>
                <div>
                  <p>:</p>
                  <p className={serialNoPaddingClass}>:</p>
                  <p>:</p>
                  <p>:</p>
                </div>
                <div className="header-ack-val-section">
                  <p>{currentBranch.MIN}</p>
                  <p className={serialNoPaddingClass}>{serialNo}</p>
                  <p>{formValues.ccd_receipt_no}</p>
                  <p>{booking.tms_br_booking_request_hdr.br_created_by}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              {i18n.t("acknowledgementReceipt:lbc")} <br />
              <span className="lbc-address">
                <p>
                  {currentBranch.wms_address1},{" "}
                  {currentBranch.wms_geo_state_desc},{" "}
                  {currentBranch.wms_geo_city_desc},{" "}
                  {currentBranch.wms_zip_code}{" "}
                </p>
                <p>
                  Tel. No: {currentBranch.wms_contact_no} TIN No.:
                  {currentBranch.TIN}
                </p>
              </span>
              <hr />
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="2">
              <p>{i18n.t("acknowledgementReceipt:consignee")}</p>
              <p className="address-text">
                {
                  booking.tms_brccd_consgt_consignee_details
                    .consignee_company_name
                }
              </p>
              <p className="address-text">
                {i18n.t("acknowledgementReceipt:careof")}{" "}
              </p>
              <br />
              {renderAddressDtl(val, booking, true)}
              {/* if regular pickup then {renderAddressDtl("from", booking.true)} */}
              <p className="address-text">
                {i18n.t("acknowledgementReceipt:brsd_to_primary_phone")}{" "}
                {booking.tms_brsd_shipment_details.brsd_to_primary_phone}
              </p>
              <hr />
            </Table.Cell>
            <Table.Cell>
              <strong>{disval}</strong>
              {comp2}
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="2">
              <p>
                {booking.tms_brsd_shipment_details.brsd_from_contact_person}
              </p>
              {renderAddressDtl("from", booking, true)}
              <p className="address-text">
                {i18n.t("acknowledgementReceipt:brsd_to_primary_phone")}{" "}
                {booking.tms_brsd_shipment_details.brsd_from_primary_phone}
              </p>
              <p className="address-text">
                {"Card Number:"}
                {booking.tms_br_booking_request_hdr.br_customer_ref_no}
                {"TIN No.:"} {currentBranch.TIN}
              </p>
              <p>{"Said to contain:"}</p>

              <p>
                {booking.certificate_detail &&
                  booking.certificate_detail.lbc_certi_type_code.label}
              </p>
            </Table.Cell>
            <Table.Cell>
              {comp3}
              <hr />
              {/* <strong className="number">
                {booking.tms_br_booking_request_hdr.br_route_id}
              </strong> */}
              {comp}
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell>
              <Barcode
                value={booking.tms_br_booking_request_hdr.br_consign_note}
                {...barCodeOptions}
              />
            </Table.Cell>
          </Table.Row>

          <Table.Row>
            <Table.Cell colSpan="3">
              <div className="signature-info">
                <div>
                  <p></p>
                  <hr />
                  <p>{"PRINT NAME AND SIGN"} </p>
                </div>
                <div>
                  <p></p>
                  <hr />
                  <p>{"If Not Consignee: RELATIONSHIP"}</p>
                </div>
                <div>
                  <p></p>
                  <hr />
                  <p>{"DATE"}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              <div className="receipt-footer">
                <p>{"Customer Care : 8585-999"}</p>
                <p>BIR Final PTU #: {currentBranch.BIR_FINAL_PTU}</p>
                <p>
                  BIR Accredition No. : {currentBranch.BIR_ACCR_NO} Date Issued:
                  {currentBranch.Date_BIR_Issued} valid untill
                  {currentBranch.Date_BIR_Valid_Till}
                </p>
                <p>{"THIS DOCUMENT IS NOT VALID FOR CLAIM OF INPUT TAX"}</p>
              </div>
            </Table.Cell>
          </Table.Row>
        </Table.Header>
      </Table>
    );
  }
}

export default POD;
