import React, { Component } from "react";
import { Table } from "semantic-ui-react";
import { renderAddressDtl, formatDateTime } from "lib/CommonHelper";
import Barcode from "react-barcode";
import classNames from "classnames";
import i18n from "i18n";
import { charges } from "./helper";

const barCodeOptions1 = {
  format: "CODE128",
  displayValue: true,
  textAlign: "center",
  width: 2,
  height: 55,
};
class CustomerCopy extends Component {
  render() {
    const {
      booking,
      currentBranch,
      formValues,
      currentUser,
      tariff,
      chargesData,
    } = this.props;

    const serialNo = currentUser.system && currentUser.system.serial;
    const serialNoPaddingClass = classNames("", {
      "serial-padding": serialNo.length > 24,
    });
    // logic for accepted after/before
    let cutoff = "";
    if (
      booking.tms_br_booking_request_hdr.br_service_type.label ===
      "courier domestic"
    ) {
      if (
        booking.tms_br_booking_request_hdr.br_status.toLowerCase() ===
          "confirmed" &&
        booking.tms_br_booking_request_hdr.br_creation_date >
          currentBranch.wms_loc_cutoff_time
      ) {
        cutoff = "Accepted After Cut-Off";
      } else {
        cutoff = "Accepted Before Cut-off";
      }
    } else {
      cutoff = "";
    }

    // logic for address rendering
    let val = "";
    if (
      booking.tms_br_booking_request_hdr.br_sub_service_type.label
        .toLowerCase()
        .includes("regular")
    ) {
      val = "from";
    } else {
      val = "to";
    }

    //logic to get charge details
    let chargeValues = charges(tariff);
    return (
      <Table className="a4-page">
        <Table.Header>
          <Table.Row>
            <Table.Cell>
              <b>{i18n.t("acknowledgementReceipt:lbc")}</b>
              <br />
              <span className="lbc-address">
                <p>
                  {currentBranch.wms_address1},{" "}
                  {currentBranch.wms_geo_state_desc},{" "}
                  {currentBranch.wms_geo_city_desc},{" "}
                  {currentBranch.wms_zip_code}{" "}
                </p>
                <p>Tel. No: {currentBranch.wms_contact_no}</p>
                <p>TIN No.: {currentBranch.TIN}</p>
              </span>
            </Table.Cell>
            <Table.Cell colSpan="2">
              <div className="cc">
                <b>{"Cutomer's Copy"}</b>
              </div>
              <Barcode
                value={booking.tms_br_booking_request_hdr.br_consign_note}
                {...barCodeOptions1}
              />
            </Table.Cell>
            <Table.Cell colSpan="3">
              <b>{cutoff}</b>
              <p>{"THIS SERVES AS AN OFFICIAL RECEIPT"}</p>
              <div className="header-ack-section">
                <div className="head-label-section">
                  <p>{i18n.t("acknowledgementReceipt:min")}</p>
                  <p className={serialNoPaddingClass}>
                    {i18n.t("acknowledgementReceipt:SN")}
                  </p>
                  <p>{"Official Receipt No"}</p>
                </div>
                <div>
                  <p>:</p>
                  <p className={serialNoPaddingClass}>:</p>
                  <p>:</p>
                </div>
                <div className="header-ack-val-section">
                  <p>{currentBranch.MIN}</p>
                  <p>{serialNo}</p>
                  <p>{formValues.ccd_receipt_no}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="6">
              <hr />
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="2">
              <p>{"SHIPPER:"}</p>
              <br />
              <b>
                <p>
                  {booking.tms_brsd_shipment_details.brsd_from_contact_person}
                </p>
              </b>
              {renderAddressDtl("from", booking, true)}
              <p className="address-text">
                {i18n.t("acknowledgementReceipt:brsd_to_primary_phone")}{" "}
                {booking.tms_brsd_shipment_details.brsd_from_primary_phone}
              </p>
              <p className="address-text">
                {"Card Number:"}
                {booking.tms_br_booking_request_hdr.br_customer_ref_no}
                {"TIN No.:"} {currentBranch.TIN}
              </p>
            </Table.Cell>
            <Table.Cell colSpan="2">
              <p>{"CONSIGNEE:"}</p>

              <p className="address-text">
                {i18n.t("acknowledgementReceipt:careof")}{" "}
              </p>

              <b>
                <p className="address-text">
                  {
                    booking.tms_brccd_consgt_consignee_details
                      .consignee_company_name
                  }
                </p>
              </b>
              {renderAddressDtl(val, booking, true)}
              {/* if regular pickup then {renderAddressDtl("from", booking.true)} */}
              <p className="address-text">
                {i18n.t("acknowledgementReceipt:brsd_to_primary_phone")}{" "}
                {booking.tms_brsd_shipment_details.brsd_to_primary_phone}
              </p>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="6">
              <hr />
              <strong>
                {booking.tms_br_booking_request_hdr.br_service_type.label} -{" "}
                {
                  booking.shipment_details[0].tms_brcd_consgt_details.cd_thu_id
                    .label
                }
              </strong>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="2">
              <div className="route-section">
                <div>
                  <p>{"Origin"}</p>
                  <p>{"Tran. Date"}</p>
                  <p>{"Delivery Date"}</p>
                  <p>{"Area Dest. "}</p>
                  <p>{"Tran. Type"}</p>
                  <p>{"Cut-Off"}</p>
                  <p>{"Actual-Wt (Kg.)"}</p> <br /> <br />
                  <p>{"Said to Contain"}</p>
                </div>
                <div className="colon-section">
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p> <br /> <br />
                  <p>:</p>
                </div>
                <div className="route-info">
                  <p>
                    {booking.tms_br_booking_request_hdr.br_customer_location}
                  </p>
                  <p>
                    {formatDateTime(
                      booking.tms_br_booking_request_hdr.br_creation_date,
                      false
                    )}
                  </p>
                  {/* <p>{"Delivery date"}</p> */}
                  <p>
                    {formatDateTime(
                      booking.tms_brsd_shipment_details.brsd_to_delivery_date,
                      false
                    )}
                  </p>
                  <p>{booking.tms_brsd_shipment_details.brsd_to_city.label}</p>
                  <p>
                    {
                      booking.tms_br_booking_request_hdr.br_sub_service_type
                        .label
                    }
                  </p>
                  <p>{currentBranch.wms_loc_cutoff_time} PM</p>
                  <p>
                    {
                      booking.shipment_details[0].tms_brcd_consgt_details
                        .cd_gross_weight
                    }
                  </p>
                  <br /> <br />
                  <p>
                    {booking.certificate_detail &&
                      booking.certificate_detail.lbc_certi_type_code.label}
                  </p>
                </div>
              </div>
            </Table.Cell>
            <Table.Cell colSpan="2" className="line">
              <div className="route-section">
                <div>
                  <p>{"VATable(Freight)"}</p>
                  <p>{"VAT-Exempt"}</p>
                  <p>{"VAT Zero-Rated"}</p>
                  <p>{"10AM Pickup Fee"}</p>
                  <p>{"Discount"}</p>
                  <p>{"Total Sales"}</p>
                  <p>{"12% VAT"}</p>
                  <br />
                  <p>
                    <b id="anount">{"Amount Due"}</b>
                  </p>
                  <p>{"Mode"}</p>
                </div>
                <div className="colon-section">
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <br />
                  <p>:</p>
                  <p>:</p>
                </div>
                <div className="route-info">
                  <p>{chargeValues.freightSum}</p>
                  <p>{chargeValues.vatExmpt}</p>
                  <p>{chargeValues.vatZeroRated}</p>
                  <p>{chargeValues.pickupSum}</p>
                  <p>{chargeValues.discountSum}</p>
                  <p>{chargeValues.total}</p>
                  <p>{chargeValues.vat12}</p>
                  <br />
                  <strong>{formValues.ccd_receipt_amount}</strong>

                  <p>
                    {booking.tms_br_booking_request_hdr.br_payment_type.label}
                  </p>
                </div>
              </div>
            </Table.Cell>
            <Table.Cell>
              <pre className="infoText">
                Track your padala at :<br />
                <b>www.lbcexpress.com</b>
                <br />
                Talk to our Care Representative
                <br />
                <b>www.lbcexpress.com</b>
                <br />
                Tel.:<b id="no">(632) 8585-999</b>
                <br /> <b id="no">:1-800-10-8585-999</b>
                <br />
                *Only for PH outside NCR
                <br />
                <br />
                Let us know your experience :<br />
                <b>survey.lbcexpress.com</b>
              </pre>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3" className="text">
              <br />
              <pre>
                LBC Express values you privacy,for more info on our privacy
                policy
                <br />
                visit www.lbcexpress.com/privacy-policy
                <br />
                SHIPPER WARRANTS THAT THERE IS NO CASH INSIDE , CLAIMS OF CARGO
                ARE
                <br />
                LIMITED UPTO ACTUAL DECLARED VALUE ONLY
                <br />I hereby agree to be bound with terms and conditions
                written at the
                <br />
                back set forth by LBC Express
              </pre>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              <br />
              <div className="signature-info">
                <div>
                  <p>{currentUser.fullname}</p>
                  <hr />
                  <p>{"Signature of Associate "} </p>
                </div>
                <div>
                  <p>
                    {booking.tms_brsd_shipment_details.brsd_from_contact_person}
                  </p>
                  <hr />
                  <p>{"Signature of Shipper"}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan="3">
              <div className="las">
                <br />
                <pre>
                  OR Series No. : {currentBranch.OR_SERIES_START_NO} to
                  {currentBranch.OR_SERIES_END_NO} BIR Final PTU.#
                  {currentBranch.BIR_FINAL_PTU}
                  <br />
                  BIR Accredition No. : {currentBranch.BIR_ACCR_NO}Date Issued:
                  {currentBranch.Date_BIR_Issued} valid untill
                  {currentBranch.Date_BIR_Valid_Till}
                  <br />
                  *THIS INVOICE/RECEIPT SHALL BE VALID FOR FIVE(5) YEARS FROM
                  THE DATE OF PERMIT TO USE.
                </pre>
              </div>
            </Table.Cell>
          </Table.Row>
        </Table.Header>
      </Table>
    );
  }
}

export default CustomerCopy;
