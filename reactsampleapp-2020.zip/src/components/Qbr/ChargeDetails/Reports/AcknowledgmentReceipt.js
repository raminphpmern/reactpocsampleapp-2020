import React, { Component } from 'react';
import { Table } from 'semantic-ui-react';
import { renderAddressDtl, formatDateTime } from 'lib/CommonHelper';
import Barcode from 'react-barcode';
import classNames from 'classnames';
import i18n from 'i18n';

const barCodeOptions = {
  format: 'CODE128',
  displayValue: true,
  textAlign: 'left',
}

class AcknowledgmentReceipt extends Component {
  render() {
    const { booking, currentBranch, formValues, currentUser } = this.props;
    const serialNo = currentUser.system && currentUser.system.serial
    const serialNoPaddingClass = classNames('', {
      'serial-padding': serialNo.length > 24
    })
    return (
      <Table className='a4-page'>
        <Table.Header>
          <Table.Row>
            <Table.Cell>
              <Barcode value={booking.tms_br_booking_request_hdr.br_consign_note} {...barCodeOptions} />
            </Table.Cell>
            <Table.Cell className='header-empty-td'>
            </Table.Cell>
            <Table.Cell verticalAlign='top'>
              <b>{i18n.t('acknowledgementReceipt:acknowReceipt')}</b>
              <div className='header-ack-section'>
                <div className='head-label-section'>
                  <p>{i18n.t('acknowledgementReceipt:min')}</p>
                  <p className={serialNoPaddingClass}>{i18n.t('acknowledgementReceipt:serailNo')}</p>
                  <p>{i18n.t('acknowledgementReceipt:ackRecNo')}</p>
                </div>
                <div>
                  <p>:</p>
                  <p className={serialNoPaddingClass}>:</p>
                  <p>:</p>
                </div>
                <div className='header-ack-val-section'>
                  <p>{currentBranch.MIN}</p>
                  <p>{serialNo}</p>
                  <p>{formValues.ccd_receipt_no}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan='3'>
              {i18n.t('acknowledgementReceipt:lbc')} <br />
              <span className='lbc-address'>
                <p>{currentBranch.wms_address1}, {currentBranch.wms_geo_state_desc}, {currentBranch.wms_geo_city_desc}, {currentBranch.wms_zip_code} </p>
                <p>Tel. No: {currentBranch.wms_contact_no} TIN No.: {currentBranch.TIN}</p>
              </span>
              <hr />
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan='2'>
              <p>{i18n.t('acknowledgementReceipt:consignee')}</p>
              <p className='address-text'>{booking.tms_brccd_consgt_consignee_details.consignee_company_name}</p>
              <p className='address-text'>{i18n.t('acknowledgementReceipt:careof')}	</p>
              {renderAddressDtl('to', booking, true)}
              <p className='address-text'>{i18n.t('acknowledgementReceipt:brsd_to_primary_phone')} {booking.tms_brsd_shipment_details.brsd_to_primary_phone}</p>
              <hr />
            </Table.Cell>
            <Table.Cell>
              <strong>
                {booking.tms_br_booking_request_hdr.br_service_type.label} - {booking.shipment_details[0].tms_brcd_consgt_details.cd_thu_id.label}
              </strong>
              <div className='route-section'>
                <div>
                  <p>{i18n.t('acknowledgementReceipt:origin')}</p>
                  <p>{i18n.t('acknowledgementReceipt:date')}</p>
                  <p>{i18n.t('acknowledgementReceipt:dest')}</p>
                  <p>{i18n.t('acknowledgementReceipt:type')}</p>
                  <p>{i18n.t('acknowledgementReceipt:cutOff')}</p>
                </div>
                <div className='colon-section'>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                  <p>:</p>
                </div>
                <div className='route-info'>
                  <p>{booking.tms_br_booking_request_hdr.br_customer_location}</p>
                  <p>{formatDateTime(booking.tms_br_booking_request_hdr.br_creation_date, false)}</p>
                  <p>{booking.tms_brsd_shipment_details.brsd_to_city.label}</p>
                  <p>{booking.tms_br_booking_request_hdr.br_sub_service_type.label}</p>
                  <p>{currentBranch.wms_loc_cutoff_time} PM</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan='2'>
              <p>{booking.tms_brsd_shipment_details.brsd_from_contact_person}</p>
              {renderAddressDtl('from', booking, true)}
              <p className='address-text'>{i18n.t('acknowledgementReceipt:brsd_to_primary_phone')} {booking.tms_brsd_shipment_details.brsd_from_primary_phone}</p>
            </Table.Cell>
            <Table.Cell>
              <div className='route-section'>
                <div className='total'>
                  <p><strong>{i18n.t('acknowledgementReceipt:total')}</strong></p>
                </div>
                <div className='colon-section'>
                  <p><strong>:</strong></p>
                </div>
                <div className='route-info'>
                  <strong>{formValues.ccd_receipt_amount}</strong>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan='3'>
              <div className='cert-section'>
                <p>{i18n.t('acknowledgementReceipt:saidToContain')}	</p>
                <p>:</p>
                <p>{booking.certificate_detail && booking.certificate_detail.lbc_certi_type_code.label}</p>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan='3'>
              <div className='signature-section'>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan='3'>
              <div className='signature-info'>
                <div>
                  <p>{currentUser.fullname}</p>
                  <hr />
                  <p>{i18n.t('acknowledgementReceipt:signature')}	</p>
                </div>
                <div>
                  <p>{booking.tms_brsd_shipment_details.brsd_from_contact_person}</p>
                  <hr />
                  <p>{i18n.t('acknowledgementReceipt:shipper')}</p>
                </div>
              </div>
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell colSpan='3'>
              <div className='receipt-footer'>
                <p>{i18n.t('acknowledgementReceipt:ARseriesNo')}</p>
                <p>{i18n.t('acknowledgementReceipt:validity')}</p>
                <p>{i18n.t('acknowledgementReceipt:inputTax')}</p>
              </div>
            </Table.Cell>
          </Table.Row>
        </Table.Header>
      </Table>
    )
  }
}

export default AcknowledgmentReceipt
