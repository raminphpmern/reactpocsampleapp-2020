import React, { Component } from "react";
import { connect } from "react-redux";
import { reduxForm, Field } from "redux-form";
import InputField from "components/Common/InputField";
import { Grid, Icon, Label } from "semantic-ui-react";
import Checkbox from "components/Common/Checkbox";
import OrderHeader from "./../OrderDetails/OrderHeader";
import * as bookingActions from "actions/bookingActions";
import * as chargesActions from "actions/chargesAction";
import { getValue } from "lib/LocalStorage";
import ReactToPrint from "react-to-print";
import _ from "lodash";
import "./charges.css";
import i18n from "i18n";
import { withTranslation } from "react-i18next";
import { compose } from "redux";
import Popup from "components/Common/Popup";
import { Table } from "semantic-ui-react";
import { validatePromoCode, removePromoCode } from "actions/promoAction";
import Reports from "./Reports"

const validate = (values, props) => {
  const errors = {};

  if (values.padded_or) {
    if (!values.ccd_receipt_no) {
      errors.orno = i18n.t("charges:arRequired");
    }
  }
  if (
    props.currentBooking &&
    props.currentBooking.tms_br_booking_request_hdr &&
    props.currentBooking.tms_br_booking_request_hdr.br_payment_type.value === "CSH"
  ) {
    if (!values.cash) {
      errors.cash = "Cash is required.";
    }
  }
  return errors;
};

class NoPrintTemplate extends Component {
  render() {
    return <h1>No template available to print.</h1>;
  }
}

class Charges extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };
    this.toggle = this.toggle.bind(this);
    this.stepBack = this.stepBack.bind(this);
    this.formSubmit = this.formSubmit.bind(this);
    this.inputChange = this.inputChange.bind(this);
    this.saveCharge = this.saveCharge.bind(this);
    this.print = this.print.bind(this);
    this.renderPrintTemplate = this.renderPrintTemplate.bind(this);
    this.renderPrintButton = this.renderPrintButton.bind(this);
    this.promoCodeValidate = this.promoCodeValidate.bind(this);
    this.removePromo = this.removePromo.bind(this);
  }

  componentDidMount() {
    const { currentBooking, chargesData } = this.props;
    let tms_ccd_collections_cashreceipt_dtl = {};
    if (currentBooking && currentBooking.tms_ccd_collections_cashreceipt_dtl) {
      tms_ccd_collections_cashreceipt_dtl =
        currentBooking.tms_ccd_collections_cashreceipt_dtl;
      if (tms_ccd_collections_cashreceipt_dtl.ccd_receipt_no) {
        tms_ccd_collections_cashreceipt_dtl.padded_or = true;
      }
      this.props.initialize(tms_ccd_collections_cashreceipt_dtl);
    }
    if (chargesData) {
      let hash =
        this.props.formValues && this.props.formValues.values
          ? _.cloneDeep(this.props.formValues.values)
          : {};
      hash["freight_charge"] = chargesData.frt
        ? parseFloat(chargesData.frt)
        : 0;
      hash["vat"] = chargesData.vat ? parseFloat(chargesData.vat) : 0;
      hash["disbursement_fee"] = chargesData.df
        ? parseFloat(chargesData.df)
        : 0;
      hash["vas"] = chargesData.vas ? parseFloat(chargesData.vas) : 0;
      hash["valuation_charge"] = chargesData.dvfee
        ? parseFloat(chargesData.dvfee)
        : 0;
      hash["remittance"] = chargesData.remit
        ? parseFloat(chargesData.remit)
        : 0;
      hash["discount"] = chargesData.disc ? parseFloat(chargesData.disc) : 0;
      hash["voided_amount"] = chargesData.void
        ? parseFloat(chargesData.void)
        : 0;
      hash["cod_fee"] = chargesData.cash ? parseFloat(chargesData.cash) : 0;
      hash["ras_odz"] = chargesData.ras ? parseFloat(chargesData.ras) : 0;
      hash["ccd_receipt_amount"] =
        hash["freight_charge"] +
        hash["vat"] +
        hash["disbursement_fee"] +
        hash["vas"] +
        hash["valuation_charge"] +
        hash["remittance"] +
        hash["cod_fee"] +
        hash["ras_odz"] -
        hash["discount"];
      if (
        currentBooking &&
        currentBooking.tms_ccd_collections_cashreceipt_dtl
      ) {
        hash["ccd_receipt_no"] =
          tms_ccd_collections_cashreceipt_dtl.ccd_receipt_no;
        if (tms_ccd_collections_cashreceipt_dtl.ccd_receipt_no) {
          hash["padded_or"] = true;
        }
      }
      this.props.initialize(hash);
    } else {
      if (currentBooking.tms_br_booking_request_hdr) {
        const brId = currentBooking.tms_br_booking_request_hdr.br_request_id;
        this.props.getCalculatedCharges(brId);
      }
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const { currentBooking } = this.props;
    if (currentBooking !== nextProps.currentBooking) {
      if (
        nextProps.currentBooking &&
        nextProps.currentBooking.tms_ccd_collections_cashreceipt_dtl
      ) {
        this.props.initialize(
          nextProps.currentBooking.tms_ccd_collections_cashreceipt_dtl
        );
      }
    }
    if (
      nextProps.chargesData &&
      this.props.chargesData !== nextProps.chargesData &&
      this.props.formValues
    ) {
      let hash = this.props.formValues.values
        ? _.cloneDeep(this.props.formValues.values)
        : {};
      hash["freight_charge"] = nextProps.chargesData.frt
        ? parseFloat(nextProps.chargesData.frt)
        : 0;
      hash["vat"] = nextProps.chargesData.vat
        ? parseFloat(nextProps.chargesData.vat)
        : 0;
      hash["disbursement_fee"] = nextProps.chargesData.df
        ? parseFloat(nextProps.chargesData.df)
        : 0;
      hash["vas"] = nextProps.chargesData.vas
        ? parseFloat(nextProps.chargesData.vas)
        : 0;
      hash["valuation_charge"] = nextProps.chargesData.dvfee
        ? parseFloat(nextProps.chargesData.dvfee)
        : 0;
      hash["remittance"] = nextProps.chargesData.remit
        ? parseFloat(nextProps.chargesData.remit)
        : 0;
      hash["discount"] = nextProps.chargesData.disc
        ? parseFloat(nextProps.chargesData.disc)
        : 0;
      hash["voided_amount"] = nextProps.chargesData.void
        ? parseFloat(nextProps.chargesData.void)
        : 0;
      hash["cod_fee"] = nextProps.chargesData.cash
        ? parseFloat(nextProps.chargesData.cash)
        : 0;
      hash["ras_odz"] = nextProps.chargesData.ras
        ? parseFloat(nextProps.chargesData.ras)
        : 0;
      hash["ccd_receipt_amount"] =
        hash["freight_charge"] +
        hash["vat"] +
        hash["disbursement_fee"] +
        hash["vas"] +
        hash["valuation_charge"] +
        hash["remittance"] +
        hash["cod_fee"] +
        hash["ras_odz"] -
        hash["discount"];
      this.props.initialize(hash);
    }

    if (
      nextProps.isPromoRequest !== this.props.isPromoRequest &&
      this.props.isPromoRequest
    ) {
      if (!nextProps.isPromoValid && this.props.formValues) {
        let hash = _.cloneDeep(this.props.formValues.values);
        hash["br_promo_code"] = "";
        this.props.initialize(hash);
      }
    }
  }

  inputChange(e) {
    let hash = this.props.formValues.values;
    if (e.value) {
      hash[e.name] = parseInt(e.value);
      hash.total =
        parseFloat(hash.cash ? hash.cash : 0) +
        parseFloat(hash.card ? hash.card : 0) +
        parseFloat(hash.eWallet ? hash.eWallet : 0);
      hash.change = 0;
      if (hash.total && hash.ccd_receipt_amount) {
        hash.change = parseFloat(hash.total - hash.ccd_receipt_amount).toFixed(
          2
        );
      }
    }
  }

  toggle() {
    this.setState({ open: !this.state.open });
  }

  stepBack() {
    this.props.updateStep(3);
  }

  saveCharge(values, status) {
    const brId = getValue("br_id");
    const { currentBooking } = this.props;
    if (
      currentBooking &&
      currentBooking.tms_br_booking_request_hdr &&
      currentBooking.tms_br_booking_request_hdr.br_status !== "Incomplete"
    ) {
      this.props.updateStep(1);
    } else {
      if (
        currentBooking &&
        currentBooking.tms_ccd_collections_cashreceipt_dtl
      ) {
        this.props.updateCharges(values, brId, status);
      } else {
        this.props.createCharges(values, brId, status);
      }
    }
  }

  formSubmit(values) {
    const brId = getValue("br_id");
    const { currentBooking } = this.props;
    if (
      currentBooking &&
      currentBooking.tms_br_booking_request_hdr &&
      currentBooking.tms_br_booking_request_hdr.br_status !== "Incomplete"
    ) {
      this.props.updateStep(1);
    } else {
      if (
        currentBooking &&
        currentBooking.tms_ccd_collections_cashreceipt_dtl
      ) {
        this.props.updateCharges(values, brId, "Confirmed");
      } else {
        this.props.createCharges(values, brId, "Confirmed");
      }
    }
  }

  print(values) {
    const brId = getValue("br_id");
    const { currentBooking } = this.props;
    if (
      currentBooking &&
      currentBooking.tms_br_booking_request_hdr &&
      currentBooking.tms_br_booking_request_hdr.br_status !== "Incomplete"
    ) {
      // this.props.updateStep(1)
    } else {
      if (
        currentBooking &&
        currentBooking.tms_ccd_collections_cashreceipt_dtl
      ) {
        this.props.updateCharges(values, brId, "Print & Confirmed");
      } else {
        this.props.createCharges(values, brId, "Print & Confirmed");
      }
    }
    return new Promise((resolve, reject) => {
      setTimeout(function () {
        resolve();
      }, 1000);
    });
  }

  renderPrintTemplate(values, paymode) {
    const { currentUser, currentBooking } = this.props;

    if (paymode === "CSH") {
      return (
        <Reports
          ref={(el) => (this.componentRef = el)}
          booking={currentBooking}
          currentBranch={JSON.parse(getValue("currentBranch") || "{}")}
          formValues={values}
          currentUser={currentUser}
        />
      );
    } else {
      return <NoPrintTemplate ref={(el) => (this.componentRef = el)} />;
    }
  }

  renderPrintButton(paymode) {
    const { handleSubmit, t } = this.props;

    if (paymode === "CSH") {
      return (
        <ReactToPrint
          trigger={() => (
            <button type="button" className="secondary left-margin">
              {t("charges:confirmAndPrint")}
            </button>
          )}
          content={() => this.componentRef}
          onBeforeGetContent={handleSubmit((values) => this.print(values))}
        />
      );
    }
  }

  promoCodeValidate() {
    const brId = getValue("br_id");
    const { formValues, validatePromoCode } = this.props;
    if (formValues && formValues.values.br_promo_code) {
      validatePromoCode(brId, {
        br_promo_code: formValues.values.br_promo_code,
      });
    }
  }

  removePromo() {
    const { currentBooking } = this.props;
    if (
      currentBooking &&
      currentBooking.tms_br_booking_request_hdr &&
      currentBooking.tms_br_booking_request_hdr.br_status === "Incomplete"
    ) {
      this.props.removePromoCode(getValue("br_id"));
      let hash = _.cloneDeep(this.props.formValues.values);
      hash["br_promo_code"] = "";
      this.props.initialize(hash);
    }
  }

  promoSection(t, currentBooking) {
    if (currentBooking.tms_br_booking_request_hdr.br_promo_code) {
      return (
        <Label as="a" onClick={this.removePromo}>
          {currentBooking.tms_br_booking_request_hdr.br_promo_code}{" "}
          {currentBooking.tms_br_booking_request_hdr.br_status ===
            "Incomplete" && <Icon name="delete" />}{" "}
        </Label>
      );
    }

    if (
      currentBooking &&
      currentBooking.tms_br_booking_request_hdr &&
      currentBooking.tms_br_booking_request_hdr.br_status === "Incomplete"
    ) {
      return (
        <div className="col-3-field full-width">
          <Field
            name="br_promo_code"
            component={InputField}
            placeholder="Promo code"
          />
          <button
            type="button"
            className="primary left-margin btn-small"
            onClick={this.promoCodeValidate}
          >
            {t("charges:apply")}
          </button>
        </div>
      );
    }
  }

  render() {
    const { handleSubmit, currentBooking, t, tariff, isRequested } = this.props;
    const paymode =
      currentBooking &&
      currentBooking.tms_br_booking_request_hdr &&
      currentBooking.tms_br_booking_request_hdr.br_payment_type.value;
    let values =
      this.props.formValues && this.props.formValues.values
        ? this.props.formValues.values
        : {};
    const disabledDropDown = paymode === 'CRD'
    return (
      <form onSubmit={handleSubmit(this.formSubmit)}>
        <div className="charges-wrapper">
          <OrderHeader>
            <Grid.Row>
              <Grid.Column width={7}>
                <h3 className="sub-head">
                  <strong>{t("charges:charges")}</strong>
                </h3>
              </Grid.Column>
            </Grid.Row>
            {paymode === "CSH" && (
              <Grid.Row className="no-padding">
                <Grid.Column width={7}>
                  <Field
                    name="padded_or"
                    component={Checkbox}
                    type="checkbox"
                    label={t("charges:padded")}
                  />
                </Grid.Column>
                <Grid.Column width={7}>
                  <Field
                    name="ccd_receipt_no"
                    readOnly={!values.padded_or}
                    component={InputField}
                    label={t("charges:or/arNo")}
                  />
                </Grid.Column>
              </Grid.Row>
            )}
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  amountField={true}
                  readOnly={true}
                  name="freight_charge"
                  component={InputField}
                  label={t("charges:freightCharge")}
                  strong={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  amountField={true}
                  name="disbursement_fee"
                  readOnly={true}
                  component={InputField}
                  label={t("charges:disbursementFee")}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  amountField={true}
                  name="vas"
                  readOnly={true}
                  component={InputField}
                  label={t("charges:vas")}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  name="valuation_charge"
                  readOnly={true}
                  amountField={true}
                  component={InputField}
                  label={t("charges:valuationCharge")}
                />
              </Grid.Column>
            </Grid.Row>{" "}
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  name="ras_odz"
                  readOnly={true}
                  amountField={true}
                  component={InputField}
                  label={t("charges:ras/odz")}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  name="cod_fee"
                  readOnly={true}
                  amountField={true}
                  component={InputField}
                  label={t("charges:codFee")}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  amountField={true}
                  readOnly={true}
                  name="vat"
                  component={InputField}
                  label={t("charges:vat")}
                  strong={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  name="remittance"
                  readOnly={true}
                  amountField={true}
                  component={InputField}
                  label={t("charges:forRemittance")}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  amountField={true}
                  name="discount"
                  readOnly={true}
                  component={InputField}
                  label={t("charges:discount")}
                />
              </Grid.Column>
              <Grid.Column width={3}>
                {this.promoSection(t, currentBooking)}
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7} className="bottom-line">
                <Field
                  amountField={true}
                  name="voided_amount"
                  readOnly={true}
                  component={InputField}
                  label={t("charges:voidedAmount")}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding ">
              <Grid.Column width={7}>
                <Field
                  amountField={true}
                  name="ccd_receipt_amount"
                  readOnly={true}
                  component={InputField}
                  label={t("charges:totalAmountDue")}
                  strong={true}
                />
              </Grid.Column>
              <Grid.Column width={3} className="no-label">
                <Field
                  amountField={true}
                  name="currency"
                  component={InputField}
                  placeholder="PHP"
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={7}>
                <h5>{t("charges:amountTendered")}</h5>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7} className="italic-label">
                <Field
                  type="number"
                  amountField={true}
                  onChange={(e) => {
                    this.inputChange(e.target);
                  }}
                  name="cash"
                  component={InputField}
                  label={t("charges:cash")}
                  readOnly={disabledDropDown}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7} className="italic-label">
                <Field
                  type="number"
                  amountField={true}
                  onChange={(e) => {
                    this.inputChange(e.target);
                  }}
                  name="instrument_no"
                  component={InputField}
                  label={t("charges:instrumentNo.")}
                  readOnly={disabledDropDown}
                />
              </Grid.Column>
              <Grid.Column width={3} className="no-label">
                <Field
                  name="authcode"
                  component={InputField}
                  placeholder="authorization code"
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7} className="bottom-line">
                <Field
                  amountField={true}
                  readOnly={true}
                  name="total"
                  component={InputField}
                  label={t("charges:total")}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={7}>
                <Field
                  amountField={true}
                  readOnly={true}
                  name="change"
                  component={InputField}
                  label={t("charges:change")}
                />
              </Grid.Column>
              <Grid.Column width={7}>
                <div>
                  <Popup
                    trigger={
                      <button type="button" className="link-button secondary">
                        {t("charges:tariffDtl")}
                      </button>
                    }
                    header="Tariff"
                    description={
                      <div>
                        <Table celled>
                          <Table.Header>
                            <Table.Row>
                              <Table.HeaderCell>
                                {t("charges:contractId")}
                              </Table.HeaderCell>
                              <Table.HeaderCell>
                                {t("charges:tariffId")}{" "}
                              </Table.HeaderCell>
                              <Table.HeaderCell>
                                {t("charges:billAmt")}
                              </Table.HeaderCell>
                            </Table.Row>
                          </Table.Header>
                          <Table.Body>
                            {_.map(tariff, (item, index) => {
                              return (
                                <Table.Row key={index}>
                                  <Table.Cell>
                                    {item.brctd_contract_id}
                                  </Table.Cell>
                                  <Table.Cell>
                                    {item.brctd_tariff_id}
                                  </Table.Cell>
                                  <Table.Cell>
                                    {item.brctd_rate_for_billable_weight}
                                  </Table.Cell>
                                </Table.Row>
                              );
                            })}
                          </Table.Body>
                        </Table>
                      </div>
                    }
                  />
                </div>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={12}>
                <div className="doc-action left-align">
                  <button
                    type="button"
                    className="link-button"
                    onClick={this.stepBack}
                  >
                    {t("charges:back")}
                  </button>
                  <button
                    type="button"
                    className="primary"
                    disabled={isRequested}
                    onClick={handleSubmit((values) =>
                      this.saveCharge(values, "save")
                    )}
                  >
                    {" "}
                    {t("charges:save")}
                  </button>
                  <button
                    disabled={isRequested}
                    type="submit"
                    className="secondary left-margin"
                  >
                    {t("charges:confirm")}{" "}
                  </button>
                  {this.renderPrintButton(paymode)}
                </div>
                <div>
                  <div style={{ display: "none" }}>
                    {this.renderPrintTemplate(values, paymode)}
                  </div>
                </div>
              </Grid.Column>
            </Grid.Row>
          </OrderHeader>
        </div>
      </form>
    );
  }
}

Charges = reduxForm({
  form: "ChargesForm",
  validate,
})(Charges);

const mapDispatchToProps = (dispatch) => ({
  updateStep: (step) => dispatch(bookingActions.updateStep(step)),
  createCharges: (params, brId, status) =>
    dispatch(chargesActions.create(params, brId, status)),
  updateCharges: (params, brId, status) =>
    dispatch(chargesActions.update(params, brId, status)),
  getCalculatedCharges: (brid) =>
    dispatch(chargesActions.getCalculatedCharges(brid)),
  validatePromoCode: (params, brId) =>
    dispatch(validatePromoCode(params, brId)),
  removePromoCode: (brId) => dispatch(removePromoCode(brId)),
});

const mapStateToProps = (state) => ({
  formValues: state.form.ChargesForm,
  currentBooking: state.bookingReducer.currentBooking,
  chargesData: state.bookingReducer.chargesData,
  tariff: state.bookingReducer.tariff,
  currentUser: state.loginReducer.user,
  isRequested: state.bookingReducer.isRequested,
  isPromoValid: state.bookingReducer.isPromoValid,
  isPromoRequest: state.bookingReducer.isPromoRequest,
});

export default compose(
  withTranslation("charges"),
  connect(mapStateToProps, mapDispatchToProps)
)(Charges);
