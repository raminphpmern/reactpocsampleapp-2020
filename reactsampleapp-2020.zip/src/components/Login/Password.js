import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Field } from 'redux-form';
import inputField from 'components/Common/InputField';
import { userLogout, passwordLogin } from 'actions/loginAction';
import history from 'routes/history';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

const validate = values => {
  const errors = {}

  errors.password = !values.password

  return errors;
}

class Password extends Component {
  constructor(props) {
    super(props)
    this.formSubmit = this.formSubmit.bind(this)
  }

  formSubmit(values) {
    if (this.props.currentUser) {
      this.props.create({ password: values.password, username: this.props.currentUser.username })
    }
  }
  changeUser() {
    this.props.logout()
  }

  componentDidMount() {
    if (this.props.currentUser && this.props.currentUser.loggedIn) {
      history.push('/');
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.currentUser && nextProps.currentUser.loggedIn) {
      history.push('/');
    }
  }

  render() {
    const { handleSubmit } = this.props
    return (
      <div>
        <div className="login-wrap">
          <h2>Enter Password</h2>
          <form onSubmit={handleSubmit(this.formSubmit)} autoComplete="off">
            <Field tabIndex="0" autoFocus label="Password" id="password" name="password" type="password" component={inputField} />
            <div className="input_field">
              <div className="actions">
                <span>
                  {<Link to="/login" className="change-user" onClick={() => this.changeUser()}>Change User</Link>}
                </span>
                <button type="submit">Login</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    )
  }
}

Password.propTypes = {
  logout: PropTypes.func.isRequired,
  create: PropTypes.func.isRequired,
  currentUser: PropTypes.object,
}

Password = reduxForm({
  form: 'PasswordForm',
  validate
})(Password);

const mapDispatchToProps = (dispatch) => ({
  logout: () => dispatch(userLogout()),
  create: (values) => dispatch(passwordLogin(values))
})

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
})

export default connect(mapStateToProps, mapDispatchToProps)(Password)
