import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field } from 'redux-form';
import inputField from 'components/Common/InputField';
import { userLogin, initializeUser } from 'actions/loginAction';
import history from 'routes/history';
import PropTypes from 'prop-types';
import './login.css'

const validate = values => {
  const errors = {};
  errors.username = !values.username

  return errors
}

class Login extends Component {
  constructor(props) {
    super(props)
    this.formSubmit = this.formSubmit.bind(this)
  }

  formSubmit(values) {
    this.props.login(values)
  }

  componentDidMount() {
    if (this.props.currentUser) {
      if (this.props.currentUser.loggedIn) {
        history.push('/');
        return false
      }
      if (this.props.currentUser.newUser) {
        history.push('/create-password');
      } else {
        history.push('/password');
      }
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps && nextProps.currentUser) {
      if (nextProps.currentUser.newUser) {
        history.push('/create-password');
      } else {
        history.push('/password');
      }
    }
  }

  render() {
    const { handleSubmit } = this.props
    return (
      <div>
        <div className="login-wrap">
          <h2>Sign in</h2>
          <form onSubmit={handleSubmit(this.formSubmit)}>
            <Field tabIndex="0" autoFocus label="Username" name="username" component={inputField} placeholder="" id="username" />
            <div className="actions">
              <span></span>
              <button type="submit">Login</button>
            </div>
          </form>
        </div>
      </div>
    )
  }
}

Login.propTypes = {
  login: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  currentUser: PropTypes.object
}

Login = reduxForm({
  form: 'LoginForm',
  validate
})(Login);

const mapDispatchToProps = (dispatch) => ({
  login: (data) => dispatch(userLogin(data)),
  clearData: () => dispatch(initializeUser())
})

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
})

export default connect(mapStateToProps, mapDispatchToProps)(Login)
