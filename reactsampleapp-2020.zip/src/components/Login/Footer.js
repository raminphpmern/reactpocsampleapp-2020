import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div className="landing-footer">
        <div>
          <span>All Rights Reserved. &copy; Copyright 2019. Ramco Systems.</span>
        </div>
      </div>
    )
  }
}