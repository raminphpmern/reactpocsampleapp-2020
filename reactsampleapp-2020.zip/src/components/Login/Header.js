import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import Logo from 'images/ramco-logo-white.png';

export default class Header extends Component {
  render() {
    return (
      <div>
        <div className="header version-details">
          <Link to="/" className="brand">
            <img src={Logo} alt="logo" />
          </Link>
        </div>
      </div>
    )
  }
}