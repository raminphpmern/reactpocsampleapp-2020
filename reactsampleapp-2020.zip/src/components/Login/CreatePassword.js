import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Field } from 'redux-form';
import inputField from 'components/Common/InputField';
import { createPassword, userLogout } from 'actions/loginAction';
import history from 'routes/history';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

const validate = values => {
  const errors = {}
  errors.new_password = !values.new_password
  if (!values.confirm_password)
    errors.confirm_password = true
  else if (values.confirm_password !== values.new_password) {
    errors.confirm_password = "Password mismatched"
    errors.new_password = true
  }
  return errors
}

class CreatePassword extends Component {
  constructor(props) {
    super(props)
    this.formSubmit = this.formSubmit.bind(this)
  }

  formSubmit(values) {
    if (this.props.currentUser) {
      this.props.create({ ...values, username: this.props.currentUser.username })
    }
  }

  componentDidMount() {
    if (this.props.currentUser) {
      if (this.props.currentUser.newUser) {
        history.push('/create-password');
      } else {
        history.push('/');
      }
    }
  }

  changeUser() {
    this.props.logout()
  }

  render() {
    const { handleSubmit } = this.props
    return (
      <div>
        <div className="login-wrap">
          <h2>Create Password</h2>
          <form onSubmit={handleSubmit(this.formSubmit)} autoComplete="off">

            <Field label="New Password" name="new_password" type="password" component={inputField} placeholder="" id="newPassword" />
            <Field label="Confirm Password" name="confirm_password" type="password" component={inputField} placeholder="" id="confirmPassword" />

            <div className="input_field">
              <div className="actions">
                <span>
                  {<Link to="/login" className="change-user" onClick={() => this.changeUser()}>Change User</Link>}
                </span>
                <button type="submit">Login</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    )
  }
}

CreatePassword.propTypes = {
  create: PropTypes.func.isRequired,
  logout: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  currentUser: PropTypes.object
}

CreatePassword = reduxForm({
  form: 'CreatePasswordForm',
  validate
})(CreatePassword);

const mapDispatchToProps = (dispatch) => ({
  create: (values) => dispatch(createPassword(values)),
  logout: () => dispatch(userLogout())
})

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user
})

export default connect(mapStateToProps, mapDispatchToProps)(CreatePassword)
