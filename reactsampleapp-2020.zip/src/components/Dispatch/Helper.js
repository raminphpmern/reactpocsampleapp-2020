import _ from 'lodash';

export function formatDispatchFormValues(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["location"])
      hash["location"] = hash["location"].value;
    if (hash["doc_type"])
      hash["doc_type"] = hash["doc_type"].value;
    if (hash["service_type"])
      hash["service_type"] = hash["service_type"].value;
    if (hash["subservice_type"])
      hash["subservice_type"] = hash["subservice_type"].value;
    if (hash["request_location"])
      hash["request_location"] = hash["request_location"].value;
    return hash
  } else {
    return {}
  }
}

export function buildDispatchSearchData(selectedCustomerCode, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  tempHash['customer_code'] = selectedCustomerCode
  return tempHash
}

export function showDispatchData(data, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  _.merge(tempHash, data)
  return tempHash
}

export function formalHelpOnCustomer(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["wms_customer_status"])
      hash["wms_customer_status"] = hash["wms_customer_status"].value;
    return hash
  } else {
    return {}
  }
}