import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { withRouter } from "react-router-dom";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import * as dispatchDocumentAction from "actions/dispatchDocumentAction";
import i18n from 'i18n';
import "./DispatchView.css";
import _ from "lodash";

const columns = [
  { key: "ddtd_thu_id", name: i18n.t('ThuGrid:thuId') },
  { key: "ddtd_thu_qty", name: i18n.t('ThuGrid:thuQty') },
  { key: "ddtd_thu_vol", name: i18n.t('ThuGrid:volume') },
  { key: "ddtsd_gross_weight", name: i18n.t('ThuGrid:grossWeight') },
]

class ResultTableTHU extends Component {
  constructor(props) {
    super(props)
    this.state = {
      defaultValues: null
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
  }

  changeLimit(pageNo, limit) {
    const { match } = this.props
    if (match.path === "/dispatchDocument/create/:ddId") {
      let docnos = _.map(this.props.result_link_house, 'ddh_dispatch_doc_no')
      this.props.loadViewTHUDetails({ 'doc_no': docnos.join() }, pageNo, limit)
    }
    else if (match.path === "/dispatchDocument/view/:ddId") {
      const docno = this.props.dispatchViewForm.values
      this.props.loadViewTHUDetails({ 'doc_no': docno.ddh_dispatch_doc_no }, pageNo, limit)
    }
  }

  paginationHandler(pageNo, limit) {
    const { match } = this.props
    if (match.path === "/dispatchDocument/create/:ddId") {
      let docnos = _.map(this.props.result_link_house, 'ddh_dispatch_doc_no')
      this.props.loadViewTHUDetails({ 'doc_no': docnos.join() }, pageNo, limit)
    }
    else if (match.path === "/dispatchDocument/view/:ddId") {
      const docno = this.props.dispatchViewForm.values
      this.props.loadViewTHUDetails({ 'doc_no': docno.ddh_dispatch_doc_no }, pageNo, limit)
    }
  }

  render() {
    const { result, totalPage, totalRecord, resetTHUResults } = this.props
    const { defaultValues } = this.state
    return (
      <div>
        <Grid stackable >
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  columns={columns}
                  rows={result}
                  rowKey="ddtd_thu_id"
                  width={250}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  defaultValues={defaultValues}
                  enableExport={true}
                  initialize={resetTHUResults}
                  showCheckbox={false}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  loadViewTHUDetails: (data, pageNo, limit) => dispatch(dispatchDocumentAction.loadViewTHUDetails(data, pageNo, limit)),
  resetTHUResults: () => dispatch(dispatchDocumentAction.resetTHUResults())
})

const mapStateToProps = state => ({
  result: state.dispatchReducer.result_thu,
  totalPage: state.dispatchReducer.totalPage_thu,
  totalRecord: state.dispatchReducer.totalRecord_thu,
  dispatchCreateForm: state.form.DispatchCreateForm,
  dispatchViewForm: state.form.DispatchViewForm,
  result_link_house: state.dispatchReducer.result_link_house
})

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(ResultTableTHU))