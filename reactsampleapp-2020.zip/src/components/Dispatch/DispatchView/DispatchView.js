import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import InputField from "components/Common/InputField";
import { reduxForm, Field, formValueSelector } from "redux-form";
import { Grid, Accordion, Icon } from "semantic-ui-react";
import ResultTableTHU from "./ResultTableTHU";
import { showDispatchData } from "../Helper";
import { connect } from "react-redux";
import * as dispatchDocumentAction from "actions/dispatchDocumentAction";
import ConsignmentFields from "./ConsignmentFields";
import HblFeilds from "./HblFeilds";
import HawbFields from "./HawbFields";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import _ from "lodash";
import "./DispatchView.css";

class DispatchView extends Component {

  componentDidMount() {
    const { currentUser, match: { params } } = this.props
    const locations = (currentUser && currentUser.locations) || [];
    if (locations.length > 0) {
      this.props.initialize({ location: locations[0].value, division: locations[0].wms_loc_code });
    }
    const dd_no = params.ddId;
    this.props.getDetails(dd_no, true);
    this.props.loadViewTHUDetails({ 'doc_no': dd_no }, 1, 10, true);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.formValues.values !== nextProps.dd_data) {
      let hash = _.cloneDeep(nextProps.formValues.values)
      this.props.initialize(showDispatchData(nextProps.dd_data, hash));
    }
  }

  render() {
    const { docType, t } = this.props
    return (
      <div>
        <form className="dispatch">
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="division"
                  component={InputField}
                  label={t('division')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="location"
                  component={InputField}
                  label={t('location')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4} />
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_status"
                  component={InputField}
                  label={t('status')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_type"
                  component={InputField}
                  label={t('dispatchDocumentType')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ddh_reference_doc_no"
                  component={InputField}
                  label={t('bookingRequestNo')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column className="dispatch-create">
                <h6 className="custom-title">
                  <span>{(docType === "Consignment Note" ? 'Consignment Note details' : 'House details')}</span>
                </h6>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                {(docType === "Consignment Note") &&
                  <ConsignmentFields />
                }
                {(docType === "HBL") &&
                  <HblFeilds />
                }
                {(docType === "HAWB") &&
                  <HawbFields />
                }
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="ddh_declared_goods_value"
                  component={InputField}
                  label={t('declaredValueofGoods')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ddh_currency"
                  component={InputField}
                  label={t('currency')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ddh_subservice_type"
                  component={InputField}
                  label={t('subServiceType')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="ddh_spl_instructions"
                  component={InputField}
                  label={t('specialInstruction')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ddh_service_type"
                  component={InputField}
                  label={t('serviceType')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column>
                <Accordion>
                  <Accordion.Title
                    active={true}
                    index={1}>
                    <h3 className="sub-head">
                      <strong>
                        <Icon name='dropdown' />
                        {t('accordionTitle')}
                      </strong>
                    </h3>
                  </Accordion.Title>
                  <Accordion.Content active={true}>
                    <ResultTableTHU />
                  </Accordion.Content>
                </Accordion>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div >
    );
  }
}

DispatchView = reduxForm({
  form: "DispatchViewForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
})(DispatchView);

const selector = formValueSelector('DispatchViewForm');
DispatchView = connect(state => {
  const docType = selector(state, 'ddh_dispatch_doc_type');
  return {
    docType,
  };
})(DispatchView);

const mapDispatchToProps = dispatch => ({
  getDetails: (dd_no) =>
    dispatch(dispatchDocumentAction.loadSelectedView(dd_no)),
  loadViewTHUDetails: (dd_no, pageNo, limit) => dispatch(dispatchDocumentAction.loadViewTHUDetails(dd_no, pageNo, limit))
});

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
  dd_data: state.dispatchReducer.dd_data,
  formValues: state.form.DispatchViewForm
});

export default compose(withTranslation('dispatchViewForm'), connect(mapStateToProps, mapDispatchToProps))(withRouter(DispatchView));