import React from "react";
import InputField from "components/Common/InputField";
import DateTimePicker from "components/Common/DateTimePicker";
import { Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import { withTranslation } from 'react-i18next';

const HawbFields = (props) => {
  const { t } = props
  return (
    <div>
      <Grid stackable>
        <Grid.Row className="no-padding" >
          <Grid.Column width={4}>
            <Field
              name="ddh_dispatch_doc_no"
              component={InputField}
              label={t('hawbNo')}
              readOnly={true}
            />
          </Grid.Column>
          <Grid.Column width={4}>
            <Field
              name="ddh_dispatch_doc_date"
              component={DateTimePicker}
              disabled={true}
              label={t('hawbDate')}
            />
          </Grid.Column>
          <Grid.Column width={4}>
            <Field
              name="ddh_mawb_of_hawb"
              component={InputField}
              readOnly={true}
              label={t('mawbNo')}
            />
          </Grid.Column>
          <Grid.Column width={4}>
            <Field
              name="ddh_dispatch_doc_date"
              component={DateTimePicker}
              disabled={true}
              label={t('mawbDate')}
            />
          </Grid.Column>
        </Grid.Row>
      </Grid>
    </div >
  );
}

export default withTranslation('dispatchViewForm')(HawbFields);