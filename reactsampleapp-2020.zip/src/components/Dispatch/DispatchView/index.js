import React from "react";
import Wrapper from "components/LandingPage/Wrapper";
import DispatchView from "./DispatchView";
import { withTranslation } from 'react-i18next';
import { Icon } from 'semantic-ui-react'
import "./DispatchView.css";

const DispatchViewForm = (props) => {
  const { t } = props
  return (
    <Wrapper DisableBranch={true} className="dispatch-head">
      <div className="dispatch-head">
        <h3>{t('title')}</h3>
        <div className="back-link">
          <a href="javascript: false" onClick={props.history.goBack}>
            <Icon disabled name='arrow left' />
            {t('translation:back')}</a>
        </div>
      </div>
      <div className="dispatch-wrapper">
        <DispatchView />
      </div>
    </Wrapper>
  )
}

export default withTranslation('dispatchViewForm')(DispatchViewForm)