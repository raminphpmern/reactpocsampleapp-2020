import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import * as dispatchDocumentAction from "actions/dispatchDocumentAction";
import { formatDispatchFormValues } from "../Helper";
import i18n from 'i18n';
import "./dispatch.css";

class LinkFormatter extends React.Component {
  render() {
    const doctype = this.props.dependentValues.rowData.ddh_dispatch_doc_type;
    const docno = this.props.dependentValues.rowData.ddh_dispatch_doc_no;
    const ddcreate = ['MBL', "MAWB"];
    if (ddcreate.indexOf(doctype) === -1) {
      return <Link to={`/dispatchDocument/view/${docno}`}>{docno}</Link>
    } else {
      return <Link to={`/dispatchDocument/create/${docno}`}>{docno}</Link>
    }
  }
};

const columns = [
  {
    key: "ddh_dispatch_doc_no", name: i18n.t("dispatchSearchGrid:dispatchDocumentNo"), formatter: LinkFormatter, getRowMetaData: (rowData, columnInfo) => {
      return { rowData, columnInfo };
    }
  },
  { key: "ddh_dispatch_doc_type", name: i18n.t("dispatchSearchGrid:dispatchDocumentType") },
  { key: "ddh_customer_id", name: i18n.t("dispatchSearchGrid:customerCode") },
  { key: "ddh_location", name: i18n.t("dispatchSearchGrid:bookingRequestLocation") },
]

class ResultTable extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selectedIds: null,
      defaultValues: null
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
  }

  changeLimit(pageNo, limit) {
    this.props.search(formatDispatchFormValues(this.props.dispatchDocumentForm.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.search(formatDispatchFormValues(this.props.dispatchDocumentForm.values), pageNo, limit);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  render() {
    const { result, totalPage, totalRecord, resetData } = this.props
    const { defaultValues } = this.state
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row >
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  columns={columns}
                  rows={result}
                  rowKey="ddh_dispatch_doc_no"
                  totalPages={totalPage}
                  selectedRows={this.selectedRows}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  defaultValues={defaultValues}
                  enableExport={true}
                  initialize={resetData}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  search: (data, pageNo, limit) => dispatch(dispatchDocumentAction.search(data, pageNo, limit)),
  resetData: () => dispatch(dispatchDocumentAction.resetSearchData())
})

const mapStateToProps = state => ({
  result: state.dispatchReducer.result,
  totalPage: state.dispatchReducer.totalPage,
  totalRecord: state.dispatchReducer.totalRecord,
  dispatchDocumentForm: state.form.DispachDocumentForm,
  ddcreate: state.dispatchReducer.ddcreate
})

export default connect(mapStateToProps, mapDispatchToProps)(ResultTable)