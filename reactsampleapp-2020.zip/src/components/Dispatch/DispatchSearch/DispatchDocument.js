import React, { Component } from "react";
import InputField from "components/Common/InputField";
import Dropdown from "components/Common/Dropdown";
import { reduxForm, Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import { formatDispatchFormValues, buildDispatchSearchData } from "../Helper";
import { search, loadDispatchDefaults, loadMasterDefaults } from "actions/dispatchDocumentAction";
import Popup from "components/Common/Popup";
import HelpOnCustomer from "./HelpOnCustomer";
import { getValue } from "lib/LocalStorage";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import _ from "lodash";
import "./dispatch.css";

class DispachDocument extends Component {
  constructor(props) {
    super(props);
    this.state = {
      customerHelp: false,
    }
    this.formSubmit = this.formSubmit.bind(this);
    this.selectCustomerCode = this.selectCustomerCode.bind(this);
    this.toggle = this.toggle.bind(this);
  }

  componentDidMount() {
    const {
      dispatch_type,
      getDispatchMasterValues,
      getLoadMasterValues,
      service_type,
      subservice_type,
    } = this.props;
    if (dispatch_type.length === 0) {
      getDispatchMasterValues("document_type", "dispatch_type")
    }
    if (service_type.length === 0) {
      getLoadMasterValues("shipment_type", "service_type")
    }
    if (subservice_type.length === 0) {
      getLoadMasterValues("service_mode", "subservice_type")
    }
    if (getValue('currentBranch')) {
      let currentBranch = JSON.parse(getValue('currentBranch') ? getValue('currentBranch') : {})
      if (currentBranch.value) {
        this.props.initialize({ wms_div_code: currentBranch.value, wms_div_loc_code: currentBranch.wms_loc_code });
      }
    }
  }

  formSubmit(values) {
    this.props.dispatchSearch(formatDispatchFormValues(values), 1, 10);
  }

  toggle() {
    this.setState(prevState => ({
      customerHelp: !prevState.customerHelp
    }));
  }

  selectCustomerCode(selectedCustomerCode) {
    let hash = _.cloneDeep(this.props.formValues.values)
    this.props.initialize(buildDispatchSearchData(selectedCustomerCode, hash))
  }

  render() {
    const { handleSubmit, dispatch_type, service_type, subservice_type, t } = this.props;
    return (
      <div className="dispatch">

        <Popup size="fullscreen" open={this.state.customerHelp} close={() => { this.toggle('customerHelp') }}
          header="Help on Customer" description={<HelpOnCustomer close={this.toggle} handleOnSelect={this.selectCustomerCode} />} />

        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row>
              <Grid.Column width={5}>
                <Field
                  name="wms_div_code"
                  component={InputField}
                  label={t('division')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={5}>
                <Field
                  name="wms_div_loc_code"
                  component={InputField}
                  label={t('location')}
                  readOnly={true}
                />
              </Grid.Column>
              {/* TODO :- Currently Disabled. Victor about to come back
               <Grid.Column width={5}>
                <Field
                  name="request_location"
                  component={Dropdown}
                  label={t('bookingRequestLocation')}
                  clearable={true}
                  options={locations}
                />
              </Grid.Column> */}
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={5}>
                <Field
                  name="doc_type"
                  component={Dropdown}
                  label={t('dispatchDocumentType')}
                  options={dispatch_type}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={5}>
                <Field
                  name="doc_no"
                  component={InputField}
                  label={t('dispatchDocumentNo')}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={5}>
                <Field
                  name="customer_code"
                  component={InputField}
                  label={t('customerCode')}
                  iconName="search"
                  handleClick={this.toggle}
                  clearable={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={5}>
                <Field
                  name="service_type"
                  component={Dropdown}
                  label={t('serviceType')}
                  options={service_type}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={5}>
                <Field
                  name="subservice_type"
                  component={Dropdown}
                  label={t('subServiceType')}
                  options={subservice_type}
                  clearable={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='search' type="submit" className="primary">
                    {t('searchBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div >
    );
  }
}

DispachDocument = reduxForm({
  form: "DispachDocumentForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
})(DispachDocument);

const mapDispatchToProps = dispatch => ({
  getDispatchMasterValues: (action, stateName) =>
    dispatch(loadDispatchDefaults(action, stateName)),
  getLoadMasterValues: (action, stateName) =>
    dispatch(loadMasterDefaults(action, stateName)),
  dispatchSearch: (data, pageNo, pageLimit) =>
    dispatch(search(data, pageNo, pageLimit))
});

const mapStateToProps = state => ({
  dispatch_type: state.dispatchReducer.options.dispatch_type,
  service_type: state.dispatchReducer.options.service_type,
  subservice_type: state.dispatchReducer.options.subservice_type,
  formValues: state.form.DispachDocumentForm
});

export default compose(withTranslation('dispatchSearchForm'), connect(mapStateToProps, mapDispatchToProps))(DispachDocument);
