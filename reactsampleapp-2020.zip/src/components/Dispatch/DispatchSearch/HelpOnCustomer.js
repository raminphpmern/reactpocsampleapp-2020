import React, { Component } from "react";
import { reduxForm, Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import DataGrid from "components/Common/DataGrid";
import Dropdown from "components/Common/Dropdown";
import InputField from "components/Common/InputField";
import * as dispatchHelpAction from "actions/dispatchHelpAction";
import { loadDispatchDefaults } from "actions/dispatchDocumentAction";
import { formalHelpOnCustomer } from "../Helper";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import i18n from 'i18n';
import "./dispatch.css";

const columns = [
  { key: "wms_customer_id", name: i18n.t('helpOnCustomerGird:id') },
  { key: "wms_customer_name", name: i18n.t('helpOnCustomerGird:name') },
  { key: "wms_customer_description", name: i18n.t('helpOnCustomerGird:description') },
  { key: "wms_customer_address1", name: i18n.t('helpOnCustomerGird:addressLine1') },
  { key: "wms_customer_address2", name: i18n.t('helpOnCustomerGird:addressLine2') },
  { key: "wms_customer_address3", name: i18n.t('helpOnCustomerGird:addressLine3') },
  { key: "wms_customer_city", name: i18n.t('helpOnCustomerGird:city') },
  { key: "wms_customer_state", name: i18n.t('helpOnCustomerGird:state') },
  { key: "wms_customer_country", name: i18n.t('helpOnCustomerGird:country') },
  { key: "wms_customer_bill_postal_code", name: i18n.t('helpOnCustomerGird:postalCode') },
  { key: "wms_customer_status", name: i18n.t('helpOnCustomerGird:status') },
  { key: "wms_customer_phone1", name: i18n.t('helpOnCustomerGird:phone') },
  { key: "wms_customer_email", name: i18n.t('helpOnCustomerGird:email') },
  { key: "wms_customer_fax", name: i18n.t('helpOnCustomerGird:fax') },
]

class HelpOnCustomer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIds: null,
      defaultValues: null
    };
    this.paginationHandler = this.paginationHandler.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.selectCusomerCode = this.selectCusomerCode.bind(this)
  }

  componentDidMount() {
    const {
      customer_status,
      getDispatchMasterValues,
    } = this.props;
    if (customer_status.length === 0) {
      getDispatchMasterValues("customer_status", "customer_status")
    }
  }

  selectCusomerCode() {
    const { close } = this.props
    const { selectedIds } = this.state
    if (selectedIds !== null) {
      this.props.handleOnSelect(selectedIds[0].wms_customer_id)
      close('help', 'customerHelp')
    }
  }

  changeLimit(pageNo, limit) {
    this.props.loadHelpOnCustomer((this.props.formValues), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.loadHelpOnCustomer((this.props.formValues), pageNo, limit);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }


  formSubmit(values) {
    this.props.loadHelpOnCustomer(formalHelpOnCustomer(values), 1, 10);
  }

  render() {
    const { handleSubmit, result, totalPage, totalRecord, customer_status, t } = this.props
    const { defaultValues } = this.state
    return (
      <form onSubmit={handleSubmit(this.formSubmit)}>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={4}>
              <Field name="wms_customer_id" component={InputField} clearable={true}
                label={t('id')} />
              <Field name="wms_customer_address1" component={InputField} clearable={true}
                label={t('addressLine1')} />
              <Field name="wms_customer_state" component={InputField} clearable={true}
                label={t('state')} />
              <Field name="wms_customer_status" component={Dropdown} clearable={true} options={customer_status} label={t('status')} />
              {/* <Field name="wms_customer_id" component={InputField} clearable={true} label="Customer ID" /> */}
            </Grid.Column>
            <Grid.Column width={4}>
              <Field name="first_name" component={InputField} clearable={true}
                label={t('firstName')} />
              <Field name="wms_customer_address2" component={InputField} clearable={true}
                label={t('addressLine2')} />
              <Field name="wms_customer_country" component={InputField} clearable={true}
                label={t('country')} />
              <Field name="wms_customer_phone1" component={InputField} clearable={true}
                label={t('phone')} />
              {/* <Field name="wms_customer_name" component={InputField} clearable={true} label="Customer Name" /> */}
            </Grid.Column>
            <Grid.Column width={4}>
              <Field name="middle_name" component={InputField} clearable={true}
                label={t('middleName')} />
              <Field name="wms_customer_address3" component={InputField} clearable={true}
                label={t('addressLine3')} />
              <Field name="wms_customer_bill_postal_code" component={InputField} clearable={true} label={t('postalCode')} />
              <Field name="wms_customer_email" component={InputField} clearable={true}
                label={t('email')} />
              <Field name="locDiv" component={InputField} clearable={true}
                label={t('division')} />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field name="last_name" component={InputField} clearable={true}
                label={t('lastName')} />
              <Field name="wms_customer_city" component={InputField} clearable={true}
                label={t('city')} />
              <Field name="wms_customer_description" component={InputField} clearable={true}
                label={t('description')} />
              <Field name="Location" component={InputField} clearable={true}
                label={t('location')} />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="no-padding">
            <Grid.Column width={16} className="no-padding">
              <div className="help-search">
                <button id='search' type="submit" className="primary">{t('searchBtn')}</button>
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row >
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  columns={columns}
                  rows={result}
                  rowKey="wms_customer_id"
                  totalPages={totalPage}
                  selectedRows={this.selectedRows}
                  width={200}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  defaultValues={defaultValues}
                  enableExport={true}
                  singleSelect={true}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row >
            <Grid.Column width={16}>
              <div className="help-submit">
                <button id='select' type="submit" className="primary" onClick={this.selectCusomerCode}>
                  {t('selectBtn')}
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </form >
    )
  }
}

HelpOnCustomer = reduxForm({
  form: 'HelpOnCustomerForm',
})(HelpOnCustomer);

const mapDispatchToProps = (dispatch) => ({
  loadHelpOnCustomer: (params, pageNo, limit) =>
    dispatch(dispatchHelpAction.helpOnCustomerAction(params, pageNo, limit)),
  getDispatchMasterValues: (action, stateName) =>
    dispatch(loadDispatchDefaults(action, stateName)),
})

const mapStateToProps = state => ({
  result: state.dispatchReducer.result_help_customer,
  isRequested: state.dispatchReducer.isRequested,
  customer_status: state.dispatchReducer.options.customer_status,
  totalPage: state.dispatchReducer.totalPage_help_customer,
  totalRecord: state.dispatchReducer.totalRecord_help_customer,
  formValues: state.form.HelpOnCustomerForm,
})

export default compose(withTranslation('helpOnCustomerForm'), connect(mapStateToProps, mapDispatchToProps))(HelpOnCustomer);