import React from "react";
import Wrapper from "components/LandingPage/Wrapper";
import ResultTable from "./ResultTable";
import DispatchDocument from "./DispatchDocument";
import { withTranslation } from 'react-i18next';
import { Icon } from 'semantic-ui-react'
import "./dispatch.css";
import history from 'routes/history';

const DispatchSearch = (props) => {
  const { t } = props
  return (
    <Wrapper DisableBranch={true}>
      <div className="dispatch-search-head">
        <div className='title'>
          <h3>{t('title')}</h3>
        </div>
        <div className="back-link">
          <a href="javascript: false" onClick={props.history.goBack}>
            <Icon disabled name='arrow left' />
            {t('translation:back')}</a>
          <button type="button" onClick={() => history.push('/dispatchDocument/create')} className="secondary btn-small nav-btn">
            <Icon name='add' /> {t('create-link')}
          </button>
        </div>
      </div>
      <div className="dispatch-search-wrapper">
        <DispatchDocument />
        <ResultTable />
      </div>
    </Wrapper>
  )
}
export default withTranslation('dispatchSearchForm')(DispatchSearch)