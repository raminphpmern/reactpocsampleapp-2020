import _ from 'lodash';

export function formatCreateFormValues(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["location"])
      hash["location"] = hash["location"].value
    if (hash["ddh_dispatch_doc_type"])
      hash["ddh_dispatch_doc_type"] = hash["ddh_dispatch_doc_type"].value
    if (values.ddh_dispatch_doc_type_code) {
      if (hash["ddh_dispatch_doc_type_code"])
        hash["ddh_dispatch_doc_type"] = hash["ddh_dispatch_doc_type_code"]
    }
    if (hash["ddh_currency"])
      hash["ddh_currency"] = hash["ddh_currency"].value
    if (hash["ddh_weight_uom"])
      hash["ddh_weight_uom"] = hash["ddh_weight_uom"].value
    if (hash["ddh_volume_uom"])
      hash["ddh_volume_uom"] = hash["ddh_volume_uom"].value
    if (hash["ddh_dispatch_doc_type_link"])
      hash["ddh_dispatch_doc_type_link"] = hash["ddh_dispatch_doc_type_link"].value
    return hash
  } else {
    return {}
  }
}

export function loadSelectedTripCode(selectedTripId, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  tempHash['plpth_trip_plan_id'] = selectedTripId.plpth_trip_plan_id
  tempHash['sd_from_port'] = selectedTripId.sd_from_port
  tempHash['sd_to_port'] = selectedTripId.sd_to_port
  tempHash['sd_total_transit_time'] = selectedTripId.sd_total_transit_time
  tempHash['sd_carrier_id'] = selectedTripId.sd_carrier_id
  tempHash['sd_trip_id'] = selectedTripId.sd_trip_id
  tempHash['plpth_schedule_id'] = selectedTripId.plpth_schedule_id
  return tempHash
}

export function loadSelectedTripCodeByID(selectedTripId, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  tempHash['sd_from_port'] = selectedTripId.sd_from_port
  tempHash['sd_to_port'] = selectedTripId.sd_to_port
  tempHash['sd_total_transit_time'] = selectedTripId.sd_total_transit_time
  tempHash['sd_carrier_id'] = selectedTripId.sd_carrier_id
  tempHash['sd_trip_id'] = selectedTripId.sd_trip_id
  tempHash['plpth_schedule_id'] = selectedTripId.plpth_schedule_id
  return tempHash
}

export function formatHelpTripFormValues(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["br_service_type"])
      hash["br_service_type"] = hash["br_service_type"].value;
    return hash
  }
}