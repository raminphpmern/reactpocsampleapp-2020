import i18n from 'i18n';

export default function validate(values) {
  const errors = {};
  if (!values.ddh_dispatch_doc_type) {
    errors.ddh_dispatch_doc_type = i18n.t('dispatchvalidation:docTypeReq')
  }
  if (!values.plpth_trip_plan_id) {
    errors.plpth_trip_plan_id = i18n.t('dispatchvalidation:tripPlanIdReq')
  }
  if (!values.ddh_dispatch_doc_no) {
    errors.ddh_dispatch_doc_no = i18n.t('dispatchvalidation:masterDocNoReq')
    if (values.ddh_dispatch_doc_type) {
      const docType = values.ddh_dispatch_doc_type
      if (docType.value === 'MBL') {
        errors.ddh_dispatch_doc_no = i18n.t('dispatchvalidation:mblNoReq')
      }
      if (docType.value === 'MAWB') {
        errors.ddh_dispatch_doc_no = i18n.t('dispatchvalidation:mawbNoReq')
      }
    }
  }
  if (!values.ddh_dispatch_doc_date) {
    errors.ddh_dispatch_doc_date = i18n.t('dispatchvalidation:masterDocDateReq')
    if (values.ddh_dispatch_doc_type) {
      const docType = values.ddh_dispatch_doc_type
      if (docType.value === 'MBL') {
        errors.ddh_dispatch_doc_date = i18n.t('dispatchvalidation:mblDateReq')
      }
      if (docType.value === 'MAWB') {
        errors.ddh_dispatch_doc_date = i18n.t('dispatchvalidation:mawbDateReq')
      }
    }
  }
  return errors
}