import React from "react";
import Wrapper from "components/LandingPage/Wrapper";
import DispatchCreate from "./DispatchCreate";
import { withTranslation } from 'react-i18next';
import { Icon } from 'semantic-ui-react';
import "./DispatchCreate.css";

const DispatchCreateForm = (props) => {
  const { t } = props
  return (
    <Wrapper DisableBranch={true} className="dispatch-head">
      <div className="dispatch-head">
        <h3>{t('title')}</h3>
        <div className="back-link">
          <a href="javascript: false" onClick={props.history.goBack}>
            <Icon disabled name='arrow left' />
            {t('translation:back')}</a>
        </div>
      </div>
      <div className="dispatch-wrapper">
        <DispatchCreate />
      </div>
    </Wrapper>
  )
}

export default withTranslation('dispatchCreateForm')(DispatchCreateForm);