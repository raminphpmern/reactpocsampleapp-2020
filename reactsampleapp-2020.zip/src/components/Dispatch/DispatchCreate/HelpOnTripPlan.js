import React, { Component } from "react";
import { Field, reduxForm } from "redux-form";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import Dropdown from "components/Common/Dropdown";
import InputField from "components/Common/InputField";
import DataGrid from "components/Common/DataGrid";
import DateTimePicker from "components/Common/DateTimePicker";
import * as dispatchHelpAction from "actions/dispatchHelpAction";
import * as masterActions from 'actions/masterAction';
import { loadDispatchDefaults, loadMasterDefaults } from "actions/dispatchDocumentAction";
import { formatHelpTripFormValues } from "./Helper";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import i18n from 'i18n';

const columns = [
  { key: "plpth_trip_plan_id", name: i18n.t('helpOnTripGird:id/no') },
  { key: "plpth_trip_plan_status_desc", name: i18n.t('helpOnTripGird:status') },
  { key: "plpth_trip_plan_date", name: i18n.t('helpOnTripGird:date') },
  { key: "plpth_vehicle_id", name: i18n.t('helpOnTripGird:vehicleId') },
  { key: "plpth_equipment_id", name: i18n.t('helpOnTripGird:equipmentId') },
  { key: "plpth_driver_id", name: i18n.t('helpOnTripGird:driverId') },
  { key: "plpth_trip_plan_from", name: i18n.t('helpOnTripGird:fromLocation') },
  { key: "plpth_trip_plan_to", name: i18n.t('helpOnTripGird:toLocation') },
]

class HelpOnTripPlan extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIds: null,
      defaultValues: null,
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.selectTripId = this.selectTripId.bind(this)
  }

  componentDidMount() {
    const {
      dispatch_type,
      getDispatchMasterValues,
      getLoadMasterValues,
      br_service_type,
      tripStatus,
      getTripStatus,
    } = this.props;
    if (dispatch_type.length === 0) {
      getDispatchMasterValues("document_type", "dispatch_type");
    }
    if (br_service_type.length === 0) {
      getLoadMasterValues("service_mode", "br_service_type");
    }
    if (tripStatus.length === 0) {
      getTripStatus()
    }
  }

  changeLimit(pageNo, limit) {
    this.props.loadTripPlanId(formatHelpTripFormValues(this.props.formValues), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.loadTripPlanId(formatHelpTripFormValues(this.props.formValues), pageNo, limit);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  formSubmit(values) {
    this.props.loadTripPlanId(formatHelpTripFormValues(values), 1, 10);
  }

  selectTripId() {
    const { close } = this.props
    const { selectedIds } = this.state
    if (selectedIds !== null) {
      this.props.handleOnSelect(selectedIds[0])
      close('help', 'tripHelp')
    }
  }

  render() {
    const { handleSubmit, result_help_trip, totalPage_help_trip, totalRecord_help_trip, dispatch_type, br_service_type, tripStatus, t } = this.props
    const { defaultValues } = this.state
    return (
      <form onSubmit={handleSubmit(this.formSubmit)}>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={5}>
              <Field
                name="plpth_trip_plan_id"
                component={InputField}
                clearable={true}
                label={t('id/no')} />
              <Field
                name="plpth_vehicle_id"
                component={InputField}
                clearable={true}
                label={t('vehicleId')} />
              <Field
                name="plpth_equipment_id"
                component={InputField}
                clearable={true}
                label={t('equipmentId')} />
              <Field
                name="plpth_handler_id"
                component={InputField}
                clearable={true}
                label={t('handlerId')} />
              <Field
                name="plpth_agent_id"
                component={InputField}
                clearable={true}
                label={t('agentId')} />
              <Field
                name="wms_vendor_name"
                component={InputField}
                clearable={true}
                label={t('agentName')} />
            </Grid.Column>
            <Grid.Column width={5}>
              <Field
                name="plpth_trip_plan_date"
                component={DateTimePicker}
                clearable={true}
                label={t('date')} />
              <Field
                name="plpth_driver_id"
                component={InputField}
                clearable={true}
                label={t('driverId')} />
              <Field
                name="wms_emp_first_name"
                component={InputField}
                clearable={true}
                label={t('driverName')} />
              <Field
                name="wms_eqp_description"
                component={InputField}
                clearable={true}
                label={t('handlerName')} />
              <Field
                name="plpth_trip_plan_to"
                component={InputField}
                clearable={true}
                label={t('toLocation')} />
              <Field
                name="plpth_trip_plan_from"
                component={InputField}
                clearable={true}
                label={t('fromLocation')} />
            </Grid.Column>
            <Grid.Column width={5}>
              <Field
                name="wms_code_desc"
                component={Dropdown}
                clearable={true}
                label={t('status')}
                options={tripStatus} />
              <Field
                name="pltph_vehicle_reg_num"
                component={InputField}
                clearable={true}
                label={t('vehicleRegNo')} />
              <Field
                name="plpth_schedule_id"
                component={InputField}
                clearable={true}
                label={t('scheduleId')} />
              <Field
                name="sd_to_port"
                component={InputField}
                clearable={true}
                label={t('scheduleTo')} />
              <Field
                name="sd_from_port"
                component={InputField}
                clearable={true}
                label={t('scheduleFrom')} />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="help-search">
                <button className="primary"> {t('searchBtn')} </button>
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={columns}
                rows={result_help_trip}
                rowKey="br_request_Id"
                totalPages={totalPage_help_trip}
                selectedRows={this.selectedRows}
                totalRecord={totalRecord_help_trip}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                defaultValues={defaultValues}
                enableExport={true}
                singleSelect={true} />
              <div className="get-details">
                <button type="button" className="primary" onClick={this.selectTripId}> {t('okBtn')} </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </form>
    )
  }
}

HelpOnTripPlan = reduxForm({
  form: 'HelpOnTripPlanForm',
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
})(HelpOnTripPlan);

const mapDispatchToProps = (dispatch) => ({
  loadTripPlanId: (params, pageNo, limit) =>
    dispatch(dispatchHelpAction.helpOnTripPlan(params, pageNo, limit)),
  getLoadMasterValues: (action, stateName) =>
    dispatch(loadMasterDefaults(action, stateName)),
  getDispatchMasterValues: (action, stateName) =>
    dispatch(loadDispatchDefaults(action, stateName)),
  getTripStatus: type =>
    dispatch(masterActions.getTripStatus("tripStatus")),
})

const mapStateToProps = state => ({
  result_help_trip: state.dispatchReducer.result_help_trip,
  totalPage_help_trip: state.dispatchReducer.totalPage_help_trip,
  totalRecord_help_trip: state.dispatchReducer.totalRecord_help_trip,
  dispatch_type: state.dispatchReducer.options.dispatch_type,
  br_service_type: state.dispatchReducer.options.br_service_type,
  tripStatus: state.masterReducer.options.tripStatus,
  formValues: state.form.HelpOnTripPlanForm,
})

export default compose(withTranslation('helpOnTripForm'), connect(mapStateToProps, mapDispatchToProps))(HelpOnTripPlan);