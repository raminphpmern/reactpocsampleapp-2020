import _ from 'lodash';

export function formatLinkHouseValues(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["ddh_dispatch_doc_status_link"])
      hash["ddh_dispatch_doc_status_link"] = hash["ddh_dispatch_doc_status_link"].value;
    if (hash["ddh_dispatch_doc_type_link"])
      hash["ddh_dispatch_doc_type_link"] = hash["ddh_dispatch_doc_type_link"].value;
    if (hash["br_service_type"])
      hash["br_service_type"] = hash["br_service_type"].value;
    if (hash["br_sub_service_type"])
      hash["br_sub_service_type"] = hash["br_sub_service_type"].value;
    return hash
  } else {
    return {}
  }
}

export function showSelectedValue(field, selectedValue, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  tempHash[field] = selectedValue
  return tempHash
}

export function showLinkDocType(values, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  _.merge(values, tempHash);
  return tempHash
}