import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import * as dispatchDocumentAction from "actions/dispatchDocumentAction";
import "../DispatchCreate.css";
import i18n from 'i18n';
import _ from "lodash";

const columns = [
  { key: "ddh_reference_doc_no", name: i18n.t('linkHouseGrid:brId') },
  { key: "br_requested_date", name: i18n.t('linkHouseGrid:brDate') },
  { key: "ddh_dispatch_doc_type_link", name: i18n.t('linkHouseGrid:dispatchDocType') },
  { key: "ddh_dispatch_doc_no", name: i18n.t('linkHouseGrid:dispatchDocNo') },
  { key: "wms_customer_name", name: i18n.t('linkHouseGrid:customerName') },
  { key: "wms_consignor_desc", name: i18n.t('linkHouseGrid:consignorName') },
  { key: "ccd_consignee_name", name: i18n.t('linkHouseGrid:consigneeName') },
  { key: "sd_vessel_name", name: i18n.t('linkHouseGrid:vesselName') },
  { key: "ddh_vessel_flight_rail_number", name: i18n.t('linkHouseGrid:voyageID') },
  { key: "br_service_type", name: i18n.t('linkHouseGrid:serviceType') },
]

class ResultTableLinkHouse extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selectedIds: null,
      defaultValues: null,
      freshStatus: false,
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.dispatchCreateForm) {
      const status = nextProps.dispatchCreateForm
      if (status.values) {
        if (status.values.ddh_dispatch_doc_status === "Fresh") {
          this.setState({ freshStatus: true })
        } else {
          this.setState({ freshStatus: false })
        }
      }
    }
  }

  changeLimit(pageNo, limit) {
    const plpth_trip_plan_id = this.props.dispatchCreateForm.values.plpth_trip_plan_id
    this.props.linkRecords({ plpth_trip_plan_id: plpth_trip_plan_id }, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    const plpth_trip_plan_id = this.props.dispatchCreateForm.values.plpth_trip_plan_id
    this.props.linkRecords({ plpth_trip_plan_id: plpth_trip_plan_id }, pageNo, limit);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  assignMaster() {
    const selectedRecords = this.state.selectedIds
    const datas = this.props.dispatchCreateForm.values
    if (selectedRecords) {
      let brId = _.map(selectedRecords, 'ddh_reference_doc_no')
      let data = { ddh_reference_doc_no: brId.join(), ddh_dispatch_doc_type: datas.ddh_dispatch_doc_type, ddh_dispatch_doc_no: datas.ddh_dispatch_doc_no }
      this.props.assignUnassign(data, 'assign')
    }
  }

  unAssignMaster() {
    const selectedRecords = this.state.selectedIds
    const datas = this.props.dispatchCreateForm.values
    if (selectedRecords) {
      let brId = _.map(selectedRecords, 'ddh_reference_doc_no')
      let data = { ddh_reference_doc_no: brId.join(), ddh_dispatch_doc_type: datas.ddh_dispatch_doc_type, ddh_dispatch_doc_no: datas.ddh_dispatch_doc_no }
      this.props.assignUnassign(data, 'unassign')
    }
  }

  render() {
    const { result, totalPage, totalRecord, resetLHRecords } = this.props
    const { defaultValues, selectedIds, freshStatus } = this.state
    const disabled = selectedIds && selectedIds.length > 0
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid columns={columns}
                  rows={result}
                  rowKey="ddh_reference_doc_no"
                  width={260}
                  totalPages={totalPage}
                  selectedRows={this.selectedRows}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  defaultValues={defaultValues}
                  enableExport={true}
                  initialize={resetLHRecords} />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="link-house-button">
            <Grid.Column width={8}>
              <div className="assign-button-right">
                <button id='assign' type="button" className="primary btn-small" disabled={!disabled || !freshStatus} onClick={() => this.assignMaster()}>{i18n.t('linkHouseGrid:assignBtn')}</button>
              </div>
            </Grid.Column>
            <Grid.Column width={1}>
              <button id='unassign' type="button" className="primary btn-small" disabled={!disabled || !freshStatus} onClick={() => this.unAssignMaster()}>{i18n.t('linkHouseGrid:unAssignBtn')}</button>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  assignUnassign: (data, action) =>
    dispatch(dispatchDocumentAction.changeMasterNumber(data, action)),
  linkRecords: (data, pageNo, limit) =>
    dispatch(dispatchDocumentAction.loadLinkHouseRecords(data, pageNo, limit)),
  resetLHRecords: () => dispatch(dispatchDocumentAction.resetLHRecords())
})

const mapStateToProps = state => ({
  result: state.dispatchReducer.result_link_house,
  totalPage: state.dispatchReducer.totalPage_link_house,
  totalRecord: state.dispatchReducer.totalRecord_link_house,
  dispatchCreateForm: state.form.DispatchCreateForm
})

export default connect(mapStateToProps, mapDispatchToProps)(ResultTableLinkHouse)