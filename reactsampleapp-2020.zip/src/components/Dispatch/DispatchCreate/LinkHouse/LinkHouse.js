import React, { Component } from "react";
import InputField from "components/Common/InputField";
import InputSearchField from 'components/Common/InputSearchField';
import Dropdown from "components/Common/Dropdown";
import { reduxForm, Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import DateTimePicker from "components/Common/DateTimePicker";
import Popup from 'components/Common/Popup';
import { connect } from "react-redux";
import { formatLinkHouseValues, showSelectedValue, showLinkDocType } from "./Helper";
import { buildDispatchSearchData } from "../../Helper";
import * as masterActions from 'actions/masterAction';
import { SEARCH_WORD_COUNT } from 'config';
import HelpOnCustomer from "components/Dispatch/DispatchSearch/HelpOnCustomer";
import * as dispatchDocumentAction from 'actions/dispatchDocumentAction';
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import "../DispatchCreate.css";
import _ from "lodash";

const linkHouseDocTypes = [
  { value: 'CN', label: 'Consignment Note' },
  { value: 'HBL', label: 'HBL' },
  { value: 'HAWB', label: 'HAWB' }
];

class LinkHouse extends Component {
  constructor(props) {
    super(props);
    this.state = {
      customerHelp: false,
      search: {
        consignee_search: true,
        consignor_search: true,
      },
    }
    this.selectCustomerCode = this.selectCustomerCode.bind(this)
    this.searchRecords = this.searchRecords.bind(this)
    this.toggle = this.toggle.bind(this)
    this.findByCompanyAndFLMName = this.findByCompanyAndFLMName.bind(this)
    this.fillNameValues = this.fillNameValues.bind(this)
  }

  componentDidMount() {
    const {
      doc_status,
      dispatch_type,
      getDispatchMasterValues,
      getLoadMasterValues,
      service_type,
      subservice_type,
    } = this.props
    if (doc_status.length === 0) {
      getDispatchMasterValues("status", "doc_status")
    }
    if (dispatch_type.length === 0) {
      getDispatchMasterValues("document_type", "dispatch_type")
    }
    if (service_type.length === 0) {
      getLoadMasterValues("shipment_type", "service_type")
    }
    if (subservice_type.length === 0) {
      getLoadMasterValues("service_mode", "subservice_type")
    }
  }

  findByCompanyAndFLMName(value, action) {
    let { search } = this.state;
    if (value && value.length >= SEARCH_WORD_COUNT) {
      if (action === 'consignee') {
        this.props.getConsigneeConsignorSearch(action, `keyword=${value}`)
      } else if (action === 'consignor') {
        this.props.getConsigneeConsignorSearch('shipper', `keyword=${value}&parentId=undefined`)
      }
    }
    this.setState({ search })
  }

  fillNameValues(item, type) {
    let { search } = this.state;
    if (type.includes('consignee')) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(showSelectedValue('wms_consignee_desc', item['wms_consignee_desc'], hash))
      this.setState({ search: search })
    } else if (type.includes('consignor')) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(showSelectedValue('wms_consignor_desc', item['wms_customer_description'], hash))
      this.setState({ search: search })
    }
  }

  componentDidUpdate(prevProps) {
    const ddh_dispatch_doc_type = this.props.DispatchCreateForm && this.props.DispatchCreateForm.values && this.props.DispatchCreateForm.values.ddh_dispatch_doc_type
    const hash = _.cloneDeep(this.props.formValues.values)
    if (prevProps.DispatchCreateForm !== this.props.DispatchCreateForm) {
      if (ddh_dispatch_doc_type) {
        if ((ddh_dispatch_doc_type.value || ddh_dispatch_doc_type) === "MBL") {
          this.props.initialize(showLinkDocType(hash, { ddh_dispatch_doc_type_link: { value: "HBL", label: "HBL" } }));
        }
        else if ((ddh_dispatch_doc_type.value || ddh_dispatch_doc_type) === "MAWB") {
          this.props.initialize(showLinkDocType(hash, { ddh_dispatch_doc_type_link: { value: "HAWB", label: "HAWB" } }));
        }
      }
    }
  }

  toggle() {
    this.setState(prevState => ({
      customerHelp: !prevState.customerHelp
    }));
  }

  searchRecords() {
    this.props.linkRecords(formatLinkHouseValues(this.props.formValues.values), 1, 10)
  }

  selectCustomerCode(selectedCustomerCode) {
    const hash = _.cloneDeep(this.props.formValues.values)
    this.props.initialize(buildDispatchSearchData(selectedCustomerCode, hash))
  }

  render() {
    const { options, doc_status, service_type, subservice_type, t } = this.props
    return (
      <div className="link-house">
        <Grid stackable>
          <Grid.Row className="no-padding">
            <Grid.Column width={4}>
              <Field
                name="ddh_dispatch_doc_type_link"
                component={Dropdown}
                label={t('dispatchDocumentType')}
                clearable={true}
                options={linkHouseDocTypes}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="ddh_dispatch_doc_no_from"
                component={InputField}
                label={t('dispatchDocNoFrom')}
                clearable={true}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="ddh_dispatch_doc_no_to"
                component={InputField}
                label={t('dispatchDocNoTo')}
                clearable={true}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="br_service_type"
                component={Dropdown}
                label={t('serviceType')}
                clearable={true}
                options={service_type}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="no-padding">
            <Grid.Column width={4}>
              <Field
                name="ddh_dispatch_doc_date_from"
                component={DateTimePicker}
                label={t('dispatchDocDateFrom')}
                clearable={true}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="ddh_dispatch_doc_date_to"
                component={DateTimePicker}
                label={t('dispatchDocDateTo')}
                clearable={true}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="ddh_dispatch_doc_status_link"
                component={Dropdown}
                label={t('dispatchDocStatus')}
                options={doc_status}
                clearable={true}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="br_sub_service_type"
                component={Dropdown}
                label={t('subServiceType')}
                clearable={true}
                options={subservice_type}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="no-padding">
            <Grid.Column width={4}>
              <Field
                name="location_id"
                component={Dropdown}
                label={t('locationId')}
                readOnly={true}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="sd_vessel_name"
                component={InputField}
                label={t('vesselName')}
                clearable={true}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="ddh_vessel_flight_rail_number"
                component={InputField}
                label={t('vesselId')}
                clearable={true}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="no-padding">
            <Grid.Column width={4}>
              <Field
                name="wms_consignor_desc"
                component={InputSearchField}
                label={t('consignor')}
                id="consignor"
                options={options.shipper}
                fillNameValues={this.fillNameValues}
                findByCompanyAndFLMName={this.findByCompanyAndFLMName}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="wms_consignee_desc"
                component={InputSearchField}
                label={t('consignee')}
                id="consignee"
                options={options.consignee}
                fillNameValues={this.fillNameValues}
                findByCompanyAndFLMName={this.findByCompanyAndFLMName} />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                name="customer_code"
                component={InputField}
                handleClick={this.toggle}
                clearable={true}
                label={t('customerId')}
                iconName="search"
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <div className="text-center">
                <button id='search' type="button" className="primary"
                  onClick={() => this.searchRecords()}>
                  {t('searchBtn')}
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Popup size="fullscreen" open={this.state.customerHelp} close={this.toggle}
          header="Help on Customer" description={<HelpOnCustomer close={this.toggle} handleOnSelect={this.selectCustomerCode} />} />
      </div>
    )
  }
}

LinkHouse = reduxForm({
  form: "LinkHouseForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
})(LinkHouse);

const mapDispatchToProps = (dispatch) => ({
  getDispatchMasterValues: (action, stateName) =>
    dispatch(dispatchDocumentAction.loadDispatchDefaults(action, stateName)),
  getLoadMasterValues: (action, stateName) =>
    dispatch(dispatchDocumentAction.loadMasterDefaults(action, stateName)),
  getConsigneeConsignorSearch: (action, queryStr) =>
    dispatch(masterActions.getShipper(action, queryStr)),
  linkRecords: (data, pageNo, limit) =>
    dispatch(dispatchDocumentAction.loadLinkHouseRecords(data, pageNo, limit))
})

const mapStateToProps = state => ({
  doc_status: state.dispatchReducer.options.doc_status,
  dispatch_type: state.dispatchReducer.options.dispatch_type,
  service_type: state.dispatchReducer.options.service_type,
  subservice_type: state.dispatchReducer.options.subservice_type,
  formValues: state.form.LinkHouseForm,
  options: state.masterReducer.options,
  DispatchCreateForm: state.form.DispatchCreateForm
})

export default compose(withTranslation('dispatchCreateForm'), connect(mapStateToProps, mapDispatchToProps))(LinkHouse);