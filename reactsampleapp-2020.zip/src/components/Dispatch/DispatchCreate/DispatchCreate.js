import React, { Component } from "react";
import InputField from "components/Common/InputField";
import Dropdown from "components/Common/Dropdown";
import { reduxForm, Field, formValueSelector } from "redux-form";
import { Grid, Icon, Accordion } from "semantic-ui-react";
import DateTimePicker from "components/Common/DateTimePicker";
import ResultTableLinkHouse from "./LinkHouse/ResultTableLinkHouse";
import LinkHouse from "../DispatchCreate/LinkHouse/LinkHouse";
import ResultTableTHU from "../DispatchView/ResultTableTHU";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Popup from "components/Common/Popup";
import HelpOnTripPlan from "./HelpOnTripPlan";
import * as helper from "../DispatchCreate/Helper";
import { showDispatchData } from "../../Dispatch/Helper"
import * as dispatchDocumentAction from "actions/dispatchDocumentAction";
import * as dispatchHelpAction from "actions/dispatchHelpAction";
import { SEARCH_WORD_COUNT } from "config";
import validate from "./CreateValidation";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import "./DispatchCreate.css";
import _ from "lodash";

const masterOptions = [
  { value: 'MBL', label: 'MBL' },
  { value: 'MAWB', label: 'MAWB' }
];

class DispatchCreate extends Component {
  constructor(props) {
    super(props)
    this.state = {
      helpTrip: false,
      activeindex: [],
      isStatusEnabled: false,
      tripLogEnterKey: false,
      activeStatus: false,
    }
    this.toggle = this.toggle.bind(this)
    this.toggleTripLogEnterKey = this.toggleTripLogEnterKey.bind(this)
    this.selectTripId = this.selectTripId.bind(this);
    this.setAccordionState = this.setAccordionState.bind(this)
    this.saveDispatchDetails = this.saveDispatchDetails.bind(this)
    this.confirmDispatchDetails = this.confirmDispatchDetails.bind(this)
    this.cancelDispatchDetails = this.cancelDispatchDetails.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.accordionClick = this.accordionClick.bind(this)
  }

  componentDidMount() {
    let _self = this;
    const {
      currentUser,
      currency_value,
      unit_value,
      weight_value,
      getDispatchMasterValues,
      getLoadMasterValues,
      match: { params },
    } = this.props
    const locations = (currentUser && currentUser.locations) || [];
    if (locations.length > 0) {
      this.props.initialize({ location: locations[0].value, division: locations[0].wms_loc_code });
    }
    if (currency_value.length === 0) {
      getLoadMasterValues("currencies", "currency_value");
    }
    if (unit_value.length === 0) {
      getDispatchMasterValues("unit_volume", "unit_value");
    }
    if (weight_value.length === 0) {
      getDispatchMasterValues("unit_weight", "weight_value");
    }
    if (params.ddId) {
      const dd_no = params.ddId;
      this.props.getDetails(dd_no, true)
    }

    //Declaring Enter Key for Fetch Trip Log By ID
    let enterKeyElement = document.getElementById('plpth_trip_plan_id')
    enterKeyElement.addEventListener('keypress', (event) => {
      _self.toggleTripLogEnterKey(false)
      _self.setState({ activeindex: [] })
      if (event.keyCode === 13) {
        _self.toggleTripLogEnterKey(true)
        let tripLogID = _self.props.formValues && _self.props.formValues.values
        delete (tripLogID["sd_from_port"])
        delete (tripLogID["sd_to_port"])
        delete (tripLogID["sd_total_transit_time"])
        delete (tripLogID["sd_carrier_id"])
        delete (tripLogID["sd_trip_id"])
        delete (tripLogID["plpth_schedule_id"])
        let checkTripID = tripLogID["plpth_trip_plan_id"]
        if (checkTripID && checkTripID.length >= SEARCH_WORD_COUNT) {
          _self.props.getTripLogIDDetails(tripLogID)
        }
        event.preventDefault()
      }
    })
  }

  componentDidUpdate(prevProps) {
    if (prevProps.location.key !== this.props.location.key) {
      const dddata = this.props.location.state;
      const hash = _.cloneDeep(prevProps.formValues.values)
      if (dddata && dddata.detail != null) {
        this.props.initialize(showDispatchData(dddata.detail, hash));
        this.setState({ isStatusEnabled: true })
      }
      this.setState({ activeindex: [] })
    } else if (prevProps.dd_data != null) {
      const hash = _.cloneDeep(prevProps.formValues.values)
      this.props.initialize(showDispatchData(prevProps.dd_data, hash));
      this.setState({ isStatusEnabled: true })
      if (prevProps.dd_data.ddh_dispatch_doc_status !== "Fresh") {
        this.setState({ activeStatus: true })
      }
    }
  }

  setAccordionState(e, titleProps) {
    const { index } = titleProps
    const { activeindex } = this.state
    const newIndex = activeindex === index ? -1 : index
    this.setState({ activeindex: newIndex })
    const plpth_trip_plan_id = this.props.formValues.values.plpth_trip_plan_id
    const ddh_dispatch_doc_no = this.props.formValues.values.ddh_dispatch_doc_no
    const ddh_dispatch_doc_type = this.props.formValues.values.ddh_dispatch_doc_type
    if (newIndex === 1) {
      if (ddh_dispatch_doc_no) {
        const ddh_dispatch_doc_type_link = this.props.LinkHouseForm.values.ddh_dispatch_doc_type_link
        const ddh_dispatch_doc_status_code = this.props.formValues.values.ddh_dispatch_doc_status_code
        this.props.linkRecords(helper.formatCreateFormValues({ plpth_trip_plan_id, ddh_dispatch_doc_no, ddh_dispatch_doc_status_code, ddh_dispatch_doc_type_link }), 1, 10)
      }
      else if (ddh_dispatch_doc_type && plpth_trip_plan_id) {
        const ddh_dispatch_doc_type_link = this.props.LinkHouseForm.values.ddh_dispatch_doc_type_link
        this.props.linkRecords(helper.formatCreateFormValues({ plpth_trip_plan_id, ddh_dispatch_doc_type_link }), 1, 10)
      }
      else if (plpth_trip_plan_id) {
        this.props.linkRecords(helper.formatCreateFormValues({ plpth_trip_plan_id, ddh_dispatch_doc_status_code: 'noStatus' }), 1, 10)
      }
    }
    if (newIndex === 2) {
      let docnos = _.map(this.props.result_link_house, 'ddh_dispatch_doc_no')
      this.props.loadViewTHUDetails({ 'doc_no': docnos.join() }, 1, 10)
    }
  }

  accordionClick(e, index) {
    if (e.keyCode === 13) {
      if (index === this.state.activeindex) {
        this.setState({ activeindex: [] })
      }
      else {
        this.setState({ activeindex: index })
        const plpth_trip_plan_id = this.props.formValues.values.plpth_trip_plan_id
        const ddh_dispatch_doc_no = this.props.formValues.values.ddh_dispatch_doc_no
        const ddh_dispatch_doc_type = this.props.formValues.values.ddh_dispatch_doc_type
        if (index === 1) {
          if (ddh_dispatch_doc_no) {
            const ddh_dispatch_doc_type_link = this.props.LinkHouseForm.values.ddh_dispatch_doc_type_link
            const ddh_dispatch_doc_status_code = this.props.formValues.values.ddh_dispatch_doc_status_code
            this.props.linkRecords(helper.formatCreateFormValues({ plpth_trip_plan_id, ddh_dispatch_doc_no, ddh_dispatch_doc_status_code, ddh_dispatch_doc_type_link }), 1, 10)
          }
          else if (ddh_dispatch_doc_type && plpth_trip_plan_id) {
            const ddh_dispatch_doc_type_link = this.props.LinkHouseForm.values.ddh_dispatch_doc_type_link
            this.props.linkRecords(helper.formatCreateFormValues({ plpth_trip_plan_id, ddh_dispatch_doc_type_link }), 1, 10)
          }
          else if (plpth_trip_plan_id) {
            this.props.linkRecords(helper.formatCreateFormValues({ plpth_trip_plan_id }), 1, 10)
          }
        }
        if (index === 2) {
          let docnos = _.map(this.props.result_link_house, 'ddh_dispatch_doc_no')
          this.props.loadViewTHUDetails({ 'doc_no': docnos.join() }, 1, 10)
        }
      }
    }
  }

  toggle() {
    this.setState(prevState => ({
      helpTrip: !prevState.helpTrip,
    }));
  }

  toggleTripLogEnterKey(toggleEnterState) {
    this.setState({ tripLogEnterKey: toggleEnterState })
  }

  selectTripId(selectedTripId) {
    if (selectedTripId) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(helper.loadSelectedTripCode(selectedTripId, hash))
    }
  }

  loadTripLogById(selectedTripId) {
    const { tripLogEnterKey } = this.state
    if (tripLogEnterKey) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(helper.loadSelectedTripCodeByID(selectedTripId, hash))
    }
  }

  saveDispatchDetails() {
    const saveDispatchValues = this.props.formValues.values
    this.props.create(helper.formatCreateFormValues(saveDispatchValues), 'save')
  }

  confirmDispatchDetails() {
    const confirmDispatchValues = this.props.formValues.values
    this.props.create(helper.formatCreateFormValues(confirmDispatchValues), 'confirm')
    this.setState({ activeStatus: true })
  }

  cancelDispatchDetails() {
    const cancelDispatchValues = this.props.formValues.values
    this.props.create(helper.formatCreateFormValues(cancelDispatchValues), 'cancel')
    this.setState({ activeStatus: true })
  }

  formSubmit() {
    // TODO: This has been left blank to handle multiple submit buttons. Later may enable for enter key
  }

  render() {
    const { activeindex, isStatusEnabled, activeStatus } = this.state
    const { invalid, handleSubmit, getTripLogData, docType, docTypeValue, currency_value, unit_value, weight_value, status, t } = this.props
    if (getTripLogData.length > 0) {
      this.loadTripLogById(getTripLogData[0])
    }
    return (
      <div className="dispatch">
        <Popup size="fullscreen" open={this.state.helpTrip} close={this.toggle}
          header="Help on Trip Plan"
          description={<HelpOnTripPlan close={this.toggle} handleOnSelect={this.selectTripId} />} />
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="dispatch-create-form">
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="division"
                  component={InputField}
                  label={t('division')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="location"
                  component={InputField}
                  label={t('location')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4} />
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_status"
                  component={InputField}
                  label={t('status')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                {(status === undefined) &&
                  <Field
                    name="ddh_dispatch_doc_type"
                    component={Dropdown}
                    label={t('dispatchDocumentType')}
                    options={masterOptions}
                    clearable={true}
                    required={true}
                  />
                }
                {(status !== undefined) &&
                  <Field
                    name="ddh_dispatch_doc_type"
                    component={InputField}
                    label={t('dispatchDocumentType')}
                    readOnly={isStatusEnabled}
                  />
                }
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_trip_plan_id"
                  component={InputField}
                  label={t('tripLog')}
                  iconName="search"
                  handleClick={this.toggle}
                  required={true}
                  readOnly={isStatusEnabled}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column className="dispatch-create">
                <h6 className="custom-title">
                  <span>{t('subTitle')}</span>
                </h6>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_no"
                  component={InputField}
                  label={((docTypeValue || docType) !== "MAWB") ? "MBL No." : "MAWB NO."}
                  clearable={true}
                  required={true}
                  readOnly={isStatusEnabled}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_date"
                  component={DateTimePicker}
                  label={((docTypeValue || docType) !== "MAWB") ? "MBL Date" : "MAWB Date"}
                  clearable={true}
                  required={true}
                  readOnly={activeStatus}
                  disabled={activeStatus}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_schedule_id"
                  component={InputField}
                  label={t('scheduleId')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="sd_trip_id"
                  component={InputField}
                  label={t('vesselNo')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="sd_carrier_id"
                  component={InputField}
                  label={t('carrierName')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="sd_total_transit_time"
                  component={InputField}
                  label={t('totalTransitTime')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="sd_from_port"
                  component={InputField}
                  label={t('origin')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="sd_to_port"
                  component={InputField}
                  label={t('destination')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            {(docType === "MAWB" || docTypeValue === "MAWB") &&
              <Grid.Row className="no-padding">
                <Grid.Column width={4}>
                  <Field
                    name="ddh_declaredvalue_charge"
                    component={InputField}
                    amountField={true}
                    label={t('destinationCurrency')}
                    clearable={true}
                    readOnly={isStatusEnabled}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  {(status === undefined) &&
                    <Field
                      name="ddh_currency"
                      component={Dropdown}
                      label={t('currency')}
                      options={currency_value}
                      clearable={true}
                    />
                  }
                  {(status !== undefined) &&
                    <Field
                      name="ddh_currency"
                      component={InputField}
                      label={t('currency')}
                      readOnly={isStatusEnabled}
                    />
                  }
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="ddh_net_weight"
                    component={InputField}
                    label={t('totalNetWeight')}
                    amountField={true}
                    clearable={true}
                    readOnly={isStatusEnabled}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  {(status === undefined) &&
                    <Field
                      name="ddh_weight_uom"
                      component={Dropdown}
                      label={t('weightUom')}
                      options={weight_value}
                      clearable={true}
                    />
                  }
                  {(status !== undefined) &&
                    <Field
                      name="ddh_weight_uom"
                      component={InputField}
                      label={t('weightUom')}
                      readOnly={isStatusEnabled}
                    />
                  }
                </Grid.Column>
              </Grid.Row>
            }
            {(docType === "MAWB" || docTypeValue === "MAWB") &&
              <Grid.Row className="no-padding">
                <Grid.Column width={4}>
                  <Field
                    name="ddh_chargeable_weight"
                    component={InputField}
                    label={t('totalChargeableWeight')}
                    amountField={true}
                    clearable={true}
                    readOnly={isStatusEnabled}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="ddh_total_volume"
                    component={InputField}
                    amountField={true}
                    label={t('totalVolume')}
                    clearable={true}
                    readOnly={isStatusEnabled}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  {(status === undefined) &&
                    <Field
                      name="ddh_volume_uom"
                      component={Dropdown}
                      label={t('volumeUom')}
                      options={unit_value}
                      clearable={true}
                    />
                  }
                  {(status !== undefined) &&
                    <Field
                      name="ddh_volume_uom"
                      component={InputField}
                      label={t('volumeUom')}
                      readOnly={isStatusEnabled}
                    />
                  }
                </Grid.Column>
              </Grid.Row>
            }
            <Grid.Row className="no-padding">
              <Grid.Column width={16}>
                <Accordion>
                  <Accordion.Title
                    active={activeindex === 1}
                    index={1}
                    onClick={this.setAccordionState}
                    onKeyUp={(e) => { this.accordionClick(e, 1) }}
                    tabIndex="0">
                    <h3 className="sub-head">
                      <strong>
                        <Icon name='dropdown' />
                        {t('accordionTitle1')}
                      </strong>
                    </h3>
                  </Accordion.Title>
                  <Accordion.Content active={activeindex === 1}>
                    <LinkHouse handleClick={this.toggle} />
                  </Accordion.Content>
                  <Accordion.Content active={activeindex === 1}>
                    <ResultTableLinkHouse />
                  </Accordion.Content>
                </Accordion>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={16}>
                <Accordion>
                  <Accordion.Title
                    active={activeindex === 2}
                    index={2}
                    onKeyUp={(e) => { this.accordionClick(e, 2) }}
                    tabIndex="0"
                    onClick={this.setAccordionState}>
                    <h3 className="sub-head">
                      <strong>
                        <Icon name='dropdown' />
                        {t('accordionTitle2')}
                      </strong>
                    </h3>
                  </Accordion.Title>
                  <Accordion.Content active={activeindex === 2}>
                    <ResultTableTHU />
                  </Accordion.Content>
                </Accordion>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="create-buttons">
              <Grid.Column width={5}>
                <div className="assign-button-right">
                  <button disabled={invalid || activeStatus} id='save' type='button' className="primary"
                    onClick={() => this.saveDispatchDetails()}>
                    {t('saveBtn')}
                  </button>
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="text-center">
                  <button id='confirm' type='button' className="secondary" disabled={invalid || !isStatusEnabled || activeStatus}
                    onClick={() => this.confirmDispatchDetails()}>
                    {t('confirmBtn')}
                  </button>
                </div>
              </Grid.Column>
              {/* //TODO Need to get Confirm from Business Team (Victor)
            <Grid.Column width={2}>
              <div className="assign-button-left">
                <button id='amend' type="button" className="secondary">
                  {t('amendBtn')}
                </button>
              </div>
            </Grid.Column> */}
              <Grid.Column >
                <div className="text-center">
                  <button id='cancel' type="button" className="secondary"
                    disabled={invalid || !isStatusEnabled || activeStatus}
                    onClick={() => this.cancelDispatchDetails()}>
                    {t('cancelBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    );
  }
}

DispatchCreate = reduxForm({
  form: "DispatchCreateForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate,
})(DispatchCreate);

const selector = formValueSelector('DispatchCreateForm');
DispatchCreate = connect(state => {
  const docType = selector(state, 'ddh_dispatch_doc_type');
  const docTypeValue = selector(state, 'ddh_dispatch_doc_type.value');
  const status = selector(state, 'ddh_dispatch_doc_status');
  return {
    docType,
    docTypeValue,
    status,
  };
})(DispatchCreate);

const mapDispatchToProps = (dispatch) => ({
  create: (params, action) =>
    dispatch(dispatchDocumentAction.createDispatchAction(params, action)),
  getDispatchMasterValues: (action, stateName) =>
    dispatch(dispatchDocumentAction.loadDispatchDefaults(action, stateName)),
  getLoadMasterValues: (action, stateName) =>
    dispatch(dispatchDocumentAction.loadMasterDefaults(action, stateName)),
  linkRecords: (data, pageNo, limit) =>
    dispatch(dispatchDocumentAction.loadLinkHouseRecords(data, pageNo, limit)),
  getTripLogIDDetails: (tripLogID) =>
    dispatch(dispatchHelpAction.helpOnTripPlanByID(tripLogID, '1', '10')),
  getDetails: (dd_no) =>
    dispatch(dispatchDocumentAction.loadMasterView(dd_no)),
  loadViewTHUDetails: (dd_no, pageNo, limit) =>
    dispatch(dispatchDocumentAction.loadViewTHUDetails(dd_no, pageNo, limit))
})

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
  result: state.dispatchReducer.result,
  formValues: state.form.DispatchCreateForm,
  getTripLogData: state.dispatchReducer.result_help_trip_by_id,
  currency_value: state.dispatchReducer.options.currency_value,
  unit_value: state.dispatchReducer.options.unit_value,
  weight_value: state.dispatchReducer.options.weight_value,
  dd_data: state.dispatchReducer.dd_data,
  LinkHouseForm: state.form.LinkHouseForm,
  result_link_house: state.dispatchReducer.result_link_house,
});

export default compose(withTranslation('dispatchCreateForm'), connect(mapStateToProps, mapDispatchToProps))(withRouter(DispatchCreate));