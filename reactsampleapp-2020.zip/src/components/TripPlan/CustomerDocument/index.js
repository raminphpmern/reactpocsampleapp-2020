import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import { compose } from 'redux';
import DataGrid from 'components/Common/DataGrid';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import i18n from 'i18n';
import _ from 'lodash';
import ImageFormatter from 'components/Common/DataGrid/ImageFormatter';
import { getcustomerDocument } from 'actions/customerDocumentActions';


const columns = [
  { key: "vdd_doc_type_ml", name: i18n.t("customerDocument:document_type") },
  { key: "vdd_doc_date_ml", name: i18n.t("customerDocument:document_date") },
  { key: "vdd_doc_name_ml", name: i18n.t("customerDocument:document_no") },
  { key: "tran_attachement", name: i18n.t('customerDocument:attachment'), formatter: <ImageFormatter fileColumn='tran_attachement' />, getRowMetaData: (row) => row },
]

class CustomerDocument extends Component {
  constructor(props) {
    super(props);
    this.state = {
      updatedRows: [],
    }
  }

  componentDidMount() {
    const { getcustomerDocument, rowInfo } = this.props
    getcustomerDocument(`br_request_id=${rowInfo.br_request_id}`, 1, 10)
  }

  rowEdit(row, updateValue) {
    _.merge(row, updateValue)
    if (row && row.new === true) {
      let { updatedRows } = this.state
      if (updatedRows.length > 0) {
        const index = _.findIndex(updatedRows, (updatedRow) => {
          return (updatedRow.id === row.id
          )
        })
        updatedRows[index] = row
        this.setState({ updatedRows })

      } else {
        updatedRows.push(row)
      }
      this.setState({ updatedRows })
    }
    else {
      let { updatedRows } = this.state
      const response = _.reduce(this.props.result, (arr, item) => {
        if (item.br_request_id === row.br_request_id) {
          _.merge(item, updateValue)
          arr.push(item)
        }
        return arr
      }, [])
      updatedRows = updatedRows.concat(response)
      this.setState({ updatedRows })
    }
  }

  changeLimit(pageNo, limit) {
    const { rowInfo } = this.props
    getcustomerDocument(`br_request_id=${rowInfo.br_request_id}`, pageNo, limit)
  }

  paginationHandler(pageNo, limit) {
    const { rowInfo } = this.props
    getcustomerDocument(`br_request_id=${rowInfo.br_request_id}`, pageNo, limit)
  }
  render() {
    const { result, totalPage, totalRecord, pageLimit, rowInfo } = this.props
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row className="no-padding">
            <Grid.Column width={8}>
              <label>Booking Request ID :{rowInfo.br_request_id} </label>
            </Grid.Column>
            <Grid.Column width={8}>
              <label>Customer Name :{result[0] ? result[0].wms_customer_name : ''} </label>
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row className="document_wrapper">
            <Grid.Column width={16} >
              <DataGrid
                columns={columns}
                rows={result}
                pageLimit={pageLimit}
                totalPages={totalPage}
                totalRecord={totalRecord}
                rowEdit={this.rowEdit}
                singleSelect={false}
                width={250}
                showSelectedCount={false}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  result: state.customerDocumentReducer.result,
  totalPage: state.customerDocumentReducer.totalPage,
  totalRecord: state.customerDocumentReducer.totalRecord,
  pageLimit: state.customerDocumentReducer.limit,
})

const mapDispatchToProps = (dispatch) => ({
  getcustomerDocument: (queryString, pageNo, limit) => dispatch(getcustomerDocument(queryString, pageNo, limit)),

})

export default compose(withTranslation('customerDocument'), connect(mapStateToProps, mapDispatchToProps))(CustomerDocument);
