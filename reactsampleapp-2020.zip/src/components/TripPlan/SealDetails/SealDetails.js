import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import { reduxForm } from "redux-form";
import { compose } from 'redux';
import i18n from 'i18n';
import DataGrid from 'components/Common/DataGrid';
import { connect } from 'react-redux';
import { fetchTripSeal, initializeTS, saveTripDtl, deleteTripSeal } from 'actions/tripHubAction';
import { withTranslation } from 'react-i18next';
import { AlertError } from 'lib/Alert';
import InputSearchEditor from 'components/Common/DataGrid/InputSearchEditor';
import _ from 'lodash';

export const columns = [
  { key: "tlsd_seal_no", name: i18n.t("vehicleSeal:tlsd_seal_no"), editable: true },
  { key: "tlsd_sealed_by", name: i18n.t("vehicleSeal:tlsd_sealed_by"), editor: <InputSearchEditor propName='employee' />, editable: true }
]

class HelpOnTripSeal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      updatedRows: [],
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.getGridNewData = this.getGridNewData.bind(this)
    this.save = this.save.bind(this)
    this.rowEdit = this.rowEdit.bind(this)
    this.buildQueryString = this.buildQueryString.bind(this)
    this.dropSelectedRows = this.dropSelectedRows.bind(this)
  }

  buildQueryString() {
    const { formValues } = this.props
    return `tlsd_trip_id=${formValues.values.trip_id}`
  }

  componentDidMount() {
    const { fetchTripSeal } = this.props
    fetchTripSeal(this.buildQueryString(), 1, 10)
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.isSaveRequested !== this.props.isSaveRequested) {
      if (nextProps.isSaveRequested) {
        this.setState({ updatedRows: [] })
      }
    }
  }

  getGridNewData(data) {
    let { newData } = this.state
    if (data) {
      if (newData.length > 0) {
        const recordIndex = _.findIndex(newData, (row) => row.id === data.id)
        if (recordIndex >= 0) {
          newData[recordIndex] = data
        } else {
          newData.push(data)
        }
      } else {
        newData.push(data)
      }
      this.setState({ newData })
    }
  }

  save() {
    let { updatedRows } = this.state
    const { formValues } = this.props
    if (updatedRows.length > 0) {
      let isValid = true
      let seal = 'Please Enter SealNo'
      let sealedby = 'Please Enter Sealby'
      _.each(updatedRows, (row) => {
        if (!row.tlsd_seal_no || !row.tlsd_sealed_by) {
          isValid = false
          if (!isValid) {
            if (!row.tlsd_seal_no) {
              AlertError(seal)
            } else if (!row.tlsd_sealed_by) {
              AlertError(sealedby)
            }
            return false
          }
        }
      })
      if (isValid) {
        let hash = { data: updatedRows, tlsd_trip_id: formValues.values.trip_id }
        hash = _.merge(hash)
        this.props.saveTripDtl(hash)
      }
    }
  }

  rowEdit(row, updateValue) {
    _.merge(row, updateValue)
    if (row && row.new === true) {
      let { updatedRows } = this.state
      if (updatedRows.length > 0) {
        const recordIndex = _.findIndex(updatedRows, (item) => item.id === row.id)
        if (recordIndex >= 0) {
          updatedRows[recordIndex] = row
        } else {
          updatedRows.push(row)
        }
      } else {
        updatedRows.push(row)
      }
      this.setState({ updatedRows })
    } else {
      const response = _.reduce(this.props.result, (arr, item) => {
        if (item.tlsd_seal_line_no === row.tlsd_seal_line_no) {
          _.merge(item, updateValue)
          arr.push(item)
        }
        return arr
      }, [])
      this.setState({ updatedRows: response })
    }
  }

  dropSelectedRows(rows) {
    const { deleteTripSeal } = this.props
    deleteTripSeal({ tlsd_seal_line_no: _.map(rows, 'tlsd_seal_line_no') })
  }

  changeLimit(pageNo, limit) {
    this.props.fetchTripSeal(this.buildQueryString(), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.fetchTripSeal(this.buildQueryString(), pageNo, limit);
  }

  render() {
    const { result, totalPage, totalRecord, initializeTS, t } = this.props
    const { updatedRows } = this.state
    const disabled = updatedRows.length > 0
    return (
      <div>
        <Grid stackable>
          <Grid.Row className="document_wrapper">
            <Grid.Column width={16} >
              <DataGrid
                rows={result}
                totalPages={totalPage}
                totalRecord={totalRecord}
                rowEdit={this.rowEdit}
                singleSelect={false}
                width={150}
                showSelectedCount={false}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                addRow={true}
                deleteRow={true}
                exportName='TS'
                initialize={initializeTS}
                dropSelectedRows={this.dropSelectedRows}
                columns={columns}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='save' type="button" className="primary btn-small btn-long" disabled={!disabled} onClick={this.save}> {t('saveBtn')}</button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}
HelpOnTripSeal = reduxForm({
  form: 'HelpOnTripSeal'
})(HelpOnTripSeal);

const mapStateToProps = state => ({
  result: state.triphubReducer.tripresult,
  totalPage: state.triphubReducer.totalPageLink,
  totalRecord: state.triphubReducer.totalRecordLink,
  isSaveRequested: state.triphubReducer.isSaveRequested,
  formValues: state.form.TripPlan,
})

const mapDispatchToProps = (dispatch) => ({
  fetchTripSeal: (queryString, pageNo, pageLimit) => dispatch(fetchTripSeal(queryString, pageNo, pageLimit)),
  initializeTS: () => dispatch(initializeTS()),
  saveTripDtl: (params) => dispatch(saveTripDtl(params)),
  deleteTripSeal: (params) => dispatch(deleteTripSeal(params)),
})

export default compose(withTranslation('vehicleSeal'), connect(mapStateToProps, mapDispatchToProps))(HelpOnTripSeal);