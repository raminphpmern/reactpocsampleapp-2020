import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import DataGrid from 'components/Common/DataGrid';
import { connect } from 'react-redux';
import { getSerialNumbers, initializeSN } from "actions/tripplanAction";

const columns = [
  { key: "br_request_id", name: "Booking Request" },
  { key: "ddh_dispatch_doc_no", name: "Dispatch Doc No" },
  { key: "ctsd_serial_no", name: "Serial No" }
]

class SerialDetails extends Component {
  constructor(props) {
    super(props);
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
  }

  componentDidMount() {
    const { rowInfo } = this.props
    this.props.getSerialNumbers(`br_request_id=${rowInfo.br_request_id}&ddh_dispatch_doc_no=${rowInfo.ddh_dispatch_doc_no}`, 1, 10)
  }

  changeLimit(pageNo, limit) {
    const { rowInfo } = this.props
    this.props.getSerialNoResults(`br_request_id=${rowInfo.br_request_id}&ddh_dispatch_doc_no=${rowInfo.ddh_dispatch_doc_no}`, pageNo, limit);
  }
  paginationHandler(pageNo, limit) {
    const { rowInfo } = this.props
    this.props.getSerialNoResults(`br_request_id=${rowInfo.br_request_id}&ddh_dispatch_doc_no=${rowInfo.ddh_dispatch_doc_no}`, pageNo, limit);
  }

  render() {
    const { result, totalPage, totalRecord, initializeSN } = this.props
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  rowKey="br_request_id"
                  rows={result}
                  columns={columns}
                  totalPages={totalPage}
                  showCheckbox={false}
                  width={150}
                  paginationHandler={this.paginationHandler}
                  changeLimit={this.changeLimit}
                  totalRecord={totalRecord}
                  initialize={initializeSN}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  result: state.tripplanReducer.serialnoresult,
  totalPage: state.tripplanReducer.totalPage,
  totalRecord: state.tripplanReducer.totalRecord,
})

const mapDispatchToProps = (dispatch) => ({
  getSerialNumbers: (values, pageNo, pageLimit) => dispatch(getSerialNumbers(values, pageNo, pageLimit)),
  initializeSN: () => dispatch(initializeSN())
})

export default connect(mapStateToProps, mapDispatchToProps)(SerialDetails)
