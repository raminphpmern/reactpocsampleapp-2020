import React, { Component } from 'react'
import DataGrid from 'components/Common/DataGrid';
import DropDownEditor from 'components/Common/DataGrid/DropDownEditor';
import { Grid } from "semantic-ui-react";
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import i18n from 'i18n';
import _ from 'lodash';
import  * as updateResourceAction from 'actions/updateResourceAction';
import DatePickerEditor from 'components/Common/DataGrid/DatePickerEditor';
import ObjectFormatter from 'components/Common/DataGrid/ObjectFormatter';

const headers = [
  { key: "wms_veh_desc", name: i18n.t("updateResource:agentid")},
  { key: "wms_veh_desc", name: i18n.t("updateResource:agentname")},
  { key: "wms_veh_own_typ", name: i18n.t('updateResource:ownertype')},
  { key: "tlrut_resource_type", name: i18n.t('updateResource:resourcecategory'), editor: <DropDownEditor propName="typeOptions"
    resultType="object" />, formatter: <ObjectFormatter fieldName='tlrut_resource_type' /> },
  { key: "tlrut_resource_id", name: i18n.t("updateResource:resourceid"),editable: true},
  { key: "tlrut_license_plate", name: i18n.t("updateResource:licenseplateno"),editable: true},
  { key: "tlrut_vendor_ref", name: i18n.t("updateResource:vendorrefno"),editable: true },
  { key: "tlrut_effective_from_date", name: i18n.t("updateResource:effectivefrom"), editor: DatePickerEditor, showTimeSelect: true },
  { key: "tlrut_effective_to_date", name: i18n.t("updateResource:effectiveto"), editor: DatePickerEditor, showTimeSelect: true }
]

class updateResource extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRows: []
    }
    this.rowEdit = this.rowEdit.bind(this)
    this.dropSelectedRows = this.dropSelectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
    this.save = this.save.bind(this)
  }

  componentDidMount() {
    const { formValues, getResourceDtl, getTypeOptions } = this.props
    const queryString = `pageNo=${1}&limit=${10}`
    getResourceDtl(formValues.trip_id, queryString, 10)
    const type="RESCATE"
    getTypeOptions(type,queryString)
  }
  
  changeLimit(pageNo, limit) {
    const { formValues } = this.props
    const queryString = `pageNo=${1}&limit=${10}`
    this.props.getResourceDtl(formValues.trip_id, queryString, 10)
  }

  paginationHandler(pageNo, limit) {
    const { formValues} = this.props
    const queryString = `pageNo=${1}&limit=${10}`
    this.props.getResourceDtl(formValues.trip_id, queryString, 10)
  }

  rowEdit(row, updateValue) {
    if (row && row.new === true) {
      let { selectedRows } = this.state
      if (selectedRows.length > 0) {
        const index = _.findIndex(selectedRows, (selectedRow) => {
          return (selectedRow.id === row.id
          )
        })
        if (index >= 0) {
          selectedRows[index] = row
        } else {
          selectedRows.push(row)
        }
        this.setState({ selectedRows })

      } else {
        selectedRows.push(row)
      }
      this.setState({ selectedRows })
    }
    else {
      let { selectedRows, tab } = this.state
      const uniqColumnName = 'tlrut_resource_id'
      const propsName ='attachments'
      const response = _.reduce(this.props[propsName], (arr, item) => {
        if (item[uniqColumnName] === row[uniqColumnName]) {
          _.merge(item, updateValue)
          arr.push(item)
        }
        return arr
      }, [])
      selectedRows = selectedRows.concat(response)
      this.setState({ selectedRows })
    }
  }

  dropSelectedRows(rows) {  
    const { selectedRows } = this.state   
    const { formValues }= this.props
    this.props.deleteTripResources(formValues.trip_id, rows)
    this.setState({ selectedRows: [] })
  }  

  save() {  
    const { selectedRows } = this.state   
    const { formValues }= this.props  
    this.props.saveTripResources(formValues.trip_id, selectedRows)
    this.setState({ selectedRows: [] })
  }

  render() {
    const { formValues,  totalPage, totalRecord, pageLimit, t ,attachments,typeOptions} = this.props
    return (
      <Grid stackable className="fixed-grid">
        <Grid.Row>
          <Grid.Column width='8'>
            <label>Trip id:{formValues.trip_id}  </label>
          </Grid.Column>       
        </Grid.Row>
        <Grid.Row className="document_wrapper">
          <Grid.Column>
            <DataGrid
              columns={headers}
              rows={attachments}
              rowEdit={this.rowEdit}
              width={150}
              showSelectedCount={false}
              totalPages={totalPage}
              changeLimit={this.changeLimit}
              paginationHandler={this.paginationHandler}
              totalRecord={totalRecord}
              pageLimit={pageLimit}
              addRow={true}
              deleteRow={true}
              removeColumnHeaderFormatter={true}
              dropSelectedRows={this.dropSelectedRows}
              selectedRows={this.selectedRows}
            />
          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column width={16}>
            <div className="text-center">
              <button id='save' type="button" className="primary btn-small btn-long" onClick={this.save}> {t('saveBtn')}</button>
            </div>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    )
  }
}

const mapDispatchToProps = dispatch => ({ 
  getResourceDtl: (tripId, pageNo, limit) => dispatch(updateResourceAction.getResourceDtl(tripId, pageNo, limit)),
  getTypeOptions: (type,queryString) => dispatch(updateResourceAction.getTypeOptions(type,queryString)),
  saveTripResources: (tripId, params,queryString) => dispatch(updateResourceAction.saveTripResources(tripId, params,queryString)),
  deleteTripResources: (tripId, params,queryString) => dispatch(updateResourceAction.deleteTripResources(tripId, params,queryString)),
  
});
const mapStateToProps = state => ({
  attachments: state.updateResourceReducer.attachments,
  totalPage: state.updateResourceReducer.totalPage,
  totalRecord: state.updateResourceReducer.totalRecord,
  pageLimit: state.updateResourceReducer.limit,
  typeOptions: state.updateResourceReducer.typeOptions,
});

export default compose(withTranslation('updateResource'), connect(mapStateToProps, mapDispatchToProps))(updateResource)
