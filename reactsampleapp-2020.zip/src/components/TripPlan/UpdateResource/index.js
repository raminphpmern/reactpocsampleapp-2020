import React, { Component } from 'react'
import Popup from 'components/Common/Popup';
import UpdateResource from './updateResourcePopup';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';

class UpdateResourcePopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      fileName: null,
    };
    this.toggle = this.toggle.bind(this)
  }

  toggle() {
    this.setState({ open: !this.state.open })
  }

  render() {
    const { title, formValues } = this.props
    return (
      <div className="multiple-attachment-wrapper">
      <Popup open={this.state.open} close={this.toggle} size='fullscreen'
        header={title} description={<UpdateResource
          {...this.props}
          formValues={formValues ? formValues.values : {}}
        />} close={this.toggle} />
      <a onClick={this.toggle}>Update Resource</a>
    </div>
    )
  }
}

const mapStateToProps = state => ({
  formValues: state.form.TripPlan,
});

export default compose(withTranslation('TripPlan'), connect(mapStateToProps, null))(UpdateResourcePopup)