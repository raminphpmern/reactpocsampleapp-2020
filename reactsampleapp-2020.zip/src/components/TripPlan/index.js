import React, { Component } from 'react';
import { reduxForm } from 'redux-form';
import Wrapper from "components/LandingPage/Wrapper";
import { connect } from 'react-redux';
import { Grid, Icon } from "semantic-ui-react";
import Popup from 'components/Common/Popup';
import HelpOnTripPlan from "../Dispatch/DispatchCreate/HelpOnTripPlan";
import DataGrid from 'components/Common/DataGrid';
import Footer from "components/TripPlan/Footer";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import * as tripplanAction from "actions/tripplanAction";
import * as masterActions from 'actions/masterAction';
import { withTranslation } from 'react-i18next';
import _ from 'lodash';
import { compose } from 'redux';
import "./trip.css";
import DynamicFields from 'components/Common/DynamicFields';
import jsonLogic from 'json-logic-js';
import {
  tripFormFields, bHubLegBehaviourRule, bHubLegBehaviourFields, deliveryRules,
  returnRule, lineHaulRule, lineHaulVisibleCols, pickRule,
  brDtlHeaders, standardEventDtlHeaders, accidentIncidentHeaders, incidentHeaders,
} from './Helper';
import { formatFormValues } from 'lib/CommonHelper';
import { AlertError } from 'lib/Alert'
import validate from './validation';
import history from 'routes/history';
import { SEARCH_WORD_COUNT } from 'config';
import MultipleAttachments from 'components/Common/MultipleAttachments';
import LinkPopUp from '../Common/DataGrid/LinkPopUp';
import SealDetails from './SealDetails/SealDetails';

class TripPlan extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRows: [],
      tripHelp: false,
      rating: 0,
      currentHelp: '',
      standardEventsHeaders: standardEventDtlHeaders,
      tab: 0,
      formFields: tripFormFields,
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.inputChange = this.inputChange.bind(this)
    this.ratingChanged = this.ratingChanged.bind(this)
    this.toggle = this.toggle.bind(this)
    this.selectTripId = this.selectTripId.bind(this)
    this.handlelegBehaviours = this.handlelegBehaviours.bind(this)
    this.handleSelectChange = this.handleSelectChange.bind(this)
    this.tripPlanSave = this.tripPlanSave.bind(this)
    this.handledispatchDocno = this.handledispatchDocno.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.onRowEdit = this.onRowEdit.bind(this)
    this.search = this.search.bind(this)
    this.fillData = this.fillData.bind(this)
    this.postData = this.postData.bind(this)
    this.incidentExpenseOnEdit = this.incidentExpenseOnEdit.bind(this)
    this.dropSelectedRows = this.dropSelectedRows.bind(this)
    this.handlelegIds = this.handlelegIds.bind(this)
  }

  componentWillUnmount() {
    this.props.initializeTripLogs()
  }

  componentDidMount() {
    const {
      idType,
      getidType,
      stdEvents,
      getstdEvents,
      mode_of_collections,
      getModeOfCollections,
      relationType,
      getrelationType,
      expenseType,
      getexpenseType,
      incidentType,
      getincidentType,
      accidentType,
      getaccidentType,
    } = this.props;
    /*  from link to launch screen code starts  */
    const { match: { params } } = this.props;

    if (params.trId) {
      this.props.initialize({ trip_id: decodeURIComponent(params.trId), tabIndex: 0 })
      this.props.getTripLogs({ trip_id: decodeURIComponent(params.trId) }, 1, 10)
      this.props.fetchExpenseDetails(decodeURIComponent(params.trId), 1, 10)
      this.props.getIncidentDetails(decodeURIComponent(params.trId), 1, 10)
    } else {
      this.props.initialize({ tabIndex: 0 })
    }
    /*  from link to launch screen code ends  */
    if (idType.length === 0) {
      getidType();
    }
    if (relationType.length === 0) {
      getrelationType();
    }
    if (expenseType.length === 0) {
      getexpenseType();
    }
    if (incidentType.length === 0) {
      getincidentType();
    }
    if (accidentType.length === 0) {
      getaccidentType();
    }

    if (stdEvents.length === 0) {
      getstdEvents();
    }
    if (mode_of_collections.length === 0)
      getModeOfCollections()

    let node = document.getElementById("trip_id")
    node && node.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let hash = this.props.formValues && this.props.formValues.values
        if (hash.trip_id) {
          this.props.getTripLogs({ trip_id: hash.trip_id }, 1, 10)
          this.props.fetchExpenseDetails(hash.trip_id, 1, 10)
          this.props.getIncidentDetails(hash.trip_id, 1, 10)
          history.push(`/tripLog/${encodeURIComponent(hash.trip_id)}`)
          this.setState({ selectedRows: [], formFields: tripFormFields, tab: 0 })
          this.props.initialize({ tabIndex: 0, trip_id: hash.trip_id })
        }
        event.preventDefault()
      }
    })
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.result !== nextProps.result) {
      if (nextProps.result.length > 0) {
        let hash = _.cloneDeep(this.props.formValues.values)
        const trip = nextProps.result[0]
        hash['wms_code_desc'] = trip['wms_code_desc']
        this.props.initialize(hash)
      }
    }
  }

  selectedRows(values) {
    this.setState({ selectedRows: values })
  }

  onRowEdit(row) {
    let { selectedRows } = this.state
    if (selectedRows.length > 0) {
      const index = _.findIndex(selectedRows, (selectedRow) => {
        return (selectedRow.ddh_dispatch_doc_no === row.ddh_dispatch_doc_no
          && selectedRow.plptd_trip_plan_seq === row.plptd_trip_plan_seq
          && selectedRow.br_request_id === row.br_request_id)
      })
      selectedRows[index] = row
      this.setState({ selectedRows })
    }
  }
  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  formSubmit(values) {
    this.postData(values, 'save')
  }
  postData(values, action) {
    const { formFields, selectedRows } = this.state
    let tripstatus = ['Cancelled', 'Deleted', 'Executed', 'Shortclosed']
    let status = values.wms_code_desc
    if (action === 'save') {
      if (tripstatus.includes(status)) {
        AlertError('Trip plan in Cancelled,Deleted,Executed,Shortclosed  Status cannot Modify.')
        return
      }
    }
    if (action === 'confirmed') {
      if (tripstatus.includes(status)) {
        AlertError('Trip plan in Cancelled,Deleted,Executed,Shortclosed  Status cannot Confirm.')
        return
      }
    }
    let hash = _.reduce(Object.keys(values), (hash, obj) => {
      const field = _.find(formFields, (field) => field.value === obj)
      if (field) {
        hash[obj] = values[obj]
      }

      if (obj === 'tpad_attachment') {
        hash['tpad_attachment_file_name'] = values['tpad_attachment_file_name']
      }
      return hash
    }, {})
    hash = formatFormValues(hash, 'LOWER')
    hash['selectedRows'] = selectedRows
    hash['activeTab'] = values.tabIndex
    hash['btnAction'] = action
    this.props.post(hash, 1, 10);
    this.setState({ selectedRows: [] })
  }

  tripPlanSave() {
    this.postData(this.props.formValues.values, 'save')
  }

  selectTripId(selectedTripId) {
    if (selectedTripId && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
        hash["trip_id"] = selectedTripId["plpth_trip_plan_id"]

      } else {
        hash["trip_id"] = selectedTripId["plpth_trip_plan_id"]
      }

      this.props.initialize(hash)
    }
  }

  ratingChanged(newRating) {
    this.setState({ rating: newRating })
    let hash = {}
    if (this.props.formValues && this.props.formValues.values) {
      hash = _.cloneDeep(this.props.formValues.values);
    }
    hash.feedback = newRating;
    this.props.initialize(hash)
  }

  inputChange(e) {
    this.setState({ rating: e.target.value })
  }

  handlelegBehaviours(data) {
    let { standardEventsHeaders, formFields } = this.state
    const { formValues } = this.props
    let hash = _.cloneDeep(formValues.values)
    if (data) {
      if (data.value.toLowerCase() === 'bhub') {
        formFields = _.filter(formFields, (field) => _.includes(bHubLegBehaviourFields, field.value))
        this.setState({ formFields })
      } else
        if (data.value.toLowerCase() === 'lhtr') {
          formFields = _.filter(formFields, (field) => _.includes(lineHaulVisibleCols, field.value))
          this.setState({ formFields })
        } else
          if (data.value.toLowerCase() === 'pick') {
            const additionalColumns = [{ label: 'Consignor', value: 'consignor', type: 'inputBox' }]
            const fields = _.filter(tripFormFields, (field) => field.value !== 'ccd_consignee_name')
            this.setState({ formFields: fields.concat(additionalColumns) })
          } else {
            this.setState({ formFields: tripFormFields })
          }
      this.props.getTripEvents(`plptd_leg_behaviour=${data.value}`)

      if (data.value.toLowerCase() === 'dvry') {
        standardEventsHeaders = _.filter(standardEventsHeaders, (event) => event.key !== 'handed_over')
        this.setState({ standardEventsHeaders: standardEventsHeaders })
      } else {
        this.setState({ standardEventsHeaders: standardEventDtlHeaders })
      }
      hash["plptd_leg_behaviour"] = data
      this.props.getTripLogs(formatFormValues(hash, 'LOWER'), 1, 10);
      this.setState({ selectedRows: [] })
    } else {
      hash["plptd_leg_behaviour"] = null
      this.props.getTripLogs(formatFormValues(hash, 'LOWER'), 1, 10);
      this.setState({ formFields: tripFormFields })
    }
  }

  handledispatchDocno(data) {
    const { formValues } = this.props
    let hash = _.cloneDeep(formValues.values)
    if (data) {
      hash['ddh_dispatch_doc_no'] = data
      this.props.getTripLogs(formatFormValues(hash, 'LOWER'), 1, 10);
      this.setState({ selectedRows: [] })
    } else {
      hash['ddh_dispatch_doc_no'] = null
      this.props.getTripLogs(formatFormValues(hash, 'LOWER'), 1, 10);
      this.setState({ selectedRows: [] })
    }
  }

  handlelegIds(data) {
    const { formValues } = this.props
    let hash = _.cloneDeep(formValues.values)
    if (data) {
      hash['plptd_trip_plan_seq'] = data
      this.props.getTripLogs(formatFormValues(hash), 1, 10);
      this.setState({ selectedRows: [] })
    } else {
      hash['plptd_trip_plan_seq'] = null
      this.props.getTripLogs(hash, 1, 10);
      this.setState({ selectedRows: [] })
    }
  }

  handleSelectChange(data, childName) {
    let hash = _.cloneDeep(this.props.formValues.values)
    hash[childName] = data
    hash = formatFormValues(hash, 'LOWER')

    if (jsonLogic.apply(pickRule, hash)) {
      const additionalColumns = [{ label: 'Consignor', value: 'consignor', type: 'inputBox' }]
      const fields = _.filter(tripFormFields, (field) => field.value !== 'ccd_consignee_name')
      this.setState({ formFields: fields.concat(additionalColumns) })
      return
    }

    if (jsonLogic.apply(deliveryRules, hash)) {
      const additionalColumns = [
        { label: 'Number', value: 'Number', type: 'inputBox' },
        { label: 'Amount', value: 'Amount', type: 'inputBox' }
      ]
      this.setState({ formFields: tripFormFields.concat(additionalColumns) })
      return
    }

    if (jsonLogic.apply(lineHaulRule, hash)) {
      // const additionalColumns = [{ label: 'NOD', value: 'NOD', type: 'inputBox' }]
      const fields = _.filter(tripFormFields, (field) => _.includes(lineHaulVisibleCols, field.value))
      // this.setState({ formFields: fields.concat(additionalColumns) })
      this.setState({ formFields: fields })
      return
    }

    if (jsonLogic.apply(returnRule, hash)) {
      const additionalColumns = [{ label: 'NOD', value: 'NOD', type: 'inputBox' }]
      const fields = _.filter(tripFormFields, (field) => field.value !== 'mode_collection')
      this.setState({ formFields: fields.concat(additionalColumns) })
      return
    }

    if (jsonLogic.apply(bHubLegBehaviourRule, hash)) {
      const fields = _.filter(tripFormFields, (field) => _.includes(bHubLegBehaviourFields, field.value))
      this.setState({ formFields: fields })
      return
    }

    this.setState({ formFields: tripFormFields })
  }

  changeLimit(pageNo, limit) {
    let hash = formatFormValues(this.props.formValues.values, 'LOWER')
    if (this.state.tab === 2) {
      this.props.fetchExpenseDetails(hash.trip_id, pageNo, limit)
    } else if (this.state.tab === 3) {
      this.props.getIncidentDetails(hash.trip_id, pageNo, limit)
    } else {
      this.props.getTripLogs(hash, pageNo, limit)
    }
  }

  paginationHandler(pageNo, limit) {
    let hash = formatFormValues(this.props.formValues.values, 'LOWER')
    if (this.state.tab === 2) {
      this.props.fetchExpenseDetails(hash.trip_id, pageNo, limit)
    } else if (this.state.tab === 3) {
      this.props.getIncidentDetails(hash.trip_id, pageNo, limit)
    } else {
      this.props.getTripLogs(hash, pageNo, limit)
    }
  }

  onTabChange(index) {
    this.setState({ tab: index, selectedRows: [] })
    let hash = _.cloneDeep(this.props.formValues.values)
    hash['tabIndex'] = index
    this.props.initialize(hash)
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT)
      this.props.getReasonCode(fieldName, `keyword=${value}`);
  }

  fillData(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    hash['tled_reason_code'] = option.value
    hash['tled_reason_description'] = option.wms_code_desc
    this.props.initialize(hash);
  }

  dropSelectedRows(rows) {
    if (rows.length > 0) {
      let { selectedRows, tab } = this.state
      let hash = _.cloneDeep(this.props.formValues.values);
      hash['selectedRows'] = selectedRows
      hash['activeTab'] = tab
      const actionName = tab === 2 ? 'deleteExpenseDtl' : 'deleteIncidentDtl'
      this.props.deleteExpAndIncidentDtl(actionName, hash.trip_id, hash, 1, 10);
    }
  }

  incidentExpenseOnEdit(row, updateValue) {
    _.merge(row, updateValue)
    if (row && row.new === true) {
      let { selectedRows } = this.state
      if (selectedRows.length > 0) {
        const index = _.findIndex(selectedRows, (selectedRow) => {
          return (selectedRow.id === row.id
          )
        })
        if (index >= 0) {
          selectedRows[index] = row
        } else {
          selectedRows.push(row)
        }
        this.setState({ selectedRows })

      } else {
        selectedRows.push(row)
      }
      this.setState({ selectedRows })
    }
    else {
      let { selectedRows, tab } = this.state
      const uniqColumnName = tab === 2 ? 'tms_tled_guid' : 'tlid_incident_id'
      const propsName = tab === 2 ? 'expenseDetailsResult' : 'incidentDetailsResult'
      const response = _.reduce(this.props[propsName], (arr, item) => {
        if (item[uniqColumnName] === row[uniqColumnName]) {
          _.merge(item, updateValue)
          arr.push(item)
        }
        return arr
      }, [])
      selectedRows = selectedRows.concat(response)
      this.setState({ selectedRows })
    }
  }

  render() {
    const { handleSubmit, legBehaviours, dispatchDocno, idType, stdEvents, mode_of_collections, relationType, totalPage, totalRecord, pageLimit, expenseType, incidentType, tripEvents, accidentType, t, expenseDetailsResult, expenseTotalPage, expenseTotalRecord, reason_code, result, incidentDetailsResult, incidentTotalPage, incidentTotalRecord, incidentpageLimit, formValues ,legIds} = this.props;
    const { formFields, currentHelp, tripHelp, rating, selectedRows, standardEventsHeaders } = this.state
    return (
      <Wrapper DisableBranch={true}>
        <Popup size="fullscreen" open={tripHelp} close={() => { this.toggle('help', 'tripHelp') }}
          header="Help on Trip Plan" description={<HelpOnTripPlan close={this.toggle}
            handleOnSelect={this.selectTripId} name={currentHelp} />} />

        <div className="collection-head">
          <h3>TRIP LOG</h3>
          <div className='back-link'>
            <a href="javascript: false" onClick={this.props.history.goBack}><Icon disabled name='arrow left' />
              {t('translation:back')}</a>
          </div>
        </div>
        <div className="trip-wrapper">
          <form onSubmit={handleSubmit(this.formSubmit)}>
            <Grid stackable>
              <Grid.Row>
                <DynamicFields
                  search={this.search}
                  fillData={this.fillData}
                  filterFields={formFields}
                  legBehaviours={legBehaviours}
                  dispatchDocno={dispatchDocno}
                  mode_of_collections={mode_of_collections}
                  idType={idType}
                  stdEvents={stdEvents}
                  relationType={relationType}
                  toggle={this.toggle}
                  handlelegBehaviours={this.handlelegBehaviours}
                  handledispatchDocno={this.handledispatchDocno}
                  handleSelectChange={this.handleSelectChange}
                  ratingChanged={this.ratingChanged}
                  rating={rating}
                  inputChange={this.inputChange}
                  expenseType={expenseType}
                  incidentType={incidentType}
                  accidentType={accidentType}
                  tripEvents={tripEvents}
                  reason_code={reason_code}
                  legIds={legIds}
                  handlelegIds={this.handlelegIds}
                />
              </Grid.Row>
              <Grid.Row>
                <Grid.Column width='10'>
                </Grid.Column>
                <Grid.Column width='2'>
                  <LinkPopUp name="Seal Details" defaultValue="Seal Details"> <SealDetails /> </LinkPopUp>
                </Grid.Column>
                <Grid.Column width='3'>
                  {formValues && formValues.values.ddh_dispatch_doc_no &&
                    <MultipleAttachments
                      docType='THUPOD'
                      title='Proof of Delivery'
                    />}
                </Grid.Column>
                <Grid.Column width={16} className="text-center">
                  <button id="post" type="submit" className="primary btn-small btn-long">
                    POST
                  </button>
                </Grid.Column>
              </Grid.Row>
            </Grid>
            <Grid stackable>
              <Grid.Row>
                <Grid.Column width={16}>
                </Grid.Column>
                <Grid.Column width={16} className="trip-plan-grid">
                  <Tabs
                    selectedIndex={this.state.tab}
                    onSelect={tabIndex => this.onTabChange(tabIndex)}>
                    <TabList>
                      <Tab>BR-THU Details</Tab>
                      <Tab> Standard Event Details</Tab>
                      <Tab>Expense</Tab>
                      <Tab>Incident</Tab>

                    </TabList>

                    <TabPanel>
                      <DataGrid
                        columns={brDtlHeaders}
                        rows={result}
                        rowKey="br_request_id"
                        selectedRows={this.selectedRows}
                        width={150}
                        showSelectedCount={false}
                        totalPages={totalPage}
                        changeLimit={this.changeLimit}
                        paginationHandler={this.paginationHandler}
                        enableExport={true}
                        totalRecord={totalRecord}
                        pageLimit={pageLimit}
                        rowEdit={this.onRowEdit}
                      />
                    </TabPanel>
                    <TabPanel>
                      <DataGrid
                        columns={standardEventsHeaders}
                        rows={result}
                        rowKey="br_request_id"
                        selectedRows={this.selectedRows}
                        width={150}
                        showSelectedCount={false}
                        totalPages={totalPage}
                        changeLimit={this.changeLimit}
                        paginationHandler={this.paginationHandler}
                        enableExport={true}
                        totalRecord={totalRecord}
                        pageLimit={pageLimit}
                        rowEdit={this.onRowEdit}
                      />
                    </TabPanel>
                    <TabPanel>
                      <Grid.Row className="document_wrapper">
                        <DataGrid
                          columns={accidentIncidentHeaders}
                          rows={expenseDetailsResult}
                          selectedRows={this.selectedRows}
                          width={150}
                          showSelectedCount={false}
                          totalPages={expenseTotalPage}
                          changeLimit={this.changeLimit}
                          paginationHandler={this.paginationHandler}
                          enableExport={true}
                          totalRecord={expenseTotalRecord}
                          pageLimit={pageLimit}
                          addRow={true}
                          deleteRow={true}
                          dropSelectedRows={this.dropSelectedRows}
                          rowEdit={this.incidentExpenseOnEdit}
                        />
                      </Grid.Row>
                    </TabPanel>
                    <TabPanel>
                      <Grid.Row className="document_wrapper">
                        <DataGrid
                          columns={incidentHeaders}
                          rows={incidentDetailsResult}
                          selectedRows={this.selectedRows}
                          width={150}
                          showSelectedCount={false}
                          totalPages={incidentTotalPage}
                          changeLimit={this.changeLimit}
                          paginationHandler={this.paginationHandler}
                          enableExport={true}
                          totalRecord={incidentTotalRecord}
                          pageLimit={incidentpageLimit}
                          addRow={true}
                          deleteRow={true}
                          dropSelectedRows={this.dropSelectedRows}
                          rowEdit={this.incidentExpenseOnEdit}
                        />
                      </Grid.Row>
                    </TabPanel>
                  </Tabs>
                </Grid.Column>
              </Grid.Row>
              <Grid.Row>
                <Grid.Column width={16}>
                  <Footer tab={this.state.tab} selectedRecords={selectedRows} postData={this.postData} handleSubmit={handleSubmit} />
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </form>
        </div>
      </Wrapper>
    );
  }
}

TripPlan = reduxForm({
  form: "TripPlan",
  validate,
})(TripPlan);

const mapDispatchToProps = dispatch => ({
  getrelationType: () =>
    dispatch(tripplanAction.getrelationType('relationType')),
  getstdEvents: () =>
    dispatch(tripplanAction.getstdEvents('stdEvents')),
  getidType: () =>
    dispatch(tripplanAction.getidType('idType')),
  getexpenseType: () =>
    dispatch(tripplanAction.getOptions('expenseType')),
  getincidentType: () =>
    dispatch(tripplanAction.getOptions('incidentType')),
  getaccidentType: () =>
    dispatch(tripplanAction.getOptions('accidentType')),
  getTripEvents: (queryString) =>
    dispatch(tripplanAction.getOptions('tripEvents', queryString, 'stdEvents')),
  getTripLogs: (data, pageNo, limit) =>
    dispatch(tripplanAction.getTripLogs(data, pageNo, limit)),
  getModeOfCollections: () => dispatch(masterActions.getModeOfCollections('mode_of_collections')),
  post: (data, pageNo, limit) => dispatch(tripplanAction.tripPost(data, pageNo, limit)),
  fetchExpenseDetails: (tripId, pageNo, limit) => dispatch(tripplanAction.fetchExpenseDetails(tripId, pageNo, limit)),
  getReasonCode: (action, queryStr, stateName) => dispatch(masterActions.getReasonCode(action, queryStr, stateName)),
  deleteExpAndIncidentDtl: (actionName, tripId, data, pageNo, limit) => dispatch(tripplanAction.deleteExpAndIncidentDtl(actionName, tripId, data, pageNo, limit)),
  getIncidentDetails: (tripId, pageNo, limit) => dispatch(tripplanAction.getIncidentDetails(tripId, pageNo, limit)),
  initializeTripLogs: () => dispatch(tripplanAction.initializeTripLogs())
});
const mapStateToProps = state => ({
  result: state.tripplanReducer.result,
  totalPage: state.tripplanReducer.totalPage,
  totalRecord: state.tripplanReducer.totalRecord,
  pageLimit: state.tripplanReducer.limit,
  formValues: state.form.TripPlan,
  legBehaviours: state.tripplanReducer.options.legBehaviours,
  dispatchDocno: state.tripplanReducer.options.dispatchDocno,
  idType: state.tripplanReducer.options.idType,
  relationType: state.tripplanReducer.options.relationType,
  stdEvents: state.tripplanReducer.options.stdEvents,
  mode_of_collections: state.masterReducer.options.mode_of_collections,
  expenseType: state.tripplanReducer.options.expenseType,
  incidentType: state.tripplanReducer.options.incidentType,
  accidentType: state.tripplanReducer.options.accidentType,
  expenseDetailsResult: state.tripplanReducer.expenseDetails.result,
  expenseTotalPage: state.tripplanReducer.expenseDetails.totalPage,
  expenseTotalRecord: state.tripplanReducer.expenseDetails.totalRecord,
  reason_code: state.masterReducer.options.reason_code,
  incidentDetailsResult: state.tripplanReducer.incidentDetails.result,
  incidentTotalPage: state.tripplanReducer.incidentDetails.totalPage,
  incidentTotalRecord: state.tripplanReducer.incidentDetails.totalRecord,
  incidentpageLimit: state.tripplanReducer.incidentDetails.limit,
  legIds: state.tripplanReducer.options.legIds
});

export default compose(withTranslation('TripPlan'), connect(mapStateToProps, mapDispatchToProps))(TripPlan)