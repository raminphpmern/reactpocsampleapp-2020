import React, { Component } from "react";
import { connect } from 'react-redux';
import * as tripplanidsAction from "actions/tripplanAction";
import { formatFormValues } from 'lib/CommonHelper';
import { AlertError } from 'lib/Alert';
import _ from 'lodash';
import UpdateResourcePopup from '../../TripPlan/UpdateResource/index';

class Footer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      amend: false,
    };
    this.renderButtonBasedOnTab = this.renderButtonBasedOnTab.bind(this)
    this.confirm = this.confirm.bind(this)
  }
  shortAmend(action) {
    const { formValues, selectedRecords, tab } = this.props
    let values = this.props.formValues.values
    let hash = _.reduce(Object.keys(values), (hash, obj) => {
      const field = _.find(formValues, (field) => field.value === obj)
      if (field) {
        hash[obj] = values[obj]
      }

      if (obj === 'tpad_attachment') {
        hash['tpad_attachment_file_name'] = values['tpad_attachment_file_name']
      }
      return hash
    }, {})
    hash = values
    hash = formatFormValues(hash, 'LOWER')
    hash['selectedRows'] = selectedRecords
    hash['activeTab'] = tab

    if (action === 'tripShortclose') {
      let tripstatus = ['Cancelled', 'Deleted', 'Executed', 'Shortclosed']
      let status = values.wms_code_desc
      if (tripstatus.includes(status)) {
        AlertError('Trips in Executed,Short Closed, Cancelled, Deleted status cannot be Short Closed.')
        return
      }
    }
    if (action === 'tripAmend') {
      let status = values.wms_code_desc
      if (status !== 'Executed') {
        AlertError('Only a trip with status as Executed can be amended')
        return
      }
    }
    this.props.tripAmend(action, hash, 1, 10);
  }
  tripAmend() {
    this.shortAmend('tripAmend')
  }
  tripShortclose() {
    this.shortAmend('tripShortclose')

  }

  tripRemovebr() {
    const { formValues, selectedRecords } = this.props
    let values = this.props.formValues.values
    let tripstatus = ['Cancelled', 'Deleted', 'Executed', 'Shortclosed']
    let status = values.wms_code_desc
    if (tripstatus.includes(status)) {
      AlertError('Selected Booking Request cannot be removed for Trip plan in Cancelled,Deleted,Executed,Shortclosed  Status.')
      return
    }
    let hash = _.reduce(Object.keys(values), (hash, obj) => {
      const field = _.find(formValues, (field) => field.value === obj)
      if (field) {
        hash[obj] = values[obj]
      }

      if (obj === 'tpad_attachment') {
        hash['tpad_attachment_file_name'] = values['tpad_attachment_file_name']
      }
      return hash
    }, {})
    hash = values
    hash = formatFormValues(hash, 'LOWER')
    hash['selectedRows'] = selectedRecords
    this.props.tripRemovebr(hash, 1, 10);
  }

  tripReject() {
    const { formValues, selectedRecords, tab } = this.props
    let values = this.props.formValues.values
    let tripstatus = ['Executed', 'Shortclosed']
    let status = values.wms_code_desc
    if (values.wms_code_desc === 'Cancelled') {
      AlertError('The trip has already been cancelled.')
      return
    }
    if (tripstatus.includes(status)) {
      AlertError('The Trip is in Executed,Shortclosed  Status.It cannot be cancelled')
      return
    }
    let hash = _.reduce(Object.keys(values), (hash, obj) => {
      const field = _.find(formValues, (field) => field.value === obj)
      if (field) {
        hash[obj] = values[obj]
      }

      if (obj === 'tpad_attachment') {
        hash['tpad_attachment_file_name'] = values['tpad_attachment_file_name']
      }
      return hash
    }, {})
    hash = values
    hash = formatFormValues(hash, 'LOWER')
    hash['selectedRows'] = selectedRecords
    hash['activeTab'] = tab
    this.props.tripReject(hash, 1, 10);
  }

  confirm() {
    const { formValues, postData } = this.props
    postData(formValues.values, 'confirmed')
  }

  renderButtonBasedOnTab() {
    const { tab } = this.props

    if (tab === 0) {
      return (
        <div>
          {/* <button type="button" id="removebr" className="primary btn-small" onClick={() => { this.tripRemovebr(); }}>Remove BR from trip</button> */}
        </div>)
    } else if (tab === 1) {
      return (<div>
        <button type="button" id="confirm" className="primary btn-small" onClick={this.confirm}>Confirm</button>
        <button type="button" id="shortclose" className="primary btn-small" onClick={() => { this.tripShortclose(); }}>Shortclose</button>
        <button id="amend" type="button" onClick={() => { this.tripAmend(); }} className="primary btn-small">
          Amend  </button>
      </div>)
    } else if (tab === 2) {
      return (
        <div>
          <button className="primary btn-small" id="approve" onClick={() => {
            this.handleApprove();
          }}>Approve</button>
          <button type="button" className="primary btn-small" id="reject" onClick={() => {
            this.tripReject();
          }}>Reject</button>
        </div>
      )
    }
  }

  render() {
    return (
      <div className="footer">
        <div className="actions br-hd-footer">
          <div>
            <button className="primary btn-small" type='submit' >Save</button>
          </div>
          <div>
            <UpdateResourcePopup title="Update Resource" />
          </div>
          {this.renderButtonBasedOnTab()}
        </div>
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  tripRemovebr: (data, pageNo, limit) => dispatch(tripplanidsAction.gettripRemovebr(data, pageNo, limit)),
  tripReject: (data, pageNo, limit) => dispatch(tripplanidsAction.tripReject(data, pageNo, limit)),
  tripAmend: (action, data, pageNo, limit) => dispatch(tripplanidsAction.tripButtonActions(action, data, pageNo, limit)),
})

const mapStateToProps = state => ({
  formValues: state.form.TripPlan
})

export default connect(mapStateToProps, mapDispatchToProps)(Footer)

