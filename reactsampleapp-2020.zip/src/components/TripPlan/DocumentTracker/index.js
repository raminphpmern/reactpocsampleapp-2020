import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import { compose } from 'redux';
import DataGrid from 'components/Common/DataGrid';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import DropDownEditor from 'components/Common/DataGrid/DropDownEditor'
import i18n from 'i18n';
import { reduxForm, Field } from "redux-form";
import InputField from "components/Common/InputField";
import _ from 'lodash';
import { docTrackerDtl, initializeDT, saveDocTrackerRecords, deleteDocTrackerRecords } from 'actions/documentTrackerAction';
import * as masterActions from 'actions/masterAction';
import InputSearchEditor from 'components/Common/DataGrid/InputSearchEditor';
import { getValue } from 'lib/LocalStorage';
import { AlertError } from 'lib/Alert';

class DocumentTracker extends Component {
  constructor(props) {
    super(props);
    this.state = {
      updatedRows: [],
      selectedIds: null
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.rowEdit = this.rowEdit.bind(this)
    this.save = this.save.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.buildQueryString = this.buildQueryString.bind(this)
    this.dropSelectedRows = this.dropSelectedRows.bind(this)
  }

  buildQueryString(dispatchNo) {
    let queryString = ''
    const { rowInfo, transactionType } = this.props

    if (transactionType === 'TRIP HUB') {
      queryString = `ddh_dispatch_doc_no=${dispatchNo}`
    } else if (transactionType === 'TRIP LOG') {
      queryString = `br_request_id=${rowInfo.br_request_id}&plpth_trip_plan_id=${rowInfo.plpth_trip_plan_id}&ddh_dispatch_doc_no=${dispatchNo || rowInfo.ddh_dispatch_doc_no}`
    }
    queryString = `${queryString}&transactionType=${transactionType.toUpperCase()}`
    return queryString
  }

  componentDidMount() {
    const { getQuickCodeMaster, docType, rowInfo, transactionType } = this.props

    if (transactionType !== 'TRIP HUB') {
      this.props.initialize({ plpth_trip_plan_id: rowInfo.plpth_trip_plan_id, br_request_id: rowInfo.br_request_id })
      if (docType.length === 0) {
        getQuickCodeMaster("docType");
      }
    } else {
      this.props.initialize({ ddh_dispatch_doc_no: null })
    }

    let node = document.getElementById("dispatchDocNo")
    node && node.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let hash = this.props.formValues.values
        if (hash.ddh_dispatch_doc_no) {
          this.props.docTrackerDtl(this.buildQueryString(hash.ddh_dispatch_doc_no), 1, 10)
        } else {
          AlertError('Dispatch document is required.')
        }
        event.preventDefault()
      }
    })
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.isSaveRequested !== this.props.isSaveRequested) {
      if (nextProps.isSaveRequested) {
        this.setState({ updatedRows: [] })
      }
    }

    if (nextProps.selectedRows !== this.props.selectedRows) {
      if (nextProps.selectedRows.length > 0) {
        this.setState({ updatedRows: nextProps.selectedRows })
      }
    }
  }

  rowEdit(row, updateValue) {
    _.merge(row, updateValue)
    if (row && row.new === true) {
      let { updatedRows } = this.state
      if (!row.hasOwnProperty('serial_no')) {
        let { result } = this.props
        if (updatedRows.length > 0) {
          result = updatedRows
        }
        const doc = result[result.length - 1]
        if (doc && doc['serial_no'])
          row['serial_no'] = parseInt(doc['serial_no']) + 1
        else
          row['serial_no'] = 1
      }
      if (updatedRows.length > 0) {
        const recordIndex = _.findIndex(updatedRows, (item) => item.id === row.id)
        if (recordIndex >= 0) {
          updatedRows[recordIndex] = row
        } else {
          updatedRows.push(row)
        }
      } else {
        updatedRows.push(row)
      }
      this.setState({ updatedRows })
    }
    else {
      let { updatedRows } = this.state
      const index = _.findIndex(updatedRows, (item) => item.serial_no === row.serial_no)
      if (index >= 0) {
        updatedRows[index] = _.merge(updatedRows[index], updateValue)
      } else {
        const response = _.reduce(this.props.result, (arr, item) => {
          if (item.serial_no === row.serial_no) {
            _.merge(item, updateValue)
            arr.push(item)
          }
          return arr
        }, [])
        updatedRows = updatedRows.concat(response)
      }
      this.setState({ updatedRows })
    }
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  save() {
    const { saveDocTrackerRecords, formValues } = this.props
    const { updatedRows } = this.state
    if (updatedRows.length > 0) {
      const isValid = this.isAllRowsValid(updatedRows)
      if (isValid) {
        let hash = _.cloneDeep(formValues.values)
        hash['selectedRecords'] = updatedRows
        saveDocTrackerRecords(hash)
      } else {
        AlertError('Doc Type or Doc No is missing!')
      }
    }
  }

  isAllRowsValid(rows) {
    let isValid = true
    rows.forEach(row => {
      if (!row.doc_no || !row.doc_type) {
        isValid = false
        return false
      }
    });

    return isValid
  }

  dropSelectedRows() {
    const { deleteDocTrackerRecords, formValues } = this.props
    const { selectedIds } = this.state
    if (selectedIds.length > 0) {
      let hash = _.cloneDeep(formValues.values)
      hash['selectedRecords'] = selectedIds
      deleteDocTrackerRecords(hash)
    }
  }

  changeLimit(pageNo, limit) {
    const queryString = this.buildQueryString()
    this.props.docTrackerDtl(queryString, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    const queryString = this.buildQueryString()
    this.props.docTrackerDtl(queryString, pageNo, limit);
  }

  renderFields(transactionType) {
    let fields = []

    if (transactionType === 'TRIP LOG') {
      fields.push(<Grid.Column width={4} key='1'>
        <Field
          name="plpth_trip_plan_id"
          component={InputField}
          label="Trip No"
          readOnly={true}
        />
      </Grid.Column>)
    }

    fields.push(<Grid.Column width={6} key='2'>
      <Field
        id="dispatchDocNo"
        name="ddh_dispatch_doc_no"
        component={InputField}
        label="Dispatch Doc No:"
        required="true"
      />
    </Grid.Column>)

    if (transactionType === 'TRIP LOG') {
      fields.push(<Grid.Column width={6} key='3'>
        <Field
          name="br_request_id"
          component={InputField}
          label="Booking Request Id"
          readOnly={true}
        />
      </Grid.Column>)
    }

    return fields
  }

  getGridColumns(location) {
    const locCond = (row) => row.loc === location.value
    return [
      { key: "doc_type", name: i18n.t("documentTracker:doc_type"), editor: <DropDownEditor propName="docType" />, editable: locCond },
      { key: "doc_no", name: i18n.t("documentTracker:doc_no"), editable: locCond },
      { key: "loc", name: i18n.t("documentTracker:loc"), editable: false },
      { key: "username", name: i18n.t("documentTracker:username"), editable: false },
      { key: "reason", name: i18n.t("documentTracker:reason"), editor: <InputSearchEditor propName='reason_code' />, editable: locCond },
      { key: "br_id", name: i18n.t("documentTracker:br_id"), editable: false }
    ]
  }

  render() {
    const { result, totalPage, totalRecord, initializeDT, t, pageLimit, currentUser, transactionType } = this.props
    const location = JSON.parse(getValue('currentBranch') || '{}')
    const { updatedRows } = this.state
    const disabled = updatedRows.length === 0
    const user = (currentUser && currentUser.username);
    const defaultNewRowHash = { loc: location.value, username: user }
    const isTripLog = transactionType === 'TRIP LOG'

    return (
      <div>
        <form>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding document-tracker-header">
              {this.renderFields(transactionType)}
            </Grid.Row>
          </Grid>
          <Grid stackable>
            <Grid.Row className="document_wrapper">
              <Grid.Column width={16} >
                <DataGrid
                  columns={this.getGridColumns(location)}
                  rows={result}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  rowEdit={this.rowEdit}
                  singleSelect={false}
                  width={250}
                  showSelectedCount={false}
                  selectedRows={this.selectedRows}
                  dropSelectedRows={this.dropSelectedRows}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  addRow={isTripLog}
                  deleteRow={isTripLog}
                  exportName='DT'
                  initialize={initializeDT}
                  pageLimit={pageLimit}
                  defaultNewRowHash={defaultNewRowHash}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              {isTripLog && <Grid.Column width={16}>
                <div className="text-center">
                  <button id='save' type="button" className="primary btn-small btn-long" disabled={disabled} onClick={this.save} > {t('saveBtn')} </button>
                </div>
              </Grid.Column>}
            </Grid.Row>
          </Grid>
        </form>
      </div >
    )
  }
}

DocumentTracker = reduxForm({
  form: 'DocumentTrackerForm'
})(DocumentTracker);

const mapStateToProps = state => ({
  formValues: state.form.DocumentTrackerForm,
  result: state.documentTrackerReducer.result,
  totalPage: state.documentTrackerReducer.totalPageLink,
  totalRecord: state.documentTrackerReducer.totalRecordLink,
  isSaveRequested: state.documentTrackerReducer.isSaveRequested,
  pageLimit: state.documentTrackerReducer.linkLimit,
  docType: state.masterReducer.options.docType,
  currentUser: state.loginReducer.user,
  selectedRows: state.documentTrackerReducer.selectedRows,
})

const mapDispatchToProps = (dispatch) => ({
  docTrackerDtl: (queryString, pageNo, limit) => dispatch(docTrackerDtl(queryString, pageNo, limit)),
  initializeDT: () => dispatch(initializeDT()),
  saveDocTrackerRecords: (params) => dispatch(saveDocTrackerRecords(params)),
  getQuickCodeMaster: type => dispatch(masterActions.getQuickCodeMaster(type)),
  deleteDocTrackerRecords: (params) => dispatch(deleteDocTrackerRecords(params)),
})

export default compose(withTranslation('documentTracker'), connect(mapStateToProps, mapDispatchToProps))(DocumentTracker);
