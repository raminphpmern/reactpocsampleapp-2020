
export default function validate(values) {
  const errors = {};
  if (values.tabIndex === 0 || values.tabIndex === 1) {
    if (!values.ddh_dispatch_doc_no) {
      errors.ddh_dispatch_doc_no = "Dispatch Document No is required."
    }
    if (!values.plptd_leg_behaviour) {
      errors.plptd_leg_behaviour = "Leg Behaviour is required."
    }

    if (values.standard_events && !values.date_time) {
      errors.date_time = "Date & Time is required."
    }
  }

  if (values.quantity && values.quantity < 0) {
    errors.quantity = "Quantity should be greater then 0."
  }
  return errors
}