import React from 'react';
import LinkPopUp from 'components/Common/DataGrid/LinkPopUp';
import SerialDetails from './POPUP/SerialDetails';
import MoreDetails from 'components/InventoryHub/Popup/MoreDetails';
import DropDownEditor from 'components/Common/DataGrid/DropDownEditor';
import DatePickerEditor from 'components/Common/DataGrid/DatePickerEditor';
import NumberEditor from 'components/Common/DataGrid/NumberEditor';
import MultipleAttachments from 'components/Common/MultipleAttachments';
import DocumentTracker from './DocumentTracker';
import CustomerDocument from './CustomerDocument';
import _ from 'lodash';

export const tripFormFields = [
  {
    label: 'Trip Id', value: 'trip_id', type: 'inputSearch', id: 'trip_id',
    iconName: 'search',
    methods: {
      handleClick: 'toggle',
    },
    values: {
      props: {
        childName: "tripHelp",
      }
    }
  },
  {
    label: 'Dispatch Document No', value: 'ddh_dispatch_doc_no', type: 'dropDown',
    values: {
      props: {
        options: 'dispatchDocno',
        clearable: true
      }
    },
    methods: {
      handleOnSelect: 'handledispatchDocno'
    }
  },
  {
    label: 'Leg Behaviour', value: 'plptd_leg_behaviour', type: 'dropDown',
    values: {
      props: {
        options: 'legBehaviours',
        clearable: true
      }
    },
    methods: {
      handleOnSelect: 'handlelegBehaviours'
    }
  },
  {
    label: 'Status', value: 'wms_code_desc', type: 'inputBox', values: {
      props: {
        readOnly: true,
      }
    }
  },
  {
    label: 'Leg Id', value: 'plptd_trip_plan_seq', type: 'dropDown',
    values: {
      props: {
        options: 'legIds',
        clearable: true
      }
    },
    methods: {
      handleOnSelect: 'handlelegIds'
    }
  },
  {
    label: 'Standard Events', value: 'standard_events', type: 'dropDown',
    values: {
      props: {
        options: 'stdEvents',
        childName: 'standard_events',
        clearable: true,
      }
    },
    methods: {
      handleOnSelect: 'handleSelectChange'
    }
  },
  {
    label: 'Date & Time', value: 'date_time', type: 'dateTime',
    values: {
      props: {
        showTimeSelect: true
      }
    }
  },
  { label: 'Consignee', value: 'ccd_consignee_name', type: 'inputBox' },
  { label: 'Remarks', value: 'tled_remarks1', type: 'inputBox' },
  {
    label: 'Id Type', value: 'tltrh_id_type', type: 'dropDown',
    values: {
      props: {
        options: 'idType',
        clearable: true
      }
    }
  },
  // { label: 'Representative', value: 'Representative', type: 'inputBox' },
  {
    label: 'Relationship Type', value: 'tltrh_desig_relation', type: 'dropDown',
    values: {
      props: {
        options: 'relationType',
        clearable: true
      }
    }
  },
  { label: 'Id No', value: 'tltrh_id_no', type: 'inputBox' },
  { label: 'Total Amount collected', value: 'tlccd_amount_collected', type: 'inputBox' },
  {
    label: 'Quantity', value: 'quantity', type: 'inputBox', filedType: 'number',
    values: {
      props: {
        min: 1,
      }
    }
  },
  {
    label: 'Reason Code', value: 'tled_reason_code', type: 'inputSearch', id: 'reason_code',
    methods: {
      findByCompanyAndFLMName: 'search',
      fillNameValues: 'fillData'
    },
    values: {
      props: {
        options: 'reason_code'
      }
    }
  },
  {
    label: 'Reason Description', value: 'tled_reason_description', type: 'inputBox', values: {
      props: {
        readOnly: true,
      }
    }
  },
  {
    label: 'Mode of Collection', value: 'mode_collection', type: 'dropDown',
    values: {
      props: {
        options: 'mode_of_collections',
        childName: 'mode_collection',
        clearable: true
      }
    },
    methods: {
      handleOnSelect: 'handleSelectChange'
    }
  },
  {
    label: 'Feedback', value: 'dds_feedback', type: 'inputBox',
    methods: {
      onChange: 'inputChange'
    }
  },
  {
    label: '', value: 'rating', type: 'inputRatingStar',
    methods: {
      onChange: 'ratingChanged'
    },
    values: {
      props: {
        value: 'rating'
      }
    }
  },
]

export const bHubLegBehaviourRule = {
  "and": [
    {
      "===": [{ "var": "plptd_leg_behaviour" }, 'bhub']
    },
    {
      "or": [
        { "===": [{ "var": "standard_events" }, 'retund'] },
        { "===": [{ "var": "standard_events" }, 'dep'] },
        { "===": [{ "var": "standard_events" }, 'hndovrf'] },
        { "===": [{ "var": "standard_events" }, 'arvd'] },
        { "===": [{ "var": "standard_events" }, 'takenover'] },
      ],
    },
  ]
}

export const bHubLegBehaviourFields = ['trip_id', 'ddh_dispatch_doc_no', 'plptd_leg_behaviour', 'wms_code_desc', 'standard_events', 'date_time', 'quantity', 'tpad_attachment', 'wms_code_desc', 'tled_remarks1']


export const deliveryRules = {
  "and": [
    {
      "===": [{
        "var": "plptd_leg_behaviour"
      }, 'dvry']
    },
    {
      "===": [{
        "var": "standard_events"
      }, "hndovrf"
      ]
    },
    {
      "===": [{
        "var": "mode_collection"
      }, "chk"
      ]
    }
  ]
}


export const returnRule = {
  "and": [
    {
      "===": [{ "var": "plptd_leg_behaviour" }, 'dvry']
    },
    {
      "or": [
        { "===": [{ "var": "standard_events" }, 'retund'] },
        { "===": [{ "var": "standard_events" }, 'retvbecha'] },
        { "===": [{ "var": "standard_events" }, 'retvb'] },
      ],
    },
  ]
}

export const lineHaulRule = {
  "and": [
    {
      "or": [
        { "===": [{ "var": "plptd_leg_behaviour" }, 'lhdir'] },
        { "===": [{ "var": "plptd_leg_behaviour" }, 'lhodc'] },
        { "===": [{ "var": "plptd_leg_behaviour" }, 'lhta'] },
        { "===": [{ "var": "plptd_leg_behaviour" }, 'lhto'] },
        { "===": [{ "var": "plptd_leg_behaviour" }, 'lhtr'] },
        { "===": [{ "var": "plptd_leg_behaviour" }, 'lhtrl'] },
        { "===": [{ "var": "plptd_leg_behaviour" }, 'lhv'] },
      ]
    },
    {
      "or": [
        { "===": [{ "var": "standard_events" }, 'retund'] },
        { "===": [{ "var": "standard_events" }, 'dep'] },
        { "===": [{ "var": "standard_events" }, 'hndovrf'] },
        { "===": [{ "var": "standard_events" }, 'arvd'] },
        { "===": [{ "var": "standard_events" }, 'takenover'] },
        { "===": [{ "var": "standard_events" }, ''] },
      ],
    },
  ]
}

export const pickRule = {
  "===": [{ "var": "plptd_leg_behaviour" }, 'pick']
}

export const lineHaulVisibleCols = ['trip_id', 'ddh_dispatch_doc_no', 'plptd_leg_behaviour', 'wms_code_desc', 'standard_events', 'quantity', 'tpad_attachment', 'tled_remarks1', 'tled_reason_code', 'date_time']

const documentTrackerJsonRule = {
  "and": [
    { "===": [{ "var": 'plptd_leg_behaviour' }, "Dvry"] },
    { "===": [{ "var": 'plpth_trip_plan_status' }, "EX"] },
  ]
}


const SerialLinkFormatter = <LinkPopUp name="Serial No" defaultValue="Serial No"> <SerialDetails /> </LinkPopUp>
const moreDetailsFormatter = <LinkPopUp name='More Details' defaultValue='More Details'> <MoreDetails transactionType='TRIP LOG' /> </LinkPopUp>
const DocumenttrackerLinkFormatter = <LinkPopUp name="Document Tracker" defaultValue="Document Tracker" linkJsonRule={documentTrackerJsonRule}> <DocumentTracker transactionType='TRIP LOG' />  </LinkPopUp>
const CustomerDocumentLinkFormatter = <LinkPopUp name="Customer Document" defaultValue="Customer Document"> <CustomerDocument /> </LinkPopUp>



export const brDtlHeaders = [
  { key: "br_request_id", name: "Booking Request ID" },
  { key: "cd_thu_id", name: "THU" },
  { key: "ddh_dispatch_doc_no", name: "Dispatch Document" },
  { key: "ctsd_serial_no", name: "Serial No", formatter: SerialLinkFormatter, getRowMetaData: (row) => row },
  { key: "cd_thu_qty", name: "Planned Quantity" },
  { key: "tltd_thu_actual_qty", name: "Actual Quantity" },
  { key: "more_details", name: "More Details", formatter: moreDetailsFormatter, getRowMetaData: (row) => row },
  { key: "plpth_trip_plan_to", name: "Trip To" },
  { key: "ccd_consignee_name", name: "Consignee Name" },
  { key: "tlccd_amount_to_be_collected", name: "Amount to be collected" },
  { key: "tlccd_amount_collected", name: "Amount Collected" },
  { key: "tlccd_reason_for_diff", name: "Reason Code" },
  { key: "tlccd_reason_for_diff_desc", name: "Reason Code Description" },
  { key: "hmotd_thu_serial_no", name: "Output THU Seal No" },
  { key: "hmlpsd_sealed_by", name: "Seal By", editable: true },
  { key: "plptd_trip_plan_seq", name: "Leg Id" },
  { key: "plptd_leg_behaviour", name: "Leg Behaviour" }
]

export const standardEventDtlHeaders = [
  { key: "tled_bkr_id", name: "Booking Request ID" },
  { key: "ddh_dispatch_doc_no", name: "Dispatch Document" },
  { key: "plptd_trip_plan_seq", name: "Leg Id" },
  { key: "plptd_leg_behaviour", name: "Leg Behaviour" },
  // { key: "trip_start_date", name: "Trip Start" },
  { key: "arvd_date", name: "Arrived" },  
  { key: "dep_date", name: "Departed" },
  { key: "hndovrf_date", name: "Handed Over" },
  { key: "takenover_date", name: "Taken Over" },
  { key: "retund_date", name: "Returned" },
  // { key: "trip_end_date", name: "Trip End" },
  { key: "tled_reason_code", name: "Reason Code" },
  { key: "tled_reason_description", name: "Reason Code Description" },
  { key: "tled_remarks1", name: "Remarks" },
  { key: "tled_event_nod", name: "NOD", editable: true },
  { key: "tlcid_mode_of_collection", name: "Mode of collection" },
  { key: "dds_feedback", name: "Feedback" },
  { key: "terd_qualitative_value", name: "Actual Qualitative Details" },
  { key: "terd_quantitative_value", name: "Actual  Quantitative Details" },
  { key: "Document Tracker", name: "Document Tracker", formatter: DocumenttrackerLinkFormatter, getRowMetaData: (row) => row },
  { key: "Customer Document", name: "Customer Document", formatter: CustomerDocumentLinkFormatter, getRowMetaData: (row) => row },

]

const commonJsonRule = {
  "!==": [{ "var": "new" }, true]
}
export const accidentIncidentHeaders = [
  { key: "tled_expense_type", name: "Expense Type", editor: <DropDownEditor propName="expenseType" /> },
  { key: "tled_bill_amount", name: "Expense Amount", editable: true, editor: <NumberEditor allowNegNumber={false} /> },
  { key: "tled_remarks", name: "Remarks", editable: true },
  {
    key: "tlid_attachment", name: "Expense  Attachments", formatter: <MultipleAttachments title='Expense' docType='EXPENSE' linkJsonRule={commonJsonRule} />, getRowMetaData: (row) => row
  },
  { key: "5", name: "Rejection Remarks", editable: true }
]

export const incidentHeaders = [
  { key: "tlid_incident_id", name: "Incident Id" },
  { key: "tlid_incident_date", name: "Incident Date", editor: DatePickerEditor, showTimeSelect: true },
  { key: "tlid_incident_type", name: "Incident Type", editor: <DropDownEditor propName="incidentType" /> },
  { key: "tlid_detailed_description", name: "Detailed Description", editable: true },
  { key: "tlid_accident_type", name: "Accident Type", editor: <DropDownEditor propName="accidentType" /> },
  {
    key: "tlid_attachment1", name: "Attachments", formatter: <MultipleAttachments title='Incident' docType='INCIDENT' linkJsonRule={commonJsonRule} />, getRowMetaData: (row) => row
  }
]

