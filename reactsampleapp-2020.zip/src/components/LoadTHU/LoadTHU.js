import React, { Component } from "react";
import InputField from "components/Common/InputField";
import { compose } from 'redux';
import InputSearchField from "components/Common/InputSearchField"
import { reduxForm, Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import { save } from "actions/loadTHUAction";
import { SEARCH_WORD_COUNT } from "config";
import { getProducts } from "actions/masterAction";
import { withTranslation } from 'react-i18next';
import { formatFormValues } from "lib/CommonHelper";
import { getValue } from "lib/LocalStorage";
import "./loadTHU.css";
import validate from './LoadTHUValidation'
import _ from "lodash";

class LoadThuSave extends Component {
  constructor(props) {
    super(props);
    this.formSubmit = this.formSubmit.bind(this)
    this.search = this.search.bind(this)
    this.setValue = this.setValue.bind(this);
  }

  componentDidMount() {
    if (getValue('currentBranch')) {
      let currentBranch = JSON.parse(getValue('currentBranch') ? getValue('currentBranch') : {})
      if (currentBranch.value) {
        this.props.initialize({ division: currentBranch.wms_div_desc, location: currentBranch.value });
      }
    }
  }

  search(value) {
    if (value.length >= SEARCH_WORD_COUNT) {
      this.props.getProducts(
        'products',
        `keyword=${value}&wms_thu_is_ethu=1`
      );
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "products") {
      hash["wms_thu_id"] = option.value;
    }
    this.props.initialize(hash);
  }

  formSubmit() {
    const formValues = this.props.formValues.values
    this.props.save(formatFormValues(formValues))
  }

  render() {
    const { handleSubmit, products, t } = this.props;

    return (
      <div>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="division"
                  component={InputField}
                  label={t('division')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="location"
                  component={InputField}
                  label={t('location')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="wms_thu_id"
                  component={InputSearchField}
                  label={t('wms_thu_id')}
                  findByCompanyAndFLMName={this.search}
                  id="products"
                  options={products.slice(0, 5)}
                  fillNameValues={this.setValue}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="prefixlength"
                  component={InputField}
                  label={t('prefixlength')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="prefixvalue"
                  component={InputField}
                  label={t('prefixvalue')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="totaseriallength"
                  component={InputField}
                  label={t('totaseriallength')}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="thuserialnofrom"
                  component={InputField}
                  label={t('thuserialnofrom')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="thuserialnoto"
                  component={InputField}
                  label={t('thuserialnoto')}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='save' type="submit" className="primary btn-small btn-long"> {t('saveBtn')}</button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    );
  }
}

LoadThuSave = reduxForm({
  form: "LoadTHU",
  validate
})(LoadThuSave);

const mapDispatchToProps = dispatch => ({
  getProducts: (action, queryStr) =>
    dispatch(getProducts(action, queryStr)),
  save: (params, actions) => dispatch(save(params, actions)),
});

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
  formValues: state.form.LoadTHU,
  current_location: state.masterReducer.options.current_location,
  products: state.masterReducer.options.products
});

export default compose(withTranslation('loadTHU'), connect(mapStateToProps, mapDispatchToProps))(LoadThuSave);
