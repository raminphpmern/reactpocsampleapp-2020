import React, { Component } from 'react';
import Wrapper from "components/LandingPage/Wrapper";
import LoadTHU from './LoadTHU';
import { Icon } from 'semantic-ui-react'
import { withTranslation } from 'react-i18next';
import './loadTHU.css';

class LoadThu extends Component {

  render() {
    const { t } = this.props
    return (
      <Wrapper DisableBranch={true}>
        <div className="loadthu-head">
          <h3>{t('title')}</h3>
          <div className="back-link">
            <a href="javascript: false" onClick={this.props.history.goBack}>
              <Icon disabled name='arrow left' />
              {t('translation:back')}</a>
          </div>
        </div>
        <div className="loadthu-wrapper">
          <LoadTHU />
        </div>
      </Wrapper>
    )
  }
}

export default withTranslation('loadTHU')(LoadThu)