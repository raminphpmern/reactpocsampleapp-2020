import i18n from 'i18n';

const Validation = (values) => {
  const errors = {};

  if (!values.wms_thu_id) {
    errors.wms_thu_id = i18n.t('loadTHU:validation_thuid')
  }

  if (!values.prefixlength)
    errors.prefixlength = i18n.t('loadTHU:validation_prefixlength')
  else if (values.prefixlength && !/^[0-9]+$/i.test(values.prefixlength)) {
    errors.prefixlength = i18n.t('loadTHU:numbervalid')
  }

  if (!values.prefixvalue)
    errors.prefixvalue = i18n.t('loadTHU:validation_prefixvalue')
  else if (values.prefixvalue && values.prefixvalue.length > values.prefixlength) {
    errors.prefixvalue = i18n.t('loadTHU:prefixlengthgreater')
  }
  else if (values.prefixvalue && values.prefixvalue.length < values.prefixlength) {
    errors.prefixvalue = i18n.t('loadTHU:prefixlengthlesser')
  }

  if (!values.totaseriallength)
    errors.totaseriallength = i18n.t('loadTHU:validation_totaseriallength')
  else if (values.totaseriallength > 18) {
    errors.totaseriallength = i18n.t('loadTHU:seriallengthvalue')
  }
  else if (values.totaseriallength && !/^[0-9]+$/i.test(values.totaseriallength)) {
    errors.totaseriallength = i18n.t('loadTHU:numbervalid')
  }

  if (!values.thuserialnofrom)
    errors.thuserialnofrom = i18n.t('loadTHU:validation_thuserialnofrom')
  else if (values.thuserialnofrom && values.thuserialnofrom.length > values.totaseriallength) {
    errors.thuserialnofrom = i18n.t('loadTHU:seriallengthgreater')
  }
  else if (values.thuserialnofrom && values.thuserialnofrom.length < values.totaseriallength) {
    errors.thuserialnofrom = i18n.t('loadTHU:seriallengthlesser')
  }

  if (!values.thuserialnoto)
    errors.thuserialnoto = i18n.t('loadTHU:validation_thuserialnoto')
  else if (values.thuserialnoto && values.thuserialnoto.length > values.totaseriallength) {
    errors.thuserialnoto = i18n.t('loadTHU:seriallengthgreater')
  }
  else if (values.thuserialnoto && values.thuserialnoto.length < values.totaseriallength) {
    errors.thuserialnoto = i18n.t('loadTHU:seriallengthlesser')
  }

  return errors
}

export default Validation;