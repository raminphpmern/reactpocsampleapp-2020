import React, { Component } from 'react';
import Wrapper from 'components/LandingPage/Wrapper';
import Select from 'react-select';
import { reduxForm, Field } from 'redux-form';
import { connect } from 'react-redux';
import DataGrid from 'components/Common/DataGrid';
import Footer from 'components/BrHub/Footer';
import { Grid } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import * as masterActions from 'actions/masterAction';
import { search } from 'actions/brHubActions';
import { SEARCH_WORD_COUNT } from 'config';
import { gridHeaders, advancesFields } from './Helper';
import { stringToComponentMapper } from 'components/Common/DynamicFields/Helper';
import _ from 'lodash';
import './index.css';

class BrHubNew extends Component {
  constructor(props) {
    super(props)
    this.state = {
      options: advancesFields,
      selectedField: null,
      filterFields: [],
      selectedRecords: null,
      accordActive: false,
      searchTags: null,
    }

    this.onFilterSelect = this.onFilterSelect.bind(this)
    this.renderFields = this.renderFields.bind(this)
    this.addFilter = this.addFilter.bind(this)
    this.search = this.search.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.fillData = this.fillData.bind(this)
    this.toggleAccordionState = this.toggleAccordionState.bind(this)
    this.removeTagFilter = this.removeTagFilter.bind(this)
    this.editTagInput = this.editTagInput.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
  }

  componentDidMount() {
    const {
      getQuickCodeMaster,
      getEventDetail,
      getEventLocation,
      shipment_type,
      service_mode,
      request_type,
      last_event,
      event_location,
      failed_attempts,
      creation_mode,
      request_status,
      billing_status,
      current_location
    } = this.props;
    if (shipment_type.length === 0) {
      getQuickCodeMaster("shipment_type");
    }
    if (service_mode.length === 0) {
      getQuickCodeMaster("service_mode");
    }

    if (request_type.length === 0) {
      getQuickCodeMaster("request_type");
    }

    if (billing_status.length === 0) {
      getQuickCodeMaster("billing_status");
    }

    if (last_event.length === 0) {
      getEventDetail("last_event");
    }

    if (event_location.length === 0) {
      getEventLocation("event_location");
    }

    if (failed_attempts.length === 0) {
      getEventDetail("failed_attempts");
    }

    if (creation_mode.length === 0) {
      getQuickCodeMaster("creation_mode");
    }

    if (request_status.length === 0) {
      getQuickCodeMaster("request_status");
    }

    if (current_location.length === 0) {
      getQuickCodeMaster("current_location")
    }
  }

  onFilterSelect(field) {
    this.setState({ selectedField: field })
  }

  addFilter() {
    const { selectedField, filterFields, options } = this.state
    const availableFilters = _.filter(options, (field) => field.value !== selectedField.value)
    filterFields.push(selectedField)
    this.setState({ filterFields: filterFields, selectedField: null, options: availableFilters })
    const values = this.props.formValues.values
    let hash = _.cloneDeep(values)
    hash = _.reduce(hash, (temp, v, k) => {
      let field = _.find(this.state.filterFields, (field) => field.value === k)
      if (v) {
        temp[k] = {
          value: v,
          label: field.label
        }
      }
      return temp
    }, {})
    this.setState({ searchTags: hash })
    this.props.search(values, 1, 10);
  }

  renderFields(stateName) {
    let fields = this.state[stateName]
    if (!Array.isArray(fields)) {
      fields = fields ? [fields] : []
    }
    return fields.map((field, key) => {
      let methods = field.methods || {};
      let props = field.values ? field.values.props || {} : {};
      if (Object.keys(methods).length > 0) {
        methods = _.reduce(methods, (hash, v, k) => {
          hash[k] = this[v]
          return hash;
        }, {})
      }
      if (Object.keys(props).length > 0) {
        props = _.reduce(props, (hash, v, k) => {
          hash[k] = this.props[v]
          return hash
        }, {})
      }
      return (
        <Grid.Column width={4} key={key}>
          <Field
            key={key}
            name={field.value}
            component={stringToComponentMapper[field.type]}
            label={field.label}
            id={field.id || field.name}
            {...methods}
            {...props}
          />
        </Grid.Column>
      )
    })
  }

  toggleAccordionState() {
    this.setState({ accordActive: !this.state.accordActive })
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName.match(/shipper/g)) {
        if (fieldName === 'shipper')
          queryString += "&searchField=wms_customer_id";
        this.props.getShipper("shipper", queryString, fieldName);
      }

      if (fieldName === 'reason_code') {
        this.props.getReasonCode(fieldName, queryString, fieldName);
      }
    }
  }

  fillData(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === 'reason_code') {
      hash['br_reason_code'] = option.wms_code_desc
    } else {
      if (fieldName === "shipper") {
        hash["br_customer_id"] = option.wms_customer_id;
      } else {
        hash["brsd_from_contact_person"] = option.wms_customer_description;
      }
    }
    this.props.initialize(hash);
  }

  selectedRows(values) {
    this.setState({ selectedRecords: values })
  }

  removeTagFilter(value, key) {
    const values = this.props.formValues.values
    let { options, searchTags } = this.state
    options.push(_.find(advancesFields, (field) => field.value === key))
    delete values[key]
    delete searchTags[key]
    this.props.search(values, 1, 10);
    this.setState({ options, searchTags })
  }

  editTagInput(key) {
    this.setState({ selectedField: _.find(advancesFields, (field) => field.value === key) })
  }

  changeLimit(pageNo, limit) {
    this.props.search(this.props.formValues.values, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.search(this.props.formValues.values, pageNo, limit);
  }

  render() {
    const { brRecords, totalPage, totalRecord } = this.props
    const { selectedField, selectedRecords, searchTags } = this.state
    return (
      <Wrapper DisableBranch={true}>
        <div className="collection-head">
          <h3>BR HUB</h3>
        </div>
        <div className="brhub-wrapper">
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={12}>
                <h3>Search</h3>
              </Grid.Column>
              <Grid.Column width={4}>
                <button type="button" className="secondary btn-small">
                  <Link to="/acceptance">Quick Booking Request</Link>
                </button>
                <button type="button" className="secondary btn-small">
                  CCM Booking Request
                </button>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={4}>
                <div className="input_field" >
                  <label>Select Column</label>
                  <div className="input_holder">
                    <Select name="custom_filter"
                      options={this.state.options}
                      onChange={this.onFilterSelect}
                      value={selectedField || null} />
                  </div>
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                {this.renderFields('selectedField')}
              </Grid.Column>
              <Grid.Column width={4}>
                {selectedField ?
                  <button type="button" className="primary btn-small btn-long" onClick={this.addFilter}>Search</button> : null
                }
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
              </Grid.Column>
              <Grid.Column width={16}>
                <DataGrid
                  columns={gridHeaders}
                  rows={brRecords}
                  rowKey="br_request_id"
                  totalPages={totalPage}
                  selectedRows={this.selectedRows}
                  width={150}
                  showSelectedCount={false}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  enableExport={true}
                  tags={searchTags}
                  removeTagFilter={this.removeTagFilter}
                  editTag={this.editTagInput}
                />
              </Grid.Column>
            </Grid.Row>

            <Grid.Row>
              <Grid.Column width={16}>
                <Footer selectedRecords={selectedRecords} />
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </div>
      </Wrapper>
    )
  }
}

BrHubNew = reduxForm({
  form: "BrHubNew"
})(BrHubNew);

const mapDispatchToProps = dispatch => ({
  getEventLocation: type => dispatch(masterActions.getEventDetail(type)),
  getQuickCodeMaster: type =>
    dispatch(masterActions.getQuickCodeMaster(type)),
  getEventDetail: type => dispatch(masterActions.getEventDetail(type)),
  getShipper: (action, queryStr, stateName) =>
    dispatch(masterActions.getShipper(action, queryStr, stateName)),
  getReasonCode: (action, queryStr, stateName) =>
    dispatch(masterActions.getReasonCode(action, queryStr, stateName)),
  search: (data, pageNo, limit) => dispatch(search(data, pageNo, limit))
});

const mapStateToProps = state => ({
  shipment_type: state.masterReducer.options.shipment_type,
  service_mode: state.masterReducer.options.service_mode,
  request_type: state.masterReducer.options.request_type,
  current_location: state.masterReducer.options.current_location,
  billing_status: state.masterReducer.options.billing_status,
  last_event: state.masterReducer.options.last_event,
  event_location: state.masterReducer.options.event_location,
  failed_attempts: state.masterReducer.options.failed_attempts,
  reason_code: state.masterReducer.options.reason_code,
  creation_mode: state.masterReducer.options.creation_mode,
  request_status: state.masterReducer.options.request_status,
  shipper: state.masterReducer.options.shipper,
  shipperFirstName: state.masterReducer.options.shipper_first_name,
  brRecords: state.brhubReducer.result,
  totalPage: state.brhubReducer.totalPage,
  totalRecord: state.brhubReducer.totalRecord,
  formValues: state.form.BrHubNew,
});

export default connect(mapStateToProps, mapDispatchToProps)(BrHubNew)