import React, { Component } from 'react';
import Wrapper from 'components/LandingPage/Wrapper';
import { compose } from 'redux';
import { reduxForm, Field } from 'redux-form';
import InputField from 'components/Common/InputField';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import DataGrid from 'components/Common/DataGrid';
import Footer from 'components/BrHub/Footer';
import { Grid, Icon } from 'semantic-ui-react';
import * as masterActions from 'actions/masterAction';
import { search, initializeBR } from 'actions/brHubActions';
import { fetchAll } from 'actions/searchTemplateActions';
import { SEARCH_WORD_COUNT } from 'config';
import { gridHeaders, basicHeaders, advancesFields, basicFields } from './Helper';
import DynamicFields from 'components/Common/DynamicFields';
import SearchTemplate from 'components/Common/SearchTemplate';
import { getValue } from 'lib/LocalStorage';
import _ from 'lodash';
import history from 'routes/history';
import './index.css';

class BrHubNew extends Component {
  constructor(props) {
    super(props)
    this.state = {
      options: advancesFields,
      filterFields: basicFields,
      selectedRecords: null,
      accordActive: false,
      searchTags: null,
      hideForm: false,
      selectedOptions: [],
      selectedTemplate: {},
      templatePopupOpen: false,
      selectedHeaderOptions: [],
    }

    this.onFilterSelect = this.onFilterSelect.bind(this)
    this.addFilter = this.addFilter.bind(this)
    this.search = this.search.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.fillData = this.fillData.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.removeTagFilter = this.removeTagFilter.bind(this)
    this.toggleForm = this.toggleForm.bind(this)
    this.editTagInput = this.editTagInput.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
    this.onTemplateChange = this.onTemplateChange.bind(this)
    this.defaultHazardocus = this.defaultHazardocus.bind(this)
    this.onHeaderSelection = this.onHeaderSelection.bind(this)
  }

  componentDidMount() {
    const {
      getQuickCodeMaster,
      getEventDetail,
      getEventLocation,
      shipment_type,
      service_mode,
      request_type,
      last_event,
      event_location,
      failed_attempts,
      creation_mode,
      request_status,
      billing_status,
      current_location,
      fetchAllTemplates,
    } = this.props;
    if (shipment_type.length === 0) {
      getQuickCodeMaster("shipment_type");
    }
    if (service_mode.length === 0) {
      getQuickCodeMaster("service_mode");
    }

    if (request_type.length === 0) {
      getQuickCodeMaster("request_type");
    }

    if (billing_status.length === 0) {
      getQuickCodeMaster("billing_status");
    }

    if (last_event.length === 0) {
      getEventDetail("last_event");
    }

    if (event_location.length === 0) {
      getEventLocation("event_location");
    }

    if (failed_attempts.length === 0) {
      getEventDetail("failed_attempts");
    }

    if (creation_mode.length === 0) {
      getQuickCodeMaster("creation_mode");
    }

    if (request_status.length === 0) {
      getQuickCodeMaster("request_status");
    }

    if (current_location.length === 0) {
      getQuickCodeMaster("current_location")
    }

    fetchAllTemplates()

    const location = JSON.parse(getValue('currentBranch') || '{}')
    this.props.initialize({ br_customer_location: location.value, br_customer_location_label: location.label });
  }

  componentWillReceiveProps(nextProps) {
    const { templates } = this.props
    if (templates !== nextProps.templates) {
      const template = nextProps.templates[0]
      if (template && Object.keys(this.state.selectedTemplate).length === 0) {
        const filters = basicFields.concat(template.tostd_search_fields)
        this.setState({ filterFields: filters, selectedTemplate: template, selectedOptions: filters })
        this.defaultHazardocus(filters)
      }
    }
  }
  defaultHazardocus(filters) {
    if (filters) {
      const hasHacCode = _.find(filters, (filter) => filter.value === 'ctsd_hac_code')
      if (hasHacCode)
        this.props.initialize({ ctsd_hac_code: 'Y' })
    }
  }

  onFilterSelect(option) {
    this.setState({ selectedOptions: option })
  }

  onHeaderSelection(option) {
    this.setState({ selectedHeaderOptions: option })
  }

  addFilter() {
    this.setState({ filterFields: basicFields.concat(this.state.selectedOptions) })
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName.match(/shipper/g)) {
        if (fieldName === 'shipper')
          queryString += "&searchField=wms_customer_id";
        this.props.getShipper("shipper", queryString, fieldName);
      }

      if (fieldName === 'reason_code') {
        this.props.getReasonCode(fieldName, queryString, fieldName);
      }
    }
  }

  fillData(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === 'reason_code') {
      hash['br_reason_code'] = option.wms_code_desc
    } else {
      if (fieldName === "shipper") {
        hash["br_customer_id"] = option.wms_customer_id;
      } else {
        hash["brsd_from_contact_person"] = option.wms_customer_description;
      }
    }
    this.props.initialize(hash);
  }

  selectedRows(values) {
    this.setState({ selectedRecords: values })
  }

  removeTagFilter(value, key) {
    const values = this.props.formValues.values
    let { searchTags } = this.state
    delete values[key]
    delete searchTags[key]
    this.setState({ searchTags })
    this.props.search(values, 1, this.props.limit);
  }

  editTagInput(key) {
    this.setState({ hideForm: false })
  }

  toggleForm() {
    this.setState({ hideForm: !this.state.hideForm })
  }

  changeLimit(pageNo, limit) {
    this.props.search(this.props.formValues.values, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.search(this.props.formValues.values, pageNo, limit);
  }

  onTemplateChange(option) {
    if (option && option.tostd_search_fields) {
      const filters = basicFields.concat(option.tostd_search_fields)
      this.setState({ filterFields: filters, selectedTemplate: option, selectedOptions: option.tostd_search_fields })
      this.defaultHazardocus(option.tostd_search_fields)
    } else {
      this.setState({ filterFields: basicFields, selectedTemplate: {}, selectedOptions: [] })
    }
  }

  formSubmit(values) {
    let hash = _.cloneDeep(values)
    let filter = {}
    hash = _.reduce(hash, (temp, v, k) => {
      let field = _.find(this.state.filterFields, (field) => field.value === k)
      if (field && v) {
        temp[k] = {
          value: v,
          label: field.label
        }
        filter[k] = v
      } else if (_.includes(['br_created_by', 'br_customer_location'], k)) {
        filter[k] = v
      }
      return temp
    }, {})
    this.setState({ searchTags: hash, hideForm: true })
    this.props.search(filter, 1, this.props.limit);
  }

  render() {
    const {
      handleSubmit, brRecords, totalPage, totalRecord, shipper, shipperFirstName,
      shipment_type, service_mode, last_event, event_location, request_type,
      failed_attempts, request_status, billing_status, current_location,
      creation_mode, reason_code, templates, initializeBR, t, limit
    } = this.props
    const { selectedRecords, searchTags, hideForm, options, filterFields, selectedTemplate, selectedOptions, selectedHeaderOptions } = this.state

    return (
      <Wrapper DisableBranch={true}>
        <div className="collection-head brhub-header-section">
          <div className='title'>
            <h3>{t('title')}</h3>
          </div>
          <div className='back-link'>
            <button className="link-button secondary" type="button" onClick={this.props.history.goBack}><Icon disabled name='arrow left' />{t('translation:back')}</button>
            <button type="button" onClick={() => history.push('/acceptance')} className="secondary btn-small nav-btn">
              {t('qbr_link')}
            </button>
          </div>
        </div>

        <div className="brhub-wrapper">
          <div className={(hideForm ? 'relative' : '') + ' toggle-title'}>
            <h3 onClick={this.toggleForm}>
              <Icon name={(hideForm ? 'down' : 'right') + ' caret'} size='large' />
              {t('searchTitle')}
            </h3>
          </div>
          {hideForm ? null :
            <form onSubmit={handleSubmit(this.formSubmit)}>
              <Grid stackable>
                <Grid.Row>
                  <Grid.Column width={8}>
                  </Grid.Column>
                  <Grid.Column width={8}>
                    <SearchTemplate
                      addFilter={this.addFilter}
                      selectedFieldsOptions={selectedOptions}
                      fieldOptions={options}
                      onChangeField={this.onFilterSelect}
                      templateOptions={templates}
                      selectedTemplate={selectedTemplate}
                      onTemplateChange={this.onTemplateChange}
                      templateType='BRHUB'
                    />
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row>
                  <Grid.Column width={4}>
                    <Field
                      name="br_customer_location_label"
                      component={InputField}
                      label={t('searchField:br_customer_location')}
                      readOnly={true}
                    />
                  </Grid.Column>
                  <Grid.Column width={12}></Grid.Column>
                  <DynamicFields
                    filterFields={filterFields}
                    search={this.search}
                    fillData={this.fillData}
                    shipper={shipper}
                    shipperFirstName={shipperFirstName}
                    shipment_type={shipment_type}
                    service_mode={service_mode}
                    last_event={last_event}
                    event_location={event_location}
                    request_type={request_type}
                    failed_attempts={failed_attempts}
                    request_status={request_status}
                    billing_status={billing_status}
                    current_location={current_location}
                    creation_mode={creation_mode}
                    reason_code={reason_code}
                  />
                </Grid.Row>

                <Grid.Row>
                  <Grid.Column width={14} className="text-center">
                    <button type="submit" className="primary btn-small btn-long">
                      {t('searchBtn')}
                    </button>
                  </Grid.Column>
                </Grid.Row>
              </Grid>
            </form>
          }
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
              </Grid.Column>
              <Grid.Column width={16}>
                <DataGrid
                  columns={basicHeaders.concat(selectedHeaderOptions)}
                  rows={brRecords}
                  rowKey="br_request_id"
                  totalPages={totalPage}
                  selectedRows={this.selectedRows}
                  width={250}
                  showSelectedCount={false}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  enableExport={true}
                  tags={searchTags}
                  removeTagFilter={this.removeTagFilter}
                  editTag={this.editTagInput}
                  exportName='Br-Hub'
                  initialize={initializeBR}
                  enableHeaderSelector={true}
                  headerSelectorOptions={{
                    options: gridHeaders,
                    onChange: this.onHeaderSelection,
                    selectedValues: selectedHeaderOptions,
                  }}
                  pageLimit={limit}
                  showCheckbox={true}
                />
              </Grid.Column>
            </Grid.Row>

            <Grid.Row>
              <Grid.Column width={16}>
                <Footer selectedRecords={selectedRecords} />
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </div>
      </Wrapper>
    )
  }
}

BrHubNew = reduxForm({
  form: "BrHubNew"
})(BrHubNew);

const mapDispatchToProps = dispatch => ({
  getEventLocation: type => dispatch(masterActions.getEventDetail(type)),
  getQuickCodeMaster: type =>
    dispatch(masterActions.getQuickCodeMaster(type)),
  getEventDetail: type => dispatch(masterActions.getEventDetail(type)),
  getShipper: (action, queryStr, stateName) =>
    dispatch(masterActions.getShipper(action, queryStr, stateName)),
  getReasonCode: (action, queryStr, stateName) =>
    dispatch(masterActions.getReasonCode(action, queryStr, stateName)),
  search: (data, pageNo, limit) => dispatch(search(data, pageNo, limit)),
  fetchAllTemplates: () => dispatch(fetchAll('BrHub')),
  initializeBR: () => dispatch(initializeBR())
});

const mapStateToProps = state => ({
  shipment_type: state.masterReducer.options.shipment_type,
  service_mode: state.masterReducer.options.service_mode,
  request_type: state.masterReducer.options.request_type,
  current_location: state.masterReducer.options.current_location,
  billing_status: state.masterReducer.options.billing_status,
  last_event: state.masterReducer.options.last_event,
  event_location: state.masterReducer.options.event_location,
  failed_attempts: state.masterReducer.options.failed_attempts,
  reason_code: state.masterReducer.options.reason_code,
  creation_mode: state.masterReducer.options.creation_mode,
  request_status: state.masterReducer.options.request_status,
  shipper: state.masterReducer.options.shipper,
  shipperFirstName: state.masterReducer.options.shipper_first_name,
  currentUser: state.loginReducer.user,
  brRecords: state.brhubReducer.result,
  totalPage: state.brhubReducer.totalPage,
  totalRecord: state.brhubReducer.totalRecord,
  formValues: state.form.BrHubNew,
  templates: state.searchTemplateReducer.templates,
  limit: state.brhubReducer.limit,
});

export default compose(withTranslation('brHub'), connect(mapStateToProps, mapDispatchToProps))(BrHubNew)