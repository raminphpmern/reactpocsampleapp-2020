import React from 'react';
import { Link } from 'react-router-dom';
import i18n from 'i18n';

const LinkFormatter = ({ value }) => {
  return (<Link to={`/acceptance/${value}`}>{value}</Link>)
};

const RecurringCirlce = ({ value }) => {
  value = value || 'N'
  const displayTxt = value === 'N' ? 'N' : 'Y'
  return (<div>
    <span className={`recurring-status ${displayTxt === 'N' ? 'green' : 'blue'}`}>{displayTxt}</span>
  </div>)
}

const StatusFormatter = ({ value }) => {
  return <span className={value.replace(/ /g, '-').toLowerCase() + ' grid-status-br'}>{value}</span>
};


export const basicHeaders = [
  { key: "br_request_id", name: i18n.t('brHubGrid:br_request_id'), formatter: LinkFormatter },
  { key: "br_customer_id", name: i18n.t('brHubGrid:br_customer_id') },
  { key: "custname", name: i18n.t('brHubGrid:custname') },
  { key: "br_recurring_flag", name: i18n.t('brHubGrid:br_recurring_flag'), formatter: RecurringCirlce },
  { key: "brstatus", name: i18n.t('brHubGrid:brstatus'), formatter: StatusFormatter },
  { key: "br_creation_date", name: i18n.t('brHubGrid:br_creation_date') },
  { key: "br_type", name: i18n.t('brHubGrid:br_type') },
]

export const gridHeaders = [
  { key: "br_original_br_id", name: i18n.t('brHubGrid:br_original_br_id') },
  { key: "br_customer_ref_no", name: i18n.t('brHubGrid:br_customer_ref_no') },
  { key: "br_sender_ref_no", name: i18n.t('brHubGrid:br_sender_ref_no') },
  { key: "br_receiver_ref_no", name: i18n.t('brHubGrid:br_receiver_ref_no') },
  { key: "ddh_dispatch_doc_type", name: i18n.t('brHubGrid:ddh_dispatch_doc_type'), editable: true },
  { key: "ddh_dispatch_doc_no", name: i18n.t('brHubGrid:ddh_dispatch_doc_no'), editable: true },
  { key: "brsd_from_pick_date", name: i18n.t('brHubGrid:brsd_from_pick_date') },
  { key: "brsd_to_delivery_date", name: i18n.t('brHubGrid:brsd_to_delivery_date') },
  { key: "br_customer_location", name: i18n.t('brHubGrid:br_customer_location') },
  { key: "tesed_event_desc", name: i18n.t('brHubGrid:tesed_event_desc'), editable: true },
  { key: "br_created_by", name: i18n.t('brHubGrid:br_created_by'), editable: true },
  { key: "br_hazardous", name: i18n.t('brHubGrid:br_hazardous') },
  { key: "wms_paramdesc", name: i18n.t('brHubGrid:wms_paramdesc'), editable: true },
  { key: "cod_or_cop", name: i18n.t('brHubGrid:cod_or_cop'), editable: true },
  { key: "br_service_type", name: i18n.t('brHubGrid:br_service_type'), editable: true },
  { key: "br_sub_service_type", name: i18n.t('brHubGrid:br_sub_service_type') },
  { key: "br_billing_status", name: i18n.t('brHubGrid:br_billing_status') },
  { key: "br_consign_note", name: i18n.t('brHubGrid:ctsd_serial_no') },
  { key: "tmfdh_br_id", name: i18n.t('brHubGrid:tmfdh_br_id'), editable: true },
  { key: "brdm_disbursement_mode", name: i18n.t('brHubGrid:brdm_disbursement_mode'), editable: true },
  { key: "brdm_bank_name", name: i18n.t('brHubGrid:brdm_bank_name'), editable: true },
  { key: "brdm_account_no", name: i18n.t('brHubGrid:brdm_account_no'), editable: true },
  { key: "brdm_bank_code", name: i18n.t('brHubGrid:brdm_bank_code'), editable: true },
  { key: "brdm_accountholder_name", name: i18n.t('brHubGrid:brdm_accountholder_name'), editable: true },
  { key: "brdm_kyc_id", name: i18n.t('brHubGrid:brdm_kyc_id'), editable: true },
  { key: "brdm_ewalletid", name: i18n.t('brHubGrid:brdm_ewalletid'), editable: true },
  { key: "cd_amount_collected", name: i18n.t('brHubGrid:cd_amount_collected'), editable: true },
  { key: "br_last_modified_by", name: i18n.t('brHubGrid:br_last_modified_by'), editable: true },
  { key: "ccd_created_by", name: i18n.t('brHubGrid:ccd_created_by'), editable: true },
  { key: "ccd_depositrefdocno", name: i18n.t('brHubGrid:ccd_depositrefdocno'), editable: true },
  { key: "brsd_to_contact_person", name: i18n.t('brHubGrid:brsd_to_contact_person') },
  { key: "brsd_to_address_line1", name: i18n.t('brHubGrid:brsd_to_address_line1') },
  { key: "from_suburb", name: i18n.t('brHubGrid:from_suburb') },
  { key: "from_city", name: i18n.t('brHubGrid:from_city') },
  { key: "from_state", name: i18n.t('brHubGrid:from_state') },
  { key: "from_country", name: i18n.t('brHubGrid:from_country') },
  { key: "brsd_from_contact_person", name: i18n.t('brHubGrid:brsd_from_contact_person') },
  { key: "brsd_from_address_line1", name: i18n.t('brHubGrid:brsd_from_address_line1') },
  { key: "to_suburb", name: i18n.t('brHubGrid:to_suburb') },
  { key: "to_city", name: i18n.t('brHubGrid:to_city') },
  { key: "to_state", name: i18n.t('brHubGrid:to_state') },
  { key: "to_country", name: i18n.t('brHubGrid:to_country') }
];

export const basicFields = [
  { label: i18n.t('searchField:ctsd_serial_no'), value: 'br_consign_note', type: 'inputBox' },
  { label: i18n.t('searchField:br_request_id'), value: 'br_request_id', type: 'inputBox' },
  { label: i18n.t('searchField:br_creation_date'), value: 'br_creation_date', type: 'dateTime' },
  {
    label: i18n.t('searchField:br_customer_id'), value: 'br_customer_id', type: 'inputSearch', id: 'shipper',
    methods: {
      findByCompanyAndFLMName: 'search',
      fillNameValues: 'fillData'
    },
    values: {
      props: {
        options: 'shipper'
      }
    }
  },
]

export const advancesFields = [
  {
    label: i18n.t('searchField:brsd_from_contact_person'), value: 'brsd_from_contact_person', type: 'inputSearch', id: 'shipper_first_name',
    methods: {
      findByCompanyAndFLMName: 'search',
      fillNameValues: 'fillData'
    },
    values: {
      props: {
        options: 'shipperFirstName'
      }
    }
  },
  {
    label: i18n.t('searchField:br_service_type'), value: 'br_service_type', type: 'dropDown',
    values: {
      props: {
        options: 'shipment_type',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('searchField:br_sub_service_type'), value: 'br_sub_service_type', type: 'dropDown',
    values: {
      props: {
        options: 'service_mode',
        clearable: true,
      }
    }
  },
  { label: i18n.t('searchField:br_customer_ref_no'), value: 'br_customer_ref_no', type: 'inputBox' },
  { label: i18n.t('searchField:br_sender_ref_no'), value: 'br_sender_ref_no', type: 'inputBox' },
  { label: i18n.t('searchField:br_receiver_ref_no'), value: 'br_receiver_ref_no', type: 'inputBox' },
  { label: i18n.t('searchField:brsd_to_deliverytime_slot_from_1'), value: 'brsd_to_deliverytime_slot_from_1', type: 'dateTime' },
  { label: i18n.t('searchField:brsd_to_deliverytime_slot_from_2'), value: 'brsd_to_deliverytime_slot_from_2', type: 'dateTime' },
  {
    label: i18n.t('searchField:tesed_event_id'), value: 'tesed_event_id', type: 'dropDown',
    values: {
      props: {
        options: 'last_event',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('searchField:plepd_leg_to'), value: 'plepd_leg_to', type: 'dropDown',
    values: {
      props: {
        options: 'event_location',
        clearable: true,
      }
    }
  },
  { label: i18n.t('searchField:brsd_from_picktime_slot_from_1'), value: 'brsd_from_picktime_slot_from_1', type: 'dateTime' },
  { label: i18n.t('searchField:brsd_from_picktime_slot_from_2'), value: 'brsd_from_picktime_slot_from_2', type: 'dateTime' },
  {
    label: i18n.t('searchField:br_type'), value: 'br_type', type: 'dropDown',
    values: {
      props: {
        options: 'request_type',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('searchField:failed_atte'), value: 'failed_atte', type: 'dropDown',
    values: {
      props: {
        options: 'failed_attempts',
        clearable: true,
      }
    }
  },
  { label: i18n.t('searchField:br_original_br_id'), value: 'br_original_br_id', type: 'inputBox' },
  { label: i18n.t('searchField:br_created_by'), value: 'br_created_by', type: 'inputBox' },
  {
    label: i18n.t('searchField:br_status'), value: 'br_status', type: 'dropDown',
    values: {
      props: {
        options: 'request_status',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('searchField:br_billing_status'), value: 'br_billing_status', type: 'dropDown',
    values: {
      props: {
        options: 'billing_status',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('searchField:customer_location'), value: 'customer_location', type: 'dropDown',
    values: {
      props: {
        options: 'current_location',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('searchField:br_creation_source'), value: 'br_creation_source', type: 'dropDown',
    values: {
      props: {
        options: 'creation_mode',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('searchField:br_reason_code'), value: 'br_reason_code', type: 'inputSearch', id: 'reason_code',
    methods: {
      findByCompanyAndFLMName: 'search',
      fillNameValues: 'fillData'
    },
    values: {
      props: {
        options: 'reason_code'
      }
    }
  },
  {
    label: i18n.t('searchField:br_hazardous'), value: 'br_hazardous', type: 'radioButton',
    options: [{ label: 'Yes', value: 'Y' }, { label: 'No', value: 'N' }],
  },
  // {
  //   label: i18n.t('searchField:br_cop'), value: 'br_cop', type: 'checkBox'
  // },
  {
    label: i18n.t('searchField:br_cod'), value: 'br_cod', type: 'checkBox'
  },
]