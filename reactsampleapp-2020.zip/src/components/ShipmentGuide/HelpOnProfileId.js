import React, { Component } from 'react'
import { reduxForm } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { gridHeaders, basicFields } from './ProfileIdHelper';
import { profileId, initializePRO } from "actions/shipmentGuideAction";
import DynamicFields from 'components/Common/DynamicFields';
import DataGrid from 'components/Common/DataGrid';
import { formatFormValues } from 'lib/CommonHelper';
import { getQuickCodeMaster } from "actions/masterAction";
import { withTranslation } from 'react-i18next';
import { getGeoType, getValidateDetatils } from 'actions/shipmentGuideAction'
import { compose } from 'redux';

class HelpOnProfileId extends Component {
  constructor(props) {
    super(props);
    this.state = {
      filterFields: basicFields,
      selectedRecord: null,
      defaultValues: null,
      error: '',
      page: 1
    };
    this.formSubmit = this.formSubmit.bind(this);
    this.paginationHandler = this.paginationHandler.bind(this);
    this.selectedRows = this.selectedRows.bind(this);
    this.changeLimit = this.changeLimit.bind(this);
    this.getProfileDetails = this.getProfileDetails.bind(this);
  }

  componentDidMount() {
    const { geoType, getGeoType, dgClass, getQuickCodeMaster, transportMode, restrictionCategory, product_items, validationDocument, validationStage, status, getValidateDetatils } = this.props;
    if (geoType.length === 0) {
      getGeoType()
    }
    if (dgClass.length === 0) {
      getQuickCodeMaster("dgClass");
    }
    if (transportMode.length === 0) {
      getQuickCodeMaster("transportMode");
    }
    if (restrictionCategory.length === 0) {
      getQuickCodeMaster("restrictionCategory");
    }
    if (product_items.length === 0) {
      getQuickCodeMaster("product_items");
    }
    if (validationDocument.length === 0) {
      getValidateDetatils("validationDocument");
    }
    if (validationStage.length === 0) {
      getValidateDetatils("validationStage");
    }
    if (status.length === 0) {
      getValidateDetatils("status");
    }
  }

  formSubmit(form) {
    this.props.profileId(formatFormValues(form.values), 1, 10, true);
  }

  selectedRows(values) {
    this.setState({ selectedRecord: values[0] })
  }

  changeLimit(pageNo, limit) {
    this.props.profileId(formatFormValues(this.props.formValues.values), 1, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.profileId(formatFormValues(this.props.formValues.values), pageNo, limit);
  }

  getProfileDetails() {
    const { selectedRecord } = this.state
    const { close } = this.props
    if (selectedRecord !== null) {
      this.props.getProfileDetails(selectedRecord)
      close('help', 'profileHelp')
    }
  }

  render() {
    const { error, filterFields, defaultValues, selectedRecord } = this.state
    const { isRequested, handleSubmit, result, totalPage, totalRecord, geoType, initializePRO, t, transportMode, dgClass, validationDocument, validationStage, status, restrictionCategory, product_items } = this.props
    const disabled = selectedRecord === null
    return (
      <div>
        <form>
          <Grid stackable>
            {error && <span className='error-msg'>{error}</span>}
            <Grid.Row>
              <DynamicFields
                filterFields={filterFields}
                geoType={geoType}
                transportMode={transportMode}
                dgClass={dgClass}
                validationStage={validationStage}
                validationDocument={validationDocument}
                status={status}
                restrictionCategory={restrictionCategory}
                product_items={product_items}
                cols={3}
              />
            </Grid.Row>
          </Grid>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button onClick={
                    handleSubmit(values =>
                      this.formSubmit({
                        values
                      }))
                  } className="primary" disabled={isRequested}>
                    {t('getBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={gridHeaders}
                rows={result}
                totalPages={totalPage}
                width={250}
                paginationHandler={this.paginationHandler}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                defaultValues={defaultValues}
                totalRecord={totalRecord}
                enableExport={true}
                singleSelect={true}
                initialize={initializePRO}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='details' onClick={this.getProfileDetails} type="button" className="primary" disabled={disabled}>
                  {t('okBtn')}
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

HelpOnProfileId = reduxForm({
  form: 'HelpOnProfileId'
})(HelpOnProfileId);

const mapStateToProps = state => ({
  formValues: state.form.HelpOnProfileId,
  isRequested: state.shipmentGuideReducer.isRequested,
  result: state.shipmentGuideReducer.profileResult,
  totalPage: state.shipmentGuideReducer.totalPage,
  totalRecord: state.shipmentGuideReducer.totalRecord,
  geoType: state.shipmentGuideReducer.geoType,
  validationStage: state.shipmentGuideReducer.options.validationStage,
  validationDocument: state.shipmentGuideReducer.options.validationDocument,
  dgClass: state.masterReducer.options.dgClass,
  transportMode: state.masterReducer.options.transportMode,
  restrictionCategory: state.masterReducer.options.restrictionCategory,
  product_items: state.masterReducer.options.product_items,
  status: state.shipmentGuideReducer.options.status,
})

const mapDispatchToProps = (dispatch) => ({
  profileId: (values, pageNo, pageLimit, isSearch) => dispatch(profileId(values, pageNo, pageLimit, isSearch)),
  initializePRO: () => dispatch(initializePRO()),
  getGeoType: () => dispatch(getGeoType('geoType')),
  getValidateDetatils: type => dispatch(getValidateDetatils(type)),
  getQuickCodeMaster: type => dispatch(getQuickCodeMaster(type)),
})

export default compose(withTranslation('shipmentGuide'), connect(mapStateToProps, mapDispatchToProps))(HelpOnProfileId)
