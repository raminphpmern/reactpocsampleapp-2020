import i18n from 'i18n';

export const gridHeaders = [
  { key: "dph_profile_id", name: i18n.t('shipmentGuide:dph_profile_id') },
  { key: "dph_description", name: i18n.t('shipmentGuide:dph_description') },
  { key: "dph_effective_from", name: i18n.t('shipmentGuide:dph_effective_from') },
  { key: "dph_effective_to", name: i18n.t('shipmentGuide:dph_effective_to') },
  { key: "dph_status", name: i18n.t('shipmentGuide:dph_status') }
];

export const basicFields = [
  {
    label: i18n.t('shipmentGuide:dph_profile_id'), value: 'dph_profile_id', type: 'inputBox'
  },
  { label: i18n.t('shipmentGuide:dph_description'), value: 'dph_description', type: 'inputBox' },
  {
    label: i18n.t('shipmentGuide:dph_status'), value: 'dph_status', type: 'dropDown',
    values: {
      props: {
        options: 'status',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:dph_validation_document'), value: 'dph_validation_document', type: 'dropDown',
    values: {
      props: {
        options: 'validationDocument',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:dph_validation_stage'), value: 'dph_validation_stage', type: 'dropDown',
    values: {
      props: {
        options: 'validationStage',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:drd_transport_mode'), value: 'drd_transport_mode', type: 'dropDown',
    values: {
      props: {
        options: 'transportMode',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:dph_dg_class'), value: 'dph_dg_class', type: 'dropDown',
    values: {
      props: {
        options: 'dgClass',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:drd_from_geo_type'), value: 'drd_from_geo_type', type: 'dropDown',
    values: {
      props: {
        options: 'geoType',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:drd_from_geo'), value: 'drd_from_geo', type: 'inputSearch', id: 'form_geo',
    methods: {
      findByCompanyAndFLMName: 'search',
      fillNameValues: 'fillData'
    },
    values: {
      props: {
        options: 'form_geo'
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:drd_to_geo_type'), value: 'drd_to_geo_type', type: 'dropDown',
    values: {
      props: {
        options: 'geoType',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:drd_to_geo'), value: 'drd_to_geo', type: 'inputSearch', id: 'to_geo',
    methods: {
      findByCompanyAndFLMName: 'search',
      fillNameValues: 'fillData'
    },
    values: {
      props: {
        options: 'to_geo'
      }
    }
  },
  { label: i18n.t('shipmentGuide:dph_effective_from'), value: 'dph_effective_from', type: 'dateTime' },
  { label: i18n.t('shipmentGuide:dph_effective_to'), value: 'dph_effective_to', type: 'dateTime' },
  {
    label: i18n.t('shipmentGuide:drd_sku'), value: 'drd_sku', type: 'dropDown',
    values: {
      props: {
        options: 'product_items',
        clearable: true,
      }
    }
  },
  {
    label: i18n.t('shipmentGuide:drd_res_category'), value: 'drd_res_category', type: 'dropDown',
    values: {
      props: {
        options: 'restrictionCategory',
        clearable: true,
      }
    }
  }
]