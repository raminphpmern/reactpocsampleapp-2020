import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import { compose } from 'redux';
import DataGrid from 'components/Common/DataGrid';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import i18n from 'i18n';
import { reduxForm, Field } from "redux-form";
import InputField from "components/Common/InputField";
import InputSearchField from "components/Common/InputSearchField";
import Popup from 'components/Common/Popup';
import HelpOnProfile from './HelpOnProfileId';
import { fetchShipmentDetails, initializeSH, getProfileIdSearch } from 'actions/shipmentGuideAction';
import { formatFormValues } from "lib/CommonHelper";
import { SEARCH_WORD_COUNT } from "config";
import _ from 'lodash';

const columns = [
  { key: "drd_document_type", name: i18n.t("shipmentGuide:drd_document_type"), editable: false },
  { key: "drd_document_name", name: i18n.t("shipmentGuide:drd_document_name"), editable: false },
  { key: "drd_cls_of_stores", name: i18n.t("shipmentGuide:drd_cls_of_stores"), editable: false },
  { key: "drd_sku", name: i18n.t("shipmentGuide:drd_sku"), editable: false },
  { key: "drd_transport_mode", name: i18n.t("shipmentGuide:drd_transport_mode"), editable: false },
  { key: "drd_from_geo_type", name: i18n.t("shipmentGuide:drd_from_geo_type"), editable: false },
  { key: "drd_from_geo", name: i18n.t("shipmentGuide:drd_from_geo"), editable: false },
  { key: "drd_to_geo_type", name: i18n.t("shipmentGuide:drd_to_geo_type"), editable: false },
  { key: "drd_to_geo", name: i18n.t("shipmentGuide:drd_to_geo"), editable: false },
  { key: "drd_res_category", name: i18n.t("shipmentGuide:drd_res_category"), editable: false },
  { key: "drd_regulation", name: i18n.t("shipmentGuide:drd_regulation"), editable: false },
  { key: "drd_quantity", name: i18n.t("shipmentGuide:drd_quantity"), editable: false },
  { key: "drd_uom", name: i18n.t("shipmentGuide:drd_uom"), editable: false }]

class ShipmentGuide extends Component {
  constructor(props) {
    super(props);
    this.state = {
      profileHelp: false,
      currentHelp: ''
    }
    this.toggle = this.toggle.bind(this);
    this.paginationHandler = this.paginationHandler.bind(this);
    this.changeLimit = this.changeLimit.bind(this);
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
  }

  componentDidMount() {
    const { currentBooking, fetchShipmentDetails, initialize } = this.props
    if (currentBooking) {
      const hash = { brId: currentBooking.tms_br_booking_request_hdr.br_request_id }
      initialize(hash)
      fetchShipmentDetails(hash, 1, 10, true);
    }
    let node = document.getElementById("profileIds")
    node && node.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        const hash = this.props.formValues.values
        fetchShipmentDetails(hash, 1, 10, true);
        event.preventDefault()
      }
    })
  }

  componentWillReceiveProps(nextProps) {
    const { formValues, initialize, dph_profile_id } = this.props
    let hash = _.cloneDeep(formValues ? formValues.values : {})
    if (nextProps.dph_profile_id !== dph_profile_id) {
      hash["dph_profile_id"] = nextProps.dph_profile_id
      hash["dph_description"] = nextProps.dph_description
      initialize(hash)
    }

    if (Object.keys(hash).length === 0 && nextProps.dph_profile_id) {
      hash["dph_profile_id"] = nextProps.dph_profile_id
      hash["dph_description"] = nextProps.dph_description
      initialize(hash)
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      this.props.getProfileIdSearch(queryString, fieldName);
    }
  }

  setValue(data) {
    if (data) {
      let hash = {}
      hash["dph_profile_id"] = data["dph_profile_id"]
      hash["dph_description"] = data["dph_description"]
      this.props.initialize(hash)
      this.props.fetchShipmentDetails(hash, 1, 10, true);
    }
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  changeLimit(pageNo, limit) {
    this.props.fetchShipmentDetails(formatFormValues(this.props.formValues.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.fetchShipmentDetails(formatFormValues(this.props.formValues.values), pageNo, limit);
  }

  render() {
    const { result, totalPage, totalRecord, profileIds, initializeSH, pageLimit, t, currentBooking } = this.props
    const { profileHelp, currentHelp, } = this.state
    return (
      <div>
        <Popup size="fullscreen" open={profileHelp} close={() => { this.toggle('help', 'profileHelp') }} header="Help On Document Profile" description={<HelpOnProfile getProfileDetails={this.setValue} onEnterKeyPress={() => { this.formSubmit(); }} close={this.toggle} name={currentHelp} />} />
        <form>
          <Grid stackable className="fixed-grid">
            {currentBooking && currentBooking.tms_br_booking_request_hdr.br_status === 'Incomplete' && <Grid.Row className="no-padding">
              <Grid.Column width={6}>
                <Field
                  name="dph_profile_id"
                  component={InputSearchField}
                  label={t('dph_profile_id')}
                  iconName="search"
                  findByCompanyAndFLMName={this.search}
                  id="profileIds"
                  options={profileIds}
                  fillNameValues={this.setValue}
                  childName="profileHelp"
                  handleClick={this.toggle}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={6}>
                <Field
                  name="dph_description"
                  component={InputField}
                  label="Description"
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>}
          </Grid>
          <Grid stackable>
            <Grid.Row className="document_wrapper">
              <Grid.Column width={16} >
                <DataGrid
                  columns={columns}
                  rows={result}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  rowEdit={this.rowEdit}
                  singleSelect={false}
                  width={250}
                  showSelectedCount={false}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  exportName='SH'
                  initialize={initializeSH}
                  pageLimit={pageLimit}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    )
  }
}

ShipmentGuide = reduxForm({
  form: "ShipmentGuide"
})(ShipmentGuide);

const mapStateToProps = state => ({
  profileIds: state.shipmentGuideReducer.options.profileIds,
  result: state.shipmentGuideReducer.shipmentResult,
  totalPage: state.shipmentGuideReducer.totalPageLink,
  totalRecord: state.shipmentGuideReducer.totalRecordLink,
  pageLimit: state.shipmentGuideReducer.limit,
  formValues: state.form.ShipmentGuide,
  currentBooking: state.bookingReducer.currentBooking,
  dph_profile_id: state.shipmentGuideReducer.dph_profile_id,
  dph_description: state.shipmentGuideReducer.dph_description,
})

const mapDispatchToProps = (dispatch) => ({
  fetchShipmentDetails: (values, pageNo, pageLimit, isSearch) => dispatch(fetchShipmentDetails(values, pageNo, pageLimit, isSearch)),
  initializeSH: () => dispatch(initializeSH()),
  getProfileIdSearch: (type, queryStr) => dispatch(getProfileIdSearch(type, queryStr)),
})

export default compose(withTranslation('shipmentGuide'), connect(mapStateToProps, mapDispatchToProps))(ShipmentGuide);