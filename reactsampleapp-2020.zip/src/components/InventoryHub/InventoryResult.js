import React, { Component } from 'react';
import DataGrid from 'components/Common/DataGrid';
import InputField from 'components/Common/InputField';
import InputSearchField from "components/Common/InputSearchField";
import Dropdown from 'components/Common/Dropdown';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import { getReasonCode } from "actions/masterAction";
import { reduxForm, Field } from 'redux-form';
import { Grid } from "semantic-ui-react";
import { gridHeaders, selectaction } from './Helper';
import { SEARCH_WORD_COUNT } from "config";
import { connect } from "react-redux";
import * as inventoryHubAction from "actions/inventoryHubAction";
import { formatFormValues } from 'lib/CommonHelper';
import _ from 'lodash';
import './inventoryhub.css';


function validate(values) {
  const errors = {};

  if (values.bay_type !== 'Virtual' && !values.select_action) {
    errors.select_action = "Select Action is required."
  }
  if (values.bay_type !== 'Virtual' && !values.ccd_reasoncode) {
    errors.ccd_reasoncode = "Reason code is required."
  }

  return errors
}

class InventoryResult extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selectedIds: [],
      value: props.value,
      isOpen: false
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.compute = this.compute.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
    this.setBayType = this.setBayType.bind(this);
    this.onRowEdit = this.onRowEdit.bind(this)
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  changeLimit(pageNo, limit) {
    this.props.search(formatFormValues(this.props.inventorySearch.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.search(formatFormValues(this.props.inventorySearch.values), pageNo, limit);
  }

  search(value) {
    if (value.length >= SEARCH_WORD_COUNT) {
      this.props.getReasonCode(
        'reason_code',
        `keyword=${value}`,
      );
    }
  }

  setValue(option) {
    let hash = _.cloneDeep(this.props.formValues.values);
    hash["ccd_reasoncode"] = option.value;
    hash["wms_code_desc"] = option.wms_code_desc;
    this.props.initialize(hash);
  }

  formSubmit(values) {
    const { selectedIds } = this.state
    if (selectedIds.length > 0) {
      values = formatFormValues(values)
      values['selectedRows'] = selectedIds
      this.props.save(values)
    }
  }

  compute() {
    if (this.state.selectedIds && this.state.selectedIds.length > 0) {
      let obj = _.cloneDeep(this.props.formValues.values)
      let data = _.reduce(this.state.selectedIds, (hash, pv) => {
        hash['hmhid_quantity'] += parseInt(pv.hmhid_quantity) || 0
        hash['hmred_exec_wt'] += parseInt(pv.hmred_exec_wt) || 0
        hash['hmred_volume'] += parseInt(pv.hmred_volume) || 0
        return hash
      }, { hmhid_quantity: 0, hmred_exec_wt: 0, hmred_volume: 0 })
      this.props.initialize(_.merge(obj, data))
    }
  }

  onUpdateRow(row, updateValue) {
    this.props.updateRow(row, updateValue)
    const response = _.reduce(this.state.selectedIds, (arr, item) => {
      if (item.ccd_br_no === row.ccd_br_no) {
        _.merge(item, updateValue)
      }
      arr.push(item)
      return arr
    }, [])
    this.setState({ selectedIds: response })
  }

  setBayType() {
    const { inventorySearch, formValues } = this.props
    let hash = formValues ? _.cloneDeep(formValues.values) : {}
    const searchFormValues = inventorySearch ? inventorySearch.values : {}
    const bay_type = searchFormValues.bay_type ? searchFormValues.bay_type.value : ''
    if (bay_type !== hash['bay_type']) {
      hash['bay_type'] = bay_type
      this.props.initialize(hash)
    }
  }

  onRowEdit(row) {
    let { selectedIds } = this.state
    if (selectedIds.length > 0) {
      const index = _.findIndex(selectedIds, (selectedRow) => {
        return (selectedRow.hmhid_bay_id === row.hmhid_bay_id
          && selectedRow.hmhid_thu_id === row.hmhid_thu_id
          && selectedRow.ddh_reference_doc_no === row.ddh_reference_doc_no
          && selectedRow.ddh_dispatch_doc_no === row.ddh_dispatch_doc_no)
      })
      selectedIds[index] = row
      this.setState({ selectedIds })
    }
  }


  render() {
    const { handleSubmit, result, totalPage, totalRecord, reason_code, initializeIH, t, formValues } = this.props
    const { selectedIds } = this.state
    const disabled = selectedIds.length === 0
    this.setBayType()
    const disabledDropDown = formValues ? (formValues.values.bay_type === 'Virtual') : false

    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  rows={result}
                  totalPages={totalPage}
                  width={150}
                  columns={gridHeaders}
                  paginationHandler={this.paginationHandler}
                  selectedRows={this.selectedRows}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  singleSelect={false}
                  exportName='IH'
                  initialize={initializeIH}
                  rowEdit={this.onRowEdit}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row>
              <Grid.Column width={4} className="small-width">
                <Field name="hmhid_quantity" component={InputField} label="Total Available Quantity " readOnly={true} />
                <Field name="hmred_exec_wt" component={InputField} label="Total Weight " readOnly={true} />
                <Field name="hmred_volume" component={InputField} label="Total Volume " readOnly={true} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="select_action" component={Dropdown} label="Select Action" options={selectaction} clearable={true} required={true} readOnly={disabledDropDown} />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="ccd_reasoncode" component={InputSearchField} label="Reason Code" findByCompanyAndFLMName={this.search} options={reason_code} fillNameValues={this.setValue} required={true} readOnly={disabledDropDown} id='ivHub_reason_code' />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field name="wms_code_desc" component={InputField} label="Reason Description" readOnly={true} id='ivHub_reason_desc' />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={5}>
                <div className="text-center">
                  <button disabled={disabled} type="button" onClick={() => this.compute()} className="primary btn-small">{t('computeBtn')}</button>
                </div>
              </Grid.Column>
              <Grid.Column width={6}>
                <div className="text-center">
                  <button id='save' type="submit" disabled={disabled} className="primary btn-small">{t('saveBtn')}</button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    )
  }
}

InventoryResult = reduxForm({
  form: 'InventoryResult',
  validate,
})(InventoryResult);

const mapDispatchToProps = (dispatch) => ({
  search: (values, pageNo, limit) => dispatch(inventoryHubAction.search(values, pageNo, limit)),
  getReasonCode: (action, queryStr) =>
    dispatch(getReasonCode(action, queryStr)),
  save: (values) => dispatch(inventoryHubAction.buttonAction(values, 'save')),
  updateRow: (row, updateValue) => dispatch(inventoryHubAction.updateRow(row, updateValue)),
  initializeIH: () => dispatch(inventoryHubAction.initializeIH())
})

const mapStateToProps = state => ({
  result: state.inventoryHubReducer.result,
  totalPage: state.inventoryHubReducer.totalPage,
  totalRecord: state.inventoryHubReducer.totalRecord,
  inventorySearch: state.form.InventorySearch,
  formValues: state.form.InventoryResult,
  reason_code: state.masterReducer.options.reason_code,
})

export default compose(withTranslation('inventoryHubGrid'), connect(mapStateToProps, mapDispatchToProps))(InventoryResult);