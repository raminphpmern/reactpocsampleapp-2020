import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import DataGrid from 'components/Common/DataGrid';
import { reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import { getSerialNumbers, initializeSN } from "actions/inventoryHubAction";

export const columns = [
  { key: "ddh_dispatch_doc_no", name: "Dispatch Doc No" },
  { key: "hmhid_serialno", name: "Serial No" }
]

class SerialDetails extends Component {
  constructor(props) {
    super(props);
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.buildQueryString = this.buildQueryString.bind(this)
  }

  buildQueryString() {
    let queryString = ''
    const { rowInfo } = this.props
    queryString = `bay_type=${rowInfo.bay_type}`

    if (rowInfo.bay_type === 'Virtual') {
      queryString = queryString + `&hmhivbd_bay_id=${rowInfo.hmhid_bay_id}&hmhivbd_despatch_doc_no=${rowInfo.ddh_dispatch_doc_no}&hmhivbd_thu_id=${rowInfo.hmhid_thu_id}`
    } else {
      queryString = queryString + `&hmhid_bay_id=${rowInfo.hmhid_bay_id}&hmhid_despatch_doc_no=${rowInfo.ddh_dispatch_doc_no}&hmhid_thu_id=${rowInfo.hmhid_thu_id}`
    }
    return queryString
  }

  componentDidMount() {
    const { getSerialNumbers } = this.props
    let queryString = this.buildQueryString()
    getSerialNumbers(queryString, 1, 10)
  }

  changeLimit(pageNo, limit) {
    const queryString = this.buildQueryString()
    this.props.getSerialNumbers(queryString, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    const queryString = this.buildQueryString()
    this.props.getSerialNumbers(queryString, pageNo, limit);
  }

  render() {
    const { result, totalPage, totalRecord, initializeSN, pageLimit } = this.props
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  rows={result}
                  totalPages={totalPage}
                  columns={columns}
                  showCheckbox={false}
                  width={300}
                  paginationHandler={this.paginationHandler}
                  changeLimit={this.changeLimit}
                  totalRecord={totalRecord}
                  exportName='SN'
                  initialize={initializeSN}
                  pageLimit={pageLimit}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

SerialDetails = reduxForm({
  form: 'SerialDetailsForm'
})(SerialDetails);

const mapStateToProps = state => ({
  SerialDetails: state.form.SerialDetailsForm,
  result: state.inventoryHubReducer.serialnoresult,
  totalPage: state.inventoryHubReducer.totalPageLink,
  totalRecord: state.inventoryHubReducer.totalRecordLink,
  pageLimit: state.inventoryHubReducer.linkLimit,
})

const mapDispatchToProps = (dispatch) => ({

  getSerialNumbers: (queryString, pageNo, limit) => dispatch(getSerialNumbers(queryString, pageNo, limit)),
  initializeSN: () => dispatch(initializeSN())
})

export default connect(mapStateToProps, mapDispatchToProps)(SerialDetails)
