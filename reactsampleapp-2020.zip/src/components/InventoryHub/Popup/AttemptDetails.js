import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import { reduxForm } from 'redux-form';
import DataGrid from 'components/Common/DataGrid';
import { connect } from 'react-redux';
import { getLastAttempts, initializeLA } from "actions/inventoryHubAction";

export const columns = [
  { key: "tled_trip_plan_id", name: "Trip Id" },
  { key: "plpth_driver_id", name: "Driver Id" },
  { key: "plpth_vehicle_id", name: "Vehicle Id" },
  { key: "tled_actual_date_time", name: "Date Time" },
  { key: "tled_reason_code", name: "Reason Code" },
  { key: "tled_reason_description", name: "Reason Code Description" },
  { key: "tled_remarks1", name: "Remarks" }
]

class AttemptDetails extends Component {
  constructor(props) {
    super(props);
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
  }

  componentDidMount() {
    const { rowInfo } = this.props
    const queryString = `tled_bkr_id=${rowInfo.ddh_reference_doc_no}`
    this.props.getLastAttempts(queryString, 1, 10);
  }

  changeLimit(pageNo, limit) {
    const { rowInfo } = this.props
    const queryString = `tled_bkr_id=${rowInfo.ddh_reference_doc_no}`
    this.props.getLastAttempts(queryString, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    const { rowInfo } = this.props
    const queryString = `tled_bkr_id=${rowInfo.ddh_reference_doc_no}`
    this.props.getLastAttempts(queryString, pageNo, limit);
  }

  render() {
    const { result, totalPage, totalRecord, initializeLA, pageLimit } = this.props
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  rows={result}
                  columns={columns}
                  totalPages={totalPage}
                  width={200}
                  showCheckbox={false}
                  totalRecord={totalRecord}
                  paginationHandler={this.paginationHandler}
                  changeLimit={this.changeLimit}
                  exportName='LA'
                  initialize={initializeLA}
                  pageLimit={pageLimit}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

AttemptDetails = reduxForm({
  form: 'AttemptDetailsForm'
})(AttemptDetails);

const mapStateToProps = state => ({
  AttemptDetailsForm: state.form.AttemptDetailsForm,
  result: state.inventoryHubReducer.lastattemptresult,
  totalPage: state.inventoryHubReducer.totalPageLink,
  totalRecord: state.inventoryHubReducer.totalRecordLink,
  pageLimit: state.inventoryHubReducer.linkLimit,
})

const mapDispatchToProps = (dispatch) => ({
  getLastAttempts: (values, pageNo, limit) => dispatch(getLastAttempts(values, pageNo, limit)),
  initializeLA: () => dispatch(initializeLA())
})

export default connect(mapStateToProps, mapDispatchToProps)(AttemptDetails)
