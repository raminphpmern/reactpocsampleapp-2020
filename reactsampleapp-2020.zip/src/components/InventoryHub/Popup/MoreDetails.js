import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import { reduxForm } from "redux-form";
import { compose } from 'redux';
import DatePickerEditor from 'components/Common/DataGrid/DatePickerEditor';
import DataGrid from 'components/Common/DataGrid';
import GridDropDownEditor from 'components/Common/DataGrid/DropDownEditor';
import FileUploadEditor from 'components/Common/DataGrid/FileUploadEditor';
import { connect } from 'react-redux';
import { fetchDiscrepancyDetails, initializeMD, saveDiscrepancyRecords, deleteDiscrepancy } from 'actions/inventoryHubAction';
import { getDiscrepancy } from 'actions/masterAction';
import { withTranslation } from 'react-i18next';
import ImageFormatter from 'components/Common/DataGrid/ImageFormatter';
import ObjectFormatter from 'components/Common/DataGrid/ObjectFormatter';
import { AlertError } from 'lib/Alert';
import _ from 'lodash';


class MoreDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      updatedRows: [],
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.getGridNewData = this.getGridNewData.bind(this)
    this.save = this.save.bind(this)
    this.rowEdit = this.rowEdit.bind(this)
    this.getHeaders = this.getHeaders.bind(this)
    this.buildQueryString = this.buildQueryString.bind(this)
    this.formatExtraParams = this.formatExtraParams.bind(this)
    this.dropSelectedRows = this.dropSelectedRows.bind(this)
  }

  serialNoQueryString(rowInfo) {
    let queryString = `bay_type=${rowInfo.bay_type}&options=true`

    if (rowInfo.bay_type === 'Virtual') {
      queryString = queryString + `&hmhivbd_bay_id=${rowInfo.hmhid_bay_id}&hmhivbd_despatch_doc_no=${rowInfo.ddh_dispatch_doc_no}&hmhivbd_thu_id=${encodeURIComponent(rowInfo.hmhid_thu_id)}`
    } else {
      queryString = queryString + `&hmhid_bay_id=${rowInfo.hmhid_bay_id}&hmhid_despatch_doc_no=${rowInfo.ddh_dispatch_doc_no}&hmhid_thu_id=${encodeURIComponent(rowInfo.hmhid_thu_id)}`
    }
    return queryString
  }

  buildQueryString() {
    const { hub_dis_ref_doc_no } = this.formatExtraParams()
    let queryString = ''
    const { rowInfo, transactionType, hubLoadingFormValues } = this.props

    if (transactionType === 'HUB INVENTORY') {
      queryString = this.serialNoQueryString(rowInfo)
    } else if (transactionType === 'HUB RECEIPT') {
      queryString = `ddh_dispatch_doc_no=${rowInfo.ddh_dispatch_doc_no}`
    } else if (transactionType === 'HUB LOADING') {
      queryString = `ddh_dispatch_doc_no=${rowInfo.ddh_dispatch_doc_no}&exec_no=${hubLoadingFormValues.values.hmleh_load_exec_no}`
    } else if (transactionType === 'TRIP LOG') {
      queryString = `br_request_id=${rowInfo.br_request_id}&ddh_dispatch_doc_no=${rowInfo.ddh_dispatch_doc_no}&options=true`
    } else if (transactionType === 'CONSOLIDATION') {
      queryString = `dispatch_doc_no=${rowInfo.hmitd_despat_doc_no}&ddh_dispatch_doc_type=${rowInfo.ddh_dispatch_doc_type}&serial_no=${encodeURIComponent(rowInfo.hmitd_thu_serial_no)}`
    } else if (transactionType === 'DECONSOLIDATION') {
      queryString = `dispatch_doc_no=${rowInfo.hmotd_despat_doc_no}&ddh_dispatch_doc_type=${rowInfo.ddh_dispatch_doc_type}&serial_no=${encodeURIComponent(rowInfo.hmotd_thu_serial_no)}`
    }
    queryString = `${queryString}&transactionType=${transactionType.toUpperCase()}&hub_dis_ref_doc_no=${hub_dis_ref_doc_no}`
    return queryString
  }

  componentDidMount() {
    const { fetchDiscrepancyDetails, getDiscrepancyType, discrepancy } = this.props
    let queryString = this.buildQueryString()
    fetchDiscrepancyDetails(queryString, 1, 10)

    if (discrepancy.length === 0) {
      getDiscrepancyType()
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.isSaveRequested !== this.props.isSaveRequested) {
      if (nextProps.isSaveRequested) {
        this.setState({ updatedRows: [] })
      }
    }
  }

  getHeaders() {
    const statusCond = (row) => (row.hub_dis_transaction === this.props.transactionType || row.new === true)
    return [
      { key: "hub_dis_transaction", name: "Transaction Type", editable: false },
      { key: "hub_dis_thu_serial", name: "SerialNo", editor: <GridDropDownEditor propName="serialNos" />, editable: statusCond },
      { key: "hub_dis_discrepancy_type", name: "Discrepancy", editor: <GridDropDownEditor propName="discrepancy" resultType='object' />, editable: statusCond, formatter: <ObjectFormatter fieldName='hub_dis_discrepancy_type' /> },
      { key: "hub_dis_document_name", name: "Document Id", editable: statusCond },
      { key: "hub_dis_document_date", name: "Doc Date", editable: statusCond, editor: DatePickerEditor },
      { key: "hub_dis_remarks", name: "Remarks", editable: statusCond },
      { key: "attachment", name: "Attachment", editable: statusCond, editor: FileUploadEditor, formatter: ImageFormatter }
    ]
  }

  getGridNewData(data) {
    let { newData } = this.state
    if (data) {
      if (newData.length > 0) {
        const recordIndex = _.findIndex(newData, (row) => row.id === data.id)
        if (recordIndex >= 0) {
          newData[recordIndex] = data
        } else {
          newData.push(data)
        }
      } else {
        newData.push(data)
      }
      this.setState({ newData })
    }
  }

  save() {
    let { updatedRows } = this.state
    const { transactionType } = this.props
    if (updatedRows.length > 0) {
      let isValid = true
      let serialno = 'Please Enter SerialNo'
      let documentdate = 'Please Enter DocumentDate'
      _.each(updatedRows, (row) => {
        if (!row.hub_dis_document_date || !row.hub_dis_thu_serial) {
          isValid = false
          if (!isValid) {
            if (!row.hub_dis_document_date) {
              AlertError(documentdate)
            } else if (!row.hub_dis_thu_serial) {
              AlertError(serialno)
            }
            return false
          }
        }
      })
      if (isValid) {
        let hash = { data: updatedRows, transaction_type: transactionType }
        hash = _.merge(hash, this.formatExtraParams())
        this.props.saveDiscrepancyRecords(hash)
      }
    }
  }

  // Dispatch / Trip plan no
  formatExtraParams() {
    const { rowInfo, transactionType } = this.props
    switch (transactionType) {
      case ('HUB RECEIPT'): {
        return { hub_dis_ref_doc_no: rowInfo.ddh_dispatch_doc_no, hub_dis_ref_doc_type: 'TP', thu_id: rowInfo.hmhid_thu_id }
      }
      case ('HUB LOADING'): {
        return { hub_dis_ref_doc_no: rowInfo.ddh_dispatch_doc_no, hub_dis_ref_doc_type: 'TP', thu_id: rowInfo.hmhid_thu_id }
      }
      case ('HUB INVENTORY'): {
        return { hub_dis_ref_doc_no: rowInfo.ddh_dispatch_doc_no, hub_dis_ref_doc_type: rowInfo.ddh_dispatch_doc_type, thu_id: rowInfo.hmhid_thu_id }
      }
      case ('TRIP LOG'): {
        return { hub_dis_ref_doc_no: rowInfo.ddh_dispatch_doc_no, thu_id: rowInfo.cd_thu_id, hub_dis_ref_doc_type: 'TP' }
      }
      case ('CONSOLIDATION'): {
        return { hub_dis_ref_doc_no: rowInfo.hmitd_despat_doc_no, thu_id: rowInfo.hmitd_thu_id, hub_dis_ref_doc_type: 'FC' }
      }
      case ('DECONSOLIDATION'): {
        return { hub_dis_ref_doc_no: rowInfo.hmotd_despat_doc_no, thu_id: rowInfo.hmotd_thu_id, hub_dis_ref_doc_type: 'FC' }
      }
      default: {
        return { hub_dis_ref_doc_no: '', thu_id: '', hub_dis_ref_doc_type: '' }
      }
    }
  }

  dropSelectedRows(rows) {
    const { transactionType, deleteDiscrepancyRecord } = this.props
    if (rows.length > 0) {
      let isValid = true
      let message = 'You are not allowed to delete other transaction document(s).'
      _.each(rows, (row) => {
        if (row.hub_dis_transaction !== transactionType) {
          isValid = false
          return false
        }
      })
      if (!isValid) {
        AlertError(message)
        return false
      }
      deleteDiscrepancyRecord({ hub_dis_linenos: _.map(rows, 'hub_dis_lineno'), transactionType: transactionType })
    }
  }

  rowEdit(row, updateValue) {
    _.merge(row, updateValue)
    if (row && row.new === true) {
      let { updatedRows } = this.state
      if (updatedRows.length > 0) {
        const recordIndex = _.findIndex(updatedRows, (item) => item.id === row.id)
        if (recordIndex >= 0) {
          updatedRows[recordIndex] = row
        } else {
          updatedRows.push(row)
        }
      } else {
        updatedRows.push(row)
      }
      this.setState({ updatedRows })
    } else {
      const response = _.reduce(this.props.result, (arr, item) => {
        if (item.hub_dis_lineno === row.hub_dis_lineno) {
          _.merge(item, updateValue)
          arr.push(item)
        }
        return arr
      }, [])
      this.setState({ updatedRows: response })
    }
  }

  changeLimit(pageNo, limit) {
    const queryString = this.buildQueryString()
    this.props.fetchDiscrepancyDetails(queryString, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    const queryString = this.buildQueryString()
    this.props.fetchDiscrepancyDetails(queryString, pageNo, limit);
  }

  render() {
    const { result, totalPage, totalRecord, initializeMD, t, transactionType, pageLimit } = this.props
    const { updatedRows } = this.state
    const disabled = updatedRows.length > 0
    const { thu_id, hub_dis_ref_doc_no } = this.formatExtraParams()
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row className="no-padding">
            <Grid.Column width={8}>
              <label>Dispatch No/Trip No: {hub_dis_ref_doc_no}</label>
            </Grid.Column>
            <Grid.Column width={8}>
              <label>THU ID: {thu_id}</label>
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row className="document_wrapper">
            <Grid.Column width={16} >
              <DataGrid
                columns={this.getHeaders()}
                rows={result}
                totalPages={totalPage}
                totalRecord={totalRecord}
                rowEdit={this.rowEdit}
                singleSelect={false}
                width={250}
                showSelectedCount={false}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                addRow={true}
                deleteRow={true}
                exportName='MD'
                initialize={initializeMD}
                defaultNewRowHash={{ hub_dis_transaction: transactionType }}
                dropSelectedRows={this.dropSelectedRows}
                pageLimit={pageLimit}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='save' type="button" className="primary btn-small btn-long" disabled={!disabled} onClick={this.save}> {t('saveBtn')}</button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}
MoreDetails = reduxForm({
  form: 'MoreDetailsForm'
})(MoreDetails);

const mapStateToProps = state => ({
  formValues: state.form.MoreDetailsForm,
  result: state.inventoryHubReducer.moredetailsresult,
  totalPage: state.inventoryHubReducer.totalPageLink,
  totalRecord: state.inventoryHubReducer.totalRecordLink,
  serialNos: state.inventoryHubReducer.serialNumberOptions,
  isSaveRequested: state.inventoryHubReducer.isSaveRequested,
  hubLoadingFormValues: state.form.HubLoadingForm,
  discrepancy: state.masterReducer.options.discrepancy,
  pageLimit: state.inventoryHubReducer.linkLimit,
})

const mapDispatchToProps = (dispatch) => ({
  fetchDiscrepancyDetails: (queryString, pageNo, limit) => dispatch(fetchDiscrepancyDetails(queryString, pageNo, limit)),
  initializeMD: () => dispatch(initializeMD()),
  saveDiscrepancyRecords: (params) => dispatch(saveDiscrepancyRecords(params)),
  deleteDiscrepancyRecord: (params) => dispatch(deleteDiscrepancy(params)),
  getDiscrepancyType: () => dispatch(getDiscrepancy('discrepancy')),
})

export default compose(withTranslation('inventoryHubGrid'), connect(mapStateToProps, mapDispatchToProps))(MoreDetails);