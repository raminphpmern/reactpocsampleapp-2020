import React, { Component } from "react";
import InputField from "components/Common/InputField";
import InputSearchField from "components/Common/InputSearchField"
import { compose } from 'redux';
import Dropdown from "components/Common/Dropdown";
import { reduxForm, Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import * as masterActions from "actions/masterAction";
import { SEARCH_WORD_COUNT } from "config";
import { search } from "actions/inventoryHubAction";
import { connect } from "react-redux";
import { formatFormValues } from 'lib/CommonHelper';
import { withTranslation } from 'react-i18next';
import _ from "lodash";
import { getValue } from "lib/LocalStorage";
import "./inventoryhub.css";

const agingOptions = [
  { value: '=', label: '=' },
  { value: '<>', label: '<>' },
  { value: '>', label: '>' },
  { value: '<', label: '<' },
  { value: 'between', label: 'Between' }
];

const dispatchDocTypeOptions = [
  { value: 'CN', label: 'Consignment Note' }
];

class InventorySearch extends Component {
  constructor(props) {
    super(props);
    this.formSubmit = this.formSubmit.bind(this);
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
  }

  componentDidMount() {
    const {
      bayType,
      getBayType,
      discrepancy,
      getDiscrepancy
    } = this.props;

    if (bayType.length === 0) {
      getBayType("bayType");
    }
    if (discrepancy.length === 0) {
      getDiscrepancy("discrepancy");
    }
    if (getValue('currentBranch')) {
      let currentBranch = JSON.parse(getValue('currentBranch') ? getValue('currentBranch') : {})
      if (currentBranch.value) {
        this.props.initialize({ wms_div_code: currentBranch.wms_div_desc, hmhid_location: currentBranch.value });
      }
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === 'shipper') {
        queryString += "&searchField=wms_customer_id";
        this.props.getShipper("shipper", queryString, fieldName);
      }
      if (fieldName === 'bay_id') {
        this.props.getBayId("bay_id", queryString, fieldName);
      }
      if (fieldName === 'dispatchDocNos') {
        this.props.getDispatchDocNo("dispatchDocNos", queryString, fieldName);
      }
      if (fieldName === 'reason_code') {
        this.props.getReasonCode("reason_code", queryString, fieldName);
      }
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "bay_id") {
      hash["hmhid_bay_id"] = option.hmhid_bay_id;
    }
    if (fieldName === "shipper") {
      hash["br_customer_id"] = option.wms_customer_id;
    }
    if (fieldName === "dispatchDocNos") {
      hash["hmhid_despatch_doc_no"] = option.hmhid_despatch_doc_no;
    }
    if (fieldName === "reason_code") {
      hash["wms_code"] = option.value;
      hash["wms_code_desc"] = option.wms_code_desc;
    }
    this.props.initialize(hash);
  }

  isDisabled() {
    let values = this.props.formValues ? this.props.formValues.values : {}
    if (values && values.bay_type && values.bay_type.value === 'Virtual') {
      return false;
    }
    return true;
  }

  formSubmit(values) {
    this.props.ihSearch(formatFormValues(values), 1, 10, true);
  }

  render() {
    const { handleSubmit, dispatchDocNos, reason_code, bayType, discrepancy, bay_id, shipper, t } = this.props;

    return (
      <div>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="wms_div_code"
                  component={InputField}
                  label={t('wms_div_code')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmhid_location"
                  component={InputField}
                  label={t('wms_div_desc')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="bay_type"
                  component={Dropdown}
                  label={t('bay_type')}
                  options={bayType}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmhid_bay_id"
                  component={InputSearchField}
                  label={t('hmhid_bay_id')}
                  findByCompanyAndFLMName={this.search}
                  options={bay_id}
                  id="bay_id"
                  fillNameValues={this.setValue}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="aging">
                  <Field
                    name="aging"
                    component={Dropdown}
                    label={t('aging')}
                    options={agingOptions}
                    clearable={true}
                  />
                  <Field
                    name="aging_from"
                    component={InputField}
                    type="number"
                  />
                  <Field
                    name="aging_to"
                    component={InputField}
                    type="number"
                  />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="br_customer_id"
                  component={InputSearchField}
                  label={t('br_customer_id')}
                  findByCompanyAndFLMName={this.search}
                  options={shipper}
                  id="shipper"
                  fillNameValues={this.setValue}
                  clearable={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_type"
                  component={Dropdown}
                  label={t('ddh_dispatch_doc_type')}
                  options={dispatchDocTypeOptions}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmhid_despatch_doc_no"
                  component={InputSearchField}
                  label={t('hmhid_despatch_doc_no')}
                  findByCompanyAndFLMName={this.search}
                  options={dispatchDocNos}
                  id="dispatchDocNos"
                  fillNameValues={this.setValue}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hub_dis_discrepancy_type"
                  component={Dropdown}
                  label={t('hub_dis_discrepancy_type')}
                  options={discrepancy}
                  clearable={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="wms_code"
                  component={InputSearchField}
                  label={t('wms_code')}
                  findByCompanyAndFLMName={this.search}
                  id="reason_code"
                  options={reason_code}
                  fillNameValues={this.setValue}
                  disabled={this.isDisabled()}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="wms_code_desc"
                  component={InputField}
                  label={t('wms_code_desc')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='search' type="submit" className="primary btn-small btn-long"> {t('searchBtn')}</button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    );
  }
}

InventorySearch = reduxForm({
  form: "InventorySearch"
})(InventorySearch);

const mapDispatchToProps = dispatch => ({
  getReasonCode: (action, queryStr) =>
    dispatch(masterActions.getReasonCode(action, queryStr)),
  getShipper: (action, queryStr) =>
    dispatch(masterActions.getShipper(action, queryStr)),
  getBayId: (type, queryStr) =>
    dispatch(masterActions.getBayId(type, queryStr)),
  getDispatchDocNo: (type, queryStr) =>
    dispatch(masterActions.getDispatchDocNo(type, queryStr)),
  getBayType: (type, queryStr) =>
    dispatch(masterActions.getBayType(type, queryStr)),
  getDiscrepancy: (type, queryStr) =>
    dispatch(masterActions.getDiscrepancy(type, queryStr)),
  ihSearch: (values, pageNo, pageLimit, isSearch) => dispatch(search(values, pageNo, pageLimit, isSearch))
});

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
  formValues: state.form.InventorySearch,
  bayType: state.masterReducer.options.bayType,
  bay_id: state.masterReducer.options.bay_id,
  shipper: state.masterReducer.options.shipper,
  dispatchDocNos: state.masterReducer.options.dispatchDocNos,
  discrepancy: state.masterReducer.options.discrepancy,
  reason_code: state.masterReducer.options.reason_code,
  current_location: state.masterReducer.options.current_location,
});

export default compose(withTranslation('inventoryHubSearch'), connect(mapStateToProps, mapDispatchToProps))(InventorySearch);
