import React, { Component } from 'react';
import Wrapper from "components/LandingPage/Wrapper";
import InventorySearch from './InventorySearch';
import InventoryResult from './InventoryResult';
import { Icon } from 'semantic-ui-react'
import { withTranslation } from 'react-i18next';
import './inventoryhub.css';

class InventoryHub extends Component {

  render() {
    const { t } = this.props
    return (
      <Wrapper DisableBranch={true}>
        <div className="inventory-head">
          <h3>{t('title')}</h3>
          <div className="back-link">
            <a onClick={this.props.history.goBack}>
              <Icon disabled name='arrow left' />
              {t('translation:back')}</a>
          </div>
        </div>
        <div className="inventory-wrapper">
          <InventorySearch />
          <InventoryResult />
        </div>
      </Wrapper>
    )
  }
}

export default withTranslation('inventoryHub')(InventoryHub)