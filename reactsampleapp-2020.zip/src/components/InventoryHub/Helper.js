import React from 'react';
import LinkPopUp from '../Common/DataGrid/LinkPopUp';
import SerialDetails from './Popup/SerialDetails';
import AttemptDetails from './Popup/AttemptDetails';
import MoreDetails from './Popup/MoreDetails';
import { Editors } from "react-data-grid-addons";
import { Link } from 'react-router-dom';
import i18n from 'i18n';

export const selectaction = [
  { value: 'DF', label: 'Return to Division Address' },
  { value: 'DP', label: 'Ship Back to Shipper ' },
  { value: 'HLD', label: 'Ask ' },
  { value: 'RL', label: 'Redeliver to Consignee' }
];

const serialFormatter = <LinkPopUp name="Serial No" defaultValue="Serial No"> <SerialDetails /> </LinkPopUp>
const attemptsFormatter = <LinkPopUp name='Last Attempt Details' defaultValue="Attempt"> <AttemptDetails /> </LinkPopUp>
const moreDetailsFormatter = <LinkPopUp name='More Details' defaultValue='More Details'> <MoreDetails transactionType='HUB INVENTORY' /> </LinkPopUp>

const LinkFormatter = ({ value }) => {
  return (<Link to={`/acceptance/${value}`}>{value}</Link>)
};

const { DropDownEditor } = Editors;

const issueTypes = [
  { id: "claim", value: "Claim" }
];

const IssueTypeEditor = <DropDownEditor options={issueTypes} />;
const statusCond = (row) => row.bay_type === 'Virtual'

export const gridHeaders = [
  { key: "hmhid_bay_id", name: i18n.t('inventoryHubGrid:hmhid_bay_id') },
  { key: "wms_bay_description", name: i18n.t('inventoryHubGrid:wms_bay_description') },
  { key: "hmhid_thu_id", name: i18n.t('inventoryHubGrid:hmhid_thu_id') },
  { key: "wms_thu_description", name: i18n.t('inventoryHubGrid:wms_thu_description') },
  { key: "ddh_reference_doc_no", name: i18n.t('inventoryHubGrid:ddh_reference_doc_no') },
  { key: "hmhid_quantity", name: i18n.t('inventoryHubGrid:hmhid_quantity') },
  { key: "hmhid_uom", name: i18n.t('inventoryHubGrid:hmhid_uom') },
  { key: "SerialNos", name: i18n.t('inventoryHubGrid:SerialNos'), formatter: serialFormatter, getRowMetaData: (row) => row },
  { key: "ddh_dispatch_doc_type", name: i18n.t('inventoryHubGrid:ddh_dispatch_doc_type') },
  { key: "ddh_dispatch_doc_no", name: i18n.t('inventoryHubGrid:ddh_dispatch_doc_no') },
  { key: "hmred_exec_wt", name: i18n.t('inventoryHubGrid:hmred_exec_wt') },
  { key: "hmred_exec_wt_uom", name: i18n.t('inventoryHubGrid:hmred_exec_wt_uom') },
  { key: "hmred_volume", name: i18n.t('inventoryHubGrid:hmred_volume') },
  { key: "hmred_volume_uom", name: i18n.t('inventoryHubGrid:hmred_volume_uom') },
  { key: "aging", name: i18n.t('inventoryHubGrid:aging') },
  { key: "ddh_customer_id", name: i18n.t('inventoryHubGrid:ddh_customer_id') },
  { key: "brsd_from_contact_person", name: i18n.t('inventoryHubGrid:brsd_from_contact_person') },
  { key: "ddh_ship_to_id", name: i18n.t('inventoryHubGrid:ddh_ship_to_id') },
  { key: "wms_shp_pt_desc", name: i18n.t('inventoryHubGrid:wms_shp_pt_desc') },
  { key: "hmred_exec_doc_no", name: i18n.t('inventoryHubGrid:hmred_exec_doc_no') },
  { key: "hmred_created_date", name: i18n.t('inventoryHubGrid:hmred_created_date') },
  { key: "hmhivbd_reason_code", name: i18n.t('inventoryHubGrid:hmhivbd_reason_code') },
  { key: "wms_code_desc", name: i18n.t('inventoryHubGrid:wms_code_desc') },
  { key: "hmotd_thu_serial_no", name: i18n.t('inventoryHubGrid:hmotd_thu_serial_no') },
  { key: "hmhivbd_claim_no", name: i18n.t('inventoryHubGrid:hmhivbd_claim_no'), editable: statusCond },
  { key: "Attempts", name: i18n.t('inventoryHubGrid:Attempts'), formatter: attemptsFormatter, getRowMetaData: (row) => row },
  { key: "hmhivbd_disposal_action", name: i18n.t('inventoryHubGrid:hmhivbd_disposal_action'), editor: IssueTypeEditor, editable: statusCond },
  { key: "MoreDetails", name: i18n.t('inventoryHubGrid:MoreDetails'), formatter: moreDetailsFormatter, getRowMetaData: (row) => row },
  { key: "return_br_id", name: i18n.t('inventoryHubGrid:br_request_Id'), formatter: LinkFormatter }
];
