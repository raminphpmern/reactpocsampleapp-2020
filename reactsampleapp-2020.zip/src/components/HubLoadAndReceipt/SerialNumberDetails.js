import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import DataGrid from 'components/Common/DataGrid';
import { reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import * as hubReceiptLoadAction from "actions/hubReceiptLoadAction";
import i18n from 'i18n';

export const columns = [
  { key: "hmhid_ref_doc_no", name: i18n.t("hubLoadGrid:bookingRequest") },
  { key: "ddh_dispatch_doc_no", name: i18n.t("hubLoadGrid:dispatchDocument") },
  { key: "hmhid_serialno", name: i18n.t("hubLoadGrid:serialNo") },
  { key: "serialqty", name: i18n.t("hubLoadGrid:actualQuantity") }
]

class SerialNumberDetails extends Component {
  constructor(props) {
    super(props);
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
  }

  componentDidMount() {
    const { rowInfo, getLoadingSerialNoResults, getReceiptSerialNoResults, transactionType, HubReceiptForm, HubLoadingForm } = this.props
    if (transactionType === "HUB LOADING") {
      let br_id = rowInfo.ddh_dispatch_doc_no
      const planNo = HubLoadingForm.values.hmleh_load_exec_no
      let queryString = `doc_id=${br_id}&hmleh_load_exec_no=${planNo}`;
      getLoadingSerialNoResults('serialNoDtls', queryString, 1, 10)
    }
    if (transactionType === "HUB RECEIPT") {
      const br_id = rowInfo.ddh_dispatch_doc_no
      const planNo = HubReceiptForm.values.hmreh_exec_doc_no
      const queryString = `tltd_dispatch_doc_no=${br_id}&hmreh_exec_doc_no=${planNo}`
      getReceiptSerialNoResults('serialNoDtls', queryString, 1, 10)
    }
  }

  changeLimit(pageNo, limit) {
    const { rowInfo, getLoadingSerialNoResults, getReceiptSerialNoResults, transactionType } = this.props
    if (transactionType === "HUB LOADING") {
      let br_id = rowInfo.ddh_dispatch_doc_no
      let queryString = `doc_id=${br_id}`;
      getLoadingSerialNoResults('serialNoDtls', queryString, pageNo, limit)
    }
    if (transactionType === "HUB RECEIPT") {
      let br_id = rowInfo.ddh_dispatch_doc_no
      let queryString = `tltd_dispatch_doc_no=${br_id}`;
      getReceiptSerialNoResults('serialNoDtls', queryString, pageNo, limit)
    }
  }

  paginationHandler(pageNo, limit) {
    const { rowInfo, getLoadingSerialNoResults, getReceiptSerialNoResults, transactionType } = this.props
    if (transactionType === "HUB LOADING") {
      let br_id = rowInfo.hmhid_despatch_doc_no
      let queryString = `doc_id=${br_id}`;
      getLoadingSerialNoResults('serialNoDtls', queryString, pageNo, limit)
    }
    if (transactionType === "HUB RECEIPT") {
      let br_id = rowInfo.ddh_dispatch_doc_no
      let queryString = `tltd_dispatch_doc_no=${br_id}`;
      getReceiptSerialNoResults('serialNoDtls', queryString, pageNo, limit)
    }
  }

  render() {
    const { result, totalPage, totalRecord, resetData } = this.props
    return (
      <div>
        <Grid stackable className="fixed-grid">
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  rows={result}
                  columns={columns}
                  totalPages={totalPage}
                  showCheckbox={false}
                  paginationHandler={this.paginationHandler}
                  changeLimit={this.changeLimit}
                  totalRecord={totalRecord}
                  initialize={resetData}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}


SerialNumberDetails = reduxForm({
  form: 'SerialNumberDetailsForm'
})(SerialNumberDetails);

const mapDispatchToProps = (dispatch) => ({
  getLoadingSerialNoResults: (action, queryString) =>
    dispatch(hubReceiptLoadAction.getLoadingFieldDetails(action, queryString)),
  getReceiptSerialNoResults: (action, queryString) =>
    dispatch(hubReceiptLoadAction.getReceiptFieldDetails(action, queryString)),
  resetData: () => dispatch(hubReceiptLoadAction.resetSerialRecords())
})

const mapStateToProps = state => ({
  SerialNumberDetails: state.form.SerialNumberDetailsForm,
  result: state.hubReceiptLoadReducer.options.serialNoDtls,
  totalPage: state.hubReceiptLoadReducer.totalPage,
  totalRecord: state.hubReceiptLoadReducer.totalRecord,
  HubReceiptForm: state.form.HubReceiptForm,
  HubLoadingForm: state.form.HubLoadingForm
})

export default connect(mapStateToProps, mapDispatchToProps)(SerialNumberDetails)