import React, { Component } from "react";
import InputField from "components/Common/InputField";
import DropDown from "components/Common/Dropdown";
import InputSearchField from "components/Common/InputSearchField";
import DateTimePicker from "components/Common/DateTimePicker";
import { reduxForm, Field } from "redux-form";
import { Grid, Form } from "semantic-ui-react";
import { connect } from "react-redux";
import Popup from "components/Common/Popup";
import HelpOnTripPlan from "components/Dispatch/DispatchCreate/HelpOnTripPlan";
import HelpOnEmployee from "components/CollectionSummary/HelpOnEmployee";
import HelpOnEquipment from "../Loading/HelpOnEquipment";
import { helpOnTripPlanByID } from "actions/dispatchHelpAction";
import * as hubReceiptLoadAction from "actions/hubReceiptLoadAction";
import { loadSelectedTripCode, loadSelectedTripCodeByID, hubLoadingMergeData, hubLoadingHelper, hubLoadingScanHelper } from "./Helper";
import HelpOnLoadingSeal from "./HelpOnLoadingSeal"
import { SEARCH_WORD_COUNT } from "config";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import Result from "./Result";
import "../HubLoadingReceipt.css";
import validate from "./Validation";
import _ from "lodash";
import i18n from 'i18n';
import HelpOnVehicle from "components/TripHub/HelpOnVehicle";
import HelpOnCarrier from "components/TripHub/HelpOnCarrier";
import history from 'routes/history';
import { Icon } from 'semantic-ui-react'

const cutOffOptions = [
  { value: 'all', label: i18n.t("hubLoadForm:all") },
  { value: '>', label: i18n.t("hubLoadForm:greaterThan") },
  { value: '<', label: i18n.t("hubLoadForm:lessThan") }
];

class HubLoading extends Component {
  constructor(props) {
    super(props)
    this.state = {
      tripHelp: false,
      tripLogEnterKey: false,
      employeeHelp: false,
      vehicleHelp: false,
      carrierHelp: false,
      currentHelp: '',
      isExitingTrip: false,
      equipmentHelp: false,
      vehicleSealDsbl: true,
      tripToEnable: false,
      enableScan: false,
      disableCutoff: true,
      loadingStatus: '',
      loadingPlanNo: '',
      limit: 10
    }
    this.toggle = this.toggle.bind(this);
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
    this.selectTripId = this.selectTripId.bind(this);
    this.loadTripLogById = this.loadTripLogById.bind(this);
    this.toggleEnterKey = this.toggleEnterKey.bind(this);
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this);
    this.getEquipmentDetails = this.getEquipmentDetails.bind(this);
    this.getVehicleDetails = this.getVehicleDetails.bind(this);
    this.getCarrierDetails = this.getCarrierDetails.bind(this);
    this.limitChange = this.limitChange.bind(this);
  }

  componentDidMount() {
    this.props.resetHeaderRecords()
    const {
      currentUser,
      trip_to,
      getTripDetails,
      cutoff_regions,
      getCutOffRegions
    } = this.props
    if (trip_to.length === 0) {
      getTripDetails()
    }
    if (cutoff_regions.length === 0) {
      getCutOffRegions()
    }
    const locations = (currentUser && currentUser.locations) || [];
    if (locations.length > 0) {
      this.props.initialize({ location: locations[0].value, division: locations[0].wms_loc_code });
    }
    let _self = this;
    let enterKeyElement = document.getElementById('plpth_trip_plan_id')
    enterKeyElement.addEventListener('keypress', (event) => {
      _self.toggleEnterKey(false)
      if (event.keyCode === 13) {
        _self.toggleEnterKey(true)
        let tripLogID = _self.props.formValues && _self.props.formValues.values
        let loadTripID = tripLogID["plpth_trip_plan_id"]
        if (loadTripID && loadTripID.length >= SEARCH_WORD_COUNT) {
          _self.props.getTripLogIdGridDetails({ plpth_trip_plan_id: tripLogID.plpth_trip_plan_id }, '1', '10')
          _self.props.getTripLogIdDetails({ plpth_trip_plan_id: tripLogID.plpth_trip_plan_id }, '1', '10')
        }
        event.preventDefault()
      }
    })
    let enterOfDispDocNumber = document.getElementById('hmhid_despatch_doc_no')
    enterOfDispDocNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let plpth_trip_plan_id = formValues["plpth_trip_plan_id"]
        let plpth_trip_plan_to = hubLoadingScanHelper(formValues["plpth_trip_plan_to"])
        let loadGridRecords = formValues["hmhid_despatch_doc_no"]
        let hmleh_load_exec_no = formValues["hmleh_load_exec_no"]
        let grid_details = _self.props.gridResult
        let stageId = _self.props.confDetFormValues.values.hmleh_staging_id
        if (loadGridRecords && loadGridRecords.length >= SEARCH_WORD_COUNT) {
          _self.props.loadGridRecords({ plpth_trip_plan_id: plpth_trip_plan_id, hmhid_despatch_doc_no: loadGridRecords, planNo: hmleh_load_exec_no, grid_details: grid_details, stage_id: stageId, to_location: plpth_trip_plan_to })
        }
        event.preventDefault()
      }
    })
    let enterOfSerialNumber = document.getElementById('hmhid_serialno')
    enterOfSerialNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let plpth_trip_plan_id = formValues["plpth_trip_plan_id"]
        let plpth_trip_plan_to = hubLoadingScanHelper(formValues["plpth_trip_plan_to"])
        let loadGridRecords = formValues["hmhid_serialno"]
        let hmleh_load_exec_no = formValues["hmleh_load_exec_no"]
        let hmhid_despatch_doc_no = []
        let stageId = _self.props.confDetFormValues.values.hmleh_staging_id
        if (formValues["hmhid_despatch_doc_no"] !== '') {
          hmhid_despatch_doc_no = formValues["hmhid_despatch_doc_no"]
        }
        if (formValues["hmhid_despatch_doc_no"] === '') {
          hmhid_despatch_doc_no = ""
        }
        let grid_details = _self.props.gridResult
        if (loadGridRecords && loadGridRecords.length >= SEARCH_WORD_COUNT) {
          _self.props.loadGridRecords({ plpth_trip_plan_id: plpth_trip_plan_id, hmhid_serialno: loadGridRecords, planNo: hmleh_load_exec_no, grid_details: grid_details, hmhid_despatch_doc_no: hmhid_despatch_doc_no, stage_id: stageId, to_location: plpth_trip_plan_to })
        }
        event.preventDefault()
      }
    })
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  toggleEnterKey(toggleEnterState) {
    this.setState({ tripLogEnterKey: toggleEnterState })
    this.setState({ isExitingTrip: toggleEnterState })
  }

  selectTripId(selectedTripId) {
    if (selectedTripId) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(loadSelectedTripCode(selectedTripId, hash))
      this.setState({ isExitingTrip: true })
    }
  }

  loadTripLogById(selectedTripId) {
    const { tripLogEnterKey } = this.state
    if (tripLogEnterKey) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(loadSelectedTripCodeByID(selectedTripId, hash))
    }
  }

  getEmployeeDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["plpth_driver_id"] = data[0]["wms_emp_employee_code"]
      this.props.initialize(hash)
    }
  }

  getEquipmentDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["plpth_equipment_id"] = data[0]["wms_eqp_equipment_id"]
      this.props.initialize(hash)
    }
  }

  getVehicleDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["plpth_vehicle_id"] = data[0]["wms_veh_id"]
      this.props.initialize(hash)
    }
  }

  getCarrierDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["plpth_agent_id"] = data[0]["wms_vendor_id"]
      this.props.initialize(hash)
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === 'employee') {
        this.props.getFeildDetails("employee", queryString, fieldName);
      }
      if (fieldName === 'equipmentId') {
        this.props.getFeildDetails("mhe", queryString, fieldName);
      }
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "employee") {
      hash["plpth_driver_id"] = option.wms_emp_employee_code;
    }
    if (fieldName === "equipmentId") {
      hash["plpth_equipment_id"] = option.wms_eqp_equipment_id;
    }
    this.props.initialize(hash);
  }

  limitChange(pageNo, limit) {
    this.setState({ pageNo: pageNo, limit: limit });
  }

  cutoffRecords() {
    const { limit } = this.state
    const formValues = this.props.formValues.values
    this.props.cutoffRecords(hubLoadingHelper(formValues), 1, limit)
  }

  componentDidUpdate(prevProps) {
    const { getTripLogData, headerResult, loading_cbm } = this.props
    if (getTripLogData.length > 0) {
      this.loadTripLogById(getTripLogData[0])
    }
    if (prevProps.headerResult !== this.props.headerResult && this.props.headerResult.length === 0 && this.props.loading_cbm && this.props.loading_cbm.length === 0) {
      const hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(hubLoadingMergeData({ hmleh_load_exec_no: '', hmleh_exec_status: '', totalvolume: '', totalweight: '', totalqty: '', hmhid_serialno: '', hmhid_despatch_doc_no: '', newTripCreation: false }, hash))
      this.setState({ enableScan: false })
      if (getTripLogData.length === 0) {
        const hash = _.cloneDeep(this.props.formValues.values && this.props.formValues.values.plpth_trip_plan_id)
        this.props.initialize({ plpth_trip_plan_id: hash })
        this.setState({ isExitingTrip: false, disableCutoff: true })
      }
    }
    if (this.props.load_response != null) {
      if (this.props.load_response !== prevProps.load_response) {
        const hash = _.cloneDeep(prevProps.formValues.values)
        this.props.initialize(hubLoadingMergeData(this.props.load_response, hash));
        if (this.props.load_response.hmleh_exec_status === "Draft") {
          this.setState({ enableScan: true })
        }
        if (this.props.load_response.hmleh_exec_status === "Confirmed") {
          this.setState({ enableScan: false })
        }
      }
    }
    if (loading_cbm && loading_cbm.length !== 0) {
      if (this.props.loading_cbm !== prevProps.loading_cbm) {
        const cbm = loading_cbm[0];
        const hash = _.cloneDeep(this.props.formValues.values)
        this.props.initialize(hubLoadingMergeData({ totalvolume: cbm.totalvolume, totalweight: cbm.totalweight, totalqty: cbm.totalqty }, hash));
      }
    }
    if (headerResult && headerResult.length !== 0) {
      if (this.props.headerResult !== prevProps.headerResult) {
        const header = headerResult[0]
        let cbm = [];
        if (loading_cbm && loading_cbm.length !== 0) {
          cbm = loading_cbm[0];
        }
        else if (loading_cbm && loading_cbm.length === 0) {
          cbm = { totalvolume: "", totalweight: "", totalqty: "" };
        }
        const hash = _.cloneDeep(this.props.formValues.values)
        this.props.initialize(hubLoadingMergeData({ hmleh_load_exec_no: header.hmleh_load_exec_no, hmleh_exec_status: header.hmleh_exec_status, plpth_driver_id: header.hmleh_drivername_p_h, plpth_vehicle_id: header.hmleh_vehicleregno_p_h, plpth_equipment_id: header.hmleh_equipment_id, plpth_agent_id: header.hmleh_agent_id, totalvolume: cbm.totalvolume, totalweight: cbm.totalweight, totalqty: cbm.totalqty, newTripCreation: header.hmleh_new_trip_plan_id, plpth_trip_plan_to: header.hmleh_hub_to_location }, hash))
      }
    }
  }

  tripCreation = (field) => (
    <Form.Radio
      checked={field.input.value}
      name={field.input.name}
      label={field.label}
      disabled={field.readOnly}
      onClick={field.readOnly ? false : (e, { checked }) => field.input.onChange(checked)}
    />
  );

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.hmleh_load_exec_no) {
      if (nextProps.formValues.values.hmleh_exec_status === "Draft" || nextProps.formValues.values.hmleh_exec_status === "Partially Loaded") {
        this.setState({ disableCutoff: false })
        this.setState({ enableScan: true })
        this.setState({ isExitingTrip: true })
        this.setState({ loadingStatus: nextProps.formValues.values.hmleh_exec_status, loadingPlanNo: nextProps.formValues.values.hmleh_load_exec_no })
        if (!nextProps.formValues.values.newTripCreation === "true") {
          this.setState({ tripToEnable: true })
        }
      }
      if (nextProps.formValues.values.hmleh_exec_status === "Confirmed") {
        this.setState({ disableCutoff: true })
        this.setState({ isExitingTrip: true })
        if (!nextProps.formValues.values.newTripCreation === true) {
          this.setState({ tripToEnable: true })
        }
        this.setState({ loadingStatus: nextProps.formValues.values.hmleh_exec_status, loadingPlanNo: nextProps.formValues.values.hmleh_load_exec_no })
      }
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.getTripLogData.length === 0) {
      if (!nextProps.formValues.values.hmleh_load_exec_no) {
        this.setState({ isExitingTrip: false })
      }
      if (nextProps.formValues.values.hmleh_load_exec_no) {
        this.setState({ tripToEnable: true })
      }
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.getTripLogData.length > 0) {
      if (nextProps.formValues.values.hmleh_load_exec_no && nextProps.formValues.values.newTripCreation === "true" && nextProps.formValues.values.hmleh_exec_status === "Confirmed") {
        this.setState({ tripToEnable: true })
      }
    }
    if (nextProps.formValues && nextProps.formValues.values) {
      if (nextProps.formValues.values.hmleh_load_exec_no) {
        this.setState({ vehicleSealDsbl: false })
      }
      else {
        this.setState({ vehicleSealDsbl: true })
      }
    }
    const { getTripLogData, headerResult } = nextProps
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.newTripCreation === "true" || nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.newTripCreation === true) {
      if (getTripLogData.length === 0 && headerResult.length === 0) {
        this.setState({ tripToEnable: false })
      }
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.newTripCreation === false) {
      this.setState({ tripToEnable: true })
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.hmleh_exec_status === undefined) {
      this.setState({ tripToEnable: false })
    }
  }

  formSubmit() {
    // TODO: This has been left blank to handle multiple submit buttons. Later may enable for enter key
  }

  render() {
    const { handleSubmit, t, employee, trip_to, cutoff_regions, mhe } = this.props
    const { tripHelp, currentHelp, employeeHelp, isExitingTrip, equipmentHelp, enableScan, disableCutoff, loadingPlanNo, loadingStatus, vehicleSealDsbl, tripToEnable, vehicleHelp, carrierHelp } = this.state
    return (
      <div className="hub-loading">

        <Popup size="fullscreen" open={equipmentHelp} close={() => { this.toggle('help', 'equipmentHelp') }} header={t('helpOnEquipment')} description={<HelpOnEquipment
          getEquipmentDetails={this.getEquipmentDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={tripHelp} close={() => { this.toggle('help', 'tripHelp') }}
          header={t('helponTripPlan')} description={<HelpOnTripPlan
            handleOnSelect={this.selectTripId} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={employeeHelp} close={() => { this.toggle('help', 'employeeHelp') }} header={t('helpOnEmployee')} description={<HelpOnEmployee
          getEmployeeDetails={this.getEmployeeDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={vehicleHelp} close={() => { this.toggle('help', 'vehicleHelp') }}
          header={t('helpOnVehicle')} description={<HelpOnVehicle
            getVehicleDetails={this.getVehicleDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={carrierHelp} close={() => { this.toggle("help", "carrierHelp") }}
          header={t('helpOnAgent')} description={<HelpOnCarrier
            getCarrierDetails={this.getCarrierDetails} close={this.toggle} name={currentHelp} />
          }
        />

        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="plpth_trip_plan_id"
                  component={InputField}
                  label={t('tripId')}
                  iconName="search"
                  handleClick={this.toggle}
                  childName="tripHelp"
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="create-trip-radio-button">
                  <Field
                    component={this.tripCreation}
                    label={t('newTripCreation')}
                    name="newTripCreation"
                    readOnly={isExitingTrip}
                  />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmleh_load_exec_no"
                  component={InputField}
                  readOnly={true}
                  label={t('hubLoadingPlanNo')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmleh_exec_status"
                  component={InputField}
                  label={t('status')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="plpth_driver_id"
                  component={InputSearchField}
                  label={t('driverId')}
                  iconName="search"
                  handleClick={this.toggle}
                  childName="employeeHelp"
                  required={true}
                  readOnly={isExitingTrip}
                  findByCompanyAndFLMName={this.search}
                  id="employee"
                  options={employee}
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_vehicle_id"
                  component={InputField}
                  label={t('vehicleId')}
                  required={true}
                  iconName="search"
                  readOnly={isExitingTrip}
                  handleClick={this.toggle}
                  childName="vehicleHelp"
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_equipment_id"
                  component={InputSearchField}
                  label={t('equipmentId')}
                  iconName="search"
                  readOnly={isExitingTrip}
                  findByCompanyAndFLMName={this.search}
                  options={mhe}
                  id="equipmentId"
                  fillNameValues={this.setValue}
                  childName="equipmentHelp"
                  handleClick={this.toggle}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_agent_id"
                  component={InputField}
                  label={t('agentId')}
                  iconName="search"
                  readOnly={isExitingTrip}
                  handleClick={this.toggle}
                  childName="carrierHelp"
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <div className="cutoff">
                  <Field
                    name="cut_off_option"
                    component={DropDown}
                    label={t('cutoff')}
                    options={cutOffOptions}
                  />
                  <Field
                    name="cut_off_time"
                    component={DateTimePicker}
                    showTimeSelect={true}
                    timeIntervals={1}
                  />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="cut_off_region"
                  component={DropDown}
                  label={t('region')}
                  options={cutoff_regions}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <div>
                  <button id='search' type="submit" className="primary"
                    disabled={disableCutoff}
                    onClick={() => this.cutoffRecords()}> {t('searchBtn')}
                  </button>
                  <Popup size="fullscreen" header="Vehicle Seal" description={<HelpOnLoadingSeal planNo={loadingPlanNo} status={loadingStatus} />} trigger={<button type="button" className="link-button" disabled={vehicleSealDsbl}>
                    Vehicle Seal </button>} />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_trip_plan_to"
                  component={!tripToEnable ? DropDown : isExitingTrip ? InputField : DropDown}
                  label={t('tripTo')}
                  options={trip_to}
                  readOnly={isExitingTrip}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={3} className="master-number">
                <Field
                  name="MAWB/MBL"
                  component={InputField}
                  label={t('MAWB/MBL')}
                />
              </Grid.Column>
              <Grid.Column width={1} > <button type="button" className="secondary btn-small nav-btn" onClick={() => history.push('/dispatchDocument/create')}>
                <Icon name='add' />
              </button>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_schedule_id"
                  component={InputField}
                  label={t('scheduleNo')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="vessel_name"
                  component={InputField}
                  label={t('vesselName')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="vessel_no"
                  component={InputField}
                  label={t('vesselNo')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column className="hub-load-receipt">
                <h6 className="custom-title">
                  <span>{t('subtitle')}</span>
                </h6>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="hmhid_despatch_doc_no"
                  component={InputField}
                  label={t('dispatchDocument')}
                  readOnly={!enableScan}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmhid_serialno"
                  component={InputField}
                  label={t('thuSerialNo')}
                  readOnly={!enableScan}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="totalqty"
                  component={InputField}
                  readOnly={true}
                  label={t('totalQuantity')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="totalvolume"
                  component={InputField}
                  readOnly={true}
                  label={t('totalVolume')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="totalweight"
                  component={InputField}
                  readOnly={true}
                  label={t('totalWeight')}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row />
          </Grid>
        </form>
        <div className="load-receipt-result-part">
          <Result pageNoLimit={this.limitChange} />
        </div>
      </div >
    );
  }
}

HubLoading = reduxForm({
  form: "HubLoadingForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate
})(HubLoading);

const mapDispatchToProps = (dispatch) => ({
  getTripLogIdGridDetails: (tripLogID, pageNo, limit) =>
    dispatch(helpOnTripPlanByID(tripLogID, pageNo, limit)),
  getTripLogIdDetails: (tripLogID, pageNo, limit) =>
    dispatch(hubReceiptLoadAction.getTripDataLoading(tripLogID, pageNo, limit)),
  loadGridRecords: (params) =>
    dispatch(hubReceiptLoadAction.saveLoadingRecords('dispatch', params)),
  cutoffRecords: (params, pageNo, limit) =>
    dispatch(hubReceiptLoadAction.saveLoadingRecords('cutoff', params, pageNo, limit)),
  getFeildDetails: (action, queryStr) =>
    dispatch(hubReceiptLoadAction.getLoadingFieldDetails(action, queryStr)),
  getTripDetails: () =>
    dispatch(hubReceiptLoadAction.getLoadingFieldDetails("trip_to")),
  getCutOffRegions: () =>
    dispatch(hubReceiptLoadAction.getLoadingFieldDetails("region")),
  resetHeaderRecords: () => dispatch(hubReceiptLoadAction.resetHeaderRecords()),
})

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
  formValues: state.form.HubLoadingForm,
  confDetFormValues: state.form.ConfirmationDetailsForm,
  getTripLogData: state.dispatchReducer.result_help_trip_by_id,
  employee: state.hubReceiptLoadReducer.options.employee,
  mhe: state.hubReceiptLoadReducer.options.mhe,
  trip_to: state.hubReceiptLoadReducer.options.trip_to,
  cutoff_regions: state.hubReceiptLoadReducer.options.region,
  load_response: state.hubReceiptLoadReducer.load_response,
  loading_cbm: state.hubReceiptLoadReducer.loading_cbm,
  headerResult: state.hubReceiptLoadReducer.loadHeaderResult,
  gridResult: state.hubReceiptLoadReducer.gridLoadResult,
  status: state.hubReceiptLoadReducer.status
})

export default compose(withTranslation('hubLoadForm'), connect(mapStateToProps, mapDispatchToProps))(HubLoading);