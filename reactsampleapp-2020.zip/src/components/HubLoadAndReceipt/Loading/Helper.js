import React from 'react';
import LinkPopUp from '../../Common/DataGrid/LinkPopUp';
import SerialDetails from 'components/HubLoadAndReceipt/SerialNumberDetails';
import MoreDetails from 'components/InventoryHub/Popup/MoreDetails';
import _ from "lodash";
import i18n from 'i18n';

const serialFormatter = <LinkPopUp name={i18n.t("hubLoadGrid:serialNo")} defaultValue="Serial No"> <SerialDetails transactionType='HUB LOADING' /> </LinkPopUp>
const moreDetailsFormatter = <LinkPopUp name={i18n.t("hubLoadGrid:moreDetails")} defaultValue='More Details'> <MoreDetails transactionType='HUB LOADING' /> </LinkPopUp>

export const columns = [
  { key: "hmhid_ref_doc_no", name: i18n.t("hubLoadGrid:bookingRequest") },
  { key: "ddh_dispatch_doc_no", name: i18n.t("hubLoadGrid:dispatchDocument") },
  { key: "hmhid_serialno", name: i18n.t("hubLoadGrid:serialNo"), formatter: serialFormatter, getRowMetaData: (row) => row },
  { key: "hmhid_quantity", name: i18n.t("hubLoadGrid:plannedQuantity") },
  { key: "hmled_act_qty", name: i18n.t("hubLoadGrid:actualQuantity") },
  { key: "check_more_details", name: i18n.t("hubLoadGrid:moreDetails"), formatter: moreDetailsFormatter, getRowMetaData: (row) => row },
  { key: "pltpd_to", name: i18n.t("hubLoadGrid:tripTo") },
  { key: "ccd_consignee_name", name: i18n.t("hubLoadGrid:consigneeName"), editable: true },
  { key: "cd_amount_collected", name: i18n.t("hubLoadGrid:amounttobecollected"), editable: true },
  { key: "check_output_thu_serial_no", name: i18n.t("hubLoadGrid:outputThuSerialNo"), editable: true },
  { key: "hmlesd_seal_no", name: i18n.t("hubLoadGrid:outputThuSealNo"), editable: true },
  { key: "hmlesd_sealed_by", name: i18n.t("hubLoadGrid:sealBy"), editable: true },
]

export function loadSelectedTripCode(selectedTripId, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  tempHash['plpth_trip_plan_id'] = selectedTripId.plpth_trip_plan_id
  tempHash['plpth_driver_id'] = selectedTripId.plpth_driver_id
  tempHash['plpth_equipment_id'] = selectedTripId.plpth_equipment_id
  tempHash['plpth_vehicle_id'] = selectedTripId.plpth_vehicle_id
  tempHash['plpth_trip_plan_to'] = selectedTripId.plpth_trip_plan_to
  tempHash['plpth_agent_id'] = selectedTripId.plpth_agent_id
  return tempHash
}

export function loadSelectedTripCodeByID(selectedTripId, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  tempHash['plpth_driver_id'] = selectedTripId.plpth_driver_id
  tempHash['plpth_equipment_id'] = selectedTripId.plpth_equipment_id
  tempHash['plpth_vehicle_id'] = selectedTripId.plpth_vehicle_id
  tempHash['plpth_trip_plan_to'] = selectedTripId.plpth_trip_plan_to
  tempHash['plpth_agent_id'] = selectedTripId.plpth_agent_id
  return tempHash
}

export function hubLoadingMergeData(data, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  _.merge(tempHash, data)
  return tempHash
}

export function hubLoadingHelper(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["cut_off_option"]) {
      hash["cut_off_option"] = hash["cut_off_option"].value
    }
    if (typeof (hash["plpth_trip_plan_to"]) == 'object') {
      hash["plpth_trip_plan_to"] = hash["plpth_trip_plan_to"].wms_loc_code
    }
    if (hash["cut_off_region"]) {
      hash["cut_off_region"] = hash["cut_off_region"].wms_geo_reg
    }
    return hash
  } else {
    return {}
  }
}

export function hubLoadingScanHelper(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (typeof hash === 'object') {
      hash = hash.wms_loc_code
    }
    return hash
  } else {
    return ""
  }
}