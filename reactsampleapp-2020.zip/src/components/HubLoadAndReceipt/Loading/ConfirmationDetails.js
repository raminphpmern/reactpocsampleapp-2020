import React, { Component } from "react";
import InputField from "components/Common/InputField";
import InputSearchField from "components/Common/InputSearchField";
import DropDown from "components/Common/Dropdown";
import DateTimePicker from "components/Common/DateTimePicker";
import { reduxForm, Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import { withTranslation } from 'react-i18next';
import * as hubReceiptLoadAction from "actions/hubReceiptLoadAction";
import Popup from 'components/Common/Popup';
import HelpOnEmployee from "components/CollectionSummary/HelpOnEmployee";
import validate from "./Validation";
import { hubLoadingHelper } from './Helper'
import { compose } from 'redux';
import { connect } from "react-redux";
import { SEARCH_WORD_COUNT } from "config";
import { hubLoadingMergeData } from './Helper';
import { AlertSuccess, AlertError } from 'lib/Alert'
import i18n from 'i18n';
import _ from "lodash";
import HelpOnEquipment from "./HelpOnEquipment";

const printOptions = [
  { value: 'forwardingManifest', label: i18n.t("hubLoadForm:forwardingManifest") },
  { value: 'ddrManifest', label: i18n.t("hubLoadForm:ddrManifest") }
];

class ConfirmationDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      employeeHelp: false,
      equipmentHelp: false,
      currentHelp: '',
      enableButton: true,
      disbledCnfBtn: false,
      disableSaveBtn: false
    }
    this.toggle = this.toggle.bind(this)
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this);
    this.getEquipmentDetails = this.getEquipmentDetails.bind(this);
    this.saveLoadingRecords = this.saveLoadingRecords.bind(this);
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
    this.printBtnAction = this.printBtnAction.bind(this);
  }

  componentDidMount() {
    this.props.resetHeaderRecords()
  }

  saveLoadingRecords() {
    const HubLoadingForm = this.props.HubLoadingForm.values
    const formValues = this.props.formValues.values
    const gridRecords = this.props.result
    let HubLoadingFormData = []
    if (HubLoadingForm && HubLoadingForm.hmleh_load_exec_no) {
      HubLoadingFormData = HubLoadingForm
    } else {
      HubLoadingFormData = hubLoadingMergeData({ hmleh_load_exec_no: "" }, this.props.HubLoadingForm.values)
    }
    const datas = Object.assign({}, { ...HubLoadingFormData }, { ...formValues }, { grid_details: gridRecords })
    this.props.saveLoadingRecords(hubLoadingHelper(datas))
  }

  partiallyCloseLoadingRecords() {
    const HubLoadingForm = this.props.HubLoadingForm.values
    const formValues = this.props.formValues.values
    const datas = Object.assign({}, { ...HubLoadingForm }, { ...formValues })
    if (HubLoadingForm.totalqty >= 1) {
      this.props.partiallyCloseLoadingRecords(hubLoadingHelper(datas))
    }
    else {
      AlertError(i18n.t("hubLoadForm:nothingScannedonPC"))
    }
  }

  confirmLoadingRecords() {
    const HubLoadingForm = this.props.HubLoadingForm.values
    const formValues = this.props.formValues.values
    const gridRecords = this.props.result
    const datas = Object.assign({}, { ...HubLoadingForm }, { ...formValues }, { grid_details: gridRecords })
    if (HubLoadingForm.totalqty >= 1) {
      this.props.confirmLoadingRecords(hubLoadingHelper(datas))
    }
    else {
      AlertError(i18n.t("hubLoadForm:nothingScanned"))
    }
  }

  printBtnAction() {
    AlertSuccess(i18n.t("hubLoadForm:printAction"))
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  getEmployeeDetails(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["hmleh_emp_id"] = data[0]["wms_emp_employee_code"]
      this.props.initialize(hash)
    }
  }

  getEquipmentDetails(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["wms_eqp_equipment_id"] = data[0]["wms_eqp_equipment_id"]
      this.props.initialize(hash)
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      let queryString1 = `bayType=DK&keyword=${value}`;
      let queryString2 = `bayType=STG&keyword=${value}`;
      if (fieldName === 'employee') {
        this.props.getFeildDetails("employee", queryString, fieldName);
      }
      if (fieldName === 'mhe') {
        this.props.getFeildDetails("mhe", queryString, fieldName);
      }
      if (fieldName === "dockid") {
        this.props.getFeildDetails("stageid", queryString1, fieldName);
      }
      if (fieldName === 'stageid') {
        this.props.getFeildDetails("stageid", queryString2, fieldName);
      }
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (option) {
      if (fieldName === "employee") {
        hash["hmleh_emp_id"] = option.wms_emp_employee_code;
      }
      if (fieldName === "mhe") {
        hash["wms_eqp_equipment_id"] = option.wms_eqp_equipment_id;
      }
      if (fieldName === "stageid") {
        hash["hmleh_staging_id"] = option.wms_bay_id;
      }
      if (fieldName === "dockid") {
        hash["hmleh_dock_id"] = option.wms_bay_id;
      }
    }
    this.props.initialize(hash);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.HubLoadingForm && nextProps.HubLoadingForm.values) {
      const HubLoadingForm = nextProps.HubLoadingForm
      if (HubLoadingForm.values.plpth_trip_plan_id && HubLoadingForm.values.plpth_vehicle_id && HubLoadingForm.values.plpth_driver_id) {
        this.setState({ enableButton: false })
      }
      else if (!HubLoadingForm.values.plpth_trip_plan_id || !HubLoadingForm.values.plpth_vehicle_id || !HubLoadingForm.values.plpth_driver_id) {
        this.setState({ enableButton: true })
      }
      if (this.props.formValues && this.props.formValues.values && this.props.formValues.values.hmleh_exec_status !== "Confirmed") {
        this.setState({ disbledCnfBtn: false })
        this.setState({ disableSaveBtn: false })
      }
      if (HubLoadingForm.values.hmleh_exec_status === "Confirmed") {
        this.setState({ disbledCnfBtn: true })
      }
      if (HubLoadingForm.values.hmleh_exec_status === "Draft" || HubLoadingForm.values.hmleh_exec_status === "Partially Loaded") {
        this.setState({ disableSaveBtn: true })
      }
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.headerResult !== null) {
      if (this.props.headerResult[0] !== undefined) {
        if (prevProps.headerResult !== this.props.headerResult && this.props.headerResult.length !== 0) {
          const header = this.props.headerResult[0]
          this.props.initialize({ hmleh_dock_id: header.hmleh_dock_id, hmleh_staging_id: header.hmleh_staging_id, hmleh_emp_id: header.hmleh_emp_id, wms_eqp_equipment_id: header.hmleh_mhe_id, hmleh_start_date: header.hmleh_start_date, hmleh_end_date: header.hmleh_end_date, hmleh_remarks: header.hmleh_remarks })
        }
      }
    }
    if (prevProps.headerResult !== this.props.headerResult && this.props.headerResult.length === 0) {
      this.props.initialize()
    }
  }

  formSubmit() {
    // TODO: This has been left blank to handle multiple submit buttons. Later may enable for enter key
  }

  render() {
    const { invalid, handleSubmit, employee, mhe, stageid, t } = this.props;
    const { currentHelp, employeeHelp, equipmentHelp, enableButton, disbledCnfBtn, disableSaveBtn } = this.state;
    return (
      <div className="dispatch">

        <Popup size="fullscreen" open={employeeHelp} close={() => { this.toggle('help', 'employeeHelp') }} header={t('helpOnEmployee')} description={<HelpOnEmployee
          getEmployeeDetails={this.getEmployeeDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={equipmentHelp} close={() => { this.toggle('help', 'equipmentHelp') }} header={t('helpOnEquipment')} description={<HelpOnEquipment
          getEquipmentDetails={this.getEquipmentDetails} close={this.toggle} name={currentHelp} />} />

        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="hmleh_dock_id"
                  component={InputSearchField}
                  label={t('dockId')}
                  required={true}
                  findByCompanyAndFLMName={this.search}
                  id="dockid"
                  options={stageid}
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmleh_staging_id"
                  component={InputSearchField}
                  label={t('stageId')}
                  required={true}
                  findByCompanyAndFLMName={this.search}
                  id="stageid"
                  options={stageid}
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmleh_emp_id"
                  component={InputSearchField}
                  label={t('employeeId')}
                  iconName="search"
                  handleClick={this.toggle}
                  required={true}
                  childName="employeeHelp"
                  findByCompanyAndFLMName={this.search}
                  id="employee"
                  options={employee}
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="additional-employee">
                  <Popup size="fullscreen" trigger={<button type="button" className="link-button" disabled={true}>
                    {t('additionalEmployee')}</button>} />
                </div>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="wms_eqp_equipment_id"
                  component={InputSearchField}
                  label={t('mhe')}
                  iconName="search"
                  required={true}
                  findByCompanyAndFLMName={this.search}
                  id="mhe"
                  options={mhe}
                  fillNameValues={this.setValue}
                  handleClick={this.toggle}
                  childName="equipmentHelp"
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmleh_start_date"
                  component={DateTimePicker}
                  showTimeSelect={true}
                  timeIntervals={1}
                  label={t('startDateTime')}
                  min={new Date()}
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmleh_end_date"
                  component={DateTimePicker}
                  showTimeSelect={true}
                  timeIntervals={1}
                  label={t('endDateTime')}
                  min={new Date()}
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmleh_remarks"
                  component={InputField}
                  label={t('remarks')}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row >
              <Grid.Column width={5} />
              <Grid.Column width={5}>
                <div className="hub-load-print-options">
                  <Field
                    name="check_print_options"
                    component={DropDown}
                    options={printOptions}
                    placeholder={t('printOptionPlaceHolder')}
                  />
                </div>
              </Grid.Column>
              <Grid.Column>
                <div className="hub-load-print-button">
                  <button id='save' type='button' className="primary" onClick={() => this.printBtnAction()}>
                    {t('printBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row />
            <Grid.Row />
            <Grid.Row className="create-buttons">
              <Grid.Column width={6}>
                <div className="assign-button-right">
                  <button id='save' type='button' className="primary" disabled={invalid || enableButton || disbledCnfBtn || disableSaveBtn}
                    onClick={() => this.saveLoadingRecords()}>
                    {t('saveBtn')}
                  </button>
                </div>
              </Grid.Column>
              <Grid.Column width={3}>
                <div className="text-center">
                  <button id='confirm' type='button' className="secondary" disabled={invalid || enableButton || disbledCnfBtn || !disableSaveBtn} onClick={() => this.partiallyCloseLoadingRecords()}>
                    {t('partiallyCloseBtn')}
                  </button>
                </div>
              </Grid.Column>
              <Grid.Column >
                <div className="text-center">
                  <button id='confirm' type="button" className="secondary" disabled={invalid || enableButton || disbledCnfBtn || !disableSaveBtn} onClick={() => this.confirmLoadingRecords()}>
                    {t('confirmBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div >
    );
  }
}
ConfirmationDetails = reduxForm({
  form: "ConfirmationDetailsForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate,
})(ConfirmationDetails);

const mapDispatchToProps = (dispatch) => ({
  saveLoadingRecords: (params) =>
    dispatch(hubReceiptLoadAction.saveLoadingRecords('save', params)),
  confirmLoadingRecords: (params) =>
    dispatch(hubReceiptLoadAction.saveLoadingRecords('confirm', params)),
  partiallyCloseLoadingRecords: (params) =>
    dispatch(hubReceiptLoadAction.saveLoadingRecords('partiallyClose', params)),
  getFeildDetails: (action, queryStr) =>
    dispatch(hubReceiptLoadAction.getLoadingFieldDetails(action, queryStr)),
  resetHeaderRecords: () => dispatch(hubReceiptLoadAction.resetHeaderRecords())
})

const mapStateToProps = state => ({
  formValues: state.form.ConfirmationDetailsForm,
  HubLoadingForm: state.form.HubLoadingForm,
  employee: state.hubReceiptLoadReducer.options.employee,
  mhe: state.hubReceiptLoadReducer.options.mhe,
  stageid: state.hubReceiptLoadReducer.options.stageid,
  headerResult: state.hubReceiptLoadReducer.loadHeaderResult,
  result: state.hubReceiptLoadReducer.gridLoadResult
})

export default compose(withTranslation('hubLoadForm'), connect(mapStateToProps, mapDispatchToProps))(ConfirmationDetails);