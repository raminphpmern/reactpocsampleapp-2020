import React from 'react';
import Wrapper from "components/LandingPage/Wrapper";
import HubLoading from './HubLoading';
import { Icon } from 'semantic-ui-react';
import { withTranslation } from 'react-i18next';

const HubLoadingForm = (props) => {
  const { t } = props;
  return (
    <Wrapper DisableBranch={true}>
      <div className="hub-loading-head">
        <h3>{t('title')}</h3>
        <div className="back-link">
          <a href="javascript: false" onClick={props.history.goBack}>
            <Icon disabled name='arrow left' />
            {t('translation:back')}</a>
        </div>
      </div>
      <div className="load-receipt-result-part">
        <HubLoading />
      </div>
    </Wrapper>
  )
}

export default withTranslation('hubLoadForm')(HubLoadingForm)