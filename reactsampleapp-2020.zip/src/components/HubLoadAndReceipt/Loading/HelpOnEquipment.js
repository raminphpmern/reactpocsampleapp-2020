import React, { Component } from 'react'
import { reduxForm } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { gridHeaders, basicFields } from './EquipmentHelper';
import { equipmentSearch, initialize } from "actions/hubReceiptLoadAction";
import DynamicFields from 'components/Common/DynamicFields';
import DataGrid from 'components/Common/DataGrid';
import { formatFormValues } from "lib/CommonHelper";
import { getEmployeeStatus, getEquipmentType, getOwnerType } from "actions/masterAction";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';

class HelpOnEquipment extends Component {
  constructor(props) {
    super(props);
    this.state = {
      filterFields: basicFields,
      selectedRecord: null,
      defaultValues: null,
      error: ''
    };
    this.formSubmit = this.formSubmit.bind(this);
    this.paginationHandler = this.paginationHandler.bind(this);
    this.selectedRows = this.selectedRows.bind(this);
    this.changeLimit = this.changeLimit.bind(this);
    this.getEquipmentDetails = this.getEquipmentDetails.bind(this);
  }

  componentDidMount() {
    const {
      employeeStatus,
      getEmployeeStatus,
      equipmentType,
      getEquipmentType,
      ownerType,
      getOwnerType
    } = this.props;
    if (employeeStatus.length === 0) {
      getEmployeeStatus();
    }
    if (equipmentType.length === 0) {
      getEquipmentType();
    }
    if (ownerType.length === 0) {
      getOwnerType();
    }
  }

  formSubmit(values) {
    this.props.equipmentSearch(formatFormValues(values), 1, 10, true);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  changeLimit(pageNo, limit) {
    this.props.equipmentSearch(formatFormValues(this.props.HelpOnEquipment.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.equipmentSearch(formatFormValues(this.props.HelpOnEquipment.values), pageNo, limit);
  }

  getEquipmentDetails() {
    const { selectedIds } = this.state
    const { close } = this.props
    if (selectedIds !== null) {
      this.props.getEquipmentDetails(selectedIds)
      close('help', 'equipmentHelp')
    }
  }

  render() {
    const { error, filterFields, defaultValues } = this.state
    const { isRequested, handleSubmit, result, totalPage, totalRecord, employeeStatus, initializeEquipmentData, t, equipmentType, ownerType } = this.props
    const disabled = this.state.selectedIds && this.state.selectedIds.length > 0
    return (
      <div>
        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable>
            {error && <span className='error-msg'>{error}</span>}
            <Grid.Row>
              <DynamicFields
                filterFields={filterFields}
                employeeStatus={employeeStatus}
                equipmentType={equipmentType}
                ownerType={ownerType}
                cols={3}
              />
            </Grid.Row>
          </Grid>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='search' type="submit" className="primary" disabled={isRequested}>
                    {t('searchBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={gridHeaders}
                rows={result}
                rowKey="wms_eqp_equipment_id"
                totalPages={totalPage}
                width={140}
                paginationHandler={this.paginationHandler}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                defaultValues={defaultValues}
                totalRecord={totalRecord}
                enableExport={true}
                singleSelect={true}
                initialize={initializeEquipmentData}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='details' onClick={this.getEquipmentDetails} type="button" className="primary" disabled={!disabled}>
                  {t('okBtn')}
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

HelpOnEquipment = reduxForm({
  form: 'HelpOnEquipment'
})(HelpOnEquipment);

const mapStateToProps = state => ({
  isRequested: state.hubReceiptLoadReducer.isRequested,
  result: state.hubReceiptLoadReducer.equipmentResult,
  totalPage: state.hubReceiptLoadReducer.equipmentTotalPage,
  totalRecord: state.hubReceiptLoadReducer.equipmentTotalRecord,
  HelpOnEquipment: state.form.HelpOnEquipment,
  ownerType: state.masterReducer.options.ownerType,
  equipmentType: state.masterReducer.options.equipmentType,
  employeeStatus: state.masterReducer.options.employeeStatus,
})

const mapDispatchToProps = (dispatch) => ({
  equipmentSearch: (values, pageNo, pageLimit, isSearch) => dispatch(equipmentSearch(values, pageNo, pageLimit, isSearch)),
  getEmployeeStatus: type =>
    dispatch(getEmployeeStatus("employeeStatus")),
  initializeEquipmentData: () => dispatch(initialize()),
  getEquipmentType: type =>
    dispatch(getEquipmentType("equipmentType")),
  getOwnerType: type =>
    dispatch(getOwnerType("ownerType"))
})

export default compose(withTranslation('helpOnEquipmentForm'), connect(mapStateToProps, mapDispatchToProps))(HelpOnEquipment)
