import i18n from 'i18n';

export const gridHeaders = [
  { key: "wms_eqp_equipment_id", name: i18n.t('helpOnEquipmentGrid:wms_eqp_equipment_id') },
  { key: "wms_eqp_description", name: i18n.t('helpOnEquipmentGrid:wms_eqp_description') },
  { key: "eqp_type", name: i18n.t('helpOnEquipmentGrid:eqp_type') },
  { key: "own_type", name: i18n.t('helpOnEquipmentGrid:own_type') },
  { key: "veh_status", name: i18n.t('helpOnEquipmentGrid:veh_status') },
  { key: "wms_eqp_agencyid", name: i18n.t('helpOnEquipmentGrid:wms_eqp_agencyid') },
  { key: "wms_vendor_name", name: i18n.t('helpOnEquipmentGrid:wms_vendor_name') },
  { key: "wms_eqp_reg_no", name: i18n.t('helpOnEquipmentGrid:wms_eqp_reg_no') },
  { key: "wms_eqp_category", name: i18n.t('helpOnEquipmentGrid:wms_eqp_category') },
  { key: "wms_eqp_default_location", name: i18n.t('helpOnEquipmentGrid:wms_eqp_default_location') },
  { key: "wms_eqp_current_location", name: i18n.t('helpOnEquipmentGrid:wms_eqp_current_location') },
];

export const basicFields = [
  { label: i18n.t('helpOnEquipmentForm:wms_eqp_equipment_id'), value: 'wms_eqp_equipment_id', type: 'inputBox' },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_description'), value: 'wms_eqp_description', type: 'inputBox' },

  {
    label: i18n.t('helpOnEquipmentForm:veh_status'), value: 'veh_status', type: 'dropDown',
    values: {
      props: {
        options: 'employeeStatus',
        clearable: true,
      }
    }
  },

  {
    label: i18n.t('helpOnEquipmentForm:eqp_type'), value: 'eqp_type', type: 'dropDown',
    values: {
      props: {
        options: 'equipmentType',
        clearable: true,
      }
    }
  },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_reg_no'), value: 'wms_eqp_reg_no', type: 'inputBox' },

  { label: i18n.t('helpOnEquipmentForm:reg.wms_eqp_exp_date'), value: 'reg.wms_eqp_exp_date', type: 'dateTime' },

  {
    label: i18n.t('helpOnEquipmentForm:veh_own'), value: 'veh_own', type: 'dropDown',
    values: {
      props: {
        options: 'ownerType',
        clearable: true,
      }
    }
  },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_agencyid'), value: 'wms_eqp_agencyid', type: 'inputBox' },

  { label: i18n.t('helpOnEquipmentForm:wms_vendor_name'), value: 'wms_vendor_name', type: 'inputBox' },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_category'), value: 'wms_eqp_category', type: 'inputBox' },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_reference_id'), value: 'wms_eqp_reference_id', type: 'inputBox' },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_exp_date'), value: 'wms_eqp_exp_date', type: 'dateTime' },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_mfg_name'), value: 'wms_eqp_mfg_name', type: 'inputBox' },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_default_location'), value: 'wms_eqp_default_location', type: 'inputBox' },

  { label: i18n.t('helpOnEquipmentForm:wms_eqp_current_location'), value: 'wms_eqp_current_location', type: 'inputBox' },
]