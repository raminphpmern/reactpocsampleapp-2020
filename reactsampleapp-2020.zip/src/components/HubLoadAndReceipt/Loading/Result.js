import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { columns } from "./Helper";
import { connect } from "react-redux";
import * as hubReceiptLoadAction from "actions/hubReceiptLoadAction";
import _ from 'lodash';
import i18n from 'i18n';
import { AlertError } from "lib/Alert";
import ConfirmationDetails from "./ConfirmationDetails";

class Result extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selectedIds: null,
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.onUpdateRow = this.onUpdateRow.bind(this)
    this.deleteSelectedRecords = this.deleteSelectedRecords.bind(this)
  }

  changeLimit(pageNo, limit) {
    const plpth_trip_plan_id = this.props.HubLoadingForm.values.plpth_trip_plan_id
    this.props.getTripDataLoading({ plpth_trip_plan_id: plpth_trip_plan_id }, pageNo, limit)
    this.props.pageNoLimit(pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    const plpth_trip_plan_id = this.props.HubLoadingForm.values.plpth_trip_plan_id
    this.props.getTripDataLoading({ plpth_trip_plan_id: plpth_trip_plan_id }, pageNo, limit)
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  onUpdateRow(row, updateValue) {
    this.props.updateRow(row, updateValue)
    const response = _.reduce(this.state.selectedIds, (arr, item) => {
      if (item.hmhid_ref_doc_no === row.hmhid_ref_doc_no) {
        _.merge(item, updateValue)
      }
      arr.push(item)
      return arr
    }, [])
    this.setState({ selectedIds: response })
  }

  deleteSelectedRecords(rows) {
    const { deleteHubLoadingRecords, HubLoadingForm } = this.props
    if (HubLoadingForm.values.hmleh_exec_status !== "Confirmed") {
      deleteHubLoadingRecords({
        hmleh_load_exec_no: HubLoadingForm.values.hmleh_load_exec_no,
        ddh_dispatch_doc_no: _.map(rows, 'ddh_dispatch_doc_no'),
        data: rows, form: "HubLoading"
      })
    }
    else {
      AlertError(i18n.t('hubLoadingvalidation:alreadyConfirmed'))
    }
  }

  render() {
    const { result, totalPage, totalRecord, resetData } = this.props
    return (
      <div>
        <Grid stackable >
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  columns={columns}
                  width={250}
                  rows={result}
                  selectedRows={this.selectedRows}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  enableExport={true}
                  initialize={resetData}
                  rowEdit={this.onUpdateRow}
                  showCheckbox={true}
                  deleteRow={true}
                  dropSelectedRows={this.deleteSelectedRecords}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <ConfirmationDetails />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  getTripDataLoading: (data, pageNo, limit) =>
    dispatch(hubReceiptLoadAction.getTripDataLoading(data, pageNo, limit)),
  resetData: () =>
    dispatch(hubReceiptLoadAction.resetTripDataRecords()),
  updateRow: (row, updateValue) =>
    dispatch(hubReceiptLoadAction.updateLoadingRow(row, updateValue)),
  deleteHubLoadingRecords: (params) =>
    dispatch(hubReceiptLoadAction.deleteHlRecords(params))
})

const mapStateToProps = state => ({
  result: state.hubReceiptLoadReducer.gridLoadResult,
  totalPage: state.hubReceiptLoadReducer.totalPage,
  totalRecord: state.hubReceiptLoadReducer.totalRecord,
  HubLoadingForm: state.form.HubLoadingForm,
})

export default connect(mapStateToProps, mapDispatchToProps)(Result)