import i18n from 'i18n';
import { formatDateTime } from 'lib/CommonHelper'
import { AlertError } from 'lib/Alert';

export default function Validation(values) {
  const errors = {};
  if (!values.hmleh_dock_id) {
    errors.hmleh_dock_id = i18n.t('hubLoadingvalidation:dockIdReq')
  }
  if (!values.plpth_driver_id) {
    errors.plpth_driver_id = i18n.t('hubLoadingvalidation:driverIdReq')
  }
  if (!values.plpth_vehicle_id) {
    errors.plpth_vehicle_id = i18n.t('hubLoadingvalidation:vehicleIdReq')
  }
  if (!values.hmleh_staging_id) {
    errors.hmleh_staging_id = i18n.t('hubLoadingvalidation:stageIdReq')
  }
  if (!values.wms_eqp_equipment_id) {
    errors.wms_eqp_equipment_id = i18n.t('hubLoadingvalidation:mheNoReq')
  }
  if (!values.hmleh_emp_id) {
    errors.hmleh_emp_id = i18n.t('hubLoadingvalidation:empReq')
  }
  if (!values.hmleh_start_date) {
    errors.hmleh_start_date = i18n.t('hubLoadingvalidation:startDateReq')
  }
  if (!values.hmleh_end_date) {
    errors.hmleh_end_date = i18n.t('hubLoadingvalidation:endDateReq')
  }
  if (!values.plpth_trip_plan_id) {
    errors.plpth_trip_plan_id = i18n.t('hubLoadingvalidation:tripIdReq')
  }
  if (values.hmleh_start_date && values.hmleh_end_date) {
    const startTime = formatDateTime(values.hmleh_start_date, false)
    const endTime = formatDateTime(values.hmleh_end_date, false)
    if (startTime > endTime) {
      AlertError(i18n.t('hubLoadingvalidation:endDateGreater'))
      errors.hmleh_end_date = i18n.t('hubLoadingvalidation:endDateGreater')
    }
  }
  if (values.cut_off_option && values.cut_off_option.value !== 'all' && !values.cut_off_time) {
    AlertError(i18n.t('hubLoadingvalidation:cutOffTimeReq'))
  }
  return errors
}