import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import { reduxForm } from "redux-form";
import { compose } from 'redux';
import i18n from 'i18n';
import DataGrid from 'components/Common/DataGrid';
import { connect } from 'react-redux';
import { fetchReceiptSeal, initializeRS, saveReceiptDtl, deleteReceiptSeal } from 'actions/hubReceiptLoadAction';
import * as masterActions from 'actions/masterAction';
import { withTranslation } from 'react-i18next';
import { AlertError } from 'lib/Alert';
import DropDownEditor from 'components/Common/DataGrid/DropDownEditor'
import InputSearchEditor from 'components/Common/DataGrid/InputSearchEditor';
import _ from 'lodash';

export const columns = [
  { key: "hmresd_un_seal_no", name: i18n.t("vehicleSeal:hmresd_un_seal_no"), editable: true },
  { key: "hmresd_un_sealed_by", name: i18n.t("vehicleSeal:hmresd_un_sealed_by"), editor: <InputSearchEditor propName='employee' />, editable: true },
  { key: "hmresd_damaged_code", name: i18n.t("vehicleSeal:hmresd_damaged_code"), editor: <DropDownEditor propName="damageCode" /> }
]

class HelpOnReceiptSeal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      updatedRows: [],
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.save = this.save.bind(this)
    this.rowEdit = this.rowEdit.bind(this)
    this.buildQueryString = this.buildQueryString.bind(this)
    this.dropSelectedRows = this.dropSelectedRows.bind(this)
  }

  buildQueryString() {
    return `hmresd_exec_doc_no=${this.props.planNo}&status=${this.props.status}`
  }

  componentDidMount() {
    const { fetchReceiptSeal, damageCode, getQuickCodeMaster } = this.props
    if (damageCode.length === 0) {
      getQuickCodeMaster("damageCode");
    }
    fetchReceiptSeal(this.buildQueryString(), 1, 10)
  }

  save() {
    let { updatedRows } = this.state
    if (updatedRows.length > 0) {
      let isValid = true
      const seal = 'Please Enter Seal#'
      const unseal = 'Please Enter UnSealedby'
      const damageCode = 'Please Enter DamageCode'
      _.each(updatedRows, (row) => {
        if (!row.hmresd_un_seal_no || !row.hmresd_un_sealed_by || !row.hmresd_damaged_code) {
          isValid = false
          if (!isValid) {
            if (!row.hmresd_un_seal_no) {
              AlertError(seal)
            } else if (!row.hmresd_un_sealed_by) {
              AlertError(unseal)
            } else if (!row.hmresd_damaged_code) {
              AlertError(damageCode)
            }
            return false
          }
        }
      })
      if (isValid) {
        let hash = { data: updatedRows, hmresd_exec_doc_no: this.props.planNo }
        hash = _.merge(hash)
        this.props.saveReceiptDtl(hash)
        this.setState({ updatedRows: [] })
      }
    }
  }

  rowEdit(row, updateValue) {
    _.merge(row, updateValue)
    if (row && row.new === true) {
      let { updatedRows } = this.state
      if (updatedRows.length > 0) {
        const recordIndex = _.findIndex(updatedRows, (item) => item.id === row.id)
        if (recordIndex >= 0) {
          updatedRows[recordIndex] = row
        } else {
          updatedRows.push(row)
        }
      } else {
        updatedRows.push(row)
      }
      this.setState({ updatedRows })
    } else {
      const response = _.reduce(this.props.result, (arr, item) => {
        if (item.hmresd_seal_line_no === row.hmresd_seal_line_no) {
          _.merge(item, updateValue)
          arr.push(item)
        }
        return arr
      }, [])
      this.setState({ updatedRows: response })
    }
  }

  dropSelectedRows(rows) {
    const { deleteReceiptSeal } = this.props
    deleteReceiptSeal({ hmresd_seal_line_no: _.map(rows, 'hmresd_seal_line_no') })
  }

  changeLimit(pageNo, limit) {
    this.props.fetchReceiptSeal(this.buildQueryString(), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.fetchReceiptSeal(this.buildQueryString(), pageNo, limit);
  }

  render() {
    const { result, totalPage, totalRecord, initializeRS, t } = this.props
    const { updatedRows } = this.state
    const disabled = updatedRows.length > 0
    return (
      <div>
        <Grid stackable>
          <Grid.Row className="document_wrapper">
            <Grid.Column width={16} >
              <DataGrid
                rows={result}
                totalPages={totalPage}
                totalRecord={totalRecord}
                rowEdit={this.rowEdit}
                singleSelect={false}
                width={650}
                showSelectedCount={false}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                addRow={true}
                deleteRow={true}
                exportName='RS'
                initialize={initializeRS}
                dropSelectedRows={this.dropSelectedRows}
                columns={columns}
                removeColumnHeaderFormatter={true}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='save' type="button" className="primary btn-small btn-long" disabled={!disabled} onClick={this.save}> {t('saveBtn')}</button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}
HelpOnReceiptSeal = reduxForm({
  form: 'HelpOnReceiptSeal'
})(HelpOnReceiptSeal);

const mapStateToProps = state => ({
  formValues: state.form.HelpOnReceiptSeal,
  result: state.hubReceiptLoadReducer.receiptresult,
  totalPage: state.hubReceiptLoadReducer.totalPageLink,
  totalRecord: state.hubReceiptLoadReducer.totalRecordLink,
  isSaveRequested: state.hubReceiptLoadReducer.isSaveRequested,
  damageCode: state.masterReducer.options.damageCode,
})

const mapDispatchToProps = (dispatch) => ({
  fetchReceiptSeal: (queryString, pageNo, pageLimit) => dispatch(fetchReceiptSeal(queryString, pageNo, pageLimit)),
  initializeRS: () => dispatch(initializeRS()),
  saveReceiptDtl: (params) => dispatch(saveReceiptDtl(params)),
  deleteReceiptSeal: (params) => dispatch(deleteReceiptSeal(params)),
  getQuickCodeMaster: type => dispatch(masterActions.getQuickCodeMaster(type)),
})

export default compose(withTranslation('vehicleSeal'), connect(mapStateToProps, mapDispatchToProps))(HelpOnReceiptSeal);