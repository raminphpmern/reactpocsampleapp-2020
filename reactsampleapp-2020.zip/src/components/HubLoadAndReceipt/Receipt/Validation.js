import i18n from 'i18n';
import { formatDateTime } from 'lib/CommonHelper'
import { AlertError } from 'lib/Alert';

export default function Validation(values) {
  const errors = {};
  if (!values.hmreh_dock_id) {
    errors.hmreh_dock_id = i18n.t('hubReceiptvalidation:dockIdReq')
  }
  if (!values.hmreh_staging_id) {
    errors.hmreh_staging_id = i18n.t('hubReceiptvalidation:stageIdReq')
  }
  if (!values.wms_eqp_equipment_id) {
    errors.wms_eqp_equipment_id = i18n.t('hubReceiptvalidation:mheNoReq')
  }
  if (!values.hmreh_emp_id) {
    errors.hmreh_emp_id = i18n.t('hubReceiptvalidation:empReq')
  }
  if (!values.hmreh_start_date) {
    errors.hmreh_start_date = i18n.t('hubReceiptvalidation:startDateReq')
  }
  if (!values.hmreh_end_date) {
    errors.hmreh_end_date = i18n.t('hubReceiptvalidation:endDateReq')
  }
  if (!values.plpth_trip_plan_id) {
    errors.plpth_trip_plan_id = i18n.t('hubReceiptvalidation:tripIdReq')
  }
  if (values.hmreh_start_date && values.hmreh_end_date) {
    const startTime = formatDateTime(values.hmreh_start_date, false)
    const endTime = formatDateTime(values.hmreh_end_date, false)
    if (startTime > endTime) {
      AlertError(i18n.t('hubReceiptvalidation:endDateGreater'))
      errors.hmreh_end_date = i18n.t('hubReceiptvalidation:endDateGreater')
    }
  }
  return errors
}