import React, { Component } from "react";
import InputField from "components/Common/InputField";
import InputSearchField from "components/Common/InputSearchField";
import DateTimePicker from "components/Common/DateTimePicker";
import DropDown from "components/Common/Dropdown";
import { reduxForm, Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import { withTranslation } from 'react-i18next';
import * as hubReceiptLoadAction from "actions/hubReceiptLoadAction";
import { compose } from 'redux';
import { connect } from "react-redux";
import Popup from 'components/Common/Popup';
import HelpOnEmployee from "components/CollectionSummary/HelpOnEmployee";
import { SEARCH_WORD_COUNT } from "config";
import validate from "./Validation";
import { hubReceiptMergeData, hubReceiptHelper } from './Helper'
import { AlertSuccess, AlertError } from 'lib/Alert'
import i18n from 'i18n';
import _ from "lodash";
import HelpOnEquipment from "../Loading/HelpOnEquipment";

const printOptions = [
  { value: 'forwardingManifest', label: i18n.t("hubReceiptForm:forwardingManifest") },
  { value: 'ddrManifest', label: i18n.t("hubReceiptForm:ddrManifest") }
];

class ConfirmationDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      employeeHelp: false,
      equipmentHelp: false,
      currentHelp: '',
      enableButton: true,
      disbledCnfBtn: false,
      disableSaveBtn: false
    }
    this.toggle = this.toggle.bind(this)
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this);
    this.getEquipmentDetails = this.getEquipmentDetails.bind(this);
    this.saveReceiptRecords = this.saveReceiptRecords.bind(this);
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
    this.printBtnAction = this.printBtnAction.bind(this);
  }

  componentDidMount() {
    this.props.resetHeaderRecords()
  }

  printBtnAction() {
    AlertSuccess(i18n.t("hubReceiptForm:printAction"))
  }

  saveReceiptRecords() {
    const HubReceiptForm = this.props.HubReceiptForm.values
    const formValues = this.props.formValues.values
    const gridRecords = this.props.result
    let HubReceiptFormData = []
    if (HubReceiptForm && HubReceiptForm.hmreh_exec_doc_no) {
      HubReceiptFormData = HubReceiptForm
    } else {
      HubReceiptFormData = hubReceiptMergeData({ hmreh_exec_doc_no: "" }, this.props.HubReceiptForm.values)
    }
    const datas = Object.assign({}, { ...HubReceiptFormData }, { ...formValues }, { grid_details: gridRecords })
    this.props.saveReceiptRecords(hubReceiptHelper(datas))
  }

  confirmReceiptRecords() {
    const HubReceiptForm = this.props.HubReceiptForm.values
    const formValues = this.props.formValues.values
    const datas = Object.assign({}, { ...HubReceiptForm }, { ...formValues })
    if (HubReceiptForm.totalqty >= 1) {
      this.props.confirmReceiptRecords(hubReceiptHelper(datas))
    }
    else {
      AlertError(i18n.t("hubReceiptForm:nothingScanned"))
    }
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  getEmployeeDetails(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["hmreh_emp_id"] = data[0]["wms_emp_employee_code"]
      this.props.initialize(hash)
    }
  }

  getEquipmentDetails(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["wms_eqp_equipment_id"] = data[0]["wms_eqp_equipment_id"]
      this.props.initialize(hash)
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      let queryString1 = `bayType=DK&keyword=${value}`;
      let queryString2 = `bayType=STG&keyword=${value}`;
      if (fieldName === 'employee') {
        this.props.getFeildDetails("employee", queryString, fieldName);
      }
      if (fieldName === 'mhe') {
        this.props.getFeildDetails("mhe", queryString, fieldName);
      }
      if (fieldName === "dockid") {
        this.props.getFeildDetails("stageid", queryString1, fieldName);
      }
      if (fieldName === 'stageid') {
        this.props.getFeildDetails("stageid", queryString2, fieldName);
      }
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "employee") {
      hash["hmreh_emp_id"] = option.wms_emp_employee_code;
    }
    if (fieldName === "mhe") {
      hash["wms_eqp_equipment_id"] = option.wms_eqp_equipment_id;
    }
    if (fieldName === "stageid") {
      hash["hmreh_staging_id"] = option.wms_bay_id;
    }
    if (fieldName === "dockid") {
      hash["hmreh_dock_id"] = option.wms_bay_id;
    }
    this.props.initialize(hash);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.HubReceiptForm && nextProps.HubReceiptForm.values) {
      const HubReceiptForm = nextProps.HubReceiptForm
      if (HubReceiptForm.values.plpth_trip_plan_id) {
        this.setState({ enableButton: false })
      }
      else if (!HubReceiptForm.values.plpth_trip_plan_id) {
        this.setState({ enableButton: true })
      }
      if (this.props.formValues && this.props.formValues.values && this.props.formValues.values.hmreh_exec_status !== "Confirmed") {
        this.setState({ disbledCnfBtn: false })
        this.setState({ disableSaveBtn: false })
      }
      if (HubReceiptForm.values.hmreh_exec_status === "Confirmed") {
        this.setState({ disbledCnfBtn: true })
      }
      if (HubReceiptForm.values.hmreh_exec_status === "Draft") {
        this.setState({ disableSaveBtn: true })
      }
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.headerResult !== null) {
      if (this.props.headerResult[0] !== undefined) {
        if (prevProps.headerResult !== this.props.headerResult && this.props.headerResult.length !== 0) {
          const header = this.props.headerResult[0]
          this.props.initialize({ hmreh_dock_id: header.hmreh_dock_id, hmreh_staging_id: header.hmreh_staging_id, hmreh_emp_id: header.hmreh_emp_id, wms_eqp_equipment_id: header.hmreh_mhe_id, hmreh_start_date: header.hmreh_start_date, hmreh_end_date: header.hmreh_end_date, hmreh_remarks: header.hmreh_remarks })
        }
      }
    }
    if (prevProps.headerResult !== this.props.headerResult && this.props.headerResult.length === 0) {
      this.props.initialize()
    }
  }

  formSubmit() {
    // TODO: This has been left blank to handle multiple submit buttons. Later may enable for enter key
  }

  render() {
    const { invalid, handleSubmit, employee, mhe, stageid, t } = this.props;
    const { currentHelp, employeeHelp, equipmentHelp, enableButton, disbledCnfBtn, disableSaveBtn } = this.state;
    return (
      <div className="dispatch">

        <Popup size="fullscreen" open={employeeHelp} close={() => { this.toggle('help', 'employeeHelp') }} header={t('helpOnEmployee')} description={<HelpOnEmployee
          getEmployeeDetails={this.getEmployeeDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={equipmentHelp} close={() => { this.toggle('help', 'equipmentHelp') }} header={t('helpOnEquipment')} description={<HelpOnEquipment getEquipmentDetails={this.getEquipmentDetails} close={this.toggle} name={currentHelp} />} />

        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="hmreh_dock_id"
                  component={InputSearchField}
                  label={t('dockId')}
                  required={true}
                  findByCompanyAndFLMName={this.search}
                  id="dockid"
                  options={stageid}
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmreh_staging_id"
                  component={InputSearchField}
                  label={t('stageId')}
                  required={true}
                  findByCompanyAndFLMName={this.search}
                  id="stageid"
                  options={stageid}
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmreh_emp_id"
                  component={InputSearchField}
                  label={t('employeeId')}
                  iconName="search"
                  handleClick={this.toggle}
                  required={true}
                  childName="employeeHelp"
                  findByCompanyAndFLMName={this.search}
                  id="employee"
                  options={employee}
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="additional-employee">
                  <Popup size="fullscreen" trigger={<button type="button" className="link-button" disabled={true}>
                    {t('additionalEmployee')}</button>} />
                </div>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="wms_eqp_equipment_id"
                  component={InputSearchField}
                  label={t('mhe')}
                  iconName="search"
                  required={true}
                  findByCompanyAndFLMName={this.search}
                  id="mhe"
                  options={mhe}
                  fillNameValues={this.setValue}
                  handleClick={this.toggle}
                  childName="equipmentHelp"
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmreh_start_date"
                  component={DateTimePicker}
                  showTimeSelect={true}
                  timeIntervals={1}
                  min={new Date()}
                  label={t('startDateTime')}
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmreh_end_date"
                  component={DateTimePicker}
                  showTimeSelect={true}
                  timeIntervals={1}
                  label={t('endDateTime')}
                  min={new Date()}
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmreh_remarks"
                  component={InputField}
                  label={t('remarks')}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row >
              <Grid.Column width={5} />
              <Grid.Column width={5}>
                <div className="hub-load-print-options">
                  <Field
                    name="check_print_options"
                    component={DropDown}
                    options={printOptions}
                    placeholder={t('printOptionPlaceHolder')}
                  />
                </div>
              </Grid.Column>
              <Grid.Column>
                <div className="hub-load-print-button">
                  <button id='save' type='button' className="primary" onClick={() => this.printBtnAction()}>
                    {t('printBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row />
            <Grid.Row />
            <Grid.Row className="create-buttons">
              <Grid.Column width={7}>
                <div className="assign-button-right">
                  <button id='save' type='button'
                    onClick={() => this.saveReceiptRecords()}
                    className="primary" disabled={invalid || enableButton || disbledCnfBtn || disableSaveBtn}>
                    {t('saveBtn')}
                  </button>
                </div>
              </Grid.Column>
              <Grid.Column >
                <div className="text-center">
                  <button id='confirm' type="button" onClick={() => this.confirmReceiptRecords()} className="secondary" disabled={invalid || enableButton || disbledCnfBtn || !disableSaveBtn}>
                    {t('confirmBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div >
    );
  }
}
ConfirmationDetails = reduxForm({
  form: "ConfirmationDetailsForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate
})(ConfirmationDetails);

const mapDispatchToProps = (dispatch) => ({
  saveReceiptRecords: (params) =>
    dispatch(hubReceiptLoadAction.saveReceiptRecords('save', params)),
  confirmReceiptRecords: (params) =>
    dispatch(hubReceiptLoadAction.saveReceiptRecords('confirm', params)),
  getFeildDetails: (action, queryStr) =>
    dispatch(hubReceiptLoadAction.getReceiptFieldDetails(action, queryStr)),
  resetHeaderRecords: () => dispatch(hubReceiptLoadAction.resetHeaderRecords()),
})

const mapStateToProps = state => ({
  HubReceiptForm: state.form.HubReceiptForm,
  formValues: state.form.ConfirmationDetailsForm,
  employee: state.hubReceiptLoadReducer.options.employee,
  headerResult: state.hubReceiptLoadReducer.receiptHeaderResult,
  mhe: state.hubReceiptLoadReducer.options.mhe,
  stageid: state.hubReceiptLoadReducer.options.stageid,
  result: state.hubReceiptLoadReducer.gridReceiptResult
});

export default compose(withTranslation('hubReceiptForm'), connect(mapStateToProps, mapDispatchToProps))(ConfirmationDetails);