import React from 'react';
import Wrapper from "components/LandingPage/Wrapper";
import HubReceipt from './HubReceipt';
import Result from "./Result";
import { Icon } from 'semantic-ui-react';
import { withTranslation } from 'react-i18next';

const HubReceiptForm = (props) => {
  const { t } = props;
  return (
    <Wrapper DisableBranch={true}>
      <div className="hub-loading-head">
        <h3>{t('title')}</h3>
        <div className="back-link">
          <a href="javascript: false" onClick={props.history.goBack}>
            <Icon disabled name='arrow left' />
            {t('translation:back')}</a>
        </div>
      </div>
      <div className="load-receipt-result-part">
        <HubReceipt />
      </div>
      <div className="load-receipt-result-part">
        <Result />
      </div>
    </Wrapper>
  )
}

export default withTranslation('hubReceiptForm')(HubReceiptForm)