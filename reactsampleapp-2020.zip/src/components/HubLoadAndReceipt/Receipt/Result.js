import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { columns } from "./Helper";
import { connect } from "react-redux";
import * as hubReceiptLoadAction from "actions/hubReceiptLoadAction";
import ConfirmationDetails from "./ConfirmationDetails";
import { AlertError } from "lib/Alert";
import i18n from 'i18n';
import _ from 'lodash';

class Result extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selectedIds: null,
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.onUpdateRow = this.onUpdateRow.bind(this)
    this.deleteSelectedRecords = this.deleteSelectedRecords.bind(this)
  }

  changeLimit(pageNo, limit) {
    const plpth_trip_plan_id = this.props.HubReceiptForm.values.plpth_trip_plan_id
    this.props.getTripDataReceipt({ plpth_trip_plan_id: plpth_trip_plan_id }, pageNo, limit)
  }

  paginationHandler(pageNo, limit) {
    const plpth_trip_plan_id = this.props.HubReceiptForm.values.plpth_trip_plan_id
    this.props.getTripDataReceipt({ plpth_trip_plan_id: plpth_trip_plan_id }, pageNo, limit)
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  onUpdateRow(row, updateValue) {
    this.props.updateRow(row, updateValue)
    const response = _.reduce(this.state.selectedIds, (arr, item) => {
      if (item.dispatch_doc_no === row.dispatch_doc_no) {
        _.merge(item, updateValue)
      }
      arr.push(item)
      return arr
    }, [])
    this.setState({ selectedIds: response })
  }

  deleteSelectedRecords(rows) {
    const { deleteHubReceiptRecords, HubReceiptForm } = this.props
    if (HubReceiptForm.values.hmreh_exec_status !== "Confirmed") {
      deleteHubReceiptRecords({
        hmreh_exec_doc_no: HubReceiptForm.values.hmreh_exec_doc_no,
        ddh_dispatch_doc_no: _.map(rows, 'ddh_dispatch_doc_no'),
        data: rows, form: "HubReceipt"
      })
    }
    else {
      AlertError(i18n.t('hubReceiptvalidation:alreadyConfirmed'))
    }
  }

  render() {
    const { result, totalPage, totalRecord, resetData } = this.props
    return (
      <div>
        <Grid stackable >
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  columns={columns}
                  width={250}
                  rows={result}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  selectedRows={this.selectedRows}
                  enableExport={true}
                  initialize={resetData}
                  rowEdit={this.onUpdateRow}
                  showCheckbox={true}
                  deleteRow={true}
                  dropSelectedRows={this.deleteSelectedRecords}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <ConfirmationDetails selectedRecords={this.state.selectedIds} />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  getTripDataReceipt: (data, pageNo, limit) =>
    dispatch(hubReceiptLoadAction.getTripDataReceipt(data, pageNo, limit)),
  resetData: () =>
    dispatch(hubReceiptLoadAction.resetTripDataRecords()),
  updateRow: (row, updateValue) =>
    dispatch(hubReceiptLoadAction.updateReceiptRow(row, updateValue)),
  deleteHubReceiptRecords: (params) =>
    dispatch(hubReceiptLoadAction.deleteHrRecords(params))
})

const mapStateToProps = state => ({
  result: state.hubReceiptLoadReducer.gridReceiptResult,
  totalPage: state.hubReceiptLoadReducer.totalPage,
  totalRecord: state.hubReceiptLoadReducer.totalRecord,
  HubReceiptForm: state.form.HubReceiptForm,
})

export default connect(mapStateToProps, mapDispatchToProps)(Result)