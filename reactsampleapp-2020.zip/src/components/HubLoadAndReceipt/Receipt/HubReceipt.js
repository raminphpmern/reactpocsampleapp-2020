import React, { Component } from "react";
import InputField from "components/Common/InputField";
import { reduxForm, Field } from "redux-form";
import InputSearchField from "components/Common/InputSearchField";
import DropDown from "components/Common/Dropdown";
import DateTimePicker from "components/Common/DateTimePicker";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import Popup from "components/Common/Popup";
import HelpOnTripPlan from "components/Dispatch/DispatchCreate/HelpOnTripPlan";
import HelpOnEmployee from "components/CollectionSummary/HelpOnEmployee";
import * as hubReceiptLoadAction from "actions/hubReceiptLoadAction";
import { helpOnTripPlanByID } from "actions/dispatchHelpAction";
import { loadSelectedTripCode, loadSelectedTripCodeByID, hubReceiptMergeData } from "./Helper";
import HelpOnEquipment from "../Loading/HelpOnEquipment";
import { SEARCH_WORD_COUNT } from "config";
import { withTranslation } from 'react-i18next';
import validate from "./Validation";
import { compose } from 'redux';
import "../HubLoadingReceipt.css";
import _ from "lodash";
import HelpOnReceiptSeal from "./HelpOnReceiptSeal";
import HelpOnVehicle from "components/TripHub/HelpOnVehicle";
import HelpOnCarrier from "components/TripHub/HelpOnCarrier";
import { getQuickCodeMaster } from "actions/masterAction";

class HubReceipt extends Component {
  constructor(props) {
    super(props)
    this.state = {
      tripHelp: false,
      tripLogEnterKey: false,
      employeeHelp: false,
      vehicleHelp: false,
      carrierHelp: false,
      currentHelp: '',
      isExitingTrip: false,
      vehicleSealDsbl: true,
      equipmentHelp: false,
      enableScan: false,
      receiptStatus: '',
      receiptPlanNo: ''
    }
    this.toggle = this.toggle.bind(this)
    this.selectTripId = this.selectTripId.bind(this);
    this.toggleEnterKey = this.toggleEnterKey.bind(this);
    this.search = this.search.bind(this);
    this.setValue = this.setValue.bind(this);
    this.loadTripLogById = this.loadTripLogById.bind(this);
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this);
    this.getEquipmentDetails = this.getEquipmentDetails.bind(this);
    this.getVehicleDetails = this.getVehicleDetails.bind(this);
    this.getCarrierDetails = this.getCarrierDetails.bind(this);
  }

  componentDidMount() {
    this.props.resetHeaderRecords()
    const {
      currentUser,
      current_location,
      getQuickCodeMaster
    } = this.props
    if (current_location.length === 0) {
      getQuickCodeMaster("current_location")
    }
    const locations = (currentUser && currentUser.locations) || [];
    if (locations.length > 0) {
      this.props.initialize({ location: locations[0].value, division: locations[0].wms_loc_code });
    }
    let _self = this;
    let enterKeyElement = document.getElementById('plpth_trip_plan_id')
    enterKeyElement.addEventListener('keypress', (event) => {
      _self.toggleEnterKey(false)
      if (event.keyCode === 13) {
        _self.toggleEnterKey(true)
        let tripLogID = _self.props.formValues && _self.props.formValues.values
        let checkTripID = tripLogID["plpth_trip_plan_id"]
        if (checkTripID && checkTripID.length >= SEARCH_WORD_COUNT) {
          _self.props.getTripLogIdGridDetails({ plpth_trip_plan_id: tripLogID.plpth_trip_plan_id }, '1', '10')
          _self.props.getTripLogIdDetails({ plpth_trip_plan_id: tripLogID.plpth_trip_plan_id }, '1', '10')
        }
        event.preventDefault()
      }
    })
    let enterOfDispDocNumber = document.getElementById('ddh_dispatch_doc_no')
    enterOfDispDocNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let plpth_trip_plan_id = formValues["plpth_trip_plan_id"]
        let loadGridRecords = formValues["ddh_dispatch_doc_no"].trim()
        let hmreh_exec_doc_no = formValues["hmreh_exec_doc_no"]
        let grid_details = _self.props.gridResult
        if (loadGridRecords && loadGridRecords.length >= SEARCH_WORD_COUNT) {
          _self.props.loadGridRecords({ plpth_trip_plan_id: plpth_trip_plan_id, ddh_dispatch_doc_no: loadGridRecords, planNo: hmreh_exec_doc_no, grid_details: grid_details })
        }
        event.preventDefault()
      }
    })
    let enterOfSerialNumber = document.getElementById('ddtsd_thu_serial_no')
    enterOfSerialNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let loadGridRecords = formValues["ddtsd_thu_serial_no"].trim()
        let plpth_trip_plan_id = formValues["plpth_trip_plan_id"]
        let hmreh_exec_doc_no = formValues["hmreh_exec_doc_no"]
        let ddh_dispatch_doc_no = ""
        if (formValues["ddh_dispatch_doc_no"] !== '') {
          ddh_dispatch_doc_no = formValues["ddh_dispatch_doc_no"]
        }
        if (formValues["ddh_dispatch_doc_no"] === undefined) {
          ddh_dispatch_doc_no = ""
        }
        let grid_details = _self.props.gridResult
        if (loadGridRecords && loadGridRecords.length >= SEARCH_WORD_COUNT) {
          _self.props.loadGridRecords({ plpth_trip_plan_id: plpth_trip_plan_id, ddtsd_thu_serial_no: loadGridRecords, planNo: hmreh_exec_doc_no, grid_details: grid_details, ddh_dispatch_doc_no: ddh_dispatch_doc_no })
        }
        event.preventDefault()
      }
    })
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  toggleEnterKey(toggleEnterState) {
    this.setState({ tripLogEnterKey: toggleEnterState })
    this.setState({ isExitingTrip: toggleEnterState })
  }

  selectTripId(selectedTripId) {
    if (selectedTripId) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(loadSelectedTripCode(selectedTripId, hash))
      this.setState({ isExitingTrip: true })
    }
  }

  loadTripLogById(selectedTripId) {
    const { tripLogEnterKey } = this.state
    if (tripLogEnterKey) {
      let hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(loadSelectedTripCodeByID(selectedTripId, hash))
    }
  }

  getEmployeeDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["plpth_driver_id"] = data[0]["wms_emp_employee_code"]
      this.props.initialize(hash)
    }
  }

  getEquipmentDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["plpth_equipment_id"] = data[0]["wms_eqp_equipment_id"]
      this.props.initialize(hash)
    }
  }

  getVehicleDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["plpth_vehicle_id"] = data[0]["wms_veh_id"]
      this.props.initialize(hash)
    }
  }

  getCarrierDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["plpth_agent_id"] = data[0]["wms_vendor_id"]
      this.props.initialize(hash)
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === 'employee') {
        this.props.getFeildDetails("employee", queryString, fieldName);
      }
      if (fieldName === 'equipmentId') {
        this.props.getFeildDetails("mhe", queryString, fieldName);
      }
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "employee") {
      hash["plpth_driver_id"] = option.wms_emp_employee_code;
    }
    if (fieldName === "equipmentId") {
      hash["plpth_equipment_id"] = option.wms_eqp_equipment_id;
    }
    this.props.initialize(hash);
  }

  componentDidUpdate(prevProps) {
    const { getTripLogData, headerResult, receipt_cbm } = this.props
    if (getTripLogData.length > 0) {
      this.loadTripLogById(getTripLogData[0])
    }
    if (prevProps.headerResult !== this.props.headerResult && this.props.headerResult.length === 0 && this.props.receipt_cbm && this.props.receipt_cbm.length === 0) {
      const hash = _.cloneDeep(this.props.formValues.values)
      this.props.initialize(hubReceiptMergeData({ hmreh_exec_doc_no: '', hmreh_exec_status: '', totalvolume: '', totalweight: '', totalqty: '', ddtsd_thu_serial_no: '', ddh_dispatch_doc_no: '' }, hash))
      this.setState({ enableScan: false })
      if (getTripLogData.length === 0) {
        const hash = _.cloneDeep(this.props.formValues.values && this.props.formValues.values.plpth_trip_plan_id)
        this.props.initialize({ plpth_trip_plan_id: hash })
        this.setState({ isExitingTrip: false, vehicleSealDsbl: true })
      }
    }
    if (this.props.load_response !== null) {
      if (this.props.load_response !== prevProps.load_response) {
        const hash = _.cloneDeep(prevProps.formValues.values)
        this.props.initialize(hubReceiptMergeData(this.props.load_response, hash));
        if (this.props.load_response.hmreh_exec_status === "Draft") {
          this.setState({ enableScan: true })
        }
        if (this.props.load_response.hmreh_exec_status === "Confirmed") {
          this.setState({ enableScan: false })
        }
      }
    }
    if (receipt_cbm && receipt_cbm.length !== 0) {
      if (this.props.receipt_cbm !== prevProps.receipt_cbm) {
        const cbm = receipt_cbm[0];
        const hash = _.cloneDeep(this.props.formValues.values)
        this.props.initialize(hubReceiptMergeData({ totalvolume: cbm.totalvolume, totalweight: cbm.totalweight, totalqty: cbm.totalqty }, hash));
      }
    }
    if (headerResult && headerResult.length !== 0) {
      if (this.props.headerResult !== prevProps.headerResult) {
        const header = this.props.headerResult[0]
        let cbm = [];
        if (receipt_cbm && receipt_cbm.length !== 0) {
          cbm = receipt_cbm[0];
        }
        const hash = _.cloneDeep(prevProps.formValues.values)
        this.props.initialize(hubReceiptMergeData({ hmreh_exec_doc_no: header.hmreh_exec_doc_no, hmreh_exec_status: header.hmreh_exec_status, totalvolume: cbm.totalvolume, totalweight: cbm.totalweight, totalqty: cbm.totalqty, plpth_agent_id: header.plpth_agent_id, plpth_driver_id: header.plpth_driver_id, plpth_equipment_id: header.plpth_equipment_id, mawb_mbl_no: header.plpth_mawb_mbl, reasonCode: header.plpth_reason_code, plpth_schedule_id: header.plpth_schedule_no, plpth_vehicle_id: header.plpth_vehicle_id, vessel_name: header.plpth_vessel_flight_name, vessel_no: header.plpth_voyage_flight_no, origin_Location: header.from_loc, arrival_date_Time: header.arrived_date, depart_date_Time: header.departed_date, handed_over_date_Time: header.handed_over_date }, hash))
      }
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.hmreh_exec_status === "Draft") {
      this.setState({ enableScan: true })
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.hmreh_exec_status) {
      this.setState({ receiptStatus: nextProps.formValues.values.hmreh_exec_status, receiptPlanNo: nextProps.formValues.values.hmreh_exec_doc_no })
    }
    if (nextProps.formValues && nextProps.formValues.values) {
      if (nextProps.formValues.values.hmreh_exec_doc_no) {
        this.setState({ vehicleSealDsbl: false, isExitingTrip: true })
      }
      else {
        this.setState({ vehicleSealDsbl: true, isExitingTrip: false })
      }
    }
  }

  formSubmit() {
    // TODO: This has been left blank to handle multiple submit buttons. Later may enable for enter key
  }

  render() {
    const { handleSubmit, t, employee, mhe, current_location } = this.props
    const { tripHelp, currentHelp, employeeHelp, equipmentHelp, isExitingTrip, enableScan, receiptPlanNo, receiptStatus, vehicleSealDsbl, vehicleHelp, carrierHelp } = this.state
    return (
      <div className="hub-loading">
        <Popup size="fullscreen" open={tripHelp} close={() => { this.toggle('help', 'tripHelp') }}
          header={t('helponTripPlan')} description={<HelpOnTripPlan
            handleOnSelect={this.selectTripId} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={equipmentHelp} close={() => { this.toggle('help', 'equipmentHelp') }} header={t('helpOnEquipment')} description={<HelpOnEquipment getEquipmentDetails={this.getEquipmentDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={employeeHelp} close={() => { this.toggle('help', 'employeeHelp') }} header={t('helpOnEmployee')} description={<HelpOnEmployee
          getEmployeeDetails={this.getEmployeeDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={vehicleHelp} close={() => { this.toggle('help', 'vehicleHelp') }}
          header={t('helpOnVehicle')} description={<HelpOnVehicle
            getVehicleDetails={this.getVehicleDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={carrierHelp} close={() => { this.toggle("help", "carrierHelp") }}
          header={t('helpOnAgent')} description={<HelpOnCarrier
            getCarrierDetails={this.getCarrierDetails} close={this.toggle} name={currentHelp} />
          }
        />

        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="plpth_trip_plan_id"
                  component={InputField}
                  label={t('tripId')}
                  iconName="search"
                  handleClick={this.toggle}
                  childName="tripHelp"
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="receipt-seal">
                  <Popup size="fullscreen" header="Vehicle Seal" description={<HelpOnReceiptSeal planNo={receiptPlanNo} status={receiptStatus} />} trigger={<button type="button" className="link-button" disabled={vehicleSealDsbl}>
                    Vehicle Seal </button>} />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmreh_exec_doc_no"
                  component={InputField}
                  readOnly={true}
                  label={t('hubReceiptPlanNo')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmreh_exec_status"
                  component={InputField}
                  label={t('status')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="plpth_driver_id"
                  component={InputSearchField}
                  label={t('driverId')}
                  iconName="search"
                  handleClick={this.toggle}
                  childName="employeeHelp"
                  readOnly={isExitingTrip}
                  findByCompanyAndFLMName={this.search}
                  id="employee"
                  options={employee}
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_vehicle_id"
                  component={InputField}
                  label={t('vehicleId')}
                  iconName="search"
                  readOnly={isExitingTrip}
                  handleClick={this.toggle}
                  childName="vehicleHelp"
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_equipment_id"
                  component={InputSearchField}
                  label={t('equipmentId')}
                  iconName="search"
                  readOnly={isExitingTrip}
                  childName='equipmentHelp'
                  handleClick={this.toggle}
                  findByCompanyAndFLMName={this.search}
                  options={mhe}
                  id="equipmentId"
                  fillNameValues={this.setValue}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="plpth_agent_id"
                  component={InputField}
                  label={t('agentId')}
                  iconName="search"
                  readOnly={isExitingTrip}
                  handleClick={this.toggle}
                  childName="carrierHelp"
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="origin_Location"
                  component={isExitingTrip ? InputField : DropDown}
                  options={current_location}
                  label={t('originLocation')}
                  readOnly={isExitingTrip}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="arrival_date_Time"
                  component={DateTimePicker}
                  showTimeSelect={true}
                  timeIntervals={1}
                  max={new Date()}
                  label={t('arrival')}
                  disabled={isExitingTrip}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="handed_over_date_Time"
                  component={DateTimePicker}
                  label={t('handedOver')}
                  showTimeSelect={true}
                  timeIntervals={1}
                  max={new Date()}
                  disabled={isExitingTrip}
                />
              </Grid.Column>
              <Grid.Column width={4} className="depart_date">
                <Field
                  name="depart_date_Time"
                  component={DateTimePicker}
                  label={t('depart')}
                  showTimeSelect={true}
                  timeIntervals={1}
                  max={new Date()}
                  disabled={isExitingTrip}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="plpth_schedule_id"
                  component={InputField}
                  label={t('scheduleNo')}
                  readOnly={isExitingTrip}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="vessel_no"
                  component={InputField}
                  label={t('vesselNo')}
                  readOnly={isExitingTrip}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="vessel_name"
                  component={InputField}
                  label={t('vesselName')}
                  readOnly={isExitingTrip}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="mawb_mbl_no"
                  component={InputField}
                  label={t('MAWB/MBL')}
                  readOnly={isExitingTrip}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={12} />
              <Grid.Column width={4}>
                <Field
                  name="reasonCode"
                  component={InputField}
                  label={t('reasonCode')}
                  readOnly={isExitingTrip}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column className="hub-load-receipt">
                <h6 className="custom-title">
                  <span>{t('subtitle')}</span>
                </h6>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_no"
                  component={InputField}
                  label={t('dispatchDocument')}
                  readOnly={!enableScan}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ddtsd_thu_serial_no"
                  component={InputField}
                  label={t('thuSerialNo')}
                  readOnly={!enableScan}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="totalqty"
                  component={InputField}
                  readOnly={true}
                  label={t('totalQuantity')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="totalvolume"
                  component={InputField}
                  readOnly={true}
                  label={t('totalVolume')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="totalweight"
                  component={InputField}
                  readOnly={true}
                  label={t('totalWeight')}
                />
              </Grid.Column>
              <Grid.Column width={4} />
            </Grid.Row>
          </Grid>
        </form>
      </div >
    );
  }
}
HubReceipt = reduxForm({
  form: "HubReceiptForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate
})(HubReceipt);

const mapDispatchToProps = (dispatch) => ({
  getTripLogIdGridDetails: (tripLogID, pageNo, limit) =>
    dispatch(helpOnTripPlanByID(tripLogID, pageNo, limit)),
  getQuickCodeMaster: type =>
    dispatch(getQuickCodeMaster(type, "")),
  getTripLogIdDetails: (tripLogID, pageNo, limit) =>
    dispatch(hubReceiptLoadAction.getTripDataReceipt(tripLogID, pageNo, limit)),
  loadGridRecords: (params) =>
    dispatch(hubReceiptLoadAction.saveReceiptRecords('dispatch', params)),
  getFeildDetails: (action, queryStr) =>
    dispatch(hubReceiptLoadAction.getReceiptFieldDetails(action, queryStr)),
  resetHeaderRecords: () => dispatch(hubReceiptLoadAction.resetHeaderRecords()),
})

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
  formValues: state.form.HubReceiptForm,
  getTripLogData: state.dispatchReducer.result_help_trip_by_id,
  load_response: state.hubReceiptLoadReducer.load_response,
  receipt_cbm: state.hubReceiptLoadReducer.receipt_cbm,
  employee: state.hubReceiptLoadReducer.options.employee,
  mhe: state.hubReceiptLoadReducer.options.mhe,
  headerResult: state.hubReceiptLoadReducer.receiptHeaderResult,
  gridResult: state.hubReceiptLoadReducer.gridReceiptResult,
  status: state.hubReceiptLoadReducer.status,
  current_location: state.masterReducer.options.current_location
});

export default compose(withTranslation('hubReceiptForm'), connect(mapStateToProps, mapDispatchToProps))(HubReceipt);