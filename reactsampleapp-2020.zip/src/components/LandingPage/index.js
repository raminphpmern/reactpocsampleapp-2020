import React, { Component } from 'react';
import { connect } from 'react-redux';
import history from 'routes/history';
import Wrapper from './Wrapper'
import { Link } from 'react-router-dom';
import { updateStep } from 'actions/bookingActions';
import './landing.css';
import { getValue } from 'lib/LocalStorage';

class LandingPage extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selectedBox: ''
    }

    this.setClass = this.setClass.bind(this)
  }
  selectOption(redirectTo) {
    history.push(redirectTo.value);
    const step = this.props.currentStep || getValue('currentStep')
    this.props.updateStep(step)
  }

  setClass(boxName) {
    this.setState({ selectedBox: boxName })
  }

  render() {
    const { selectedBox } = this.state

    return (
      <Wrapper DisableBranch={false}>
        <div className="landing-wrapper">
          <div className={`landing-box ${selectedBox === 'booking' ? 'selected ' : ''}`}>
            <p>Booking</p>
            <div className="pillChild">
              <Link to="/acceptance" tabIndex="1" onFocus={() => this.setClass('booking')}>Booking Request</Link>
              <Link to="/brhub" tabIndex="2" onFocus={() => this.setClass('booking')}>BR Hub</Link>
              <Link to="/collections" tabIndex="3" onFocus={() => this.setClass('booking')}>Collections Summary</Link>
              <Link to="/dispatchDocument/hub" tabIndex="4" onFocus={() => this.setClass('booking')}>Dispatch Document</Link>
            </div>
          </div>

          <div className={`landing-box ${selectedBox === 'execution' ? 'selected ' : ''}`}>
            <Link to="/" tabIndex="5" onFocus={() => this.setClass('execution')}>Execution</Link>
            <div className="pillChild">
              <Link to="/tripHub" tabIndex="6" onFocus={() => this.setClass('execution')}>Trip Hub</Link>
            </div>
          </div>

          <div className={`landing-box ${selectedBox === 'hub' ? 'selected ' : ''}`}>
            <Link to="/" tabIndex="7" onFocus={() => this.setClass('hub')}>Hub Management</Link>
            <div className="pillChild">
              <Link to="/thuInventory" tabIndex="8" onFocus={() => this.setClass('hub')}>ETHU Inventory</Link>
              <Link to="/inventoryHub" tabIndex="8" onFocus={() => this.setClass('hub')}>Hub Inventory</Link>
              <Link to="/hub/loading" tabIndex="9" onFocus={() => this.setClass('hub')}>Hub Loading</Link>
              <Link to="/hub/receipt" tabIndex="10" onFocus={() => this.setClass('hub')}>Hub Receipt</Link>
              <Link to="/hub/bayTransfer" tabIndex="11" onFocus={() => this.setClass('hub')}>Bay Transfer</Link>
              <Link to="/hub/freightConversion" tabIndex="12" onFocus={() => this.setClass('hub')}>Freight Conversion</Link>
            </div>
          </div>
          <div className={`landing-box ${selectedBox === 'utilities' ? 'selected ' : ''}`}>
            <Link to="/utilities" tabIndex="14" onFocus={() => this.setClass('utilities')}>Utilities</Link>
          </div>
        </div>
      </Wrapper>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  updateStep: (step) => dispatch(updateStep(step)),
});

const mapStateToProps = state => ({
  currentStep: state.bookingReducer.currentStep,
})

export default connect(mapStateToProps, mapDispatchToProps)(LandingPage)
