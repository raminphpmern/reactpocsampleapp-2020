import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { userLogout } from 'actions/loginAction';
import { connect } from 'react-redux';
import Header from 'components/Header'
import { removeKey } from 'lib/LocalStorage'
import * as bookingActions from 'actions/bookingActions';
import { isMobile } from 'config'
import { getValue } from "lib/LocalStorage";
import { Spinner } from 'react-redux-spinner';
import 'react-redux-spinner/dist/react-redux-spinner.css';
import { socket } from 'components/Header'


class Wrapper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentBranch: {},
    };
    this.setCurrentLocation = this.setCurrentLocation.bind(this)
  }

  changeUser() {
    removeKey('orders')
    removeKey('charges')
    removeKey('br_id')
    this.props.logout()
    this.props.initializeBooking()

    socket.emit('close', window._env_.LOCATION_ID);
    socket.disconnect()
  }

  componentDidMount() {
    const currentBranch = getValue("currentBranch");
    if (currentBranch) {
      this.setState({ currentBranch: JSON.parse(currentBranch) })
    }
  }

  setCurrentLocation(data) {
    this.setState({ currentBranch: data })
  }

  render() {
    const { currentUser, DisableBranch } = this.props
    const { currentBranch } = this.state
    return (
      <div>
        <Spinner config={{ showSpinner: false }} />
        <Header DisableBranch={DisableBranch} setCurrentLocation={this.setCurrentLocation} />
        {this.props.children}
        {!isMobile && <div className="landing-footer">
          <div>
            <span>Serial<strong id='serial-no'>{currentUser && currentUser.system && currentUser.system.serial}</strong></span>
            <span>Permit<strong>{currentBranch.PERMIT}</strong></span>
            <span>Min<strong>{currentBranch.MIN}</strong></span>
            <span>Tin<strong>{currentBranch.TIN}</strong></span>
            <span>Associate<strong>{currentUser && currentUser.fullname}</strong></span>
            <span>Sync<strong>{currentUser && currentUser.lastSyncDate}</strong></span>
          </div>
          <div className="logout">
            {currentUser && currentUser.loggedIn &&
              <Link to="/login" className="change-user" onClick={() => this.changeUser()}>Logout</Link>
            }
          </div>
        </div>}
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  logout: () => dispatch(userLogout()),
  initializeBooking: () => dispatch(bookingActions.initializeBooking())
})

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user
})

export default connect(mapStateToProps, mapDispatchToProps)(Wrapper)
