import _ from 'lodash';

export function fcHelper(data, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  _.merge(tempHash, data)
  return tempHash
}

export function fcRecordsHelper(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["hmfch_fc_exec_type"]) {
      if (hash["hmfch_fc_exec_type"].value == 'consolidation') {
        hash["hmfch_fc_exec_type"] = 'CON'
      }
      if (hash["hmfch_fc_exec_type"].value == 'deconsolidation') {
        hash["hmfch_fc_exec_type"] = 'DCON'
      }
    }
    return hash
  } else {
    return {}
  }
}