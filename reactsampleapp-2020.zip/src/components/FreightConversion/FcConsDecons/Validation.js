import i18n from 'i18n';
import { formatDateTime } from 'lib/CommonHelper'
import { AlertError } from 'lib/Alert';

export default function Validation(values) {
  const errors = {};
  if (!values.hmfch_fc_exec_type) {
    errors.hmfch_fc_exec_type = i18n.t('fcValidation:fcTypeReq')
  }
  if (!values.hmfch_emp_id) {
    errors.hmfch_emp_id = i18n.t('fcValidation:empIdReq')
  }
  if (!values.hmfch_mhe_id) {
    errors.hmfch_mhe_id = i18n.t('fcValidation:mheNoReq')
  }
  if (!values.hmfch_start_date) {
    errors.hmfch_start_date = i18n.t('fcValidation:startDateReq')
  }
  if (!values.hmfch_end_date) {
    errors.hmfch_end_date = i18n.t('fcValidation:endDateReq')
  }
  if (!values.hmfch_fc_bay_id) {
    errors.hmfch_fc_bay_id = i18n.t('fcValidation:fcBayReq')
  }
  if (!values.hmfch_to_bay_id) {
    errors.hmfch_to_bay_id = i18n.t('fcValidation:toBayReq')
  }
  if (values.hmfch_start_date && values.hmfch_end_date) {
    const startTime = formatDateTime(values.hmfch_start_date, false)
    const endTime = formatDateTime(values.hmfch_end_date, false)
    if (startTime > endTime) {
      AlertError(i18n.t('fcValidation:endDateGreater'))
      errors.hmfch_end_date = i18n.t('fcValidation:endDateGreater')
    }
  }
  return errors
}