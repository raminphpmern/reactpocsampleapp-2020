import React from 'react';
import i18n from 'i18n';
import MoreDetails from 'components/InventoryHub/Popup/MoreDetails';
import LinkPopUp from 'components/Common/DataGrid/LinkPopUp';
import _ from 'lodash';

const moreDetailsFormatter = <LinkPopUp name={i18n.t("hubLoadGrid:moreDetails")} defaultValue='More Details'> <MoreDetails transactionType='CONSOLIDATION' /> </LinkPopUp>

export const columns = [
  { key: "ddh_dispatch_doc_type", name: i18n.t("fcInputThu:dispatchDocumentType") },
  { key: "hmitd_despat_doc_no", name: i18n.t("fcInputThu:dispatchDocNo") },
  { key: "ddh_dispatch_doc_date", name: i18n.t("fcInputThu:dispatchDocDate") },
  { key: "hmitd_thu_id", name: i18n.t("fcInputThu:thuId") },
  { key: "ddtd_thu_desc", name: i18n.t("fcInputThu:thuDescription") },
  { key: "hmitd_total_thu_qty", name: i18n.t("fcInputThu:totalQty") },
  { key: "hmitd_thu_qty", name: i18n.t("fcInputThu:qty") },
  { key: "hmitd_thu_uom", name: i18n.t("fcInputThu:qtyUom") },
  { key: "hmitd_bal_thu_qty", name: i18n.t("fcInputThu:balanceQty") },
  { key: "hmitd_ip_qty", name: i18n.t("fcInputThu:inputQty"), editable: true },
  { key: "hmitd_qtyuom", name: i18n.t("fcInputThu:uom") },
  { key: "hmitd_thu_serial_no", name: i18n.t("fcInputThu:serialNo") },
  { key: "ddtsd_length", name: i18n.t("fcInputThu:length") },
  { key: "ddtsd_breadth", name: i18n.t("fcInputThu:width") },
  { key: "ddtsd_height", name: i18n.t("fcInputThu:height") },
  { key: "ddtsd_lbh_uom", name: i18n.t("fcInputThu:dimensionUom") },
  { key: "ddtsd_gross_weight", name: i18n.t("fcInputThu:weight") },
  { key: "ddtsd_gross_weight_uom", name: i18n.t("fcInputThu:weightUom") },
  { key: "totalvolume", name: i18n.t("fcInputThu:volume") },
  { key: "ddtd_thu_vol_uom", name: i18n.t("fcInputThu:volumeUom") },
  { key: "moreDetails", name: i18n.t("fcInputThu:moreDetails"), formatter: moreDetailsFormatter, getRowMetaData: (row) => row },
]

export function fcHelper(data, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  _.merge(tempHash, data)
  return tempHash
}