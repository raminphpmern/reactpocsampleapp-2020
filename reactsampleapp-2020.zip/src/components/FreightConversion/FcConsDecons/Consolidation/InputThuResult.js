import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { columns, fcHelper } from "./InputThuHelper";
import InputField from "components/Common/InputField";
import { Field, reduxForm } from "redux-form";
import { withTranslation } from 'react-i18next';
import Popup from 'components/Common/Popup';
import * as freightConversionAction from "actions/freightConversionAction";
import { withRouter } from "react-router-dom";
import { SEARCH_WORD_COUNT } from "config";
import { connect } from "react-redux";
import { compose } from 'redux';
import _ from 'lodash';
import { AlertError } from "lib/Alert";
import i18n from 'i18n';
import HelpOnDispatchDocNo from "components/FreightConversion/Search/HelpOnDispatchDocNo";

class InputThuResult extends Component {
  constructor(props) {
    super(props)
    this.state = {
      disbledScan: true,
      disableCompute: true,
      dispatchDocNoHelp: false,
      currentHelp: '',
      selectedIds: [],
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.compute = this.compute.bind(this)
    this.toggle = this.toggle.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.getDispatchDocNoFromHelp = this.getDispatchDocNoFromHelp.bind(this)
    this.deleteSelectedRecords = this.deleteSelectedRecords.bind(this)
  }

  componentDidMount() {
    const { match: { params } } = this.props
    if (params.fcNo) {
      const fc_No = params.fcNo;
      this.props.getFCViewInputThuCon(fc_No, 1, 10);
    }
    let _self = this;
    let enterOfDispDocNumber = document.getElementById('hmhid_despatch_doc_no')
    enterOfDispDocNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let ddNo = formValues["hmhid_despatch_doc_no"]
        let fcExecNo = _self.props.fcForm.values.hmfch_fc_exec_no
        let fcExecType = _self.props.fcForm.values.hmfch_fc_exec_type
        if (ddNo && ddNo.length >= SEARCH_WORD_COUNT) {
          _self.props.inputThuSearch({ hmhid_despatch_doc_no: ddNo, fcexecutionno: fcExecNo, hmfch_fc_exec_type: fcExecType }, 1, 10)
        }
        event.preventDefault()
      }
    })
    let enterOfSerialNumber = document.getElementById('hmhid_serialno')
    enterOfSerialNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let serialNumber = formValues["hmhid_serialno"]
        let fcExecNo = _self.props.fcForm.values.hmfch_fc_exec_no
        let fcExecType = _self.props.fcForm.values.hmfch_fc_exec_type
        let ddNo = []
        if (formValues["hmhid_despatch_doc_no"] !== '') {
          ddNo = formValues["hmhid_despatch_doc_no"]
        }
        if (formValues["hmhid_despatch_doc_no"] === '') {
          ddNo = ""
        }
        if (serialNumber && serialNumber.length >= SEARCH_WORD_COUNT) {
          _self.props.inputThuSearch({ hmhid_despatch_doc_no: ddNo, fcexecutionno: fcExecNo, hmhid_serialno: serialNumber, hmfch_fc_exec_type: fcExecType }, 1, 10)
        }
        event.preventDefault()
      }
    })
  }

  changeLimit(pageNo, limit) {
    const fc_No = this.props.fcForm.values.hmfch_fc_exec_no
    this.props.getFCViewInputThuCon(fc_No, pageNo, limit)
  }

  paginationHandler(pageNo, limit) {
    const fc_No = this.props.fcForm.values.hmfch_fc_exec_no
    this.props.getFCViewInputThuCon(fc_No, pageNo, limit)
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  compute() {
    if (this.props.result && this.props.result.length > 0) {
      if (this.state.selectedIds && this.state.selectedIds.length > 0) {
        const weightUom = this.state.selectedIds[0].ddtsd_gross_weight_uom
        const volumeUom = this.state.selectedIds[0].ddtd_thu_vol_uom
        let weightUomCheck = _.every(this.state.selectedIds, ["ddtsd_gross_weight_uom", weightUom])
        let volumeUomCheck = _.every(this.state.selectedIds, ["ddtd_thu_vol_uom", volumeUom])
        let data = _.reduce(this.state.selectedIds, (hash, input) => {
          if (weightUomCheck === true) {
            hash['requiredWeight'] += parseInt(input.ddtsd_gross_weight) || 0
          }
          if (volumeUomCheck === true) {
            hash['requiredVolume'] += parseInt(input.totalvolume) || 0
          }
          return hash
        }, { requiredWeight: 0, requiredVolume: 0 })
        if (weightUomCheck === false || volumeUomCheck === false) {
          const records = this.state.selectedIds
          this.props.compute({ inputThuCompute: records })
        }
        let computedVolume = ''
        let computedWeight = ''
        if (weightUom !== null & volumeUom !== null) {
          computedWeight = data.requiredWeight + ' ' + weightUom
          computedVolume = data.requiredVolume + ' ' + volumeUom
        }
        if (weightUom === null & volumeUom !== null) {
          computedVolume = data.requiredVolume + ' ' + volumeUom
          AlertError(i18n.t("fcInputThu:weightNull"))
        }
        if (weightUom !== null & volumeUom === null) {
          computedWeight = data.requiredWeight + ' ' + weightUom
          AlertError(i18n.t("fcInputThu:volumeNull"))
        }
        if (weightUom === null & volumeUom === null) {
          AlertError(i18n.t("fcInputThu:bothNull"))
        }
        this.props.initialize({ requiredWeight: computedWeight, requiredVolume: computedVolume })
      }
      else if (this.state.selectedIds && this.state.selectedIds.length === 0) {
        AlertError(i18n.t("fcInputThu:notSelect"))
      }
    }
    if (this.props.result && this.props.result.length === 0) {
      AlertError(i18n.t("fcInputThu:notScan"))
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const status = nextProps.fcForm && nextProps.fcForm.values && nextProps.fcForm.values.hmfch_fc_status
    if (status === "Created") {
      this.setState({ disbledScan: false, disableCompute: false })
    }
    if (status === "Confirmed" || status === "Partially Closed") {
      this.setState({ disbledScan: true, disableCompute: true })
    }
    if (this.props.compute_result !== nextProps.compute_result) {
      const computeResult = nextProps.compute_result
      const computedRequiredVolume = computeResult.required_volume + ' ' + computeResult.required_volume_uom
      const computedRequiredWeight = computeResult.required_weight + ' ' + computeResult.required_weight_uom
      const hash = _.cloneDeep(nextProps.formValues.values)
      this.props.initialize(fcHelper({ requiredWeight: computedRequiredWeight, requiredVolume: computedRequiredVolume }, hash))
    }
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  getDispatchDocNoFromHelp(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["hmhid_despatch_doc_no"] = data
      this.props.initialize(hash)
    }
  }

  componentDidUpdate() {
    const thuIds = this.state.selectedIds;
    this.props.passInputThuIds(thuIds);
  }

  deleteSelectedRecords(rows) {
    const { deleteConsolidationInputRecords, fcForm } = this.props
    if (fcForm.values.hmfch_fc_status === "Created") {
      deleteConsolidationInputRecords({
        hmfch_fc_exec_no: fcForm.values.hmfch_fc_exec_no,
        hmitd_despat_doc_no: _.map(rows, 'hmitd_despat_doc_no'),
        hmitd_thu_serial_no: _.map(rows, 'hmitd_thu_serial_no'),
        data: rows, form: fcForm.values.hmfch_fc_exec_type,
      })
    }
    else {
      AlertError(i18n.t('fcValidation:alreadyConfirmed'))
    }
  }

  render() {
    const { t, result, totalPage, totalRecord, resetRecords } = this.props
    const { disbledScan, disableCompute, dispatchDocNoHelp, currentHelp } = this.state

    return (
      <div>

        <Popup size="fullscreen" open={dispatchDocNoHelp} close={() => { this.toggle('help', 'dispatchDocNoHelp') }} header="Help on Dispatch Document No." description={<HelpOnDispatchDocNo
          getDispatchDocNo={this.getDispatchDocNoFromHelp} close={this.toggle} name={currentHelp} />} />

        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={8}>
              <Field
                name="hmhid_despatch_doc_no"
                component={InputField}
                label={t('dispatchDocument')}
                readOnly={disbledScan}
                iconName="search"
                handleClick={this.toggle}
                childName="dispatchDocNoHelp"
                maxLength={18}
              />
            </Grid.Column>
            <Grid.Column width={8}>
              <Field
                name="hmhid_serialno"
                component={InputField}
                label={t('thuSerialNo')}
                readOnly={disbledScan}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={11} />
            <Grid.Column width={5}>
              <div className="country">
                <Popup size="mini" trigger={<button type="button" className="link-button" disabled={true}>
                  {t('country')}</button>} />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row />
          <Grid.Row />
          <Grid.Row>
            <h3 className="thu-title">{t('title')}</h3>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  columns={columns}
                  width={200}
                  rows={result}
                  enableExport={true}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  initialize={resetRecords}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  selectedRows={this.selectedRows}
                  showCheckbox={true}
                  deleteRow={true}
                  dropSelectedRows={this.deleteSelectedRecords}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={3}>
              <button type="button" className="secondary btn-small nav-btn" onClick={() => this.compute()} disabled={disableCompute}>
                {t('compute')}
              </button>
            </Grid.Column>
            <Grid.Column width={6}>
              <Field
                name="requiredVolume"
                component={InputField}
                label={t('requiredVolume')}
                readOnly={true}
              />
            </Grid.Column>
            <Grid.Column width={6}>
              <Field
                name="requiredWeight"
                component={InputField}
                label={t('requiredWeight')}
                readOnly={true}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

InputThuResult = reduxForm({
  form: "InputThuResultForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
})(InputThuResult);

const mapDispatchToProps = dispatch => ({
  getFCViewInputThuCon: (fc_No, pageNo, limit) =>
    dispatch(freightConversionAction.getFCViewInputThu(fc_No, pageNo, limit)),
  inputThuSearch: (data, pageNo, limit) =>
    dispatch(freightConversionAction.fcInputThuFetch(data, pageNo, limit)),
  compute: (data) =>
    dispatch(freightConversionAction.computeThu(data)),
  resetRecords: () => dispatch(freightConversionAction.resetRecords()),
  deleteConsolidationInputRecords: (params) =>
    dispatch(freightConversionAction.deleteFcInputRecords(params))
});

const mapStateToProps = state => ({
  formValues: state.form.InputThuResultForm,
  result: state.freightConversionReducer.input_Thu_result,
  totalPage: state.freightConversionReducer.input_Thu_totalPage,
  totalRecord: state.freightConversionReducer.input_Thu_totalRecord,
  fcForm: state.form.FcConsDeconsForm,
  compute_result: state.freightConversionReducer.compute_result
})

export default compose(withTranslation('fcInputThu'), connect(mapStateToProps, mapDispatchToProps))(withRouter(InputThuResult))