import i18n from 'i18n';
import React from "react";
import _ from 'lodash';
import HelpOnFcSeal from '../HelpOnFcSeal';
import LinkPopUp from 'components/Common/DataGrid/LinkPopUp';

const sealNoPopUp = <LinkPopUp name='Seal No' defaultValue='Seal No'> <HelpOnFcSeal fcType='Consolidation' /> </LinkPopUp>

export const columns = [
  { key: "hmotd_thu_id", name: i18n.t("fcOutputThu:thuId") },
  { key: "hmotd_thu_desc", name: i18n.t("fcOutputThu:thuDescription") },
  { key: "hmotd_thu_serial_no", name: i18n.t("fcOutputThu:thuSerialNo") },
  { key: "hmotd_thu_seal_no", name: i18n.t("fcOutputThu:sealNo"), formatter: sealNoPopUp, getRowMetaData: (row) => row },
  { key: "hmotd_thu_qty", name: i18n.t("fcOutputThu:totalQty") },
  { key: "hmotd_thu_length", name: i18n.t("fcOutputThu:length") },
  { key: "hmotd_thu_width", name: i18n.t("fcOutputThu:width") },
  { key: "hmotd_thu_height", name: i18n.t("fcOutputThu:height") },
  { key: "dimensionUom", name: i18n.t("fcOutputThu:dimensionUom") },
  { key: "hmotd_thu_weight", name: i18n.t("fcOutputThu:weight") },
  { key: "hmotd_thu_wt_uom", name: i18n.t("fcOutputThu:weightUom") },
  { key: "hmotd_thu_volume", name: i18n.t("fcOutputThu:volume") },
  { key: "hmotd_thu_vl_uom", name: i18n.t("fcOutputThu:volumeUom") }
]

export function fcOutputHelper(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["internal_volume"]) {
      hash["internal_volume"] = hash["internal_volume"].wms_paramdesc
    }
    if (hash["max_allowable_wt"]) {
      hash["max_allowable_wt"] = hash["max_allowable_wt"].wms_paramdesc
    }
    return hash
  } else {
    return {}
  }
}