import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { columns, fcOutputHelper } from "./OutputThuHelper";
import InputField from "components/Common/InputField";
import InputSearchField from "components/Common/InputSearchField";
import { Field, reduxForm } from "redux-form";
import { withTranslation } from 'react-i18next';
import DropDown from "components/Common/Dropdown";
import * as freightConversionAction from "actions/freightConversionAction";
import { withRouter } from "react-router-dom";
import { SEARCH_WORD_COUNT } from "config";
import { connect } from "react-redux";
import { compose } from 'redux';
import validate from '../Validation'
import { getProducts } from "actions/masterAction";
import _ from 'lodash';
import HelpOnSerialNo from "components/FreightConversion/Search/HelpOnSerialNo";
import Popup from 'components/Common/Popup';

class OutputThuResult extends Component {
  constructor(props) {
    super(props)
    this.state = {
      disbledBtnOnConfirm: false,
      disbledScan: true,
      selectedIds: [],
      serialNoHelp: false,
      currentHelp: ''
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.outputThuSearch = this.outputThuSearch.bind(this)
    this.search = this.search.bind(this)
    this.setValue = this.setValue.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.onRowEdit = this.onRowEdit.bind(this)
    this.getSerialNoFromHelp = this.getSerialNoFromHelp.bind(this)
    this.toggle = this.toggle.bind(this)
  }

  componentDidMount() {
    const { match: { params }, weight, volume, operators, getFcMasters, result_header } = this.props
    if (params.fcNo) {
      const fc_No = params.fcNo;
      this.props.getFCViewOutputThuCon(fc_No, 1, 10);
    }
    if (weight.length === 0) {
      getFcMasters("weight")
    }
    if (volume.length === 0) {
      getFcMasters("volume")
    }
    if (operators.length === 0) {
      getFcMasters("operators")
    }
    if (result_header) {
      const header = this.props.result_header
      this.props.initialize({ hmfch_fc_bay_id: header.hmfch_fc_bay_id, hmfch_to_bay_id: header.hmfch_to_bay_id })
    }
    let enterOfThuNo = document.getElementById('products')
    enterOfThuNo.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        const formValues = this.props.formValues.values
        this.props.outputThuSearch(fcOutputHelper(formValues), 1, 10)
        event.preventDefault()
      }
    })
    let enterOfSerialNumber = document.getElementById('hmtid_thu_serial_no')
    enterOfSerialNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        const formValues = this.props.formValues.values
        this.props.outputThuSearch(fcOutputHelper(formValues), 1, 10)
        event.preventDefault()
      }
    })
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      if (fieldName === 'fcBayid' || fieldName === "toBayid") {
        let queryString = `keyword=${value}`;
        this.props.getFcMasters("bayid", queryString);
      }
      if (fieldName === 'products') {
        this.props.getProducts(
          'products',
          `keyword=${value}&wms_thu_is_ethu=1`
        );
      }
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (option) {
      if (fieldName === "fcBayid") {
        hash["hmfch_fc_bay_id"] = option.wms_bay_id;
      }
      if (fieldName === "toBayid") {
        hash["hmfch_to_bay_id"] = option.wms_bay_id;
      }
      if (fieldName === "products") {
        hash["hmtid_thu_id"] = option.value;
      }
      this.props.initialize(hash);
    }
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  getSerialNoFromHelp(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values, this.props.result)
      hash["hmtid_thu_serial_no"] = data
      this.props.initialize(hash)
    }
  }

  changeLimit(pageNo, limit) {
    const formValues = this.props.formValues.values
    this.props.outputThuSearch(fcOutputHelper(formValues), pageNo, limit)
  }

  paginationHandler(pageNo, limit) {
    const formValues = this.props.formValues.values
    this.props.outputThuSearch(fcOutputHelper(formValues), pageNo, limit)
  }

  outputThuSearch() {
    const formValues = this.props.formValues.values
    this.props.outputThuSearch(fcOutputHelper(formValues), 1, 10)
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const status = nextProps.fcForm && nextProps.fcForm.values && nextProps.fcForm.values.hmfch_fc_status
    if (status === "Created") {
      this.setState({ disbledScan: false })
    }
    if (status === "Confirmed" || status === "Partially Closed") {
      this.setState({ disbledScan: true, disbledBtnOnConfirm: true })
    }
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  componentDidUpdate(prevProps) {
    if (prevProps.result_header !== this.props.result_header) {
      const header = this.props.result_header
      this.props.initialize({ hmfch_fc_bay_id: header.hmfch_fc_bay_id, hmfch_to_bay_id: header.hmfch_to_bay_id })
    }
    const thuIds = this.state.selectedIds;
    this.props.passOutputThuIds(thuIds);
    if (this.props.params && this.props.params.length !== 0) {
      this.setValue()
    }
  }

  onRowEdit(row, updateValue) {
    _.merge(row, updateValue)
    let { selectedIds } = this.state
    if (selectedIds.length > 0) {
      const recordIndex = _.findIndex(selectedIds, (item) => item.id === row.id)
      if (recordIndex >= 0) {
        selectedIds[recordIndex] = row
      }
    }
    this.setState({ selectedIds })
  }

  render() {
    const { t, result, totalPage, totalRecord, resetRecords, bayid, weight, volume, operators, products } = this.props
    const { disbledScan, disbledBtnOnConfirm, serialNoHelp, currentHelp } = this.state
    return (
      <div>

        <Popup size="fullscreen" open={serialNoHelp} close={() => { this.toggle('help', 'serialNoHelp') }} header="Help on THU Serial No." description={<HelpOnSerialNo
          getSerialNo={this.getSerialNoFromHelp} close={this.toggle} name={currentHelp} />} />

        <Grid stackable className="freight-conversion">
          <Grid.Row>
            <Grid.Column width={8}>
              <Field
                name="hmtid_thu_id"
                id="products"
                component={InputSearchField}
                options={products}
                clearable={true}
                findByCompanyAndFLMName={this.search}
                fillNameValues={this.setValue}
                label={t('thuId')}
                readOnly={disbledScan}
              />
            </Grid.Column>
            <Grid.Column width={8}>
              <Field
                name="hmtid_thu_serial_no"
                component={InputField}
                label={t('serialNo')}
                iconName="search"
                readOnly={disbledScan}
                handleClick={this.toggle}
                childName="serialNoHelp"
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="freight-conversion-output">
            <Grid.Column width={12}>
              <div className="output">
                <Field
                  name="internal_volume"
                  component={disbledScan ? InputField : DropDown}
                  label={t('internalVolume')}
                  options={operators}
                  readOnly={disbledScan}
                />
                <Field
                  name="internal_volume_1"
                  component={InputField}
                  readOnly={disbledScan}
                />
                <Field
                  name="internal_volume_2"
                  component={InputField}
                  readOnly={disbledScan}
                />
                <Field
                  name="internal_volume_3"
                  component={disbledScan ? InputField : DropDown}
                  readOnly={disbledScan}
                  options={volume}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="freight-conversion-output">
            <Grid.Column width={12}>
              <div className="output">
                <Field
                  name="max_allowable_wt"
                  component={disbledScan ? InputField : DropDown}
                  label={t('maxAllowableWt')}
                  options={operators}
                  readOnly={disbledScan}
                />
                <Field
                  name="max_allowable_wt_1"
                  component={InputField}
                  readOnly={disbledScan}
                />
                <Field
                  name="max_allowable_wt_2"
                  component={InputField}
                  readOnly={disbledScan}
                />
                <Field
                  name="max_allowable_wt_3"
                  component={disbledScan ? InputField : DropDown}
                  readOnly={disbledScan}
                  options={weight}
                />
              </div>
            </Grid.Column>
            <Grid.Column width={4}>
              <div className="assign-button-right">
                <button id='serach' type='button' className="primary" disabled={disbledScan} onClick={() => this.outputThuSearch()}>
                  {t('searchBtn')}
                </button>
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <h3 className="thu-title">{t('title')}</h3>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  columns={columns}
                  width={200}
                  rows={result}
                  enableExport={true}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  initialize={resetRecords}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  selectedRows={this.selectedRows}
                  rowEdit={this.onRowEdit}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={2} />
            <Grid.Column width={6}>
              <Field
                name="hmfch_fc_bay_id"
                component={InputSearchField}
                label={t('fcBayId')}
                readOnly={disbledBtnOnConfirm}
                findByCompanyAndFLMName={this.search}
                id="fcBayid"
                options={bayid}
                fillNameValues={this.setValue}
                required={true}
              />
            </Grid.Column>
            <Grid.Column width={6}>
              <Field
                name="hmfch_to_bay_id"
                component={InputSearchField}
                label={t('toBayId')}
                readOnly={disbledBtnOnConfirm}
                findByCompanyAndFLMName={this.search}
                id="toBayid"
                options={bayid}
                fillNameValues={this.setValue}
                required={true}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

OutputThuResult = reduxForm({
  form: "OutputThuResultForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate
})(OutputThuResult);

const mapDispatchToProps = dispatch => ({
  getFCViewOutputThuCon: (fc_No, pageNo, limit) =>
    dispatch(freightConversionAction.getFCViewOutputThu(fc_No, pageNo, limit)),
  outputThuSearch: (data, pageNo, limit) =>
    dispatch(freightConversionAction.fcOutputThuFetch(data, pageNo, limit)),
  getFcMasters: (action, queryStr) =>
    dispatch(freightConversionAction.getFcMasterDetails(action, queryStr)),
  resetRecords: () => dispatch(freightConversionAction.resetRecords()),
  getProducts: (action, queryStr) =>
    dispatch(getProducts(action, queryStr)),
});

const mapStateToProps = state => ({
  formValues: state.form.OutputThuResultForm,
  result_header: state.freightConversionReducer.result,
  result: state.freightConversionReducer.output_Thu_result,
  totalPage: state.freightConversionReducer.output_Thu_totalPage,
  totalRecord: state.freightConversionReducer.output_Thu_totalRecord,
  bayid: state.freightConversionReducer.options.bayid,
  weight: state.freightConversionReducer.options.weight,
  volume: state.freightConversionReducer.options.volume,
  operators: state.freightConversionReducer.options.operators,
  fcForm: state.form.FcConsDeconsForm,
  products: state.masterReducer.options.products
})

export default compose(withTranslation('fcOutputThu'), connect(mapStateToProps, mapDispatchToProps))(withRouter(OutputThuResult))