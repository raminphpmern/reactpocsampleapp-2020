import React, { Component } from 'react'
import InputField from "components/Common/InputField";
import DropDown from "components/Common/Dropdown";
import TextArea from 'components/Common/TextArea';
import InputSearchField from "components/Common/InputSearchField";
import DateTimePicker from "components/Common/DateTimePicker";
import { reduxForm, Field, formValueSelector } from "redux-form";
import { Grid } from "semantic-ui-react";
import { withTranslation } from 'react-i18next';
import { getValue } from "lib/LocalStorage";
import Popup from 'components/Common/Popup';
import HelpOnEmployee from "components/CollectionSummary/HelpOnEmployee";
import HelpOnEquipment from "components/HubLoadAndReceipt/Loading/HelpOnEquipment";
import ConsolidationInputThuResult from './Consolidation/InputThuResult';
import ConsolidationOutputThuResult from './Consolidation/OutputThuResult';
import DeconsolidationInputThuResult from './Deconsolidation/InputThuResult';
import DeconsolidationOutputThuResult from './Deconsolidation/OutputThuResult';
import * as freightConversionAction from "actions/freightConversionAction";
import validate from '../FcConsDecons/Validation'
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { compose } from 'redux';
import { fcHelper, fcRecordsHelper } from './Helper'
import _ from 'lodash';
import { SEARCH_WORD_COUNT } from "config";
import "../FreightConversion.css";
import i18n from 'i18n';
import { AlertError } from 'lib/Alert';

const fcTypes = [
  { value: 'consolidation', label: i18n.t("fcConsDeconsForm:consolidation") },
  { value: 'deconsolidation', label: i18n.t("fcConsDeconsForm:deconsolidation") },
];

class FcConsDecons extends Component {
  constructor(props) {
    super(props)
    this.state = {
      fc_type: '',
      employeeHelp: false,
      equipmentHelp: false,
      currentHelp: '',
      createFc: false,
      disbledBtn: false,
      disbledSaveBtn: false,
      disbledPcBtn: false,
      fcTypeDropDown: true,
      isBayExists: true,
      InputThuIds: [],
      OutputThuIds: []
    }
    this.saveFcRecords = this.saveFcRecords.bind(this)
    this.search = this.search.bind(this)
    this.setValue = this.setValue.bind(this)
    this.toggle = this.toggle.bind(this)
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this)
    this.getEquipmentDetails = this.getEquipmentDetails.bind(this)
    this.consolidationInputThu = this.consolidationInputThu.bind(this)
    this.consolidationOutputThu = this.consolidationOutputThu.bind(this)
  }

  componentDidMount() {
    this.props.resetRecords()
    const { match: { params } } = this.props
    if (getValue('currentBranch')) {
      let currentBranch = JSON.parse(getValue('currentBranch') ? getValue('currentBranch') : {})
      if (currentBranch.value) {
        this.props.initialize({ division: currentBranch.value, location: currentBranch.wms_loc_code });
      }
    }
    if (params.fcNo) {
      const fc_No = params.fcNo;
      this.props.getHeaderRecords(fc_No, true);
    }
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  getEmployeeDetails(data) {
    if (data && this.props.formValues) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["hmfch_emp_id"] = data[0]["wms_emp_employee_code"]
      this.props.initialize(hash)
    }
  }

  getEquipmentDetails(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["hmfch_mhe_id"] = data[0]["wms_eqp_equipment_id"]
      this.props.initialize(hash)
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === 'employee') {
        this.props.getFcMasters("employee", queryString, fieldName);
      }
      if (fieldName === 'mhe') {
        this.props.getFcMasters("mhe", queryString, fieldName);
      }
    }
  }

  setValue(option, fieldName) {
    if (option) {
      let hash = _.cloneDeep(this.props.formValues.values);
      if (fieldName === "employee") {
        hash["hmfch_emp_id"] = option.wms_emp_employee_code;
      }
      if (fieldName === "mhe") {
        hash["hmfch_mhe_id"] = option.wms_eqp_equipment_id;
      }
      this.props.initialize(hash);
    }
  }

  consolidationInputThu(InputThuRecords) {
    this.setState({ InputThuIds: InputThuRecords });
  }

  consolidationOutputThu(OutputThuRecords) {
    this.setState({ OutputThuIds: OutputThuRecords });
  }

  saveFcRecords() {
    let fcFormValues = this.props.formValues.values
    const bayIds = this.props.OutputThuResultForm.values
    const datas = Object.assign({}, { ...fcFormValues }, { ...bayIds }, { action: "save" })
    this.props.saveFcRecords(fcRecordsHelper(datas))
  }

  partiallyCloseFcRecords() {
    let fcFormValues = this.props.formValues.values
    let bayIds = this.props.OutputThuResultForm.values
    let sealDataValidation = this.props.sealSaveStatus
    if (fcFormValues.hmfch_fc_exec_type === "CONSOLIDATION") {
      const inputThu = this.state.InputThuIds
      const outputThu = this.state.OutputThuIds
      if (outputThu.length > 0 && sealDataValidation !== "saved") {
        AlertError(i18n.t("fcValidation:sealByRequired"))
        return false;
      }
      else {
      }
      const inputThuResult = this.props.inputThuGrid
      const outputThuResult = this.props.outputThuGrid
      if (inputThuResult.length === 0) {
        AlertError(i18n.t("fcValidation:scanInputThu"))
      }
      if (inputThuResult.length > 0 && inputThu.length < 1) {
        AlertError(i18n.t("fcValidation:inputThuSelection"))
      }
      if (inputThuResult.length > 0 && inputThu.length >= 1 && outputThuResult.length === 0) {
        AlertError(i18n.t("fcValidation:scanOutputThu"))
      }
      if (inputThu.length >= 1 && outputThuResult.length > 0 && outputThu.length === 0) {
        AlertError(i18n.t("fcValidation:outputThuSelection"))
      }
      if (outputThu.length > 1) {
        AlertError(i18n.t("fcValidation:multipleOutputThuSelection"))
      }
      if (inputThu.length > 0 && outputThu.length === 1) {
        const datas = Object.assign({}, { ...fcFormValues }, { ...bayIds }, { action: "partialclose" }, { grid_input_thu: inputThu }, { grid_output_thu: outputThu })
        this.props.saveFcRecords(fcRecordsHelper(datas))
      }
    }
    if (fcFormValues.hmfch_fc_exec_type === "DECONSOLIDATION") {
      const inputThu = this.props.inputThuGrid
      const outputThu = this.props.outputThuGrid
      if (inputThu.length > 0 && outputThu.length > 0 && sealDataValidation !== "saved") {
        AlertError(i18n.t("fcValidation:unSealByRequired"))
        return false;
      }
      if (inputThu.length > 0 && outputThu.length > 0 && sealDataValidation === "saved") {
        const datas = Object.assign({}, { ...fcFormValues }, { ...bayIds }, { action: "partialclose" }, { grid_input_thu: inputThu }, { grid_output_thu: outputThu })
        this.props.saveFcRecords(fcRecordsHelper(datas))
      }
      else if (inputThu.length === 0) {
        AlertError(i18n.t("fcValidation:deconsScan"))
      }
      else if (inputThu.length > 0 && outputThu.length === 0) {
        AlertError(i18n.t("fcValidation:deconsTheRecord"))
      }
    }
  }

  confirmFcRecords() {
    let fcFormValues = this.props.formValues.values
    let bayIds = this.props.OutputThuResultForm.values
    let sealDataValidation = this.props.sealSaveStatus
    if (fcFormValues.hmfch_fc_exec_type === "CONSOLIDATION") {
      const inputThu = this.state.InputThuIds
      const outputThu = this.state.OutputThuIds
      if (outputThu.length > 0 && sealDataValidation !== "saved") {
        AlertError(i18n.t("fcValidation:sealByRequired"))
        return false;
      }
      else {
      }
      const inputThuResult = this.props.inputThuGrid
      const outputThuResult = this.props.outputThuGrid
      if (inputThuResult.length === 0) {
        AlertError(i18n.t("fcValidation:scanInputThu"))
      }
      if (inputThuResult.length > 0 && inputThu.length < 1) {
        AlertError(i18n.t("fcValidation:inputThuSelection"))
      }
      if (inputThuResult.length > 0 && inputThu.length >= 1 && outputThuResult.length === 0) {
        AlertError(i18n.t("fcValidation:scanOutputThu"))
      }
      if (inputThu.length >= 1 && outputThuResult.length > 0 && outputThu.length === 0) {
        AlertError(i18n.t("fcValidation:outputThuSelection"))
      }
      if (outputThu.length > 1) {
        AlertError(i18n.t("fcValidation:multipleOutputThuSelection"))
      }
      if (inputThu.length > 0 && outputThu.length === 1) {
        const datas = Object.assign({}, { ...fcFormValues }, { ...bayIds }, { action: "confirm" }, { grid_input_thu: inputThu }, { grid_output_thu: outputThu })
        this.props.saveFcRecords(fcRecordsHelper(datas))
      }
    }
    if (fcFormValues.hmfch_fc_exec_type === "DECONSOLIDATION") {
      const inputThu = this.props.inputThuGrid
      const outputThu = this.props.outputThuGrid
      if (inputThu.length > 0 && outputThu.length > 0 && sealDataValidation !== "saved") {
        AlertError(i18n.t("fcValidation:unSealByRequired"))
        return false;
      }
      if (inputThu.length > 0 && outputThu.length > 0 && sealDataValidation === "saved") {
        const datas = Object.assign({}, { ...fcFormValues }, { ...bayIds }, { action: "confirm" }, { grid_input_thu: inputThu }, { grid_output_thu: outputThu })
        this.props.saveFcRecords(fcRecordsHelper(datas))
      }
      else if (inputThu.length === 0) {
        AlertError(i18n.t("fcValidation:deconsScan"))
      }
      else if (inputThu.length > 0 && outputThu.length === 0) {
        AlertError(i18n.t("fcValidation:deconsTheRecord"))
      }
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.formValues && nextProps.formValues.values) {
      if (nextProps.result_header !== this.props.result_header) {
        const header = nextProps.result_header
        const hash = _.cloneDeep(nextProps.formValues.values)
        this.props.initialize(fcHelper({ hmfch_fc_exec_no: header.hmfch_fc_exec_no, hmfch_fc_exec_date: header.hmfch_fc_exec_date, hmfch_fc_status: header.hmfch_fc_status, hmfch_emp_id: header.hmfch_emp_id, hmfch_add_emp_id: header.hmfch_add_emp_id, hmfch_mhe_id: header.hmfch_mhe_id, hmfch_special_instruction: header.hmfch_special_instruction, hmfch_start_date: header.hmfch_start_date, hmfch_end_date: header.hmfch_end_date, hmfch_fc_exec_type: header.hmfch_fc_exec_type }, hash))
        this.setState({ fc_type: header.hmfch_fc_exec_type })
      }
      if (nextProps.formValues.values.hmfch_fc_exec_no) {
        this.setState({ fcTypeDropDown: false })
      }
      if (nextProps.formValues.values.hmfch_fc_status === "Confirmed") {
        this.setState({ disbledBtn: true })
      }
      if (nextProps.formValues.values.hmfch_fc_status === "Created") {
        this.setState({ disbledSaveBtn: true, disbledBtn: false })
      }
      if (nextProps.formValues.values.hmfch_fc_status === "Partially Closed") {
        this.setState({ disbledPcBtn: true, disbledSaveBtn: true })
      }
    }
    const outputThuResultForm = nextProps.OutputThuResultForm
    if (outputThuResultForm && outputThuResultForm.values) {
      if (outputThuResultForm.values.hmfch_fc_bay_id && outputThuResultForm.values.hmfch_to_bay_id) {
        this.setState({ isBayExists: false })
      }
    }
    if (nextProps.location.pathname == "/hub/freightConversion/consDecons") {
      this.setState({ createFc: true })
    }
  }

  formSubmit() {
    // TODO: This has been left blank to handle multiple submit buttons. Later may enable for enter key
  }

  render() {
    const { t, handleSubmit, fcType, employee, mhe, invalid } = this.props
    const { fc_type, createFc, disbledBtn, currentHelp, employeeHelp, equipmentHelp, disbledSaveBtn, fcTypeDropDown, isBayExists, disbledPcBtn } = this.state
    return (
      <div className="freight-conversion">
        <Popup size="fullscreen" open={employeeHelp} close={() => { this.toggle('help', 'employeeHelp') }} header="Help On Employee" description={<HelpOnEmployee
          getEmployeeDetails={this.getEmployeeDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={equipmentHelp} close={() => { this.toggle('help', 'equipmentHelp') }} header={'Help On Equipment'} description={<HelpOnEquipment getEquipmentDetails={this.getEquipmentDetails} close={this.toggle} name={currentHelp} />} />

        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="division"
                  component={InputField}
                  label={t('division')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="location"
                  component={InputField}
                  label={t('location')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="hmfch_fc_exec_no"
                  component={InputField}
                  label={t('fcExecutionNo')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmfch_fc_exec_date"
                  component={DateTimePicker}
                  label={t('fcExecutionDate')}
                  disabled={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmfch_fc_exec_type"
                  component={fcTypeDropDown ? DropDown : InputField}
                  label={t('fcExecutionType')}
                  options={fcTypes}
                  readOnly={!fcTypeDropDown}
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmfch_fc_status"
                  component={InputField}
                  label={t('status')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column className="freight-conversion-line-brk" />
            </Grid.Row>
            {((createFc === true && fcType === undefined && fc_type === undefined) || (createFc === false && fcType === "CONSOLIDATION") || (fcType && fcType.value === "consolidation") || (fc_type === "CONSOLIDATION")) &&
              <Grid.Row className="no-padding" >
                <Grid.Column width={8}>
                  <div className="input-thu">
                    <ConsolidationInputThuResult passInputThuIds={this.consolidationInputThu} />
                  </div>
                </Grid.Column>
                <div className="freight-conversion-line-brk-ver-con"></div>
                <Grid.Column width={8} >
                  <ConsolidationOutputThuResult passOutputThuIds={this.consolidationOutputThu} />
                </Grid.Column>
              </Grid.Row>
            }
            {((createFc === false && fcType === "DECONSOLIDATION") || (fcType && fcType.value === "deconsolidation") || (fc_type === "DECONSOLIDATION")) &&
              <Grid.Row className="no-padding" >
                <Grid.Column width={8}>
                  <DeconsolidationInputThuResult />
                </Grid.Column>
                <div className="freight-conversion-line-brk-ver-dcon"></div>
                <Grid.Column width={8}>
                  <DeconsolidationOutputThuResult />
                </Grid.Column>
              </Grid.Row>
            }
            <Grid.Row className="no-padding">
              <Grid.Column className="freight-conversion-line-brk" />
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={3} className="fc-employee">
                <Field
                  name="hmfch_emp_id"
                  component={InputSearchField}
                  label={t('employee')}
                  options={employee}
                  iconName="search"
                  handleClick={this.toggle}
                  childName="employeeHelp"
                  findByCompanyAndFLMName={this.search}
                  id="employee"
                  fillNameValues={this.setValue}
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={3} className="fc-employee">
                <Field
                  name="hmfch_add_emp_id"
                  component={InputField}
                  label={t('additionalEmployee')}
                  iconName="search"
                />
              </Grid.Column>
              <Grid.Column width={2}>
                <Field
                  name="hmfch_mhe_id"
                  component={InputSearchField}
                  label={t('mhe')}
                  iconName="search"
                  findByCompanyAndFLMName={this.search}
                  id="mhe"
                  options={mhe}
                  handleClick={this.toggle}
                  childName="equipmentHelp"
                  fillNameValues={this.setValue}
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmfch_start_date"
                  component={DateTimePicker}
                  label={t('startDateAndTime')}
                  showTimeSelect={true}
                  timeIntervals={1}
                  min={new Date()}
                  required={true}
                />
              </Grid.Column>
              <Grid.Column width={4} className="fc-end-date">
                <Field
                  name="hmfch_end_date"
                  component={DateTimePicker}
                  label={t('endDateAndTime')}
                  showTimeSelect={true}
                  timeIntervals={1}
                  min={new Date()}
                  required={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                <Field
                  name="hmfch_special_instruction"
                  component={TextArea}
                  label={t('specialInstructions')}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="buttons">
              <Grid.Column width={6}>
                <div className="assign-button-right">
                  <button id='save' type='button' className="primary" disabled={disbledSaveBtn || invalid || disbledBtn || isBayExists} onClick={() => this.saveFcRecords()}>
                    {t('saveBtn')}
                  </button>
                </div>
              </Grid.Column>
              <Grid.Column width={2}>
                <div >
                  <button id='confirm' type="button" className="secondary" disabled={invalid || disbledBtn || !disbledSaveBtn || isBayExists || disbledPcBtn} onClick={() => this.confirmFcRecords()}>
                    {t('confirmBtn')}
                  </button>
                </div>
              </Grid.Column>
              <Grid.Column width={7}>
                <div className="assign-button-left">
                  <button id='partiallyClose' type='button' className="secondary" disabled={invalid || disbledBtn || !disbledSaveBtn || isBayExists || disbledPcBtn} onClick={() => this.partiallyCloseFcRecords()}>
                    {t('partiallyCloseBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div >
    );
  }
}

FcConsDecons = reduxForm({
  form: "FcConsDeconsForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate
})(FcConsDecons);

const selector = formValueSelector('FcConsDeconsForm');
FcConsDecons = connect(state => {
  const fcType = selector(state, 'hmfch_fc_exec_type');
  return {
    fcType,
  };
})(FcConsDecons);

const mapDispatchToProps = dispatch => ({
  getHeaderRecords: (fc_No) =>
    dispatch(freightConversionAction.getFCViewHeader(fc_No)),
  saveFcRecords: (data) =>
    dispatch(freightConversionAction.fcRecordsSave(data)),
  getFcMasters: (action, queryStr) =>
    dispatch(freightConversionAction.getFcMasterDetails(action, queryStr)),
  resetRecords: () => dispatch(freightConversionAction.resetRecords())
});

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
  formValues: state.form.FcConsDeconsForm,
  result_header: state.freightConversionReducer.result,
  OutputThuResultForm: state.form.OutputThuResultForm,
  employee: state.freightConversionReducer.options.employee,
  mhe: state.freightConversionReducer.options.mhe,
  outputThuGrid: state.freightConversionReducer.output_Thu_result,
  inputThuGrid: state.freightConversionReducer.input_Thu_result,
  sealSaveStatus: state.freightConversionReducer.status,
})

export default compose(withTranslation('fcConsDeconsForm'), connect(mapStateToProps, mapDispatchToProps))(withRouter(FcConsDecons))