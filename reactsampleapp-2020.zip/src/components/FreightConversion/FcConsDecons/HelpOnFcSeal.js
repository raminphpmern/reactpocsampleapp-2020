import React, { Component } from 'react';
import { Grid } from "semantic-ui-react";
import { Field, reduxForm } from "redux-form";
import { compose } from 'redux';
import i18n from 'i18n';
import DataGrid from 'components/Common/DataGrid';
import InputField from "components/Common/InputField";
import { connect } from 'react-redux';
import * as masterActions from 'actions/masterAction';
import * as freightConversionAction from "actions/freightConversionAction";
import { withTranslation } from 'react-i18next';
import { AlertError } from 'lib/Alert';
import DropDownEditor from 'components/Common/DataGrid/DropDownEditor'
import InputSearchEditor from 'components/Common/DataGrid/InputSearchEditor';
import _ from 'lodash';

export const consolidationColumns = [
  { key: "thssd_seal_no", name: i18n.t("fcSealNo:sealNo"), editable: true },
  { key: "thssd_sealed_by", name: i18n.t("fcSealNo:sealedBy"), editor: <InputSearchEditor propName='employee' />, editable: true },
]

export const deconsolidationColumns = [
  { key: "thssd_seal_no", name: i18n.t("fcSealNo:sealNo"), editable: true },
  { key: "thssd_unsealed_by", name: i18n.t("fcSealNo:unsealedBy"), editor: <InputSearchEditor propName='employee' />, editable: true },
  { key: "thssd_damaged_code", name: i18n.t("fcSealNo:damageCode"), editor: <DropDownEditor propName="damageCode" /> },
  { key: "wms_code_desc", name: i18n.t("fcSealNo:damageDescription") }
]

class HelpOnFcSeal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      updatedRows: []
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.save = this.save.bind(this)
    this.rowEdit = this.rowEdit.bind(this)
    this.dropSelectedRows = this.dropSelectedRows.bind(this)
    this.buildQueryString = this.buildQueryString.bind(this)
  }

  buildQueryString() {
    const { fcFormValues, rowInfo, fcType } = this.props
    if (fcType === "Consolidation") {
      return `hmfch_fc_exec_no=${fcFormValues.values.hmfch_fc_exec_no}&hmfch_fc_exec_type=${fcFormValues.values.hmfch_fc_exec_type}&thssd_thu_id=${rowInfo.hmotd_thu_id}&thssd_serial_no=${rowInfo.hmotd_thu_serial_no}`
    }
    if (fcType === "Deconsolidation") {
      return `hmfch_fc_exec_no=${fcFormValues.values.hmfch_fc_exec_no}&hmfch_fc_exec_type=${fcFormValues.values.hmfch_fc_exec_type}&thssd_thu_id=${rowInfo.hmitd_thu_id}&thssd_serial_no=${rowInfo.hmitd_thu_serial_no}&thssd_dispatch_doc_no=${rowInfo.hmitd_despat_doc_no}`
    }
  }

  componentDidMount() {
    const { damageCode, getQuickCodeMaster, rowInfo, fcType, fcFormValues } = this.props
    if (fcType === "Consolidation") {
      this.props.initialize({ thu_id: rowInfo.hmotd_thu_id, serial_no: rowInfo.hmotd_thu_serial_no })
      this.props.fetchConsRecords(this.buildQueryString(), 1, 10)
    }
    if (fcType === "Deconsolidation") {
      this.props.initialize({ thu_id: rowInfo.hmitd_thu_id, serial_no: rowInfo.hmitd_thu_serial_no })
      this.props.fetchDeconsRecords(this.buildQueryString(), 1, 10)

      if (damageCode.length === 0) {
        getQuickCodeMaster("damageCode");
      }
    }
    if (fcFormValues.values.hmfch_fc_status !== "Created") {
      this.setState({ disableSave: false })
    }
  }

  save() {
    let { updatedRows } = this.state
    let { fcType, fcFormValues, rowInfo } = this.props
    if (updatedRows.length > 0) {
      let isValid = true
      const sealNo = 'Please Enter Seal#'
      const sealBy = 'Please Enter Sealedby'
      const unSealBy = 'Please Enter UnSealedby'
      const damageCode = 'Please Select Damage Code'
      if (fcType === "Consolidation") {
        _.each(updatedRows, (row) => {
          if (!row.thssd_seal_no || !row.thssd_sealed_by) {
            isValid = false
            if (!isValid) {
              if (!row.thssd_seal_no) {
                AlertError(sealNo)
              }
              if (!row.thssd_sealed_by) {
                AlertError(sealBy)
              }
              if (fcType === "Deconsolidation") {
                if (!row.thssd_unsealed_by) {
                  AlertError(unSealBy)
                } else if (!row.thssd_damaged_code) {
                  AlertError(damageCode)
                }
              }
              return false
            }
          }
        })
      }
      if (fcType === "Deconsolidation") {
        _.each(updatedRows, (row) => {
          if (!row.thssd_seal_no || !row.thssd_unsealed_by || !row.thssd_damaged_code) {
            isValid = false
            if (!isValid) {
              if (!row.thssd_seal_no) {
                AlertError(sealNo)
              }
              else if (!row.thssd_unsealed_by) {
                AlertError(unSealBy)
              } else if (!row.thssd_damaged_code) {
                AlertError(damageCode)
              }
              return false
            }
          }
        })
      }
      if (isValid) {
        if (fcType === "Consolidation") {
          let hash = { data: updatedRows, thssd_thu_id: this.props.formValues.values.thu_id, thssd_serial_no: this.props.formValues.values.serial_no, hmfch_fc_exec_no: fcFormValues.values.hmfch_fc_exec_no, hmfch_fc_exec_type: fcFormValues.values.hmfch_fc_exec_type }
          hash = _.merge(hash)
          this.props.saveFcConsSeal(hash)
        }
        if (fcType === "Deconsolidation") {
          let hash = { data: updatedRows, thssd_thu_id: this.props.formValues.values.thu_id, thssd_serial_no: this.props.formValues.values.serial_no, hmfch_fc_exec_no: fcFormValues.values.hmfch_fc_exec_no, hmfch_fc_exec_type: fcFormValues.values.hmfch_fc_exec_type, thssd_dispatch_doc_no: rowInfo.hmitd_despat_doc_no }
          hash = _.merge(hash)
          this.props.saveFcDeConsSeal(hash);
        }
        this.setState({ updatedRows: [] })
      }
    }
  }

  rowEdit(row, updateValue) {
    _.merge(row, updateValue)
    if (row && row.new === true) {
      let { updatedRows } = this.state
      if (updatedRows.length > 0) {
        const recordIndex = _.findIndex(updatedRows, (item) => item.id === row.id)
        if (recordIndex >= 0) {
          updatedRows[recordIndex] = row
        } else {
          updatedRows.push(row)
        }
      } else {
        updatedRows.push(row)
      }
      this.setState({ updatedRows })
    } else {
      const response = _.reduce(this.props.consResult, (arr, item) => {
        if (item.thssd_lineno === row.thssd_lineno) {
          _.merge(item, updateValue)
          arr.push(item)
        }
        return arr
      }, [])
      this.setState({ updatedRows: response })
    }
  }

  dropSelectedRows(rows) {
    const { fcType } = this.props
    if (fcType === "Consolidation") {
      this.props.deleteFcConsSeal({ thssd_seal_no: _.map(rows, 'thssd_seal_no') })
    }
    if (fcType === "Deconsolidation") {
      this.props.deleteFcDeConsSeal({ thssd_seal_no: _.map(rows, 'thssd_seal_no') })
    }
  }

  changeLimit(pageNo, limit) {
    const { fcType } = this.props
    if (fcType === "Consolidation") {
      this.props.fetchConsRecords(this.buildQueryString(), pageNo, limit);
    }
    if (fcType === "Deconsolidation") {
      this.props.fetchDeconsRecords(this.buildQueryString(), pageNo, limit);
    }
  }

  paginationHandler(pageNo, limit) {
    const { fcType } = this.props
    if (fcType === "Consolidation") {
      this.props.fetchConsRecords(this.buildQueryString(), pageNo, limit);
    }
    if (fcType === "Deconsolidation") {
      this.props.fetchDeconsRecords(this.buildQueryString(), pageNo, limit);
    }
  }

  render() {
    const { t, fcType, consResult, consTotalPage, consTotalRecord, deconsResult, deconsTotalRecord, deconsTotalPage } = this.props
    const { updatedRows } = this.state
    const disabled = updatedRows.length > 0
    return (
      <div>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={6}>
              <Field
                name="thu_id"
                component={InputField}
                readOnly={true}
                label={t('thu_id')} />
            </Grid.Column>
            <Grid.Column width={2} />
            <Grid.Column width={6}>
              <Field
                name="serial_no"
                component={InputField}
                readOnly={true}
                label={t('serial_no')} />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="document_wrapper">
            <Grid.Column width={16} >
              {fcType === "Consolidation" && <DataGrid
                rows={consResult}
                totalPages={consTotalPage}
                totalRecord={consTotalRecord}
                rowEdit={this.rowEdit}
                singleSelect={false}
                width={250}
                showSelectedCount={false}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                addRow={true}
                exportName='RS'
                dropSelectedRows={this.dropSelectedRows}
                columns={consolidationColumns}
                removeColumnHeaderFormatter={true}
              />}
              {fcType === "Deconsolidation" && <DataGrid
                rows={deconsResult}
                totalPages={deconsTotalPage}
                totalRecord={deconsTotalRecord}
                rowEdit={this.rowEdit}
                singleSelect={false}
                showSelectedCount={false}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                addRow={true}
                exportName='RS'
                dropSelectedRows={this.dropSelectedRows}
                columns={deconsolidationColumns}
                removeColumnHeaderFormatter={true}
              />}
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="text-center">
                <button id='save' type="button" className="primary btn-small btn-long"
                  disabled={!disabled}
                  onClick={this.save}> {t('saveBtn')}</button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}
HelpOnFcSeal = reduxForm({
  form: 'HelpOnFcSealForm'
})(HelpOnFcSeal);

const mapStateToProps = state => ({
  formValues: state.form.HelpOnFcSealForm,
  fcFormValues: state.form.FcConsDeconsForm,
  damageCode: state.masterReducer.options.damageCode,
  consResult: state.freightConversionReducer.cons_seal_result,
  consTotalRecord: state.freightConversionReducer.cons_seal_totalRecord,
  consTotalPage: state.freightConversionReducer.cons_seal_totalPage,
  deconsResult: state.freightConversionReducer.decons_seal_result,
  deconsTotalRecord: state.freightConversionReducer.decons_seal_totalRecord,
  deconsTotalPage: state.freightConversionReducer.decons_seal_totalPage,
})

const mapDispatchToProps = (dispatch) => ({
  fetchConsRecords: (queryString, pageNo, limit) =>
    dispatch(freightConversionAction.fetchConsolidationSeal(queryString, pageNo, limit)),
  saveFcConsSeal: (params) =>
    dispatch(freightConversionAction.saveConsolidationSeal(params)),
  deleteFcConsSeal: (params) =>
    dispatch(freightConversionAction.deleteConsolidationSeal(params)),
  getQuickCodeMaster: (type) =>
    dispatch(masterActions.getQuickCodeMaster(type)),
  fetchDeconsRecords: (queryString, pageNo, limit) =>
    dispatch(freightConversionAction.fetchDeconsolidationSeal(queryString, pageNo, limit)),
  saveFcDeConsSeal: (params) =>
    dispatch(freightConversionAction.saveDeconsolidationSeal(params)),
  deleteFcDeConsSeal: (params) =>
    dispatch(freightConversionAction.deleteDeconsolidationSeal(params)),
})

export default compose(withTranslation('fcSealNo'), connect(mapStateToProps, mapDispatchToProps))(HelpOnFcSeal);