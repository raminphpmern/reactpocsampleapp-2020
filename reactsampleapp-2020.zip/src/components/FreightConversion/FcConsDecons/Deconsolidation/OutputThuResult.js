import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { columns, viewColumns } from "./OutputThuHelper";
import InputField from "components/Common/InputField";
import InputSearchField from "components/Common/InputSearchField";
import { Field, reduxForm } from "redux-form";
import * as freightConversionAction from "actions/freightConversionAction";
import { withTranslation } from 'react-i18next';
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { SEARCH_WORD_COUNT } from "config";
import { compose } from 'redux';
import validate from '../Validation'
import _ from 'lodash';
import i18n from 'i18n';
import { AlertError, AlertSuccess } from "lib/Alert";

class OutputThuResult extends Component {
  constructor(props) {
    super(props)
    this.state = {
      disbledBtnOnConfirm: false,
      viewColumn: false,
      disbledScan: true
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.search = this.search.bind(this)
    this.setValue = this.setValue.bind(this)
  }

  componentDidMount() {
    const { match: { params }, result_header } = this.props
    if (params.fcNo) {
      const fc_No = params.fcNo;
      this.props.getFCViewOutputThuDecon(fc_No, 1, 10);
    }
    if (result_header) {
      const header = this.props.result_header
      this.props.initialize({ hmfch_fc_bay_id: header.hmfch_fc_bay_id, hmfch_to_bay_id: header.hmfch_to_bay_id })
    }
    let _self = this;
    let enterOfDispDocNumber = document.getElementById('hmhod_despatch_doc_no')
    enterOfDispDocNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let records = _self.props.result
        let formValues = _self.props.formValues && _self.props.formValues.values
        const ddNo = formValues["hmhod_despatch_doc_no"]
        const documentFilter = _.filter(records, (data) => data.hmitd_despat_doc_no === ddNo)
        let existingRecordCheck = _.includes(_.map(records, 'hmitd_despat_doc_no'), ddNo)
        const fcExecNo = _self.props.fcForm.values.hmfch_fc_exec_no
        const fcExecType = _self.props.fcForm.values.hmfch_fc_exec_type
        let inputQty = 0;
        if (existingRecordCheck == true && documentFilter.length === 1) {
          const checkInputQuantity = _.find(records, (item) => {
            if (item.hmitd_despat_doc_no === ddNo) {
              if (item.hmitd_ip_qty === 0) {
                this.props.scannedRecords(item)
              } else {
                inputQty = parseInt(item.hmitd_ip_qty)
              }
            }
            return inputQty;
          })
          AlertSuccess(i18n.t("fcValidation:scanSuccess"))
        }
        if ((existingRecordCheck == false || (existingRecordCheck == true && documentFilter.length > 1)) && ddNo && ddNo.length >= SEARCH_WORD_COUNT) {
          _self.props.outputThuScan({ hmhid_despatch_doc_no: ddNo, fcexecutionno: fcExecNo, hmfch_fc_exec_type: fcExecType }, 1, 100)
        }
        if (existingRecordCheck == true && inputQty === 1) {
          AlertError(i18n.t("fcValidation:alreadyScanned"))
        }
        event.preventDefault()
      }
    })
    let enterOfSerialNumber = document.getElementById('hmhid_serialno')
    enterOfSerialNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let records = _self.props.result
        let formValues = _self.props.formValues && _self.props.formValues.values
        const serialNumber = formValues["hmhid_serialno"]
        const fcExecNo = _self.props.fcForm.values.hmfch_fc_exec_no
        const fcExecType = _self.props.fcForm.values.hmfch_fc_exec_type
        let ddNo = []
        if (formValues["hmhod_despatch_doc_no"] !== '') {
          ddNo = formValues["hmhod_despatch_doc_no"]
        }
        if (formValues["hmhod_despatch_doc_no"] === '') {
          ddNo = ""
        }
        const documentFilter = _.filter(records, (data) => data.hmitd_thu_serial_no === serialNumber)
        let existingRecordCheck = _.includes(_.map(records, 'hmitd_thu_serial_no'), serialNumber)
        let inputQty = 0;
        if (existingRecordCheck == true && documentFilter.length === 1) {
          const checkInputQuantity = _.find(records, (item) => {
            if (item.hmitd_thu_serial_no === serialNumber) {
              if (item.hmitd_ip_qty === 0) {
                this.props.scannedRecords(item)
              } else {
                inputQty = parseInt(item.hmitd_ip_qty)
              }
            }
            return inputQty;
          })
          AlertSuccess(i18n.t("fcValidation:scanSuccess"))
        }
        if ((existingRecordCheck == false) && (serialNumber && serialNumber.length >= SEARCH_WORD_COUNT)) {
          _self.props.outputThuScan({ hmhid_despatch_doc_no: ddNo, fcexecutionno: fcExecNo, hmhid_serialno: serialNumber, hmfch_fc_exec_type: fcExecType }, 1, 100)
        }
        if (existingRecordCheck == true && inputQty === 1) {
          AlertError(i18n.t("fcValidation:alreadyScanned"))
        }
        event.preventDefault()
      }
    })
  }

  changeLimit(pageNo, limit) {
    const fc_No = this.props.fcForm.values.hmfch_fc_exec_no
    this.props.getFCViewOutputThuDecon(fc_No, pageNo, limit)
  }

  paginationHandler(pageNo, limit) {
    const fc_No = this.props.fcForm.values.hmfch_fc_exec_no
    this.props.getFCViewOutputThuDecon(fc_No, pageNo, limit)
  }

  search(value) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      this.props.getFcMasters("bayid", queryString);
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "fcBayid") {
      hash["hmfch_fc_bay_id"] = option.wms_bay_id;
    }
    if (fieldName === "toBayid") {
      hash["hmfch_to_bay_id"] = option.wms_bay_id;
    }
    this.props.initialize(hash);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const status = nextProps.fcForm && nextProps.fcForm.values && nextProps.fcForm.values.hmfch_fc_status
    if (status === "Confirmed" || status === "Partially Closed") {
      this.setState({ disbledScan: true, disbledBtnOnConfirm: true, viewColumn: true })
    }
    if (status === "Created" && nextProps && nextProps.input_Thu_totalRecord > 0) {
      this.setState({ disbledScan: false })
    }
    if (nextProps && nextProps.input_Thu_totalRecord !== 1 || nextProps.result && nextProps.result.length === 0) {
      this.setState({ disbledScan: true })
    }
    if (nextProps && nextProps.deconExpandClick === "Expand") {
      this.setState({ viewColumn: false })
    }
  }

  componentDidUpdate(prevProps) {
    if (prevProps.result_header !== this.props.result_header) {
      const header = this.props.result_header
      this.props.initialize({ hmfch_fc_bay_id: header.hmfch_fc_bay_id, hmfch_to_bay_id: header.hmfch_to_bay_id })
    }
  }

  render() {
    const { t, result, totalPage, totalRecord, resetRecords, bayid } = this.props
    const { disbledBtnOnConfirm, disbledScan, viewColumn } = this.state
    return (
      <div>
        <Grid stackable >
          <Grid.Row>
            <Grid.Column width={8}>
              <Field
                name="hmhod_despatch_doc_no"
                component={InputField}
                label={t('dispatchDocument')}
                readOnly={disbledScan}
              />
            </Grid.Column>
            <Grid.Column width={8}>
              <Field
                name="hmhid_serialno"
                component={InputField}
                label={t('thuSerialNo')}
                readOnly={disbledScan}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <h3 className="thu-title">{t('title')}</h3>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16} className="freight-conversion">
              <div className="input-thu-grid">
                <DataGrid
                  columns={viewColumn ? viewColumns : columns}
                  width={200}
                  rows={result}
                  enableExport={true}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  initialize={resetRecords}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={2} />
            <Grid.Column width={6}>
              <Field
                name="hmfch_fc_bay_id"
                component={InputSearchField}
                label={t('fcBayId')}
                readOnly={disbledBtnOnConfirm}
                findByCompanyAndFLMName={this.search}
                id="fcBayid"
                options={bayid}
                fillNameValues={this.setValue}
                required={true}
              />
            </Grid.Column>
            <Grid.Column width={6}>
              <Field
                name="hmfch_to_bay_id"
                component={InputSearchField}
                label={t('toBayId')}
                readOnly={disbledBtnOnConfirm}
                findByCompanyAndFLMName={this.search}
                id="toBayid"
                options={bayid}
                fillNameValues={this.setValue}
                required={true}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

OutputThuResult = reduxForm({
  form: "OutputThuResultForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate
})(OutputThuResult);

const mapDispatchToProps = dispatch => ({
  getFCViewOutputThuDecon: (fc_No, pageNo, limit) =>
    dispatch(freightConversionAction.getFCViewOutputThu(fc_No, pageNo, limit)),
  getFcMasters: (action, queryStr) =>
    dispatch(freightConversionAction.getFcMasterDetails(action, queryStr)),
  outputThuScan: (data, pageNo, limit) =>
    dispatch(freightConversionAction.scanDeconRecords(data, pageNo, limit)),
  resetRecords: () => dispatch(freightConversionAction.deleteFcDeConRecords()),
  scannedRecords: (item) => dispatch(freightConversionAction.scanSuccesDecon(item))
});

const mapStateToProps = state => ({
  formValues: state.form.OutputThuResultForm,
  result_header: state.freightConversionReducer.result,
  result: state.freightConversionReducer.output_Thu_result,
  totalPage: state.freightConversionReducer.output_Thu_totalPage,
  totalRecord: state.freightConversionReducer.output_Thu_totalRecord,
  bayid: state.freightConversionReducer.options.bayid,
  fcForm: state.form.FcConsDeconsForm,
  input_Thu_totalRecord: state.freightConversionReducer.input_Thu_totalRecord,
  deconExpandClick: state.freightConversionReducer.deconExpandClick,
})

export default compose(withTranslation('fcOutputThu'), connect(mapStateToProps, mapDispatchToProps))(withRouter(OutputThuResult))