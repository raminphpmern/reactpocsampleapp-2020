import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { columns } from "./InputThuHelper";
import InputField from "components/Common/InputField";
import { Field, reduxForm } from "redux-form";
import { withTranslation } from 'react-i18next';
import * as freightConversionAction from "actions/freightConversionAction";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { SEARCH_WORD_COUNT } from "config";
import { compose } from 'redux';
import _ from 'lodash';
import i18n from 'i18n';
import { AlertError } from "lib/Alert";

class InputThuResult extends Component {
  constructor(props) {
    super(props)
    this.state = {
      disbledScan: true
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this);
    this.deleteSelectedRecords = this.deleteSelectedRecords.bind(this);
    this.columnsInfo = [];
  }

  componentDidMount() {
    const { match: { params } } = this.props
    this.columnsInfo = columns({ fetchInfo: this.props.getFCViewInputThuDecon });
    if (params.fcNo) {
      const fc_No = params.fcNo;
      this.props.getFCViewInputThuDecon(fc_No, 1, 10);
    }
    let _self = this;
    let enterOfDispDocNumber = document.getElementById('hmhid_despatch_doc_no')
    enterOfDispDocNumber.addEventListener('keypress', (event) => {
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let ddNo = formValues["hmhid_despatch_doc_no"]
        let fcExecNo = _self.props.fcForm.values.hmfch_fc_exec_no
        let fcExecType = _self.props.fcForm.values.hmfch_fc_exec_type
        if (ddNo && ddNo.length >= SEARCH_WORD_COUNT) {
          _self.props.outputThuSearch({ hmhid_despatch_doc_no: ddNo, fcexecutionno: fcExecNo, hmfch_fc_exec_type: fcExecType }, 1, 10)
        }
        event.preventDefault()
      }
    })
  }

  changeLimit(pageNo, limit) {
    const fc_No = this.props.fcForm.values.hmfch_fc_exec_no
    this.props.getFCViewInputThuDecon(fc_No, pageNo, limit)
  }

  paginationHandler(pageNo, limit) {
    const fc_No = this.props.fcForm.values.hmfch_fc_exec_no
    this.props.getFCViewInputThuDecon(fc_No, pageNo, limit)
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const status = nextProps.fcForm && nextProps.fcForm.values && nextProps.fcForm.values.hmfch_fc_status
    if (status === "Created") {
      this.setState({ disbledScan: false })
    }
    if (status === "Confirmed" || status === "Partially Closed") {
      this.setState({ disbledScan: true })
    }
    if (nextProps && nextProps.totalRecord >= 1) {
      this.setState({ disbledScan: true })
    }
  }

  deleteSelectedRecords(rows) {
    const { deleteDeConsolidationInputRecords, fcForm, resetRecords } = this.props
    if (fcForm.values.hmfch_fc_status === "Created") {
      deleteDeConsolidationInputRecords({
        hmfch_fc_exec_no: fcForm.values.hmfch_fc_exec_no,
        hmitd_despat_doc_no: _.map(rows, 'hmitd_despat_doc_no'),
        data: rows, form: fcForm.values.hmfch_fc_exec_type,
      })
      resetRecords()
    }
    else {
      AlertError(i18n.t('fcValidation:alreadyConfirmed'))
    }
  }

  render() {
    const { t, result, totalPage, totalRecord, resetRecords } = this.props
    const { disbledScan } = this.state
    return (
      <div>
        <Grid stackable >
          <Grid.Row>
            <Grid.Column width={8}>
              <Field
                name="hmhid_despatch_doc_no"
                component={InputField}
                label={t('dispatchDocument')}
                readOnly={disbledScan}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <h3 className="thu-title">{t('title')}</h3>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16} className="freight-conversion">
              <div className="input-thu-grid">
                <DataGrid
                  columns={this.columnsInfo}
                  width={200}
                  rows={result}
                  enableExport={true}
                  totalPages={totalPage}
                  totalRecord={totalRecord}
                  initialize={resetRecords}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  showCheckbox={true}
                  deleteRow={true}
                  dropSelectedRows={this.deleteSelectedRecords}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={3}>
              <button type="button" className="secondary btn-small nav-btn">
                {t('compute')}
              </button>
            </Grid.Column>
            <Grid.Column width={6}>
              <Field
                name="requiredVolume"
                component={InputField}
                label={t('requiredVolume')}
                readOnly={true}
              />
            </Grid.Column>
            <Grid.Column width={6}>
              <Field
                name="requiredWeight"
                component={InputField}
                label={t('requiredWeight')}
                readOnly={true}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    )
  }
}

InputThuResult = reduxForm({
  form: "InputThuResultForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
})(InputThuResult);

const mapDispatchToProps = dispatch => ({
  getFCViewInputThuDecon: (fc_No, pageNo, limit, exec_no) =>
    dispatch(freightConversionAction.getFCViewInputThu(fc_No, pageNo, limit, exec_no)),
  resetRecords: () => dispatch(freightConversionAction.deleteFcDeConRecords()),
  deleteDeConsolidationInputRecords: (params) =>
    dispatch(freightConversionAction.deleteFcInputRecords(params)),
  outputThuSearch: (data, pageNo, limit) =>
    dispatch(freightConversionAction.fcInputThuFetch(data, pageNo, limit)),
});

const mapStateToProps = state => ({
  formValues: state.form.InputThuResultForm,
  result: state.freightConversionReducer.input_Thu_result,
  totalPage: state.freightConversionReducer.input_Thu_totalPage,
  totalRecord: state.freightConversionReducer.input_Thu_totalRecord,
  fcForm: state.form.FcConsDeconsForm
})

export default compose(withTranslation('fcInputThu'), connect(mapStateToProps, mapDispatchToProps))(withRouter(InputThuResult))