import i18n from 'i18n';
import React from "react";
import HelpOnFcSeal from '../HelpOnFcSeal';
import LinkPopUp from 'components/Common/DataGrid/LinkPopUp';

const sealNoPopUp = <LinkPopUp name='Seal No' defaultValue='Seal No'> <HelpOnFcSeal fcType='Deconsolidation' /> </LinkPopUp>

const deConsolidationFormatter = (row, fetchInfo) => <button id='serach' type='button' className="primary"
  onClick={() => { fetchInfo(row.row.hmitd_despat_doc_no, 1, 10, row.row.hmitd_fc_exec_no) }}>
  >>>
</button>

export const columns = (props) => [
  { key: "ddh_dispatch_doc_type", name: i18n.t("fcInputThu:dispatchDocumentType") },
  { key: "hmitd_despat_doc_no", name: i18n.t("fcInputThu:dispatchDocNo") },
  { key: "ddh_dispatch_doc_date", name: i18n.t("fcInputThu:dispatchDocDate") },
  { key: "hmitd_thu_id", name: i18n.t("fcInputThu:thuId") },
  { key: "ddtd_thu_desc", name: i18n.t("fcInputThu:thuDescription") },
  { key: "hmitd_total_thu_qty", name: i18n.t("fcInputThu:totalQty") },
  { key: "hmitd_bal_thu_qty", name: i18n.t("fcInputThu:balanceQty") },
  { key: "hmitd_ip_qty", name: i18n.t("fcInputThu:inputQty"), editable: true },
  { key: "hmitd_thu_uom", name: i18n.t("fcInputThu:uom") },
  { key: "hmitd_thu_qty", name: i18n.t("fcInputThu:qty") },
  { key: "hmitd_qtyuom", name: i18n.t("fcInputThu:qtyUom") },
  { key: "hmitd_thu_serial_no", name: i18n.t("fcInputThu:serialNo") },
  { key: "hmitd_thu_seal_no", name: i18n.t("fcInputThu:sealNo"), formatter: sealNoPopUp, getRowMetaData: (row) => row },
  { key: "ddtsd_length", name: i18n.t("fcInputThu:length") },
  { key: "ddtsd_breadth", name: i18n.t("fcInputThu:width") },
  { key: "ddtsd_height", name: i18n.t("fcInputThu:height") },
  { key: "ddtsd_lbh_uom", name: i18n.t("fcInputThu:dimensionUom") },
  { key: "ddtsd_gross_weight", name: i18n.t("fcInputThu:weight") },
  { key: "ddtsd_gross_weight_uom", name: i18n.t("fcInputThu:weightUom") },
  { key: "totalvolume", name: i18n.t("fcInputThu:volume") },
  { key: "ddtd_thu_vol_uom", name: i18n.t("fcInputThu:volumeUom") },
  { key: "deconsolidate", name: "         ", formatter: (row) => deConsolidationFormatter(row, props.fetchInfo), getRowMetaData: (row) => row }
]