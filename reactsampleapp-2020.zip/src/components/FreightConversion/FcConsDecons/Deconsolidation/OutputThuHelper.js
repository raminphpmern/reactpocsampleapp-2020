import React from 'react';
import i18n from 'i18n';
import _ from 'lodash';
import MoreDetails from 'components/InventoryHub/Popup/MoreDetails';
import LinkPopUp from 'components/Common/DataGrid/LinkPopUp';

const moreDetailsFormatter = <LinkPopUp name={i18n.t("hubLoadGrid:moreDetails")} defaultValue='More Details'> <MoreDetails transactionType='DECONSOLIDATION' /> </LinkPopUp>

export const columns = [
  { key: "ddh_dispatch_doc_type", name: i18n.t("fcOutputThu:dispatchDocumentType") },
  { key: "hmitd_despat_doc_no", name: i18n.t("fcOutputThu:dispatchDocNo") },
  { key: "ddh_dispatch_doc_date", name: i18n.t("fcOutputThu:dispatchDocDate") },
  { key: "hmitd_thu_id", name: i18n.t("fcOutputThu:thuId") },
  { key: "ddtd_thu_desc", name: i18n.t("fcOutputThu:thuDescription") },
  { key: "hmitd_thu_qty", name: i18n.t("fcOutputThu:totalQty") },
  { key: "hmitd_bal_thu_qty", name: i18n.t("fcOutputThu:balanceQty") },
  { key: "hmitd_ip_qty", name: i18n.t("fcOutputThu:inputQty") },
  { key: "hmitd_thu_uom", name: i18n.t("fcOutputThu:uom") },
  { key: "hmitd_thu_qty", name: i18n.t("fcOutputThu:qty") },
  { key: "hmitd_thu_uom", name: i18n.t("fcOutputThu:qtyUom") },
  { key: "hmitd_thu_serial_no", name: i18n.t("fcOutputThu:serialNo") },
  { key: "ddtsd_length", name: i18n.t("fcOutputThu:length") },
  { key: "ddtsd_breadth", name: i18n.t("fcOutputThu:width") },
  { key: "ddtsd_height", name: i18n.t("fcOutputThu:height") },
  { key: "ddtsd_lbh_uom", name: i18n.t("fcOutputThu:dimensionUom") },
  { key: "ddtsd_gross_weight", name: i18n.t("fcOutputThu:weight") },
  { key: "ddtsd_gross_weight_uom", name: i18n.t("fcOutputThu:weightUom") },
  { key: "totalvolume", name: i18n.t("fcOutputThu:volume") },
  { key: "ddtd_thu_vol_uom", name: i18n.t("fcOutputThu:volumeUom") },
  { key: "moreDetails", name: i18n.t("fcOutputThu:moreDetails"), formatter: moreDetailsFormatter, getRowMetaData: (row) => row },
]

export const viewColumns = [
  { key: "ddh_dispatch_doc_type", name: i18n.t("fcOutputThu:dispatchDocumentType") },
  { key: "hmotd_despat_doc_no", name: i18n.t("fcOutputThu:dispatchDocNo") },
  { key: "ddh_dispatch_doc_date", name: i18n.t("fcOutputThu:dispatchDocDate") },
  { key: "hmotd_thu_id", name: i18n.t("fcOutputThu:thuId") },
  { key: "hmotd_thu_desc", name: i18n.t("fcOutputThu:thuDescription") },
  { key: "hmotd_thu_qty", name: i18n.t("fcOutputThu:totalQty") },
  { key: "hmitd_bal_thu_qty", name: i18n.t("fcOutputThu:balanceQty") },
  { key: "hmitd_ip_qty", name: i18n.t("fcOutputThu:inputQty") },
  { key: "hmotd_thu_uom", name: i18n.t("fcOutputThu:uom") },
  { key: "hmotd_thu_qty", name: i18n.t("fcOutputThu:qty") },
  { key: "hmotd_thu_uom", name: i18n.t("fcOutputThu:qtyUom") },
  { key: "hmotd_thu_serial_no", name: i18n.t("fcOutputThu:serialNo") },
  { key: "hmotd_thu_length", name: i18n.t("fcOutputThu:length") },
  { key: "hmotd_thu_width", name: i18n.t("fcOutputThu:width") },
  { key: "hmotd_thu_height", name: i18n.t("fcOutputThu:height") },
  { key: "hmotd_thu_dm_uom", name: i18n.t("fcOutputThu:dimensionUom") },
  { key: "hmotd_thu_weight", name: i18n.t("fcOutputThu:weight") },
  { key: "hmotd_thu_wt_uom", name: i18n.t("fcOutputThu:weightUom") },
  { key: "hmotd_thu_volume", name: i18n.t("fcOutputThu:volume") },
  { key: "hmotd_thu_vl_uom", name: i18n.t("fcOutputThu:volumeUom") },
  { key: "moreDetails", name: i18n.t("fcOutputThu:moreDetails"), formatter: moreDetailsFormatter, getRowMetaData: (row) => row },
]

export function fcOutputThuHelper(data, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  _.merge(tempHash, data)
  return tempHash
}