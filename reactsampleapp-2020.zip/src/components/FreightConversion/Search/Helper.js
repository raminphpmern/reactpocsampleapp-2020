import React from "react";
import i18n from 'i18n';
import { Link } from "react-router-dom";
import _ from 'lodash';

class LinkFormatter extends React.Component {
  render() {
    const hmfch_fc_exec_no = this.props.dependentValues.rowData.hmfch_fc_exec_no;
    return <Link to={`/hub/freightConversion/${hmfch_fc_exec_no}`}>{hmfch_fc_exec_no}</Link>
  }
};

export const columns = [
  { key: "hmfch_fc_exec_type", name: i18n.t("freightConversionGrid:fcExecutionType") },
  {
    key: "hmfch_fc_exec_no", name: i18n.t("freightConversionGrid:fcExecutionNo"),
    formatter: LinkFormatter, getRowMetaData: (rowData, columnInfo) => {
      return { rowData, columnInfo };
    }
  },
  { key: "hmfch_fc_exec_date", name: i18n.t("freightConversionGrid:fcExecutionDate") },
  { key: "hmfch_fc_status", name: i18n.t("freightConversionGrid:status") },
  { key: "hmitd_thu_qty", name: i18n.t("freightConversionGrid:inputThuQty") },
  { key: "hmitd_thu_uom", name: i18n.t("freightConversionGrid:qtyUom") },
  { key: "hmotd_thu_qty", name: i18n.t("freightConversionGrid:outputThuQty") },
  { key: "hmotd_thu_uom", name: i18n.t("freightConversionGrid:qtyUom") },
  { key: "hmfch_emp_id", name: i18n.t("freightConversionGrid:employee") },
  { key: "hmfch_start_date", name: i18n.t("freightConversionGrid:startDateTime") },
  { key: "hmfch_end_date", name: i18n.t("freightConversionGrid:endDateTime") },
  { key: "hmfch_emp_id1", name: i18n.t("freightConversionGrid:employee") },
  { key: "hmfch_add_emp_id", name: i18n.t("freightConversionGrid:addlEmployee") }
]

export function fcSearchHelper(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["hmfch_fc_exec_type"]) {
      if (hash["hmfch_fc_exec_type"].value == 'consolidation') {
        hash["hmfch_fc_exec_type"] = 'CON'
      }
      if (hash["hmfch_fc_exec_type"].value == 'deconsolidation') {
        hash["hmfch_fc_exec_type"] = 'DCON'
      }
    }
    if (hash["hmfch_fc_exec_no"])
      hash["hmfch_fc_exec_no"] = hash["hmfch_fc_exec_no"].toUpperCase();
    if (hash["hmfch_fc_exec_date"] === "Invalid date")
      hash["hmfch_fc_exec_date"] = null;
    if (hash["ddh_dispatch_doc_date"] === "Invalid date")
      hash["ddh_dispatch_doc_date"] = null;
    if (hash["ddh_dispatch_doc_type"])
      hash["ddh_dispatch_doc_type"] = 'CN';
    return hash
  } else {
    return {}
  }
}

export function helpOfDispatchDocHelper(values) {
  if (values) {
    let hash = _.cloneDeep(values);
    if (hash["ddh_dispatch_doc_type"])
      hash["ddh_dispatch_doc_type"] = hash["ddh_dispatch_doc_type"].value;
    if (hash["ddh_dispatch_doc_status"])
      hash["ddh_dispatch_doc_status"] = hash["ddh_dispatch_doc_status"].value;
    return hash
  } else {
    return {}
  }
}