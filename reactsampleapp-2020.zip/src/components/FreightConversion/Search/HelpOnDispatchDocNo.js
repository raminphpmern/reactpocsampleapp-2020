import React, { Component } from "react";
import { Field, reduxForm } from "redux-form";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import InputField from "components/Common/InputField";
import DateTimePicker from "components/Common/DateTimePicker";
import DropDown from "components/Common/Dropdown";
import DataGrid from "components/Common/DataGrid";
import { helpOfDispatchDocHelper } from "./Helper";
import { helpOfFcScreens, resetHelpScreenRecords } from "actions/freightConversionAction";
import { loadDispatchDefaults } from "actions/dispatchDocumentAction";
import "../FreightConversion.css";
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import i18n from 'i18n';

const columns = [
  { key: "ddh_dispatch_doc_no", name: i18n.t('helpOnDispatchDocNoGird:no') },
  { key: "ddh_dispatch_doc_date", name: i18n.t('helpOnDispatchDocNoGird:date') },
  { key: "ddh_customer_id", name: i18n.t('helpOnDispatchDocNoGird:customerId') },
  { key: "wms_customer_name", name: i18n.t('helpOnDispatchDocNoGird:customerName') },
  { key: "ddh_consignee_id", name: i18n.t('helpOnDispatchDocNoGird:consigneeId') },
  { key: "wms_consignee_desc", name: i18n.t('helpOnDispatchDocNoGird:consigneeName') },
  { key: "ddh_consignor_id", name: i18n.t('helpOnDispatchDocNoGird:consignorId') },
  { key: "wms_consignor_desc", name: i18n.t('helpOnDispatchDocNoGird:consignorName') },
  { key: "ddh_location", name: i18n.t('helpOnDispatchDocNoGird:location') },
  { key: "wms_div_code", name: i18n.t('helpOnDispatchDocNoGird:division') }
]

class HelpOnDispatchDocNo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIds: null
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.selectDispatchDocNo = this.selectDispatchDocNo.bind(this)
  }

  componentDidMount() {
    const {
      doc_status,
      dispatch_type,
      getDispatchMasterValues
    } = this.props
    if (doc_status.length === 0) {
      getDispatchMasterValues("status", "doc_status")
    }
    if (dispatch_type.length === 0) {
      getDispatchMasterValues("document_type", "dispatch_type")
    }
  }

  changeLimit(pageNo, limit) {
    this.props.loadHelpOnDocNo(helpOfDispatchDocHelper(this.props.formValues.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.loadHelpOnDocNo(helpOfDispatchDocHelper(this.props.formValues.values), pageNo, limit);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  formSubmit(values) {
    this.props.loadHelpOnDocNo(helpOfDispatchDocHelper(values), 1, 10);
  }

  selectDispatchDocNo() {
    const { close } = this.props
    const { selectedIds } = this.state
    if (selectedIds !== null) {
      this.props.getDispatchDocNo(selectedIds[0].ddh_dispatch_doc_no)
      close('help', 'dispatchDocNoHelp')
    }
  }

  render() {
    const { handleSubmit, result, totalPage, totalRecord, t, resetData, doc_status, dispatch_type } = this.props
    return (
      <form onSubmit={handleSubmit(this.formSubmit)}>
        <Grid stackable className="freight-conversion">
          <Grid.Row>
            <Grid.Column width={5}>
              <Field
                name="ddh_dispatch_doc_type"
                component={DropDown}
                clearable={true}
                options={dispatch_type}
                label={t('ddType')} />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row className="help-dispatch-doc-no">
            <Grid.Column width={5}>
              <Field
                name="ddh_dispatch_doc_no"
                component={InputField}
                clearable={true}
                label={t('no')} />
              <Field
                name="ddh_customer_id"
                component={InputField}
                clearable={true}
                label={t('customerId')} />
              <Field
                name="ddh_consignor_id"
                component={InputField}
                clearable={true}
                label={t('consignorId')} />
              <Field
                name="ddh_consignee_id"
                component={InputField}
                clearable={true}
                label={t('consigneeId')} />
              <Field
                name="ddh_ship_from_id"
                component={InputField}
                clearable={true}
                label={t('shipFromId')} />
              <Field
                name="ddh_ship_to_id"
                component={InputField}
                clearable={true}
                label={t('shipToId')} />
            </Grid.Column>
            <Grid.Column width={5}>
              <Field
                name="ddh_dispatch_doc_date"
                component={DateTimePicker}
                clearable={true}
                label={t('date')} />
              <Field
                name="ddh_dispatch_doc_status"
                component={DropDown}
                clearable={true}
                options={doc_status}
                label={t('status')} />
              <Field
                name="ddh_cust_ref_no"
                component={InputField}
                clearable={true}
                label={t('cusRefNo')} />
              <Field
                name="ddh_location"
                component={InputField}
                clearable={true}
                label={t('location')} />
              <Field
                name="division"
                component={InputField}
                clearable={true}
                label={t('division')} />
            </Grid.Column>
            <Grid.Column width={5}>
              <Field
                name="ddh_carrier_id"
                component={InputField}
                clearable={true}
                label={t('carrierId')} />
              <Field
                name="carrierName"
                component={InputField}
                clearable={true}
                label={t('carrierName')} />
              <Field
                name="ddh_vessel_flight_rail_number"
                component={InputField}
                clearable={true}
                label={t('vesselNo')} />
              <Field
                name="ddh_mbl_of_hbl"
                component={InputField}
                clearable={true}
                label={t('mbl')} />
              <Field
                name="ddh_mawb_of_hawb"
                component={InputField}
                clearable={true}
                label={t('mawb')} />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="help-search">
                <button className="primary"> {t('searchBtn')} </button>
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={columns}
                rows={result}
                totalRecord={totalRecord}
                totalPages={totalPage}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                enableExport={true}
                initialize={resetData}
                singleSelect={true} />
              <div className="get-details">
                <button type="button" className="primary" onClick={this.selectDispatchDocNo}> {t('okBtn')} </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </form>
    )
  }
}

HelpOnDispatchDocNo = reduxForm({
  form: 'HelpOnDispatchDocNoForm',
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
})(HelpOnDispatchDocNo);

const mapDispatchToProps = (dispatch) => ({
  loadHelpOnDocNo: (params, pageNo, limit) =>
    dispatch(helpOfFcScreens('helpDispatch', params, pageNo, limit)),
  getDispatchMasterValues: (action, stateName) =>
    dispatch(loadDispatchDefaults(action, stateName)),
  resetData: () => dispatch(resetHelpScreenRecords())
})

const mapStateToProps = state => ({
  formValues: state.form.HelpOnDispatchDocNoForm,
  result: state.freightConversionReducer.dispatch_doc_help_result,
  totalPage: state.freightConversionReducer.dispatch_doc_help_totalPage,
  totalRecord: state.freightConversionReducer.dispatch_doc_help_totalRecord,
  doc_status: state.dispatchReducer.options.doc_status,
  dispatch_type: state.dispatchReducer.options.dispatch_type,
})

export default compose(withTranslation('helpOnDispatchDocNoForm'), connect(mapStateToProps, mapDispatchToProps))(HelpOnDispatchDocNo);