import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { connect } from "react-redux";
import { Grid, Menu } from "semantic-ui-react";
import { columns } from "./Helper";
import { fcSearchHelper } from './Helper';
import { freightConversionSearch, resetRecords } from "actions/freightConversionAction";
import _ from 'lodash';

class Result extends Component {
  constructor(props) {
    super(props)
    this.state = {
      activeItem: '',
      limit: '10',
      pageNo: '1',
      createdCount: 0,
      confirmedCount: 0,
      partiallyClosedCount: 0,
      totalCount: 0,
      showSubMenu: false
    }
    this.handleItemClick = this.handleItemClick.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
  }

  handleItemClick(e, { name }) {
    const { pageNo, limit } = this.state
    const { freightConversionSearchForm } = this.props
    this.setState({ activeItem: name })
    let filter = fcSearchHelper(freightConversionSearchForm.values)
    _.merge(filter, { periodic_filter: name })
    this.props.fcSearch(filter, pageNo, limit);
  }

  changeLimit(pageNo, limit) {
    const { activeItem } = this.state
    this.setState({ pageNo: pageNo, limit: limit })
    const formValues = this.props.freightConversionSearchForm.values;
    const datas = Object.assign({}, { ...formValues }, { periodic_filter: activeItem })
    this.props.fcSearch(fcSearchHelper(datas), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    const { activeItem } = this.state
    const formValues = this.props.freightConversionSearchForm.values;
    const datas = Object.assign({}, { ...formValues }, { periodic_filter: activeItem })
    this.props.fcSearch(fcSearchHelper(datas), pageNo, limit);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const fcCount = nextProps.count
    if (this.props.freightConversionSearchForm && this.props.freightConversionSearchForm.values !== nextProps.freightConversionSearchForm.values) {
      this.setState({ activeItem: '', pageNo: '1', limit: '10' })
    }
    if (fcCount) {
      let createdQty = 0
      let confirmedQty = 0
      let partiallyClosedQty = 0
      let totalQty = 0
      const counts = _.filter(fcCount, (data) => {
        if (data.wms_paramcode === "CR") {
          createdQty = data.status_qty
          return createdQty
        }
        if (data.wms_paramcode === "CO") {
          confirmedQty = data.status_qty
          return confirmedQty
        }
        if (data.wms_paramcode === "PC") {
          partiallyClosedQty = data.status_qty
          return partiallyClosedQty
        }
      })
      totalQty = parseInt(createdQty) + parseInt(confirmedQty) + parseInt(partiallyClosedQty)
      this.setState({ createdCount: createdQty, confirmedCount: confirmedQty, partiallyClosedCount: partiallyClosedQty, totalCount: totalQty })
    }
    if (fcCount !== 0) {
      this.setState({ showSubMenu: true })
    }
  }

  render() {
    const { result, totalPage, totalRecord, resetData } = this.props
    const { activeItem, totalCount, createdCount, confirmedCount, partiallyClosedCount, showSubMenu } = this.state
    return (
      <div>
        {showSubMenu == true &&
          < Grid stackable>
            <Grid.Row className="no-padding">
              <Grid.Column width={6} className='trip-hub'>
                <Menu pointing >
                  <Menu.Item
                    name='All'
                    active={activeItem === 'All'}
                    onClick={this.handleItemClick}
                  >
                    All ({totalCount})

                  </Menu.Item>
                  <Menu.Item
                    name='CR'
                    active={activeItem === 'Created'}
                    onClick={this.handleItemClick}
                  >
                    Created ({createdCount})
                  </Menu.Item>
                  <Menu.Item
                    name='PC'
                    active={activeItem === 'Partially Closed'}
                    onClick={this.handleItemClick}
                  >
                    Partially Closed ({partiallyClosedCount})
                  </Menu.Item>
                  <Menu.Item
                    name='CO'
                    active={activeItem === 'Completed'}
                    onClick={this.handleItemClick}
                  >
                    Completed ({confirmedCount})
                  </Menu.Item>
                </Menu>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        }
        <Grid stackable >
          <Grid.Row>
            <Grid.Column width={16}>
              <div>
                <DataGrid
                  columns={columns}
                  rows={result}
                  totalRecord={totalRecord}
                  totalPages={totalPage}
                  width={200}
                  enableExport={true}
                  initialize={resetData}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                />
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div >
    )
  }
}

const mapDispatchToProps = (dispatch) => ({
  fcSearch: (data, pageNo, pageLimit) =>
    dispatch(freightConversionSearch(data, pageNo, pageLimit)),
  resetData: () => dispatch(resetRecords())
})

const mapStateToProps = state => ({
  result: state.freightConversionReducer.result,
  totalPage: state.freightConversionReducer.totalPage,
  totalRecord: state.freightConversionReducer.totalRecord,
  count: state.freightConversionReducer.count,
  freightConversionSearchForm: state.form.FreightConversionSearchForm,
})

export default connect(mapStateToProps, mapDispatchToProps)(Result)