import React, { Component } from "react";
import { Field, reduxForm } from "redux-form";
import { Grid } from "semantic-ui-react";
import { connect } from "react-redux";
import InputField from "components/Common/InputField";
import DataGrid from "components/Common/DataGrid";
import { withTranslation } from 'react-i18next';
import { helpOfFcScreens, resetHelpScreenRecords } from "actions/freightConversionAction";
import { compose } from 'redux';
import i18n from 'i18n';

const columns = [
  { key: "ddtsd_thu_serial_no", name: i18n.t('helpOnSerialNoGird:serialNo') },
  { key: "ddtd_thu_id", name: i18n.t('helpOnSerialNoGird:thuId') },
  { key: "ddtd_thu_desc", name: i18n.t('helpOnSerialNoGird:thuDesc') },
  { key: "ddtd_class_stores", name: i18n.t('helpOnSerialNoGird:classOfStore') },
  { key: "ddtd_billing_status", name: i18n.t('helpOnSerialNoGird:status') }
]

class HelpOnSerialNo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIds: null
    }
    this.paginationHandler = this.paginationHandler.bind(this)
    this.selectedRows = this.selectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.formSubmit = this.formSubmit.bind(this)
    this.selectThuSerialNo = this.selectThuSerialNo.bind(this)
  }

  changeLimit(pageNo, limit) {
    this.props.loadHelpOnSerialNo((this.props.formValues.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.loadHelpOnSerialNo((this.props.formValues.values), pageNo, limit);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  formSubmit(values) {
    this.props.loadHelpOnSerialNo((values), 1, 10);
  }

  selectThuSerialNo() {
    const { close } = this.props
    const { selectedIds } = this.state
    if (selectedIds !== null) {
      this.props.getSerialNo(selectedIds[0].ddtsd_thu_serial_no)
      close('help', 'serialNoHelp')
    }
  }

  render() {
    const { handleSubmit, result, totalPage, totalRecord, t, resetData } = this.props
    return (
      <form onSubmit={handleSubmit(this.formSubmit)}>
        <Grid stackable>
          <Grid.Row>
            <Grid.Column width={5}>
              <Field
                name="ddtd_thu_id"
                component={InputField}
                clearable={true}
                label={t('thuId')} />
              <Field
                name="serialNoFrom"
                component={InputField}
                clearable={true}
                label={t('serialNoFrom')} />
            </Grid.Column>
            <Grid.Column width={5}>
              <Field
                name="ddtd_thu_desc"
                component={InputField}
                clearable={true}
                label={t('thuDesc')} />
              <Field
                name="serialNoTo"
                component={InputField}
                clearable={true}
                label={t('serialNoTo')} />
            </Grid.Column>
            <Grid.Column width={5}>
              <Field
                name="status"
                component={InputField}
                clearable={true}
                label={t('status')} />
              <Field
                name="ddtd_class_stores"
                component={InputField}
                clearable={true}
                label={t('classOfStore')} />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <div className="help-search">
                <button className="primary"> {t('searchBtn')} </button>
              </div>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={16}>
              <DataGrid
                columns={columns}
                rows={result}
                totalRecord={totalRecord}
                totalPages={totalPage}
                selectedRows={this.selectedRows}
                changeLimit={this.changeLimit}
                paginationHandler={this.paginationHandler}
                enableExport={true}
                initialize={resetData}
                singleSelect={true} />
              <div className="get-details">
                <button id='select' type="submit" className="primary" onClick={this.selectThuSerialNo}> {t('okBtn')} </button>
              </div>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </form>
    )
  }
}

HelpOnSerialNo = reduxForm({
  form: 'HelpOnSerialNoForm',
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
})(HelpOnSerialNo);

const mapDispatchToProps = (dispatch) => ({
  loadHelpOnSerialNo: (params, pageNo, limit) =>
    dispatch(helpOfFcScreens('helpSerialNo', params, pageNo, limit)),
  resetData: () => dispatch(resetHelpScreenRecords())
})

const mapStateToProps = state => ({
  formValues: state.form.HelpOnSerialNoForm,
  result: state.freightConversionReducer.serial_no_help_result,
  totalPage: state.freightConversionReducer.serial_no_help_totalPage,
  totalRecord: state.freightConversionReducer.serial_no_help_totalRecord,
})

export default compose(withTranslation('helpOnSerialNoForm'), connect(mapStateToProps, mapDispatchToProps))(HelpOnSerialNo);