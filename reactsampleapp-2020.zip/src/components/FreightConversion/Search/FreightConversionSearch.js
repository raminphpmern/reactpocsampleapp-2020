import React, { Component } from "react";
import InputField from "components/Common/InputField";
import DropDown from "components/Common/Dropdown";
import { Icon } from 'semantic-ui-react'
import DateTimePicker from "components/Common/DateTimePicker";
import Checkbox from 'components/Common/Checkbox';
import { getValue } from "lib/LocalStorage";
import { reduxForm, Field } from "redux-form";
import { Grid } from "semantic-ui-react";
import { withTranslation } from 'react-i18next';
import * as freightConversionAction from "actions/freightConversionAction";
import { connect } from "react-redux";
import { compose } from 'redux';
import { fcSearchHelper } from './Helper';
import history from 'routes/history';
import i18n from 'i18n';
import "../FreightConversion.css";
import Popup from 'components/Common/Popup';
import _ from 'lodash';
import HelpOnSerialNo from "./HelpOnSerialNo";
import HelpOnDispatchDocNo from "./HelpOnDispatchDocNo";

const fcTypes = [
  { value: 'consolidation', label: i18n.t("fcConsDeconsForm:consolidation") },
  { value: 'deconsolidation', label: i18n.t("fcConsDeconsForm:deconsolidation") },
];

const docType = [
  { value: 'consignmentNote', label: i18n.t("fcConsDeconsForm:consignmentNote") },
];

class FreightConversionSearch extends Component {
  constructor(props) {
    super(props)
    this.state = {
      serialNoHelp: false,
      dispatchDocNoHelp: false,
      currentHelp: ''
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.toggle = this.toggle.bind(this)
    this.getSerialNoFromHelp = this.getSerialNoFromHelp.bind(this)
    this.getDispatchDocNoFromHelp = this.getDispatchDocNoFromHelp.bind(this)
  }

  componentDidMount() {
    this.props.resetRecords()
    if (getValue('currentBranch')) {
      let currentBranch = JSON.parse(getValue('currentBranch') ? getValue('currentBranch') : {})
      if (currentBranch.value) {
        this.props.initialize({ division: currentBranch.value, location: currentBranch.wms_loc_code });
      }
    }
  }

  formSubmit(values) {
    this.props.fcSearch(fcSearchHelper(values), 1, 10);
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  getSerialNoFromHelp(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["hmitd_thu_serial_no"] = data
      this.props.initialize(hash)
    }
  }

  getDispatchDocNoFromHelp(data) {
    if (data && this.props.formValues && this.props.formValues.values) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["hmitd_despat_doc_no"] = data
      this.props.initialize(hash)
    }
  }

  render() {
    const { t, handleSubmit } = this.props
    const { serialNoHelp, dispatchDocNoHelp, currentHelp } = this.state
    return (
      <div className="freight-conversion">

        <Popup size="fullscreen" open={dispatchDocNoHelp} close={() => { this.toggle('help', 'dispatchDocNoHelp') }} header="Help on Dispatch Document No." description={<HelpOnDispatchDocNo
          getDispatchDocNo={this.getDispatchDocNoFromHelp} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={serialNoHelp} close={() => { this.toggle('help', 'serialNoHelp') }} header="Help on THU Serial No." description={<HelpOnSerialNo
          getSerialNo={this.getSerialNoFromHelp} close={this.toggle} name={currentHelp} />} />

        <form onSubmit={handleSubmit(this.formSubmit)}>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="division"
                  component={InputField}
                  label={t('division')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="location"
                  component={InputField}
                  label={t('location')}
                  readOnly={true}
                />
              </Grid.Column>
              <Grid.Column width={5} />
              <Grid.Column width={3}>
                <button type="button" className="secondary btn-small nav-btn" onClick={() => history.push('/hub/freightConversion/consDecons')}>
                  <Icon name='add' /> {t('new-freight-conversion')}
                </button>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="hmfch_fc_exec_type"
                  component={DropDown}
                  label={t('fcExecutionType')}
                  options={fcTypes}
                  clearable={true}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmfch_fc_exec_no"
                  component={InputField}
                  label={t('fcExecutionNo')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmfch_fc_exec_date"
                  component={DateTimePicker}
                  label={t('fcExecutionDate')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_type"
                  component={DropDown}
                  label={t('dispatchDocumentType')}
                  options={docType}
                  clearable={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={4}>
                <Field
                  name="hmitd_despat_doc_no"
                  component={InputField}
                  label={t('dispatchDocumentNo')}
                  iconName="search"
                  handleClick={this.toggle}
                  childName="dispatchDocNoHelp"
                  maxLength={18}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="ddh_dispatch_doc_date"
                  component={DateTimePicker}
                  label={t('dispatchDocumentDate')}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmitd_thu_serial_no"
                  component={InputField}
                  label={t('thuSerialNo')}
                  iconName="search"
                  handleClick={this.toggle}
                  childName="serialNoHelp"
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="thu_seal_no"
                  component={InputField}
                  label={t('thuSealNo')}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="no-padding">
              <Grid.Column width={12} />
              <Grid.Column className="fc-checkbox">
                <Field
                  name="completed"
                  component={Checkbox}
                  type="checkbox"
                  label={t('includeCompleted')}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row className="fc-button">
              <Grid.Column width={16}>
                <div className="text-center">
                  <button id='search' type="submit" className="primary">
                    {t('searchBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div >
    );
  }
}

FreightConversionSearch = reduxForm({
  form: "FreightConversionSearchForm",
})(FreightConversionSearch);

const mapDispatchToProps = dispatch => ({
  fcSearch: (data, pageNo, pageLimit) =>
    dispatch(freightConversionAction.freightConversionSearch(data, pageNo, pageLimit)),
  resetRecords: () => dispatch(freightConversionAction.resetRecords())
});

const mapStateToProps = state => ({
  formValues: state.form.FreightConversionSearchForm
});

export default compose(withTranslation('freightConversionForm'), connect(mapStateToProps, mapDispatchToProps))(FreightConversionSearch);