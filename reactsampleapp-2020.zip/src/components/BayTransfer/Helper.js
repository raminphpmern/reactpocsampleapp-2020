import React from 'react';
import i18n from 'i18n';
import InputSearchEditor from '../Common/DataGrid/InputSearchEditor';
import _ from "lodash";

export const columns = [
  { key: "hmhid_despatch_doc_no", name: i18n.t("bayTransferGrid:dispatchDocumentNo") },
  { key: "hmhid_thu_id", name: i18n.t("bayTransferGrid:thuId") },
  { key: "ddtd_thu_desc", name: i18n.t("bayTransferGrid:thuDescription") },
  { key: "hmhid_serialno", name: i18n.t("bayTransferGrid:thuSerialNumber") },
  { key: "reasonCode", name: i18n.t("bayTransferGrid:reasonCode"), editor: <InputSearchEditor propName='reason_code' /> },
  { key: "hmhid_bay_id", name: i18n.t("bayTransferGrid:bayId") },
  { key: "wms_bay_description", name: i18n.t("bayTransferGrid:bayDescription") },
]

export function showDispatchData(data, existingHash) {
  let tempHash = _.cloneDeep(existingHash)
  _.merge(tempHash, data)
  return tempHash
}