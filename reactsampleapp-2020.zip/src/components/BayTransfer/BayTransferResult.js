import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import { Grid } from "semantic-ui-react";
import { columns } from "./Helper";
import { connect } from "react-redux";
import { compose } from 'redux';
import { reduxForm, Field } from "redux-form";
import DateTimePicker from "components/Common/DateTimePicker";
import InputSearchField from "components/Common/InputSearchField";
import Checkbox from 'components/Common/Checkbox';
import InputField from "components/Common/InputField";
import * as bayTransferAction from "actions/bayTransferAction";
import { withTranslation } from 'react-i18next';
import { SEARCH_WORD_COUNT } from "config";
import Popup from 'components/Common/Popup';
import HelpOnEmployee from "components/CollectionSummary/HelpOnEmployee";
import _ from 'lodash';
import validate from "./Validation";
import { showDispatchData } from "./Helper";
import "./BayTransfer.css";
import { AlertError } from "lib/Alert";
import i18n from 'i18n';
import HelpOnEquipment from "components/HubLoadAndReceipt/Loading/HelpOnEquipment";

class BayTransferResult extends Component {
  constructor(props) {
    super(props)
    this.state = {
      employeeHelp: false,
      equipmentHelp: false,
      currentHelp: '',
      disableInputField: false,
      disableBaySelection: false,
      bayDesc: '',
      enableScan: false,
      disableBtn: false,
      disableEndTime: false,
      disableConfirm: true,
      updatedRows: [],
      msg: ''
    }
    this.toggle = this.toggle.bind(this)
    this.getEmployeeDetails = this.getEmployeeDetails.bind(this);
    this.getEquipmentDetails = this.getEquipmentDetails.bind(this);
    this.search = this.search.bind(this);
    this.rowEdit = this.rowEdit.bind(this);
    this.setValue = this.setValue.bind(this);
    this.deleteSelectedRecords = this.deleteSelectedRecords.bind(this)
  }

  componentDidMount() {
    this.props.resetRecords()
    const {
      currentUser,
      defaultuser
    } = this.props
    const locations = (currentUser && currentUser.locations) || [];
    if (locations.length > 0) {
      this.props.initialize({ location: locations[0].value, division: locations[0].wms_loc_code });
    }
    let _self = this;
    let enterOfDispDocNumber = document.getElementById('hmhid_despatch_doc_no')
    enterOfDispDocNumber.addEventListener('keypress', (event) => {
      _self.setState({ activeindex: [] })
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let hmbteh_bt_exec_no = _self.props.saveRecords.hmbteh_bt_exec_no
        const ddNo = formValues["hmhid_despatch_doc_no"]
        const bayId = formValues["hmhid_bay_id"]
        if (ddNo) {
          if (formValues.addtoVirtualBay === true) {
            _self.props.loadGridRecords({ hmhid_despatch_doc_no: ddNo, bt_exec_docno: hmbteh_bt_exec_no, hmhid_bay_id: bayId, addtoVirtualBay: true })
          }
          else {
            _self.props.loadGridRecords({ hmhid_despatch_doc_no: ddNo, bt_exec_docno: hmbteh_bt_exec_no, hmhid_bay_id: bayId })
          }
        }
        event.preventDefault()
      }
    })
    let enterOfSerialNumber = document.getElementById('hmhid_serialno')
    enterOfSerialNumber.addEventListener('keypress', (event) => {
      _self.setState({ activeindex: [] })
      if (event.keyCode === 13) {
        let formValues = _self.props.formValues && _self.props.formValues.values
        let hmbteh_bt_exec_no = _self.props.saveRecords.hmbteh_bt_exec_no
        const serialNo = formValues["hmhid_serialno"]
        const bayId = formValues["hmhid_bay_id"]
        if (serialNo) {
          if (formValues.addtoVirtualBay === true) {
            _self.props.loadGridRecords({ hmhid_serialno: serialNo, bt_exec_docno: hmbteh_bt_exec_no, hmhid_bay_id: bayId, addtoVirtualBay: true })
          }
          else {
            _self.props.loadGridRecords({ hmhid_serialno: serialNo, bt_exec_docno: hmbteh_bt_exec_no, hmhid_bay_id: bayId })
          }
        }
        event.preventDefault()
      }
    })
    this.props.getLoggedUser("defaultuser", "defaultuser")
    if (defaultuser && defaultuser.length > 0) {
      this.props.initialize({ wms_emp_employee_code: defaultuser[0].wms_emp_employee_code });
    }
  }

  toggle(modelType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  getEmployeeDetails(data) {
    if (data && this.props.formValues) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash["wms_emp_employee_code"] = data[0]["wms_emp_employee_code"]
      this.props.initialize(hash)
    }
  }

  getEquipmentDetails(data) {
    if (data && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["wms_eqp_equipment_id"] = data[0]["wms_eqp_equipment_id"]
      this.props.initialize(hash)
    }
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === 'employee') {
        this.props.getDetails("employee", queryString, fieldName);
      }
      if (fieldName === 'mhe') {
        this.props.getDetails("mhe", queryString, fieldName);
      }
      if (fieldName === 'stageid') {
        this.props.getDetails("stageid", queryString, fieldName);
      }
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "employee") {
      hash["wms_emp_employee_code"] = option.wms_emp_employee_code;
    }
    if (fieldName === "mhe") {
      hash["wms_eqp_equipment_id"] = option.wms_eqp_equipment_id;
    }
    if (fieldName === "stageid") {
      hash["hmhid_bay_id"] = option.wms_bay_id;
      hash["wms_bay_description"] = option.value;
    }
    this.props.initialize(hash);
  }

  saveBayTransferRecords() {
    const formValues = this.props.formValues.values
    this.props.BayTransferActivity("save", formValues)
  }

  confirmBayTransferRecords() {
    const formValues = this.props.formValues.values
    const bt_exec_docno = this.props.saveRecords.hmbteh_bt_exec_no
    const gridRecords = this.props.result

    if (this.props.formValues && this.props.formValues.values && this.props.formValues.values.hmbteh_status === "Draft") {
      if (gridRecords && gridRecords.length === 0) {
        AlertError(i18n.t('bayTransferValidation:noScan'))
      }
      else if (gridRecords && gridRecords.length > 0) {
        if (this.props.formValues && this.props.formValues.values && this.props.formValues.values.addtoVirtualBay === true) {
          let isValid = true
          let message = ''
          _.each(gridRecords, (row) => {
            if (!row.reasonCode) {
              isValid = false
              message = i18n.t('bayTransferValidation:reasonCodeReq')
              return false
            }
          })

          if (!isValid) {
            AlertError(message)
            return false
          }
        }
        const datas = Object.assign({}, { ...formValues, bt_exec_docno }, { gridRecords })
        this.props.BayTransferActivity("confirm", datas)
      }
    }
  }

  rowEdit(row, updateValue) {
    _.merge(row, updateValue)
    const response = _.reduce(this.props.result, (arr, item) => {
      if (item.hmhid_serialno === row.hmhid_serialno) {
        _.merge(item, updateValue)
        arr.push(item)
      }
      return arr
    }, [])
    this.setState({ updatedRows: response })
  }

  componentDidUpdate(prevProps) {
    if (this.props.saveRecords != null) {
      if (this.props.saveRecords !== prevProps.saveRecords) {
        const hash = _.cloneDeep(prevProps.formValues.values)
        this.props.initialize(showDispatchData({ hmbteh_status: this.props.saveRecords.hmbteh_status }, hash))
        if (this.props.saveRecords.hmbteh_status !== "Draft") {
          this.setState({ enableScan: false })
        }
      }
    }
    const { defaultuser } = this.props
    if (prevProps.defaultuser && prevProps.defaultuser.length === 0 && defaultuser.length > 0) {
      this.props.initialize({ wms_emp_employee_code: defaultuser[0].wms_emp_employee_code });
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.formValues && nextProps.formValues.values) {
      if (nextProps.formValues.values.addtoVirtualBay === true) {
        if (!nextProps.formValues.values.hmhid_bay_id) {
          this.setState({ disableBtn: false })
        }
        else {
          this.setState({ disableBtn: true })
        }
      }
      else {
        this.setState({ disableBtn: false })
      }
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.addtoVirtualBay === true) {
      this.setState({ disableBaySelection: true, bayDesc: "Virtual Bay" })
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.addtoVirtualBay === false) {
      this.setState({ disableInputField: false, disableBaySelection: false, bayDesc: "" })
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.hmbteh_status === "Draft") {
      this.setState({ enableScan: true, disableInputField: true })
    }
    if (nextProps.formValues && nextProps.formValues.values && nextProps.formValues.values.hmbteh_status === "Confirmed") {
      const hash = _.cloneDeep(nextProps.formValues.values)
      this.props.initialize(showDispatchData({ hmhid_despatch_doc_no: '', hmhid_serialno: '' }, hash))
      this.setState({ disableBtn: true, disableInputField: true, disableEndTime: true })
    }
  }

  deleteSelectedRecords(rows) {
    const { deleteBayTransferRecords, formValues, saveRecords } = this.props
    if (formValues.values.hmbteh_status === "Draft") {
      deleteBayTransferRecords({
        hmbted_bt_exec_no: saveRecords.hmbteh_bt_exec_no,
        hmhid_serialno: _.map(rows, 'hmhid_serialno'),
        hmhid_despatch_doc_no: _.map(rows, 'hmhid_despatch_doc_no'),
        data: rows, form: "BayTransfer"
      })
    } else {
      AlertError(i18n.t('bayTransferValidation:alreadyConfirmed'))
    }
  }

  render() {
    const { result, totalPage, employee, mhe, bayid, resetRecords, invalid, t } = this.props
    const { currentHelp, employeeHelp, disableInputField, bayDesc, enableScan, disableBtn, disableEndTime, disableBaySelection, equipmentHelp } = this.state;
    return (
      <div>
        <Popup size="fullscreen" open={employeeHelp} close={() => { this.toggle('help', 'employeeHelp') }} header={t('helpOnEmployee')} description={<HelpOnEmployee
          getEmployeeDetails={this.getEmployeeDetails} close={this.toggle} name={currentHelp} />} />

        <Popup size="fullscreen" open={equipmentHelp} close={() => { this.toggle('help', 'equipmentHelp') }} header={t('helpOnEquipment')} description={<HelpOnEquipment
          getEquipmentDetails={this.getEquipmentDetails} close={this.toggle} name={currentHelp} />} />

        <form>
          <Grid stackable className="fixed-grid">
            <Grid.Row className="no-padding" >
              <Grid.Column width={4}>
                <Field
                  name="hmhid_despatch_doc_no"
                  component={InputField}
                  label={t('dispatchDocument')}
                  readOnly={!enableScan}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmhid_serialno"
                  component={InputField}
                  label={t('thuSerialNo')}
                  readOnly={!enableScan}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  name="hmbteh_status"
                  component={InputField}
                  label={t('status')}
                  readOnly={true}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>
          <Grid stackable >
            <Grid.Row>
              <Grid.Column width={12}>
                <div className="bay-transfer-table">
                  <DataGrid
                    columns={columns}
                    width={250}
                    rows={result}
                    rowEdit={this.rowEdit}
                    enableExport={true}
                    totalPages={totalPage}
                    totalRecord={result.length}
                    initialize={resetRecords}
                    showCheckbox={true}
                    deleteRow={true}
                    dropSelectedRows={this.deleteSelectedRecords}
                  />
                </div>
              </Grid.Column>
              <Grid.Column width={4}>
                <div className="bay-transfer">
                  <Grid.Column>
                    <Field
                      name="hmhid_bay_id"
                      component={InputSearchField}
                      label={t('toBay')}
                      findByCompanyAndFLMName={this.search}
                      id="stageid"
                      options={bayid}
                      fillNameValues={this.setValue}
                      required={true}
                      readOnly={disableInputField || disableBaySelection}
                      placeholder={bayDesc}
                    />
                  </Grid.Column>
                  <Grid.Column>
                    <Field
                      name="wms_bay_description"
                      component={InputField}
                      label={t('bayDescription')}
                      readOnly={true}
                      placeholder={bayDesc}
                    />
                  </Grid.Column>
                  <Grid.Column>
                    <Field
                      name="wms_eqp_equipment_id"
                      component={InputSearchField}
                      label={t('mhe')}
                      iconName="search"
                      findByCompanyAndFLMName={this.search}
                      id="mhe"
                      options={mhe}
                      fillNameValues={this.setValue}
                      required={true}
                      readOnly={disableInputField}
                      handleClick={this.toggle}
                      childName="equipmentHelp"
                    />
                  </Grid.Column>
                  <Grid.Column>
                    <Field
                      name="wms_emp_employee_code"
                      component={InputSearchField}
                      label={t('employeeId')}
                      iconName="search"
                      handleClick={this.toggle}
                      childName="employeeHelp"
                      findByCompanyAndFLMName={this.search}
                      id="employee"
                      options={employee}
                      fillNameValues={this.setValue}
                      required={true}
                      readOnly={disableInputField}
                    />
                  </Grid.Column>
                  <Grid.Column>
                    <div className="additional-employee">
                      <Popup size="fullscreen" trigger={<button type="button" className="link-button" disabled={true}>
                        {t('additionalEmployee')}</button>} />
                    </div>
                  </Grid.Column>
                  <Grid.Column>
                    <Field
                      name="startDateTime"
                      component={DateTimePicker}
                      showTimeSelect={true}
                      timeIntervals={1}
                      min={new Date()}
                      label={t('startDateTime')}
                      required={true}
                      disabled={disableInputField}
                    />
                  </Grid.Column>
                  <Grid.Column>
                    <Field
                      name="endDateTime"
                      component={DateTimePicker}
                      showTimeSelect={true}
                      timeIntervals={1}
                      label={t('endDateTime')}
                      min={new Date()}
                      required={true}
                      disabled={disableEndTime}
                    />
                  </Grid.Column>
                  <Grid.Column>
                    <Field
                      name="addtoVirtualBay"
                      component={Checkbox}
                      type="checkbox"
                      disabled={disableInputField}
                      label={t('addtoVirtualBay')}
                    />
                  </Grid.Column>
                </div>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row />
            <Grid.Row />
            <Grid.Row className="create-buttons">
              <Grid.Column width={7}>
                <div className="assign-button-right">
                  <button id='save' type='button' className="primary" onClick={() => this.saveBayTransferRecords()} disabled={invalid || disableBtn || enableScan}>
                    {t('saveBtn')}
                  </button>
                </div>
              </Grid.Column>
              <Grid.Column width={2}>
                <div className="text-center">
                  <button id='confirm' type="button" className="secondary"
                    disabled={invalid || !enableScan}
                    onClick={() => this.confirmBayTransferRecords()}>
                    {t('confirmBtn')}
                  </button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </form>
      </div>
    )
  }
}

BayTransferResult = reduxForm({
  form: "BayTransferForm",
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate
})(BayTransferResult);

const mapDispatchToProps = (dispatch) => ({
  loadGridRecords: (params) =>
    dispatch(bayTransferAction.scanDispatchDocumentId('dispatch', params)),
  getDetails: (action, queryStr) =>
    dispatch(bayTransferAction.getFieldDetails(action, queryStr)),
  resetRecords: () => dispatch(bayTransferAction.resetRecords()),
  BayTransferActivity: (action, params) =>
    dispatch(bayTransferAction.scanDispatchDocumentId(action, params)),
  getLoggedUser: (action, params) =>
    dispatch(bayTransferAction.getFieldDetails(action, params)),
  deleteBayTransferRecords: (params) =>
    dispatch(bayTransferAction.deleteBtRecords(params))
})

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user,
  formValues: state.form.BayTransferForm,
  employee: state.bayTransferReducer.options.employee,
  defaultuser: state.bayTransferReducer.options.defaultuser,
  mhe: state.bayTransferReducer.options.mhe,
  bayid: state.bayTransferReducer.options.stageid,
  result: state.bayTransferReducer.result,
  totalPage: state.bayTransferReducer.totalPage,
  saveRecords: state.bayTransferReducer.saveRecords,
  totalRecord: state.bayTransferReducer.totalRecord
})

export default compose(withTranslation('bayTransferForm'), connect(mapStateToProps, mapDispatchToProps))(BayTransferResult)