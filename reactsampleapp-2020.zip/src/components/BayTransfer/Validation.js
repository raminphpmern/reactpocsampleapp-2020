import i18n from 'i18n';
import { formatDateTime } from 'lib/CommonHelper'
import { AlertError } from 'lib/Alert';

export default function Validation(values) {
  const errors = {};
  if (values.addtoVirtualBay !== true) {
    if (!values.hmhid_bay_id) {
      errors.hmhid_bay_id = i18n.t('bayTransferValidation:bayIdReq')
    }
  }
  if (!values.wms_eqp_equipment_id) {
    errors.wms_eqp_equipment_id = i18n.t('bayTransferValidation:mheNoReq')
  }
  if (!values.wms_emp_employee_code) {
    errors.wms_emp_employee_code = i18n.t('bayTransferValidation:empReq')
  }
  if (!values.startDateTime) {
    errors.startDateTime = i18n.t('bayTransferValidation:startDateReq')
  }
  if (!values.endDateTime) {
    errors.endDateTime = i18n.t('bayTransferValidation:endDateReq')
  }
  if (values.endDateTime && values.startDateTime) {
    const startTime = formatDateTime(values.startDateTime, false)
    const endTime = formatDateTime(values.endDateTime, false)
    if (endTime < startTime) {
      AlertError(i18n.t('bayTransferValidation:endDateGreater'))
      errors.endDateTime = i18n.t('bayTransferValidation:endDateGreater')
    }
  }
  if (values.hmhid_bay_id) {
    if (values.addtoVirtualBay === true) {
      AlertError(i18n.t('bayTransferValidation:virtualBayError'))
    }
  }
  return errors
}