import React, { Component } from "react";
import { connect } from "react-redux";
import { Detector } from "react-detect-offline";
import { Label, Icon, Menu } from "semantic-ui-react";
import { Link } from "react-router-dom";
import Clock from "react-live-clock";
import Select from "react-select";
import pjson from "../../../package.json";
import { onlineStatus } from "actions/loginAction";
import { updateBranchType } from "actions/loginAction";
import { setValue, getValue, removeKey } from "lib/LocalStorage";
import Popup from 'components/Common/Popup';
import AlertPopUp from './AlertPopUp';
import Messages from './Messages';
import _ from "lodash";
import "./header.css";
import Logo from "images/ramco-logo-white.png";
import * as bookingActions from "actions/bookingActions";
import { isMobile, commonDateDisplayFormat } from "config";
import io from 'socket.io-client';

let socketUrl = ''
let locationUrl = ''

if (window._env_) {
  socketUrl = window._env_.SOCKET_URL
  locationUrl = window._env_.LOCATION_ID
}

export let socket = io(socketUrl, {
  transports: ["websocket", "polling"]
});

class Header extends Component {
  constructor(props) {
    super(props);

    this.state = {
      currentBranch: {},
      screenWidth: null,
      sideMenu: false,
      message: [],
      msgCount: 0,
      alertPopUp: false,
      msgPopUp: false,
      message: '',
      otherMessages: [],
    };

    this.updateWindowDimensions = this.updateWindowDimensions.bind(this);
    this.setDefaultLocation = this.setDefaultLocation.bind(this);
    this.triggerMenu = this.triggerMenu.bind(this);
    this.toggle = this.toggle.bind(this);
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.updateWindowDimensions);
  }

  updateWindowDimensions() {
    this.setState({ screenWidth: window.innerWidth });
  }

  OnlineStatus(online) {
    this.props.online(online);
  }

  toggle(stateName) {
    this.setState({ [stateName]: !this.state[stateName] })
  }

  UNSAFE_componentWillMount() {
    socket = io(socketUrl, {
      transports: ["websocket", "polling"],
      forceNew: true
    })
    socket.connect()
    socket.emit("join", window._env_.LOCATION_ID);
    socket.on("message", message => {
      const msgObj = message.message || { notification_type: '', message: '' }
      if (msgObj.notification_type === 'ALERT') {
        this.setState({ alertPopUp: true, message: msgObj.message })
      } else {
        let messages = this.state.otherMessages
        messages.push(msgObj)
        this.setState({ otherMessages: messages, msgCount: this.state.msgCount + 1 })
      }
    });
  }

  componentDidMount() {
    const locations =
      (this.props.currentUser && this.props.currentUser.locations) || [];
    if (locations) {
      const localStrBranch = getValue("currentBranch");
      if (localStrBranch) {
        const branch = JSON.parse(localStrBranch);
        this.setState({ currentBranch: branch });
        this.props.updateBranchType(branch.wms_div_type);
      } else {
        const currentBranch = _.find(
          locations,
          loc => loc.wms_loc_user_default === 1
        );
        if (currentBranch) {
          this.setState({ currentBranch });
          this.props.updateBranchType(currentBranch.wms_div_type);
          setValue("currentBranch", currentBranch);
        }
      }
    }

    window.addEventListener("resize", this.updateWindowDimensions());
  }

  setDefaultLocation(data) {
    this.setState({ currentBranch: data })
    setValue('currentBranch', data)
    this.props.updateBranchType(data.wms_div_type.toLowerCase())
    removeKey('orders')
    removeKey('charges')
    removeKey('br_id')
    this.props.initializeBooking()
    this.props.setCurrentLocation(data)
  }

  getIpAddress() {
    let url = window._env_.API_URL;
    url = url.split("/")[2];
    url = url.split(":")[0];
    return url;
  }

  triggerMenu() {
    this.setState(prevState => ({
      sideMenu: !prevState.sideMenu
    }));
  }

  renderSideMenu(DisableBranch, locations, currentBranch) {
    const { currentUser } = this.props;
    return (
      <div className={`${this.state.sideMenu ? "" : "hide"} sidemenu`}>
        <div className="menu_content">
          <dl>
            <dt>Version</dt>
            <dd>{pjson.version}</dd>

            <dt>IP Address</dt>
            <dd>{this.getIpAddress()}</dd>

            <dt>Branch Code</dt>
            <dd>
              <div className="branch-code-drop-down">
                <Select
                  options={locations}
                  value={currentBranch}
                  isDisabled={locations.length === 1 || DisableBranch}
                  onChange={this.setDefaultLocation}
                  selected={locations[0]}
                />
              </div>
            </dd>

            <dt>Cut Off</dt>
            <dd>{currentBranch.wms_loc_cutoff_time}</dd>

            <dt>Time</dt>
            <dd>
              <Clock format={"hh:mm:ss A"} ticking={true} />
            </dd>

            <dt>Date</dt>
            <dd>
              <Clock format={commonDateDisplayFormat} />
            </dd>
          </dl>
          <hr />
          <div className="landing-footer">
            <dl>
              <dt>Serial</dt>
              <dd id="serial-no">
                {currentUser && currentUser.system && currentUser.system.serial}
              </dd>

              <dt>Permit</dt>
              <dd>{currentBranch.PERMIT}</dd>

              <dt>MIN</dt>
              <dd>{currentBranch.MIN}</dd>

              <dt>TIN</dt>
              <dd>{currentBranch.TIN}</dd>

              <dt>Associate</dt>
              <dd>{currentUser && currentUser.fullname}</dd>

              <dt>Sync</dt>
              <dd>{currentUser && currentUser.lastSyncDate}</dd>
            </dl>

            <div className="logout">
              {currentUser && (
                <Link
                  to="/login"
                  className="change-user"
                  onClick={() => this.changeUser()}
                >
                  <Icon name="power off" /> Logout
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  renderDesktopView(DisableBranch, locations) {
    const { currentBranch, alertPopUp, message, msgPopUp, otherMessages, msgCount } = this.state;
    const popUpConfig = {
      closeOnDimmerClick: false,
      closeOnEscape: false,
      closeIcon: false,
      centered: false,
      basic: true,
    }
    return (
      <div className="header version-details">
        <Popup size="tiny" open={alertPopUp} options={popUpConfig} close={() => { this.toggle('alertPopUp') }}
          description={<AlertPopUp close={() => { this.toggle('alertPopUp') }} message={message} />} />

        <Popup size="tiny" open={msgPopUp} close={() => { this.toggle('msgPopUp') }}
          header='Inbox' description={<Messages messages={otherMessages} />} />

        <Link to="/" className="brand">
          <img src={Logo} alt="logo" />
        </Link>
        <div className="middle-layer">
          <div className="version-ip">
            <span>
              Version<strong>{pjson.version}</strong>
            </span>
            <div className="vl"></div>
            <span>
              IP Address<strong>{this.getIpAddress()}</strong>
            </span>
          </div>
          <div className="page-heading">
            <label>Branch Code</label>
            <div className="branch-code">
              <div className="branch-code-drop-down">
                <Select
                  options={locations}
                  value={currentBranch}
                  isDisabled={locations.length === 1 || DisableBranch}
                  onChange={this.setDefaultLocation}
                />
              </div>
            </div>
            <span>
              Cut Off <strong>{currentBranch.wms_loc_cutoff_time}</strong>
            </span>
            <span>
              {" "}
              Time{" "}
              <strong>
                <Clock format={"hh:mm:ss A"} ticking={true} timezone={'UTC'} />
              </strong>
            </span>
            <span>
              Date{" "}
              <strong>
                <Clock format={commonDateDisplayFormat} />
              </strong>
            </span>
            <span className='notifi-section'>
              <Menu>
                <Menu.Item as='a'>
                  <Icon name='bell' />
                  <Label color='red' floating onClick={msgCount !== 0 ? () => { this.toggle('msgPopUp') } : null}>
                    {msgCount}
                  </Label>
                </Menu.Item>
              </Menu>
            </span>
          </div>
        </div>
        <Detector
          onChange={online => {
            this.OnlineStatus(online);
          }}
          className="offline-status"
          render={({ online }) => (
            <div className="indicator">
              <Label
                circular
                color={`${online ? "green" : "red"}`}
                empty
                key={`${online ? "green" : "red"}`}
              />
              <span className="offline-text">
                {online ? "Online" : "Offline"}{" "}
              </span>
            </div>
          )}
        />
      </div>
    );
  }

  renderMobileView(DisableBranch, locations, currentBranch) {
    return (
      <div className="header mobile-header version-details">
        <div className="menu_container">
          {this.renderSideMenu(DisableBranch, locations, currentBranch)}
          <button className="sidemenu_icon" onClick={() => this.triggerMenu()}>
            <Icon name="bars" />
          </button>
        </div>

        <Link to="/" className="brand">
          <img src={Logo} alt="logo" />
        </Link>

        <Detector
          onChange={online => {
            this.OnlineStatus(online);
          }}
          className="offline-status"
          render={({ online }) => (
            <div className="indicator">
              <Label
                circular
                color={`${online ? "green" : "red"}`}
                empty
                key={`${online ? "green" : "red"}`}
              />
              <span className="offline-text">
                {online ? "Online" : "Offline"}{" "}
              </span>
            </div>
          )}
        />
      </div>
    );
  }

  render() {
    const { currentUser, DisableBranch } = this.props;
    const locations = (currentUser && currentUser.locations) || [];
    const { currentBranch } = this.state;

    if (isMobile)
      return this.renderMobileView(DisableBranch, locations, currentBranch);
    else return this.renderDesktopView(DisableBranch, locations);
  }
}

const mapDispatchToProps = dispatch => ({
  online: status => dispatch(onlineStatus(status)),
  updateBranchType: type => dispatch(updateBranchType(type)),
  initializeBooking: () => dispatch(bookingActions.initializeBooking())
});

const mapStateToProps = state => ({
  currentUser: state.loginReducer.user
});

export default connect(mapStateToProps, mapDispatchToProps)(Header);
