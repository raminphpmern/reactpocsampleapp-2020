import React, { Component } from 'react'
import { Button, Header, Icon, Modal } from 'semantic-ui-react'


class AlertPopUp extends Component {
  render() {
    return (
      <div className='alert-notification'>
        <Header icon='exclamation circle' content='Action Required' />
        <Modal.Content>
          <h3>{this.props.message}</h3>
        </Modal.Content>
        <Modal.Actions>
          <Button color='red' onClick={this.props.close} inverted>
            <Icon name='checkmark' /> Got it
          </Button>
        </Modal.Actions>
      </div>
    )
  }
}

export default AlertPopUp