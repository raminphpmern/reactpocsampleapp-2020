import React, { Component } from 'react'
import { List } from 'semantic-ui-react'


class Messages extends Component {
  render() {
    const { messages } = this.props
    return (
      <List divided relaxed className='message-list'>
        {
          messages.map((row, index) => {
            return (
              <List.Item key={index}>
                <List.Icon name={row.notification_type.toLowerCase() + ' circle'} size='large' verticalAlign='middle' />
                <List.Content>
                  <List.Description as='a'>{row.message}</List.Description>
                </List.Content>
              </List.Item>
            )
          })
        }
      </List>
    )
  }
}

export default Messages