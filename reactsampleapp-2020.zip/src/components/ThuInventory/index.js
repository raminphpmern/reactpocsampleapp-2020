import React, { Component } from "react";
import InputField from "components/Common/InputField";
import HelpOnCustomer from 'components/Dispatch/DispatchSearch/HelpOnCustomer';
import Wrapper from 'components/LandingPage/Wrapper';
import * as thuInventoryAction from 'actions/thuInventoryAction';
import InputSearchField from "components/Common/InputSearchField";
import Dropdown from "components/Common/Dropdown";
import { reduxForm, Field } from "redux-form";
import { Grid, Menu, Icon } from "semantic-ui-react";
import { withTranslation } from 'react-i18next';
import { formatFormValues } from "lib/CommonHelper";
import { getProducts } from "actions/masterAction";
import DataGrid from 'components/Common/DataGrid';
import Popup from 'components/Common/Popup';
import { getValue } from "lib/LocalStorage";
import { SEARCH_WORD_COUNT } from "config";
import { gridHeaders } from './Helper';
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import history from 'routes/history';
import { compose } from 'redux';
import '../TripHub/triphub.css'
import '../BrHub/brhub.css';
import i18n from 'i18n';
import _ from 'lodash';

class thuInventory extends Component {
  constructor(props) {
    super(props)
    this.state = {
      activeItem: 'total',
      customerHelp: false,
      currentHelp: ''
    }
    this.formSubmit = this.formSubmit.bind(this)
    this.handleItemClick = this.handleItemClick.bind(this)
    this.search = this.search.bind(this)
    this.setValue = this.setValue.bind(this)
    this.selectCustomerCode = this.selectCustomerCode.bind(this)
    this.toggle = this.toggle.bind(this)
    this.SelectedRows = this.SelectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
  }

  componentDidMount() {
    const { status, getStatus, availabilityStatus, getAvailabilityStatus } = this.props;
    if (status.length === 0) {
      getStatus()
    }
    if (availabilityStatus.length === 0) {
      getAvailabilityStatus()
    }
    if (getValue('currentBranch')) {
      let currentBranch = JSON.parse(getValue('currentBranch') ? getValue('currentBranch') : {})
      if (currentBranch.value) {
        this.props.initialize({ wms_div_code: currentBranch.wms_div_desc, hmhid_location: currentBranch.value });
      }
    }
  }

  formSubmit(values) {
    this.props.search(formatFormValues(values), 1, this.props.limit);
  }

  handleItemClick(e, { name }) {
    const { formValues } = this.props
    this.setState({ activeItem: name })
    let filter = formatFormValues(formValues.values)
    _.merge(filter, { periodic_filter: name })
    this.props.search(filter, 1, this.props.limit);
  }

  search(value) {
    if (value.length >= SEARCH_WORD_COUNT) {
      this.props.getProducts(
        'products',
        `keyword=${value}&wms_thu_is_ethu=1`
      );
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "products") {
      hash["wms_thu_id"] = option.value;
    }
    this.props.initialize(hash);
  }

  selectCustomerCode(selectedCustomerCode) {
    if (selectedCustomerCode && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["hmtid_customer_id"] = selectedCustomerCode
      this.props.initialize(hash)
    }
  }

  toggle(modalType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  SelectedRows(values) {
    this.setState({ selectedIds: values })
  }

  changeLimit(pageNo, limit) {
    this.props.search(formatFormValues(this.props.formValues.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.search(formatFormValues(this.props.formValues.values), pageNo, limit);
  }

  render() {
    const { handleSubmit, t, total, products, availabilityStatus, status, records, totalPage, available, allocated, totalRecord, limit, initializeInventory } = this.props;
    let { activeItem, customerHelp, currentHelp, } = this.state;
    return (
      <Wrapper DisableBranch={true}>
        <Popup size="fullscreen" open={customerHelp} close={() => { this.toggle('help', 'customerHelp') }} header="Help on Customer" description={<HelpOnCustomer close={this.toggle} handleOnSelect={this.selectCustomerCode} name={currentHelp} />} />
        <div className="triphub-head">
          <div className='title'>
            <h3>{t('title')}</h3>
          </div>
          <div className="back-link">
            <a href="javascript: false" onClick={this.props.history.goBack}>
              <Icon disabled name='arrow left' />
              {t('translation:back')}</a>
          </div>
        </div>
        <div className="brhub-wrapper trip-plan-wrapper">
          <form onSubmit={handleSubmit(this.formSubmit)}>
            <Grid stackable className="fixed-grid">
              <Grid.Row className="no-padding">
                <Grid.Column width={4}>
                  <Field
                    name="wms_div_code"
                    component={InputField}
                    label={t('wms_div_code')}
                    readOnly={true}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="hmhid_location"
                    component={InputField}
                    label={t('hmhid_location')}
                    readOnly={true}
                  />
                </Grid.Column>
              </Grid.Row>
              <Grid.Row className="no-padding">
                <Grid.Column width={4}>
                  <Field
                    name="wms_thu_id"
                    id="products"
                    component={InputSearchField}
                    label={t('wms_thu_id')}
                    options={products}
                    clearable={true}
                    findByCompanyAndFLMName={this.search}
                    fillNameValues={this.setValue}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="status"
                    component={Dropdown}
                    label={t('status')}
                    clearable={true}
                    options={status}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="hmtid_customer_id"
                    component={InputField}
                    label={t('hmtid_customer_id')}
                    iconName='search'
                    handleClick={this.toggle}
                    childName='customerHelp'
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="hmtid_availability"
                    component={Dropdown}
                    options={availabilityStatus}
                    label={t('hmtid_availability')}
                    clearable={true}
                  />
                </Grid.Column>
              </Grid.Row>
              <Grid.Row>
                <Grid.Column width={16} className="text-center">
                  <button type="submit" className="primary btn-small btn-long">
                    {t('searchBtn')}
                  </button>
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </form>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={6} className='trip-hub'>
                <Menu pointing >
                  <Menu.Item
                    name='available'
                    active={activeItem === 'available'}
                    onClick={this.handleItemClick}
                  >
                    Available ({available})
              </Menu.Item>
                  <Menu.Item
                    name='allocated'
                    active={activeItem === 'allocated'}
                    onClick={this.handleItemClick}
                  >
                    Allocated ({allocated})
              </Menu.Item>
                  <Menu.Item
                    name='total'
                    active={activeItem === 'total'}
                    onClick={this.handleItemClick}
                  >
                    Total ({total})
              </Menu.Item>
                </Menu>
              </Grid.Column>
              <Grid.Column width={10}></Grid.Column>
            </Grid.Row>
          </Grid>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
                <DataGrid
                  columns={gridHeaders}
                  rows={records}
                  rowKey="wms_thu_id"
                  totalPages={totalPage}
                  selectedRows={this.selectedRows}
                  width={300}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  exportName='THU-INVENTORY'
                  initialize={initializeInventory}
                  limit={limit}
                  enableExport={true}
                  singleSelect={false}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>
          <div className="footer">
            <div className="actions br-hd-footer">
              <div>
                <span>
                  <Link to="/loadThu" className="change-user" >
                    {i18n.t('thuInventoryFooter:loadInventoryBtn')}
                  </Link>
                </span>
                <span>
                  <Link to="/thuInventory/allocateTHU" className="change-user">
                    {i18n.t('thuInventoryFooter:allocateInventoryBtn')}
                  </Link>
                </span>
              </div>
            </div >
          </div>
        </div>
      </Wrapper>
    );
  }
}

thuInventory = reduxForm({
  form: "thuInventory"
})(thuInventory);

const mapDispatchToProps = dispatch => ({
  getStatus: () => dispatch(thuInventoryAction.getStatus('status')),
  getAvailabilityStatus: () => dispatch(thuInventoryAction.getAvailabilityStatus('availabilityStatus')),
  getProducts: (action, queryStr) =>
    dispatch(getProducts(action, queryStr)),
  search: (data, pageNo, limit) => dispatch(thuInventoryAction.search(data, pageNo, limit)),
  initializeInventory: () => dispatch(thuInventoryAction.initializeInventory())
});

const mapStateToProps = state => ({
  formValues: state.form.thuInventory,
  status: state.thuInventoryReducer.status,
  availabilityStatus: state.thuInventoryReducer.availabilityStatus,
  records: state.thuInventoryReducer.result,
  totalPage: state.thuInventoryReducer.totalPage,
  totalRecord: state.thuInventoryReducer.totalRecord,
  limit: state.thuInventoryReducer.limit,
  total: state.thuInventoryReducer.total,
  products: state.masterReducer.options.products,
  available: state.thuInventoryReducer.available,
  allocated: state.thuInventoryReducer.allocated
});

export default compose(withTranslation('thuInventoryForm'), connect(mapStateToProps, mapDispatchToProps))(thuInventory);