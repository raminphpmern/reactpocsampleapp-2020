import React, { Component } from "react";
import InputField from "components/Common/InputField";
import HelpOnCustomer from 'components/Dispatch/DispatchSearch/HelpOnCustomer';
import * as thuInventoryAction from 'actions/thuInventoryAction';
import InputSearchField from "components/Common/InputSearchField";
import Wrapper from 'components/LandingPage/Wrapper';
import Dropdown from "components/Common/Dropdown";
import { getProducts } from "actions/masterAction";
import { formatFormValues } from "lib/CommonHelper";
import { reduxForm, Field } from "redux-form";
import { Grid, Icon } from "semantic-ui-react";
import { withTranslation } from 'react-i18next';
import DataGrid from 'components/Common/DataGrid';
import Popup from 'components/Common/Popup';
import { getValue } from "lib/LocalStorage";
import { SEARCH_WORD_COUNT } from "config";
import { gridHeaders } from './Helper';
import { connect } from "react-redux";
import history from 'routes/history';
import { compose } from 'redux';
import 'components/BrHub/brhub.css';
import 'components/TripHub/triphub.css';
import validate from './allocateValidation';
import _ from 'lodash';

class allocateTHU extends Component {
  constructor(props) {
    super(props)
    this.state = {
      customerHelp: false,
      currentHelp: ''

    }
    this.formSubmit = this.formSubmit.bind(this)
    this.search = this.search.bind(this)
    this.setValue = this.setValue.bind(this)
    this.selectCustomerCode = this.selectCustomerCode.bind(this)
    this.toggle = this.toggle.bind(this)
    this.setWrapperRef = this.setWrapperRef.bind(this)
    this.handleClickOutside = this.handleClickOutside.bind(this)
    this.validateSerialNumberFrom = this.validateSerialNumberFrom.bind(this)
    this.validateSerialNumberTo = this.validateSerialNumberTo.bind(this)
    this.allocate = this.allocate.bind(this)
    this.getValues = this.getValues.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
  }

  componentWillUnmount() {
    window.onbeforeunload = () => true
    document.removeEventListener('mousedown', this.handleClickOutside);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.validSerialNumber !== this.props.validSerialNumber &&
      !nextProps.validSerialNumber) {
      let hash = _.cloneDeep(this.props.formValues.values)
      if (hash['thuserialnofrom']) {
        hash['thuserialnofrom'] = ''
        this.props.initialize(hash)
      }
    }
    if (nextProps.validSerialNumber !== this.props.validSerialNumber &&
      !nextProps.validSerialNumber) {
      let hash = _.cloneDeep(this.props.formValues.values)
      if (hash['thuserialnoto']) {
        hash['thuserialnoto'] = ''
        this.props.initialize(hash)
      }
    }
    if (this.props.allocationLevel !== nextProps.allocationLevel && nextProps.allocationLevel.length > 0) {
      let hash = _.cloneDeep(this.props.formValues.values)
      hash['wms_paramdesc'] = nextProps.allocationLevel[0]
      this.props.initialize(hash)
    }
  }

  componentDidMount() {
    document.addEventListener('mousedown', this.handleClickOutside);
    const currentBranch = JSON.parse(getValue('currentBranch') || "{}")
    const { allocationLevel, getAllocationLevel } = this.props;
    let serialNumberFromNode = document.getElementById('serialNumberFrom')
    serialNumberFromNode.addEventListener("keydown", e => {
      if (e.keyCode === 9) {
        this.validateSerialNumberFrom()
      }
    })
    let serialNumberToNode = document.getElementById('serialNumberTo')
    serialNumberToNode.addEventListener("keydown", e => {
      if (e.keyCode === 9) {
        this.validateSerialNumberTo()
      }
    })
    if (currentBranch.value) {
      this.props.initialize({ wms_div_code: currentBranch.wms_div_desc, hmhid_location: currentBranch.value });
    }
    if (allocationLevel.length === 0) {
      getAllocationLevel()
    }
  }

  search(value) {
    if (value.length >= SEARCH_WORD_COUNT) {
      this.props.getProducts(
        'products',
        `keyword=${value}&wms_thu_is_ethu=1`
      );
    }
  }

  setValue(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === "products") {
      hash["wms_thu_id"] = option.value;
    }
    this.props.initialize(hash);
  }

  selectCustomerCode(selectedCustomerCode) {
    if (selectedCustomerCode && this.props.formValues) {
      let hash = {}
      if (this.props.formValues.values) {
        hash = _.cloneDeep(this.props.formValues.values)
      }
      hash["hmtid_customer_id"] = selectedCustomerCode
      this.props.initialize(hash)
    }
  }

  toggle(modalType, modelName) {
    this.setState({ [modelName]: !this.state[modelName], currentHelp: modelName })
  }

  formSubmit() {
  }

  allocate(values) {
    _.merge(values, { status: 'Allocated' })
    this.props.allocate(values)
  }

  deallocate(values) {
    _.merge(values, { status: 'Deallocated' })
    this.props.deallocate(values)
  }

  setWrapperRef(node) {
    this.wrapperRef = node;
  }

  handleClickOutside(event) {
    if (this.wrapperRef && !this.wrapperRef.contains(event.target)) {
      let hash = this.props.formValues.values
      if (hash['thuserialnofrom'] && !this.props.serialNumber) {
        this.validateSerialNumberFrom()
      }
    }
  }

  validateSerialNumberFrom() {
    const { formValues } = this.props
    let serialNumberFrom = formValues && formValues.values ? formValues.values.thuserialnofrom : null;
    if (serialNumberFrom) {
      this.props.validateSerialNumber(serialNumberFrom)
    }
  }

  validateSerialNumberTo() {
    const { formValues } = this.props
    let serialNumberTo = formValues && formValues.values ? formValues.values.thuserialnoto : null;
    if (serialNumberTo) {
      this.props.validateSerialNumber(serialNumberTo)
    }
  }

  getValues() {
    const { values } = this.props.formValues
    this.props.getSerialDetails(formatFormValues(values), 1, 10)
  }

  changeLimit(pageNo, limit) {
    this.props.getSerialDetails(formatFormValues(this.props.formValues.values), pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.getSerialDetails(formatFormValues(this.props.formValues.values), pageNo, limit);
  }

  render() {
    const { handleSubmit, t, products, allocationLevel, serialNumberResult, initializeSerialNumber, serialNumbertotalPage, serialNumbertotalRecord, serialNumberlimit } = this.props;
    const { customerHelp, currentHelp } = this.state;
    return (
      <Wrapper DisableBranch={true}>
        <Popup size="fullscreen" open={customerHelp} close={() => { this.toggle('help', 'customerHelp') }} header="Help on Customer" description={<HelpOnCustomer close={this.toggle} handleOnSelect={this.selectCustomerCode} name={currentHelp} />} />
        <div className="triphub-head">
          <div className='title'>
            <h3>{t('title')}</h3>
          </div>
          <div className="back-link">
            <a href="javascript: false" onClick={this.props.history.goBack}>
              <Icon disabled name='arrow left' />
              {t('translation:back')}</a>
          </div>
        </div>
        <div className="brhub-wrapper trip-plan-wrapper">
          <form onSubmit={handleSubmit(this.formSubmit)}>
            <Grid stackable className="fixed-grid">
              <Grid.Row className="no-padding">
                <Grid.Column width={4}>
                  <Field
                    name="wms_div_code"
                    component={InputField}
                    label={t('wms_div_code')}
                    readOnly={true}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="hmhid_location"
                    component={InputField}
                    label={t('hmhid_location')}
                    readOnly={true}
                  />
                </Grid.Column>
              </Grid.Row>
              <Grid.Row className="no-padding">
                <Grid.Column width={4}>
                  <Field
                    name="wms_thu_id"
                    id="products"
                    component={InputSearchField}
                    label={t('wms_thu_id')}
                    options={products}
                    clearable={true}
                    findByCompanyAndFLMName={this.search}
                    fillNameValues={this.setValue}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <div ref={this.setWrapperRef}>
                    <Field
                      id="serialNumberFrom"
                      name="thuserialnofrom"
                      component={InputField}
                      label={t('thuserialnofrom')}
                      required={true}
                    />
                  </div>
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    id="serialNumberTo"
                    name="thuserialnoto"
                    component={InputField}
                    label={t('thuserialnoto')}
                    required={true}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="wms_paramdesc"
                    component={Dropdown}
                    label={t('wms_paramdesc')}
                    clearable={true}
                    options={allocationLevel}
                    readOnly={true}
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    name="hmtid_customer_id"
                    component={InputField}
                    label={t('hmtid_customer_id')}
                    iconName='search'
                    handleClick={this.toggle}
                    childName='customerHelp'
                  />
                </Grid.Column>
              </Grid.Row>
              <Grid.Row>
                <Grid.Column width={8} className="text-center">
                  <button type="button" className="primary btn-small btn-long" onClick={handleSubmit(values =>
                    this.allocate(values))}>
                    {t('allocateBtn')}
                  </button>
                </Grid.Column>
                <Grid.Column width={8} className="text-center">
                  <button type="button" className="primary btn-small btn-long" onClick={() => this.getValues()}>
                    {t('getBtn')}
                  </button>
                </Grid.Column>
              </Grid.Row>
            </Grid>
            <Grid stackable>
              <Grid.Row>
                <Grid.Column width={16}>
                  <DataGrid
                    columns={gridHeaders}
                    rows={serialNumberResult}
                    rowKey="wms_thu_id"
                    totalPages={serialNumbertotalPage}
                    selectedRows={this.selectedRows}
                    width={300}
                    totalRecord={serialNumbertotalRecord}
                    changeLimit={this.changeLimit}
                    paginationHandler={this.paginationHandler}
                    exportName='THU-INVENTORY'
                    initialize={initializeSerialNumber}
                    limit={serialNumberlimit}
                    enableExport={true}
                    singleSelect={false}
                  />
                </Grid.Column>
              </Grid.Row>
            </Grid>
            <Grid.Row>
              <Grid.Column width={16} className="text-center">
                <button type="button" className="primary btn-small btn-long" onClick={handleSubmit(values =>
                  this.deallocate(values))}>
                  {t('deallocateBtn')}
                </button>
              </Grid.Column>
            </Grid.Row>
          </form>
        </div>
      </Wrapper>
    );
  }
}

allocateTHU = reduxForm({
  form: "allocateTHU",
  validate
})(allocateTHU);

const mapDispatchToProps = dispatch => ({
  getProducts: (action, queryStr) =>
    dispatch(getProducts(action, queryStr)),
  getAllocationLevel: () => dispatch(thuInventoryAction.getAllocationLevel('allocationLevel')),
  allocate: (data) => dispatch(thuInventoryAction.allocate(data, 'allocate')),
  deallocate: (data) => dispatch(thuInventoryAction.deallocate(data, 'deallocate')),
  validateSerialNumber: (serialNumber) => dispatch(thuInventoryAction.validateSerialNumber('validate', serialNumber)),
  getSerialDetails: (data, pageNo, limit) => dispatch(thuInventoryAction.getSerialDetails(data, pageNo, limit)),
  initializeSerialNumber: () => dispatch(thuInventoryAction.initializeSerialNumber())
});

const mapStateToProps = state => ({
  formValues: state.form.allocateTHU,
  products: state.masterReducer.options.products,
  allocationLevel: state.thuInventoryReducer.allocationLevel,
  validSerialNumber: state.thuInventoryReducer.validSerialNumber,
  serialNumber: state.thuInventoryReducer.serialNumber,
  serialNumbertotalPage: state.thuInventoryReducer.serialNumbertotalPage,
  serialNumbertotalRecord: state.thuInventoryReducer.serialNumbertotalRecord,
  serialNumberlimit: state.thuInventoryReducer.serialNumberlimit,
  serialNumberResult: state.thuInventoryReducer.serialNumberResult
});

export default compose(withTranslation('allocatethuForm'), connect(mapStateToProps, mapDispatchToProps))(allocateTHU);