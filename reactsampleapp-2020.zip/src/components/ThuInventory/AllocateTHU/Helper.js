import i18n from 'i18n';

export const gridHeaders = [
  { key: "hmtid_thu_id", name: i18n.t('allocatethuGrid:hmtid_thu_id') },
  { key: "hmtid_thu_serial_no", name: i18n.t('allocatethuGrid:hmtid_thu_serial_no') },
  { key: "serialNumberTo", name: i18n.t('allocatethuGrid:serialNumberTo') },
  { key: "allocationLevel", name: i18n.t('allocatethuGrid:allocationLevel') },
  { key: "hmtid_customer_id", name: i18n.t('allocatethuGrid:hmtid_customer_id') },
  { key: "status", name: i18n.t('allocatethuGrid:status') },
];
