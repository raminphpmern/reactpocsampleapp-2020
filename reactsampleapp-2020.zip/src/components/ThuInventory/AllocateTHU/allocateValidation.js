import i18n from 'i18n';

const Validation = (values) => {
  const errors = {};

  if (!values.wms_thu_id) {
    errors.wms_thu_id = i18n.t('thuInventoryForm:validation_thuid')
  }
  if (!values.thuserialnofrom) {
    errors.thuserialnofrom = i18n.t('thuInventoryForm:validation_thuserialnofrom')
  }
  if (!values.thuserialnoto) {
    errors.thuserialnoto = i18n.t('thuInventoryForm:validation_thuserialnoto')
  }
  if (!values.hmtid_customer_id) {
    errors.hmtid_customer_id = i18n.t('thuInventoryForm:validation_hmtid_customer_id')
  }

  return errors
}

export default Validation;