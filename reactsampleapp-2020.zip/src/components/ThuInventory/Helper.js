import i18n from 'i18n';

export const gridHeaders = [
  { key: "hmtid_date_in", name: i18n.t('thuInventoryGrid:hmtid_date_in') },
  { key: "hmtid_date_out", name: i18n.t('thuInventoryGrid:hmtid_date_out') },
  { key: "wms_thu_id", name: i18n.t('thuInventoryGrid:wms_thu_id') },
  { key: "wms_thu_description", name: i18n.t('thuInventoryGrid:wms_thu_description') },
  { key: "hmtid_thu_serial_no", name: i18n.t('thuInventoryGrid:hmtid_thu_serial_no') },
  { key: "status", name: i18n.t('thuInventoryGrid:status') },
  { key: "hmtid_availability", name: i18n.t('thuInventoryGrid:hmtid_availability') },
  { key: "hmtid_customer_id", name: i18n.t('thuInventoryGrid:hmtid_customer_id') },
  { key: "wms_customer_description", name: i18n.t('thuInventoryGrid:wms_customer_description') }
];