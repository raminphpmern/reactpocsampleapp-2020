import React, { Component } from 'react'
import classNames from 'classnames';
import DatePicker from "react-datepicker";
import moment from 'moment'
import { Icon } from 'semantic-ui-react'
import { commonDateFormat, commonDateTimeFormat } from 'config'
import './DateTimePicker.css'


class inputDateField extends Component {

  onChange(date) {
    let showTimeSelect = this.props.showTimeSelect
    if (showTimeSelect !== true) {
      this.props.input.onChange(moment(date).format(this.props.dateFormat ? this.props.dateFormat.toUpperCase() : 'YYYY-MM-DD'));
    }
    else {
      this.props.input.onChange(moment(date).format(this.props.dateFormat ? this.props.dateFormat.toUpperCase() : 'YYYY-MM-DD h:mm A'));
    }
  }

  render() {
    const { input, dateFormat, label, disabled, htmlFor, placeholder, min, max, meta: { touched, error }, required, showTimeSelect, timeIntervals } = this.props
    let className = classNames('form-control', {
      "error": touched && error,
    });
    return (
      <div className="input_field" >
        {label && <label htmlFor={htmlFor}>{label}{required && <em>*</em>}</label>}
        <div className="input_holder">
          <DatePicker
            className={className}
            dateFormat={showTimeSelect ? commonDateTimeFormat : dateFormat ? dateFormat : commonDateFormat}
            onChange={this.onChange.bind(this)}
            minDate={min}
            maxDate={max}
            disabled={disabled}
            placeholder={placeholder}
            showTimeSelect={showTimeSelect}
            timeIntervals={timeIntervals}
            onBlur={input.onBlur}
            selected={input.value && input.value !== 'Invalid date' ? new Date(input.value) : null}
          />
          <Icon color="grey" className="date-icon" name='calendar' />
          {touched && error && <p className="error_message">{error}</p>}
        </div>
      </div>
    )
  }
}

export default inputDateField
