import * as React from 'react'
import classNames from 'classnames'
import PropTypes from 'prop-types'
import { Icon, Input } from 'semantic-ui-react'
import _ from 'lodash'
import './MultiSelect.css'

class MultiSelect extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      options: [],
      selectedOptions: [],
      isOpen: false,
      keyword: '',
    }
    this.toggleDropdown = this.toggleDropdown.bind(this)
    this.setWrapperRef = this.setWrapperRef.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this)
    this.handleChange = this.handleChange.bind(this)
  }

  componentDidMount() {
    document.addEventListener('mousedown', this.handleClickOutside);
  }

  componentWillUnmount() {
    document.removeEventListener('mousedown', this.handleClickOutside);
  }

  componentWillReceiveProps(nextProps) {
    const { selectedValues, options } = this.props
    if (selectedValues !== nextProps.selectedValues) {
      this.setState({ selectedOptions: nextProps.selectedValues })
    }

    if (options !== nextProps.options || this.state.options.length === 0) {
      this.setState({ options: nextProps.options })
    }
  }

  setWrapperRef(node) {
    this.wrapperRef = node;
  }

  handleClickOutside(event) {
    if (this.wrapperRef && !this.wrapperRef.contains(event.target)) {
      this.setState({ isOpen: false })
    }
  }

  toggleDropdown() {
    this.setState({ isOpen: !this.state.isOpen })
  }

  isAllSelected() {
    let { valueKey } = this.props
    const { selectedOptions, options } = this.state
    valueKey = valueKey || 'value'

    const allValues = _.map(selectedOptions, valueKey)
    return _.every(options, (option) => _.includes(allValues, option[valueKey]))
  }

  toggleAll() {
    const { options } = this.state
    const { onChange } = this.props
    const isAllSelected = this.isAllSelected()

    if (isAllSelected) {
      onChange([])
      this.setState({ selectedOptions: [] })
    } else {
      this.setState({ selectedOptions: options })
      onChange(options)
    }
  }

  renderAllOption() {
    const label = "All"
    const isChecked = this.isAllSelected()
    const onChange = this.toggleAll.bind(this)
    const classes = classNames("all-option", { "active": isChecked });

    return (
      <li key={label} onClick={onChange} className={classes} onChange={onChange}>
        <input type="checkbox" name={label} checked={isChecked} onChange={() => { }} />
        <label>{label}</label>
      </li>
    )
  }

  toggleValue(option) {
    const { onChange } = this.props
    let { valueKey } = this.props
    const { selectedOptions } = this.state
    valueKey = valueKey || 'value'
    const allValues = _.map(selectedOptions, valueKey)
    const hasValue = _.includes(allValues, option[valueKey])
    let newValues = selectedOptions
    if (hasValue) {
      newValues = _.filter(newValues, (value) => value[valueKey] !== option[valueKey])
    } else {
      newValues = _.concat(newValues, option)
    }

    onChange(newValues)
    this.setState({ selectedOptions: newValues })
  }

  renderOption(option, index) {
    let { valueKey, labelKey } = this.props
    valueKey = valueKey || 'value'
    labelKey = labelKey || 'label'
    const value = option[valueKey]
    const label = option[labelKey]
    const { selectedOptions } = this.state
    const onChange = () => this.toggleValue(option)
    const allValues = _.map(selectedOptions, valueKey)
    const isChecked = _.includes(allValues, value)

    return (
      <li key={index} onClick={onChange} className={isChecked ? 'active' : ''} onChange={onChange}>
        <input type="checkbox" onChange={() => { }} name={label} checked={isChecked} />
        <label>{label}</label>
      </li>
    )
  }

  renderOptions() {
    const { options } = this.state

    return options.map((option, index) => this.renderOption(option, index))
  }

  handleChange(e) {
    const keyword = e.target.value
    if (keyword) {
      const options = this.state.options;
      let { labelKey } = this.props
      labelKey = labelKey || 'label'
      let newArray = _.filter(options, function (item) {
        if (typeof item[labelKey] === 'string')
          return item[labelKey].toLocaleLowerCase().includes(keyword)
        return item[labelKey].toString().includes(keyword)
      });
      this.setState({ options: newArray, keyword: keyword })
    } else {
      this.setState({ options: this.props.options, keyword: keyword })
    }
  }

  renderSearchBox() {
    const { searchablePlaceHolder } = this.props
    return (
      <Input
        icon='search'
        iconPosition='left'
        placeholder={searchablePlaceHolder || 'Search...'}
        onChange={(e) => this.handleChange(e)}
        value={this.state.keyword}
      />
    )
  }

  render() {
    const { showAll, placeholder, searchable } = this.props
    const { isOpen } = this.state
    const classes = classNames("wrapper-dropdown", { "active": isOpen });
    return (
      <div className="multi-select-dropdown" ref={this.setWrapperRef}>
        <div onClick={this.toggleDropdown} className='select-text'>{placeholder || 'Select'}
          <Icon name='angle down' />
        </div>
        <div className={classes}>
          <ul autoFocus className="dropdown">
            {searchable ? this.renderSearchBox() : null}
            {showAll ? this.renderAllOption() : null}
            {this.renderOptions()}
          </ul>
        </div>
      </div>
    )
  }
}

MultiSelect.propTypes = {
  showAll: PropTypes.bool,
  placeholder: PropTypes.string,
  options: PropTypes.array,
  selectedValues: PropTypes.array,
  onChange: PropTypes.func,
}

export default MultiSelect
