import React from 'react'

const renderCustomRadioField = ({ label, htmlFor, input, disabled, type }) => {
  return (
    <div className="radio-items">
      <input id={htmlFor} disabled={disabled} {...input} type={type} className="form-check-input" />
      <label htmlFor={htmlFor}>{label}</label>
    </div>
  )
}

export default renderCustomRadioField
