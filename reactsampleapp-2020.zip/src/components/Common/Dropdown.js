import React, { Component } from 'react'
import Select from 'react-select'
import { Icon } from 'semantic-ui-react'
import classNames from 'classnames';

class SelectInput extends Component {
  constructor(props) {
    super(props);
    this.state = {
      stayOpen: false
    };
  }
  onChange(data) {
    this.props.input.onChange(data);
    if (this.props.handleOnSelect) {
      this.props.handleOnSelect(data, this.props.childName)
    }
  }
  onInputChange(data) {
    if (this.props.handleSearchChange) {
      this.props.handleSearchChange(data, this.props.childName)
    }
  }

  render() {
    const { childName, id, input, options, label, iconName, placeholder, popUpOpen,
      meta: { touched, error }, showLoading, readOnly, clearable, required } = this.props
    const placeholderTxt = placeholder ? placeholder : ''
    const className = classNames('', {
      "error": touched && error,
      "read-only-select": readOnly
    });
    const idTxt = id ? id : input.name
    const clearableValue = clearable ? clearable : false
    return (
      <div className="input_field" >
        {label && <label>{label} {required && <em>*</em>}</label>}
        <div className="input_holder">
          <Select
            closeOnSelect={!this.state.stayOpen}
            {...this.props}
            value={input.value || ''}
            onBlur={() => {
              input.onBlur();
            }}
            onFocus={() => {
              input.onFocus();
            }}
            openOnFocus={true}
            onChange={this.onChange.bind(this)}
            isClearable={!readOnly ? (clearableValue) : false}
            options={!readOnly ? options : []}
            tabSelectsValue={false}
            onInputChange={this.onInputChange.bind(this)}
            placeholder={placeholderTxt}
            isSearchable={!readOnly}
            isDisabled={readOnly}
            isLoading={showLoading}
            className={className}
            id={idTxt}
          />
          {touched && error && <p className="error_message">{error}</p>}
          {iconName && <span className="copy-icon" onClick={() => { popUpOpen('help', childName) }}><Icon disabled name={iconName} /></span>}
        </div>
      </div>
    );
  }
}

export default SelectInput
