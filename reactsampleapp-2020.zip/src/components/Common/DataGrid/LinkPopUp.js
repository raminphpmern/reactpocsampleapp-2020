import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Popup from 'components/Common/Popup';
import jsonLogic from 'json-logic-js';

class LinkPopUp extends Component {
  constructor(props) {
    super(props);
    this.state = { value: props.value, isOpen: false };
    this.toggle = this.toggle.bind(this)
  }

  toggle(event) {
    this.setState({ isOpen: !this.state.isOpen })
    if (event)
      event.preventDefault()
  }

  showLink(rule, rowInfo) {
    if (rule) {
      return jsonLogic.apply(rule, rowInfo)
    } else {
      return true
    }
  }

  render() {
    const { value, isOpen } = this.state
    const { name, defaultValue, children, dependentValues, linkJsonRule } = this.props
    return (
      <div>
        <Popup size="large" open={isOpen} close={() => { this.toggle() }}
          header={name} description={React.cloneElement(children[1], { name: name, rowInfo: dependentValues })} />
        {this.showLink(linkJsonRule, dependentValues) && <Link to='' onClick={this.toggle}>{value || defaultValue}</Link>}
      </div>
    )
  }
}

export default LinkPopUp