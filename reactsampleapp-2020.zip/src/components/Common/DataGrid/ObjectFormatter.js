export default ({ row, fieldName }) => {
  if (row[fieldName] && typeof row[fieldName] === 'object') {
    return row[fieldName].label || ''
  } else
    return row[fieldName] || ''
};
