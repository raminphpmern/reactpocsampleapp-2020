import React, { Component } from 'react';
import { generateBlobUrl } from 'lib/CommonHelper';
import _ from 'lodash';

class FieldUpload extends Component {
  componentDidMount() {
    this.refs.fileUploader.click();
  }

  onChange(event) {
    let file = event.target.files[0]
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.setState({ fileName: file.name })
      let hash = { fileName: file.name, base64: reader.result }
      _.merge(hash, generateBlobUrl(reader.result))
      this.props.getFileName(hash)
    }
  }

  render() {
    return (
      <input
        ref="fileUploader"
        type="file"
        accept="image/png, image/jpeg"
        onChange={this.onChange.bind(this)}
        style={{ display: 'none' }}
      />
    )
  }
}

export default FieldUpload
