import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import FieldUpload from './FileUpload';

class FileUploadEditor extends Component {
  constructor(props) {
    super(props);
    this.state = { value: props.rowData[this.props.column.key] };
  }

  getValue() {
    return { [this.props.column.key]: this.state.value };
  }

  getInputNode() {
    return ReactDOM.findDOMNode(this).getElementsByTagName("input")[0];
  }

  setValue(value) {
    this.setState({ value: value }, () => this.props.onCommit());
  }

  render() {
    return (
      <FieldUpload getFileName={this.setValue.bind(this)} value={this.state.value} />
    );
  }
}

export default FileUploadEditor