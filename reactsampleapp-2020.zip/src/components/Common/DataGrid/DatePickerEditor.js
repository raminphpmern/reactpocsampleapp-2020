import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import { commonDateFormat, commonDateDisplayFormat } from 'config';

class DatePickerEditor extends Component {
  constructor(props) {
    super(props);
    this.state = { date: props.rowData[this.props.column.key] };
  }

  getValue() {
    return { [this.props.column.key]: this.state.date };
  }

  getInputNode() {
    return ReactDOM.findDOMNode(this).getElementsByTagName("input")[0];
  }

  setDate(date) {
    this.setState({ date: moment(date).format(commonDateDisplayFormat) }, () => this.props.onCommit());
  };
  render() {
    return (
      <DatePicker
        dateFormat={commonDateFormat}
        selected={this.state.date ? moment(this.state.date, commonDateDisplayFormat)._d : ''}
        onChange={this.setDate.bind(this)}
      />
    );
  }
}

export default DatePickerEditor