import React, { Component } from 'react';
import { Image, Icon } from 'semantic-ui-react';
import { generateBlobUrl } from 'lib/CommonHelper';
import Popup from 'components/Common/Popup';

class PreviewImage extends Component {
  render() {
    const { fileName, base64, imageUrl } = this.props
    return (<div>
      <a download={`${fileName}`} href={base64}>
        <Icon name="download" /> Download
      </a>
      <Image src={imageUrl} alt={fileName} className="preview-img" />
    </div>)
  }
}

class ImageFormatter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };
    this.toggle = this.toggle.bind(this)
  }

  toggle() {
    this.setState({ open: !this.state.open })
  }

  getFileInfo(value, dependentValues, fileColumn) {
    if (typeof (value) === 'object') {
      return value
    } else {
      let base64 = ''
      if (dependentValues && fileColumn) {
        base64 = dependentValues[fileColumn]
      }
      return { base64: base64, fileName: value }
    }
  }

  render() {
    let { value, dependentValues, fileColumn } = this.props
    value = this.getFileInfo(value, dependentValues, fileColumn)
    const base64 = value ? value.base64 : null
    const fileName = value ? value.fileName : 'FILENAME'
    const { imageUrl, mimeType } = generateBlobUrl(base64)
    return (
      <div className="file_field" >
        <Popup open={this.state.open} close={this.toggle}
          header="Preview" description={<PreviewImage close={this.toggle} imageUrl={imageUrl} base64={base64} mimeType={mimeType} fileName={fileName} />} />
        <div className="image-upload icons">
          {imageUrl && <Icon name="eye" onClick={this.toggle} title="preview" />}
          {imageUrl && <a download={fileName} href={base64} className="icons" title="download">
            <Icon name="download" />
          </a>}
        </div>
      </div>
    )
  }
}

export default ImageFormatter