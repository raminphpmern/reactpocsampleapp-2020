import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class NumberEditor extends Component {
  constructor(props) {
    super(props);
    this.state = { number: props.rowData[this.props.column.key] || '' };
  }

  getValue() {
    return { [this.props.column.key]: this.state.number };
  }

  getInputNode() {
    return ReactDOM.findDOMNode(this).getElementsByTagName("input")[0];
  }

  onChange(event) {
    const { allowNegNumber, onCommit } = this.props
    if (allowNegNumber && allowNegNumber === true) {
      this.setState({ number: event.target.value }, () => onCommit());
    } else {
      if (event.target.value > 0)
        this.setState({ number: event.target.value }, () => onCommit());
      else
        this.setState({ number: '' }, () => onCommit());
    }
  }

  render() {
    return (
      <input
        ref="inputNumber"
        style={{ width: '100%', height: '100%' }}
        value={this.state.number}
        type='number'
        onChange={this.onChange.bind(this)}
        autoFocus={true}
        min={0}
      />
    );
  }
}

export default NumberEditor