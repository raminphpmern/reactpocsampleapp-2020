import React, { Component } from 'react';
import ReactDataGrid from 'react-data-grid';
import ReactPaginate from 'react-paginate';
import { Icon } from 'semantic-ui-react';
import CustomToolbar from './CustomToolbar';
import className from 'classnames';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import moment from 'moment';
import jsonLogic from 'json-logic-js';
import _ from 'lodash';
import './dataGrid.css';

const EmptyRowsView = () => {
  const message = "No data";
  return (
    <div
      style={{ textAlign: "center", backgroundColor: "#ddd", padding: "100px" }}>
      <h3>{message}</h3>
    </div>
  );
};

const defaultColumnProperties = {
  resizable: true,
  sortable: true,
  filterable: true
};

class DataGrid extends Component {
  constructor(props) {
    super(props)
    this.state = {
      rows: [],
      selectedIndexes: [],
      offset: 0,
      limit: 10,
      pageCount: 0,
      selectedColumn: 'ALL',
      checkedRows: [],
      pageNo: 1,
      search: false,
      searchKeyWord: '',
    }
  }

  componentDidMount() {
    if (this.props && this.props.rows) {
      let { rows, totalPages } = this.props
      this.setState({ rows: rows, pageCount: totalPages || 0 })
    }
  }

  componentWillUnmount() {
    if (this.props.initialize)
      this.props.initialize()
  }

  componentWillReceiveProps(nextProps) {
    const { defaultUptRule } = this.props
    if (this.props !== nextProps) {
      if (this.props.rows !== nextProps.rows) {
        let { rows, totalPages } = nextProps
        let newArray = rows
        const { search, searchKeyWord } = this.state
        if (search && searchKeyWord.length > 3) {
          newArray = _.filter(rows, (item) => {
            return Object.keys(item).some(function (k) {
              let temp = item[k] || ''
              return temp.toLocaleLowerCase().includes(searchKeyWord.toLocaleLowerCase())
            })
          });
        }
        this.setState({ rows: newArray, pageCount: totalPages || 0, selectedIndexes: [], checkedRows: [] })
      }
      if (this.props.defaultValues !== nextProps.defaultValues) {
        let { checkedRows, rows } = this.state
        this.setState({ rows: [], checkedRows: [] })
        let arr = []
        let res = _.reduce(rows, (result, val) => {
          if (checkedRows.includes(val)) {
            if (defaultUptRule) {
              if (jsonLogic.apply(defaultUptRule, val)) {
                val = { ...val, ...nextProps.defaultValues }
              }
            } else {
              val = { ...val, ...nextProps.defaultValues }
            }
            arr.push(val)
          }
          result.push(val)
          return result
        }, []);
        this.setState({ rows: res, checkedRows: arr })
        if (this.props.selectedRows)
          this.props.selectedRows(arr)
      }
    }
  }

  formatColumns(data) {
    const gridWidth = parseInt(document.querySelector("#root").clientWidth, 10); //selector for grid
    let combinedColumnWidth = 0;

    for (let i = 0; i < data.columns.length; i++) {
      data.columns[i].width = this.getTextWidth(data, i);
      combinedColumnWidth += data.columns[i].width;
    }

    if (combinedColumnWidth < gridWidth) {
      data.columns = this.distributeRemainingSpace(
        combinedColumnWidth,
        data.columns,
        gridWidth
      );
    }
    return data;
  }

  getTextWidth(data, i) {
    const rowValues = [];
    const reducer = (a, b) => {
      a = a || ''
      b = b || ''
      return (a.length > b.length ? a : b)
    };
    const cellPadding = 16;
    const arrowWidth = 18;
    let longestCellData,
      longestCellDataWidth,
      longestColName,
      longestColNameWidth,
      longestString;

    for (let row of data.rows) {
      rowValues.push(row[data.columns[i].key]);
    }
    longestCellData = rowValues.reduce(reducer);
    longestColName = data.columns[i].name;
    longestCellDataWidth = Math.ceil(
      this.getCanvas().measureText(longestCellData).width
    );
    longestColNameWidth =
      Math.ceil(this.getCanvas("bold ").measureText(longestColName).width) +
      arrowWidth;

    longestString = Math.max(longestCellDataWidth, longestColNameWidth);

    return longestString + cellPadding;
  }

  getCanvas(fontWeight = "") {
    if (!this.canvas) {
      this.canvas = document.createElement("canvas");
      this.canvasContext = this.canvas.getContext("2d");
    }
    this.canvasContext.font = `${fontWeight}16px sans-serif`;

    return this.canvasContext;
  }

  distributeRemainingSpace(combinedColumnWidth, columns, gridWidth) {
    const spaceLeftOver = gridWidth - combinedColumnWidth;
    const remainder = spaceLeftOver % columns.length;
    const equalSpaceLeft = spaceLeftOver - remainder;

    columns[0].width += remainder; //any remaining space after distributing equally should go on first column

    for (let col of columns) {
      col.width += equalSpaceLeft / columns.length - 18;
    }
    return columns;
  }

  onGridRowsUpdated = ({ fromRow, toRow, updated }) => {
    this.setState(state => {
      const rows = state.rows.slice();
      for (let i = fromRow; i <= toRow; i++) {
        rows[i] = { ...rows[i], ...updated };
      }
      return { rows };
    }, () => {
      if (this.props.rowEdit)
        this.props.rowEdit(this.state.rows[fromRow], updated)
    });
  };

  GetSortedValue(sortColumn, sortDirection) {
    if (this.props.onSort) {
      this.props.onSort()
    } else {
      let data = this.state.rows;
      if (sortDirection !== 'NONE') {
        data = _.orderBy(data, (row) => {
          const isDate = row[sortColumn] && row[sortColumn].split('/').length === 3 ? true : false
          return isDate ? moment(row[sortColumn]).format('YYYYMMDD') : row[sortColumn]
        }, [sortDirection.toLocaleLowerCase()]);
        let selectedIndexes = _.reduce(this.state.checkedRows, (arr, selectedItem) => {
          arr.push(_.findIndex(data, (item) => item[this.props.rowKey] === selectedItem[this.props.rowKey]))
          return arr
        }, [])
        this.setState({ rows: data, selectedIndexes: selectedIndexes })
        if (this.props.resetRows) {
          this.props.resetRows(data)
        }
      }
    }
  }

  getFilteredValue(filter) {
    let data = this.state.rows;
    let newArray = _.filter(data, function (item) {
      if (typeof item[filter.column.key] === 'string')
        return item[filter.column.key].toLocaleLowerCase().includes(filter.filterTerm)
      return item[filter.column.key].toString().includes(filter.filterTerm)
    });
    this.setState({ rows: newArray })
  }

  onRowsSelected = rows => {
    let { selectedIndexes, checkedRows } = this.state
    if (this.props.singleSelect) {
      selectedIndexes = []
      checkedRows = []
    }
    selectedIndexes = selectedIndexes.concat(
      rows.map(r => r.rowIdx)
    )
    checkedRows = checkedRows.concat(
      rows.map(r => r.row)
    )
    this.setState({
      selectedIndexes: selectedIndexes,
      checkedRows: checkedRows
    }, () => {
      if (this.props.input && this.props.input.onChange) {
        this.props.input.onChange(this.state.checkedRows)
      }
      if (this.props.selectedRows) {
        this.props.selectedRows(this.state.checkedRows)
      }
    });
  };

  onRowsDeselected = rows => {
    let rowIndexes = rows.map(r => r.rowIdx);
    if (rows.length === 1) {
      this.setState({
        selectedIndexes: this.state.selectedIndexes.filter(
          i => rowIndexes.indexOf(i) === -1
        ),
        checkedRows: this.state.checkedRows.filter(val =>
          JSON.stringify(val) !== JSON.stringify(rows[0].row)
        )
      }, () => {
        if (this.props.input && this.props.input.onChange) {
          this.props.input.onChange(this.state.checkedRows)
        }
        if (this.props.selectedRows) {
          this.props.selectedRows(this.state.checkedRows)
        }
      });
    } else {
      this.setState({
        selectedIndexes: [],
        checkedRows: [],
      }, () => {
        if (this.props.input && this.props.input.onChange) {
          this.props.input.onChange(this.state.checkedRows)
        }
        if (this.props.selectedRows) {
          this.props.selectedRows(this.state.checkedRows)
        }
      });
    }
  };

  handlePageClick = data => {
    let selected = data.selected;
    this.setState({ pageNo: selected + 1, selectedIndexes: [], checkedRows: [] })
    if (this.props.paginationHandler) {
      this.props.paginationHandler(selected + 1, this.state.limit)
    }
  };

  handleAddRow() {
    let { defaultNewRowHash } = this.props
    const { rows } = this.state
    defaultNewRowHash = defaultNewRowHash || {}
    const lastRow = rows[rows.length - 1]
    let uniqId = rows.length + 1
    if (lastRow && lastRow.new) {
      uniqId = lastRow.id + 1
    }
    defaultNewRowHash = _.merge(defaultNewRowHash, { new: true, id: uniqId })
    this.setState({ rows: [...rows, _.cloneDeep(defaultNewRowHash)] })
  }

  handleDeleteRow() {
    let { rows, checkedRows, selectedIndexes } = this.state
    if (checkedRows.length > 0) {
      let newRows = _.filter(checkedRows, (row) => row.new)
      newRows = _.map(newRows, 'id')
      _.remove(rows, (row) => _.includes(newRows, row.id))
      _.remove(checkedRows, (row) => row.new)
      if (checkedRows.length === 0) {
        selectedIndexes = []
      }
      this.setState({ rows, selectedIndexes })
      if (this.props.dropSelectedRows && checkedRows.length > 0) {
        this.props.dropSelectedRows(checkedRows)
      }
    }
  }

  columSelector(e) {
    this.setState({ selectedColumn: e.target.value })
  }

  handleSearch(e) {
    const value = e.target.value
    if (value && value.length > 3) {
      const { selectedColumn } = this.state
      if (selectedColumn) {
        if (this.props.onColumnSearch && selectedColumn !== 'ALL') {
          this.props.onColumnSearch(selectedColumn, value)
        } else {
          let data = this.props.rows;
          let newArray = _.filter(data, (item) => {
            return Object.keys(item).some(function (k) {
              let temp = item[k] || ''
              return temp.toLocaleLowerCase().includes(value.toLocaleLowerCase())
            })
          });
          this.setState({ rows: newArray, selectedIndexes: [], checkedRows: [], search: true, searchKeyWord: value })
        }
      }
    } else {
      this.setState({ rows: this.props.rows, searchKeyWord: value })
    }
    if (!value) {
      this.setState({ search: false, searchKeyWord: '' })
    }
  }

  exportHandleChange(val) {
    switch (val) {
      case 'csv':
        this.exportToCsv();
        break;
      case 'xls':
        this.exportToXls();
        break;
      case 'pdf':
        this.exportToPdf();
        break;
      default:
        break;
    }
  }

  handleLimit(e) {
    this.setState({ limit: e.target.value })
    if (this.props.changeLimit) {
      this.props.changeLimit(this.state.pageNo, e.target.value)
    }
    // limit handler e.target.value
  }

  buildDataArray() {
    const { columns } = this.props
    const headers = _.map(columns, 'name')
    const { rows } = this.state
    return _.reduce(rows, (arr, row) => {
      let temp = []
      _.map(columns, (header) => {
        let key = header.key
        if (row[key]) {
          temp.push(row[key])
        } else {
          temp.push('')
        }
      })
      arr.push(temp)
      return arr
    }, [headers])
  }

  exportToCsv() {
    let csv = this.buildDataArray()
    csv = csv.join("\n")
    let fileName = this.props.exportName || 'export'
    fileName += `-${moment().format('YYYY-MM-DD-HH-mm-ss')}.csv`
    const data = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    FileSaver.saveAs(data, fileName);
  }

  exportToXls() {
    const csv = this.buildDataArray()
    const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const fileExtension = '.xlsx';
    let fileName = this.props.exportName || 'export'
    fileName += `-${moment().format('YYYY-MM-DD-HH-mm-ss')}`
    const ws = XLSX.utils.aoa_to_sheet(csv);
    const wb = { Sheets: { 'data': ws }, SheetNames: ['data'] };
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: fileType });
    FileSaver.saveAs(data, fileName + fileExtension);
  }

  exportToPdf() {
    const unit = "pt";
    const size = "a2"; // Use A1, A2, A3 or A4
    const orientation = "landscape"; // portrait or landscape
    const doc = new jsPDF(orientation, unit, size);
    const { columns } = this.props
    let headers = _.reduce(columns, (arr, col) => {
      let hash = {}
      hash['dataKey'] = col['key']
      hash['title'] = col['name']
      arr.push(hash)
      return arr
    }, [])

    const { rows } = this.state
    doc.autoTable(headers, rows, {
      theme: 'grid',
      headStyles: {
        fontSize: '7',
      },
      bodyStyles: {
        lineColor: [0, 0, 0],
        fontSize: '7',
      },
      margin: { top: 60 },
      pageBreak: 'auto',
      tableWidth: 'auto',
    });
    let fileName = this.props.exportName || 'export'
    fileName += `-${moment().format('YYYY-MM-DD-HH-mm-ss')}.pdf`
    doc.save(fileName);
  }

  renderEmptyGrid() {
    const { columns, width, showCheckbox, tags, removeTagFilter, editTag, pageLimit, addRow } = this.props
    const { rows } = this.state
    return (<ReactDataGrid
      columns={columns.map(c => ({ ...c, ...defaultColumnProperties, ...{ width: width } }))}
      rowGetter={i => rows[i]} rowsCount={0}
      onGridSort={(sortColumn, sortDirection, options) =>
        this.GetSortedValue(sortColumn, sortDirection, options)
      }
      toolbar={
        <CustomToolbar
          addRow={addRow}
          onAddRow={this.handleAddRow.bind(this)}
          addRowButtonText={<Icon name="add" />}
          fullSearch={true}
          handleLimit={this.handleLimit.bind(this)}
          limit={pageLimit || 10}
          tags={tags}
          removeTagFilter={removeTagFilter}
          editTag={editTag}
        />}
      rowSelection={{
        showCheckbox: (showCheckbox === undefined ? true : showCheckbox),
        enableShiftSelect: true,
      }}
      emptyRowsView={EmptyRowsView} />)
  }

  renderDataGrid() {
    const { columns, showCheckbox, rowKey, enableFilter, enableExport, addRow, deleteRow, tags, removeTagFilter, editTag,
      enableHeaderSelector, headerSelectorOptions, pageLimit, removeColumnHeaderFormatter, hideLimit } = this.props
    const { rows } = this.state
    let formattedColumns = []
    if (rows.length === 0) {
      formattedColumns = { columns: columns }
    } else {
      if (removeColumnHeaderFormatter) {
        formattedColumns = { columns: columns }
      } else {
        formattedColumns = this.formatColumns({ columns: columns, rows: rows })
      }
    }
    return (
      <ReactDataGrid
        rowKey={rowKey}
        columns={formattedColumns.columns.map(c => ({ ...c, ...defaultColumnProperties }))}
        rowGetter={i => rows[i]}
        rowsCount={rows.length}
        onGridRowsUpdated={this.onGridRowsUpdated}
        enableCellSelect={true}
        minHeight={rows.length * 35 + 50}
        onColumnResize={(idx, width) =>
          console.log(`Column ${idx} has been resized to ${width}`)
        }
        onGridSort={(sortColumn, sortDirection, options) =>
          this.GetSortedValue(sortColumn, sortDirection, options)
        }
        toolbar={
          <CustomToolbar
            addRow={addRow}
            onAddRow={this.handleAddRow.bind(this)}
            addRowButtonText={<Icon name="add" />}
            deleteRow={deleteRow}
            onDeleteRow={this.handleDeleteRow.bind(this)}
            deleteRowButtonText={<Icon name="delete" />}
            enableFilter={enableFilter}
            filterRowsButtonText={<Icon name="filter" />}
            export={enableExport && rows.length > 0}
            exportButtonText={<Icon name="download" />}
            exportHandleChange={this.exportHandleChange.bind(this)}
            fullSearch={true}
            columns={columns}
            columSelector={this.columSelector.bind(this)}
            handleSearch={this.handleSearch.bind(this)}
            handleLimit={this.handleLimit.bind(this)}
            limit={pageLimit || 10}
            tags={tags}
            removeTagFilter={removeTagFilter}
            editTag={editTag}
            enableHeaderSelector={enableHeaderSelector}
            headerSelectorOptions={headerSelectorOptions}
            hideLimit={hideLimit}
          />}
        onAddFilter={filter =>
          this.getFilteredValue(filter)
        }
        rowSelection={{
          showCheckbox: (showCheckbox === undefined ? true : showCheckbox),
          enableShiftSelect: true,
          onRowsSelected: this.onRowsSelected,
          onRowsDeselected: this.onRowsDeselected,
          selectBy: {
            indexes: this.state.selectedIndexes
          },
        }}
        emptyRowsView={EmptyRowsView}
      />
    )
  }

  render() {
    const { name, totalPages, showSelectedCount, totalRecord, singleSelect } = this.props
    const { rows, pageCount, search } = this.state
    const rowText = this.state.selectedIndexes.length === 1 ? "row" : "rows";
    const wrapperClass = className('react-data-grid-wrapper', { 'disable-select-all': singleSelect }, { 'empty-grid': rows.length === 0 && !search })
    return (
      <div className={wrapperClass}>
        <input type="hidden" name={name} readOnly={true} />
        {showSelectedCount && <span>
          {this.state.selectedIndexes.length} {rowText} selected
        </span>}
        {(search || rows.length > 0) && this.renderDataGrid()}
        {rows.length === 0 && !search && this.renderEmptyGrid()}
        <div className="pagination-wrapper">
          <span className="total-record-count">Showing {rows.length} records out of {totalRecord}</span>
          {totalPages > 0 && <ReactPaginate
            previousLabel={'<<'}
            nextLabel={'>>'}
            breakLabel={'...'}
            breakClassName={'break-me'}
            pageCount={pageCount}
            marginPagesDisplayed={1}
            pageRangeDisplayed={1}
            onPageChange={this.handlePageClick}
            containerClassName={'pagination'}
            subContainerClassName={'pages pagination'}
            activeClassName={'active'}
          />}
        </div>
      </div>
    )
  }
}

export default DataGrid
