import React, { Component } from 'react';
import { connect } from 'react-redux';
import Select from 'react-select';

class DropDown extends Component {
  constructor(props) {
    super(props);
    this.state = { value: props.rowData[this.props.column.key] };
  }

  onChange(option) {
    let value = option.label
    const { resultType, setValue } = this.props
    if (resultType && resultType === 'object') {
      value = option
    }
    this.setState({ value: value })
    setValue(value);
  }

  render() {
    const list = this.props[this.props.propName]
    return (
      <Select onChange={this.onChange.bind(this)} options={list} />
    );
  }
}

const mapStateToProps = state => ({
  bankCodes: state.masterReducer.options.bankCodes,
  serialNos: state.inventoryHubReducer.serialNumberOptions,
  discrepancy: state.masterReducer.options.discrepancy,
  expenseType: state.tripplanReducer.options.expenseType,
  incidentType: state.tripplanReducer.options.incidentType,
  accidentType: state.tripplanReducer.options.accidentType,
  damageCode: state.masterReducer.options.damageCode,
  typeOptions: state.tripAttachmentsReducer.typeOptions,
  docType: state.masterReducer.options.docType,
  typeOptions: state.updateResourceReducer.typeOptions,
})

export default connect(mapStateToProps, null)(DropDown)