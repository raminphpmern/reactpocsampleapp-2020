import React from 'react'
import { Toolbar } from 'react-data-grid-addons';
import { Dropdown, Label, Icon, Input } from 'semantic-ui-react';
import MultiSelect from 'components/Common/MultiSelect';

import _ from 'lodash'

export default class CustomToolbar extends Toolbar {

  onDeleteRow(e) {
    if (this.props.onDeleteRow !== null && this.props.onDeleteRow instanceof Function) {
      this.props.onDeleteRow(e);
    }
  }

  renderDeleteRowButton() {
    if (this.props.onDeleteRow) {
      return (<button type="button" className="btn delete" onClick={this.onDeleteRow.bind(this)}>
        {this.props.deleteRowButtonText}
      </button>);
    }
  }

  onExport() {

  }
  handleChange(val) {
    this.props.exportHandleChange(val)
  }

  renderExportButton() {
    if (this.props.export) {
      return (
        <div className="export-btn">
          <Dropdown
            icon='download'
            floating
            className='icon'
          >
            <Dropdown.Menu>
              <Dropdown.Item onClick={() => this.handleChange('csv')}>CSV</Dropdown.Item>
              <Dropdown.Item onClick={() => this.handleChange('xls')}>XLS</Dropdown.Item>
              {/*<Dropdown.Item onClick={() => this.handleChange('pdf')}>PDF</Dropdown.Item>*/}
            </Dropdown.Menu>
          </Dropdown>
        </div>
      )
    }
  }

  fullSearch() {

  }

  renderFullSearchApi() {
    if (this.props.fullSearch) {
      return (
        <div className="full-search">
          <Input
            icon='search'
            iconPosition='left'
            placeholder='search'
            onChange={this.props.handleSearch}
          />
        </div>

      )
    }
  }

  renderLimits() {
    const { handleLimit, limit } = this.props;
    if (handleLimit) {
      const totalRecord = 10
      return (
        <select onChange={handleLimit} defaultValue={limit || 10}>
          {_.range(10).map((item, i) => {
            const value = (item + 1) * totalRecord
            return (<option value={value} key={i}>{value}</option>)
          })}
        </select>
      )
    }
  }

  removeTag(value, key) {
    const { removeTagFilter } = this.props
    if (removeTagFilter) {
      removeTagFilter(value, key)
    }
  }

  popTagDtl(key) {
    const { editTag } = this.props

    if (editTag) {
      editTag(key)
    }
  }

  renderTags() {
    const { tags } = this.props
    if (tags && Object.keys(tags).length > 0) {
      let i = 0;
      return _.map(tags, (obj, key) => {
        i += 1
        let value = typeof (obj.value) === 'object' ? obj.value.label : obj.value.toString()
        return (
          <Label as="a" key={i} title={obj.label} className='label-tag'>
            <span onClick={() => this.popTagDtl(key)}>{`${obj.label} --> ${value}`}</span>
            <Icon name='delete' onClick={() => this.removeTag(value, key)} />
          </Label>
        )
      })
    } else {
      return null
    }
  }

  renderHeaderSelector() {
    const { headerSelectorOptions } = this.props
    return (
      <div className="header-selector">
        <MultiSelect
          {...headerSelectorOptions}
          placeholder="Column Chooser"
          showAll={true}
          searchable={true}
          valueKey='key'
          labelKey='name'
        />
      </div>
    )
  }

  render() {
    const { addRow, deleteRow, enableFilter, enableHeaderSelector, hideLimit } = this.props
    return (
      <div className="react-grid-Toolbar">
        <div className='grid-tags'>
          {this.renderTags()}
        </div>
        <div className="tools">
          {hideLimit && hideLimit === true ? null : this.renderLimits()}
          {addRow && this.renderAddRowButton()}
          {deleteRow && this.renderDeleteRowButton()}
          {enableFilter && this.renderToggleFilterButton()}
          {this.renderExportButton()}
          {enableHeaderSelector && this.renderHeaderSelector()}
          {this.renderFullSearchApi()}
        </div>
      </div>
    )
  }
}
