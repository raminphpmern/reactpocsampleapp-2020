import React, { Component } from 'react';
import { getReasonCode, getEmployeeDetails } from "actions/masterAction";
import { connect } from "react-redux";

class Search extends Component {
  constructor(props) {
    super(props);
    this.state = { value: props.rowData[this.props.column.key] };
  }

  onChange(e) {
    const value = e.target.value
    const { propName, getReasonCode, getEmployeeDetails } = this.props
    if (e.target.value.length >= 3) {
      if (propName === 'reason_code')
        getReasonCode(`keyword=${value}`)
      else
        getEmployeeDetails(`keyword=${value}`)
    }
    this.setState({ value: value })
  }

  setValue(option) {
    this.props.setValue(option.value);
  }

  render() {
    const { propName } = this.props
    const data = this.props[propName]
    return (
      <div>
        <input
          value={this.state.value}
          onChange={this.onChange.bind(this)}
        />
        {data && data.length > 0 && <ul autoFocus id="search-edit" className="search-edit">
          {data.map((item, key) => {
            return (
              <li value={key} className={'active'} key={key} onClick={() => this.setValue(item)}>{item.label}</li>
            )
          })}
        </ul>}
      </div>);
  }
}

const mapDispatchToProps = (dispatch) => ({
  getReasonCode: (queryStr) => dispatch(getReasonCode('reason_code', queryStr)),
  getEmployeeDetails: (queryStr) => dispatch(getEmployeeDetails('employee', queryStr)),
})

const mapStateToProps = state => ({
  reason_code: state.masterReducer.options.reason_code,
  employee: state.masterReducer.options.employee,
})

export default connect(mapStateToProps, mapDispatchToProps)(Search)