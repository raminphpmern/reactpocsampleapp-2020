import React, { Component } from 'react';
import { Field } from 'redux-form';
import { Grid } from 'semantic-ui-react';
import { stringToComponentMapper } from './Helper';
import ReactStars from 'react-stars';
import _ from 'lodash';
import './index.css';

const cols = {
  '3': 5,
  '4': 4,
}

class DynamicFields extends Component {
  renderFields(propsName) {
    let fields = this.props[propsName]
    if (!Array.isArray(fields)) {
      fields = fields ? [fields] : []
    }
    return fields.map((field, key) => {
      let methods = field.methods || {};
      let props = field.values ? field.values.props || {} : {};
      if (Object.keys(methods).length > 0) {
        methods = _.reduce(methods, (hash, v, k) => {
          hash[k] = this.props[v]
          return hash;
        }, {})
      }
      if (Object.keys(props).length > 0) {
        props = _.reduce(props, (hash, v, k) => {
          if (k === 'options') {
            hash[k] = this.props[v] || []
          } else {
            hash[k] = this.props[v] || v
          }
          return hash
        }, {})
      }

      return (
        <Grid.Column width={_.includes(['customDropDownDatePicker'], field.type) ? 8 : (cols[this.props.cols] || 4)} key={key}>
          {this.renderBasedonType(field, methods, props)}
        </Grid.Column>
      )
    })
  }

  renderBasedonType(field, methods, props) {
    switch (field.type) {
      case 'radioButton': {
        return this.renderRadioField(field)
      }
      case 'customDropDownDatePicker': {
        return this.renderDropDownDatePickerField(field)
      }
      case 'inputRatingStar': {
        return this.renderInputRatingStar(field, methods, props)
      }
      default:
        return this.renderField(field, methods, props)
    }
  }

  renderField(field, methods, props) {
    return (
      <Field
        name={field.value}
        component={stringToComponentMapper[field.type]}
        type={field.filedType || 'text'}
        label={field.label}
        id={field.id || field.name}
        iconName={field.iconName}
        {...methods}
        {...props}
      />
    )
  }

  renderRadioField(field) {
    return (
      <div className='input_field'>
        <label>{field.label}</label>
        <div className='input_holder'>
          <div className='radio'>
            {this.radioOptions(field)}
          </div>
        </div>
      </div>
    )
  }

  renderDropDownDatePickerField(field) {

    const datePicker = _.map(field.datePicker.fields, (picker) => {
      return (<Field
        name={picker.value}
        component={stringToComponentMapper['dateTime']}
        id={picker.value}
      />)
    })
    return (
      <div className='drop-down-date-picker'>
        <label>{field.label}</label>
        <Field
          name={field.value}
          component={stringToComponentMapper['dropDown']}
          id={field.id || field.name}
          options={field.values.options}
        />
        {datePicker}
      </div>
    )
  }

  radioOptions(field) {
    const { options } = field
    return options.map((option, key) => {
      return <Field
        key={key}
        name={field.value}
        htmlFor={`radio${key}`}
        value={option.value}
        label={option.label}
        type='radio'
        component={stringToComponentMapper[field.type]} />
    })
  }

  renderInputRatingStar(field, methods, props) {
    return (<div className='rating-field'>
      <ReactStars
        count={5}
        {...methods}
        {...props}
        size={24}
        edit={true}
        half={false}
        color2={'#ffd700'}
      />
    </div>)
  }

  render() {
    return this.renderFields('filterFields')
  }
}


export default DynamicFields