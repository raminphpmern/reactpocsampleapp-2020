import Dropdown from 'components/Common/Dropdown';
import InputSearchField from 'components/Common/InputSearchField';
import DateTimePicker from 'components/Common/DateTimePicker';
import Checkbox from 'components/Common/Checkbox';
import inputField from 'components/Common/InputField';
import CustomRadioFiled from 'components/Common/CustomRadio';
import FieldUpload from 'components/Common/FileUpload';

export const stringToComponentMapper = {
  dateTime: DateTimePicker,
  inputSearch: InputSearchField,
  dropDown: Dropdown,
  checkBox: Checkbox,
  inputBox: inputField,
  radioButton: CustomRadioFiled,
  fileUpload: FieldUpload,
}