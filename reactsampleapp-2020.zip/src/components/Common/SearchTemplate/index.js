import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { Icon } from 'semantic-ui-react';
import Select from 'react-select';
import MultiSelect from 'components/Common/MultiSelect';
import Popup from 'components/Common/Popup';
import TemplatePopup from './TemplatePopup';

class SearchTemplate extends Component {
  constructor(props) {
    super(props)
    this.state = {
      isPopupOpen: false
    }
    this.togglePopup = this.togglePopup.bind(this)
  }

  togglePopup() {
    this.setState({ isPopupOpen: !this.state.isPopupOpen })
  }

  render() {
    const { t, selectedTemplate, selectedFieldsOptions, templateOptions, fieldOptions, addFilter, onChangeField, onTemplateChange, templateType } = this.props
    const { isPopupOpen } = this.state
    return (
      <div className='filter-section'>
        <Popup size='large' open={isPopupOpen} close={this.togglePopup}
          header={!selectedTemplate.value ? t('create') : t('update', { templateName: selectedTemplate.tostd_template_name })}
          description={<TemplatePopup
            handleClose={this.togglePopup}
            selectedOptions={selectedFieldsOptions}
            template={selectedTemplate}
            templateType={templateType} />}
        />
        <div className='template-section'>
          <Icon name='file alternate' title='Templates' className='bordered inverted icon' />
          <Select name="templates"
            options={templateOptions}
            className='template-select'
            value={selectedTemplate}
            onChange={onTemplateChange}
            isClearable={true}
          />
        </div>
        <div className="input_field field-section" >
          <label>
            <Icon name='adn' title='Advance Filters' className='bordered inverted icon' />
            <Icon name='filter' title='Advance Filters' className='bordered inverted icon' />
          </label>
          <div className="input_holder">
            <MultiSelect
              options={fieldOptions}
              onChange={onChangeField}
              showAll={true}
              selectedValues={selectedTemplate.tostd_search_fields || selectedFieldsOptions}
              placeholder={t('filterSelectPlaceHolder')}
              searchable={true}
            />
            <span className="primary btn-small btn-long" onClick={addFilter}><Icon name='add' className='bordered inverted icon' /></span>
          </div>
          {selectedFieldsOptions.length === 0 ? <span className="primary btn-small btn-long disabled" title={t('saveIconTitle')} > <Icon name='save' className='bordered inverted icon disabled' /></span> :
            <span className="primary btn-small btn-long" title={t('saveIconTitle')}
              onClick={this.togglePopup}>
              <Icon name='save' className='bordered inverted icon' />
            </span>
          }
        </div>
      </div>
    )
  }
}

export default withTranslation('searchTemplates')(SearchTemplate)
