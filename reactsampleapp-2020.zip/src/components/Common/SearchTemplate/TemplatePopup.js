import React, { Component } from 'react';
import { reduxForm, Field } from 'redux-form';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import inputField from 'components/Common/InputField';
import { Grid, List } from 'semantic-ui-react';
import { create, update } from 'actions/searchTemplateActions';

const validate = values => {
  const errors = {};
  if (!values.tostd_template_name) {
    errors.tostd_template_name = "Template is required."
  }
  return errors
}

class TemplatePopup extends Component {
  constructor(props) {
    super(props)

    this.submitTemplateValues = this.submitTemplateValues.bind(this)
    this.renderSelectedFields = this.renderSelectedFields.bind(this)
  }

  componentDidMount() {
    const { template, templateType } = this.props
    template['tostd_template_type'] = templateType
    template['tostd_search_fields'] = this.props.selectedOptions
    this.props.initialize(template)
  }

  renderSelectedFields() {
    return this.props.selectedOptions.map((option, key) => {
      return (
        <List.Item as='li' value='✓' key={key}>{option.label}</List.Item>
      )
    })
  }

  submitTemplateValues(values) {
    const { template } = this.props
    if (template.value) {
      this.props.update(values, template.value)
    } else {
      this.props.create(values)
    }
    this.props.handleClose()
  }
  render() {
    const { handleSubmit, template, t } = this.props;
    return (
      <Grid stackable>
        <Grid.Row>
          <Grid.Column width={12} >
            <Field name='tostd_template_name' component={inputField} label="Template Name" required={true} />
          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column width={4}>
            <label>Selected Fields</label>
          </Grid.Column>
          <Grid.Column width={8} className='fields-display-section'>
            <List as='ol'>
              {this.renderSelectedFields()}
            </List>
          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column width={16} >
            <button type="submit" className="primary btn-small btn-long" onClick={handleSubmit(values =>
              this.submitTemplateValues(values))}>
              {template.value ? t('updateBtn') : t('createBtn')}
            </button>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    )
  }
}

TemplatePopup = reduxForm({
  form: 'TemplatePopupForm',
  validate,
})(TemplatePopup);

const mapDispatchToProps = dispatch => ({
  create: (params) => dispatch(create(params)),
  update: (params, guid) => dispatch(update(params, guid)),
});

export default compose(withTranslation('searchTemplates'), connect(null, mapDispatchToProps))(TemplatePopup)
