import React, { Component } from 'react'
import { Modal } from 'semantic-ui-react';
import './popup.css'

export default class Popup extends Component {

  render() {
    const { trigger, open, header, size, description, actions, close, options } = this.props
    return (
      <Modal trigger={trigger} size={size} open={open} onClose={close} closeIcon {...options}>
        <Modal.Header>{header}</Modal.Header>
        <Modal.Content>
          <Modal.Description>
            {description}
          </Modal.Description>
        </Modal.Content>
        {actions && <Modal.Actions>
          {actions}
        </Modal.Actions>}
      </Modal>
    )
  }
}
