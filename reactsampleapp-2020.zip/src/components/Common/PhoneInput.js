import React, { Component } from 'react'
import PhoneInput from './Phone'
import classNames from 'classnames'
import { getCode } from 'country-list'

class PhoneInputField extends Component {

  onChange(data) {
    if (data && data.length < 2) {
      this.props.input.onChange('')
    }
  }
  render() {
    const { input, label, meta: { touched, error }, required, countryCode } = this.props
    const idTxt = input.id ? input.id : input.name
    let country = 'ph'
    if (countryCode && input.value.length < 2) {
      country = getCode(countryCode) || 'ph'
      country = country.toLowerCase()
    }
    let className = classNames('', {
      'error': touched && error
    })

    return (
      <div className="input_field" >
        {label && <label>{label}{required && <em>*</em>}</label>}
        <div className="input_holder">
          <PhoneInput {...input}
            defaultCountry={'ph'}
            inputExtraProps={{ id: idTxt, name: input.name, className: className }}
            autoComplete="off"
            placeholder=''
            handleOnChange={this.onChange.bind(this)}
            onBlur={() => {
              input.onBlur();
            }}
            onFocus={() => {
              input.onFocus();
            }}
          />
          {touched && error && <p className="error_message">{error}</p>}
        </div>
      </div>
    )
  }
}

export default PhoneInputField
