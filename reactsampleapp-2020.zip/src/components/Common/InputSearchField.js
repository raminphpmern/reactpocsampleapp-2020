import React, { Component } from 'react'
import { Icon } from 'semantic-ui-react'
import classNames from 'classnames';
import { SEARCH_WORD_COUNT } from 'config'

class InputSearchField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: true,
      cursor: 0,
    };
  }

  setValue(option) {
    this.props.fillNameValues(option, this.props.id);
    this.setState({ open: !this.state.open })
  }

  onChange(event) {
    const { findByCompanyAndFLMName, input: { onChange }, id } = this.props
    onChange(event);
    if (findByCompanyAndFLMName) {
      findByCompanyAndFLMName(event.target.value, id)
      if (event.target.value.length >= SEARCH_WORD_COUNT) {
        this.setState({ open: true })
      } else {
        this.setState({ open: false })
      }
    }
  }

  handleKeyDown(e) {
    const { cursor } = this.state
    const { options } = this.props
    let node, index = null;
    if (options && options.length > 0) {
      node = document.getElementsByClassName('active')[0]
      if (node && !node.getAttribute("value")) {
        node = document.querySelector('ul.search-edit > li.active')
      }
      if (node) {
        index = node.getAttribute("value")
        if (e.keyCode === 13) {
          this.setValue(this.props.options[index])
          e.preventDefault()
        }
      }
    }

    if (e.keyCode === 38 && cursor > 0) {
      this.setState(prevState => ({
        cursor: prevState.cursor - 1
      }))
    } else if (e.keyCode === 40 && cursor < options.length - 1) {
      this.setState(prevState => ({
        cursor: prevState.cursor + 1
      }))
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.options !== nextProps.options) {
      this.setState({ cursor: 0 })
    }
  }

  render() {
    const { input, disabled, id, placeholder, type, label, iconName, readOnly, options, childName,
      handleClick, meta: { touched, error, dirty }, required } = this.props
    let className = classNames('', {
      "error": touched && error,
    });
    const placeholderTxt = placeholder ? placeholder : ''
    const idTxt = id ? id : input.name
    const disabledValue = disabled ? disabled : false
    const readOnlyValue = readOnly ? readOnly : false
    const { cursor } = this.state

    return (
      <div className="input_field" >
        {label && <label>{label}{required && <em>*</em>}</label>}
        <div className="input_holder">
          <input
            id={idTxt}
            {...input}
            disabled={disabledValue}
            type={type || 'text'}
            placeholder={placeholderTxt}
            readOnly={readOnlyValue}
            autoComplete="off"
            autoCorrect="false"
            spellCheck="false"
            className={className}
            onChange={this.onChange.bind(this)}
            onKeyDown={this.handleKeyDown.bind(this)}
          />
          {this.state.open && dirty && options && options.length > 0 && <ul autoFocus id="search-edit" className="search-edit">
            {options.map((item, key) => {
              return (
                <li value={key} className={cursor === key ? 'active' : null} key={key} onClick={() => this.setValue(item)}>{item.label}</li>
              )
            })}
          </ul>}
          {touched && error && <p className="error_message">{error}</p>}
          {iconName && <span className="copy-icon" onClick={() => { handleClick('help', childName) }}><Icon disabled name={iconName} /></span>}
        </div>
      </div>
    )
  }
}

export default InputSearchField
