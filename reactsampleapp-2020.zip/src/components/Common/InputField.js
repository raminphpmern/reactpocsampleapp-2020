import React, { Component } from 'react'
import { Icon } from 'semantic-ui-react'
import classNames from 'classnames';

class InputField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      stayOpen: false
    };
  }

  onChange(event) {
    this.props.input.onChange(event);
    if (this.props.onchange) {
      this.props.onchange(event.target.value, event)
    }
  }

  render() {
    const { input, id, placeholder, type, label, iconName, autoFocus, amountField, readOnly, childName,
      handleClick, meta: { touched, error }, required, max, min, strong, addClass, maxLength } = this.props
    let className = classNames((addClass || ''), {
      "error": touched && error,
      "text-right": amountField,
      "strong": strong
    });

    const placeholderTxt = placeholder ? placeholder : ''
    const idTxt = id ? id : input.name
    const readOnlyValue = readOnly ? readOnly : false
    let labelStrong;

    let numberOptions = {}

    if (max) {
      numberOptions['max'] = max
    }
    if (min) {
      numberOptions['min'] = min
    }

    if (strong && label) {
      labelStrong = <strong>{label}</strong>
    } else {
      labelStrong = label
    }

    return (
      <div className="input_field" >
        {label && <label>{labelStrong}{required && <em>*</em>}</label>}
        <div className="input_holder">
          <input
            id={idTxt}
            {...input}
            {...numberOptions}
            disabled={readOnlyValue}
            type={type || 'text'}
            placeholder={placeholderTxt}
            readOnly={readOnlyValue}
            autoComplete="off"
            autoCorrect="false"
            spellCheck="false"
            className={className}
            onChange={this.onChange.bind(this)}
            autoFocus={autoFocus}
            maxLength={maxLength}
          />
          {touched && error && <p className="error_message">{error}</p>}
          {iconName && <span className="copy-icon" onClick={() => { handleClick('help', childName) }}><Icon disabled name={iconName} /></span>}
        </div>
      </div>
    )
  }
}

export default InputField
