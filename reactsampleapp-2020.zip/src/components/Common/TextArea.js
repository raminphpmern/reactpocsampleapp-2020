import React, { Component } from 'react';
export default class RenderTextarea extends Component {
  render() {
    let { htmlFor, input, label, row, col, meta: { touched, error } } = this.props;
    return (
      <div className="input_field" >
        {label && <label>{label}</label>}
        <textarea {...input} id={htmlFor} rows={row} cols={col} />
        {touched && error && <p className="error_message">{error}</p>}
      </div>
    );
  }
}