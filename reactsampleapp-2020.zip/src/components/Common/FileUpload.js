import React, { Component } from 'react'
import classNames from 'classnames';
import Popup from 'components/Common/Popup';
import { Icon, Image } from 'semantic-ui-react';
import { generateBlobUrl } from 'lib/CommonHelper';
import './fileupload.css'

class PreviewImage extends Component {
  render() {
    const { fileName, mimeType, base64 } = this.props
    return (<div>
      <a download={`${fileName}.${mimeType.split('/').pop()}`} href={base64}>
        <Icon name="download" /> Download
      </a>
      <Image src={this.props.imageUrl} alt="preview image" className="preview-img" />
    </div>)
  }
}

class FieldUpload extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      fileName: null,
    };
    this.toggle = this.toggle.bind(this)
    this.renderCustomDesign = this.renderCustomDesign.bind(this)
  }

  toggle() {
    this.setState({ open: !this.state.open })
  }

  onChange(event) {
    let file = event.target.files[0]
    if (file) {
      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.setState({ fileName: file.name })
        if (this.props.getFileName) {
          this.props.getFileName(file.name, generateBlobUrl(reader.result), reader.result)
        } else {
          this.props.input.onChange(reader.result);
        }
      }
    }
  }

  setFileName(e) {
    this.props.input.onChange(e)
  }

  renderCustomDesign(showInput, label, idTxt) {
    const { fileName } = this.state
    let lableClasses = classNames('only-icon', {
      "adjust-icon": fileName,
    });
    if (showInput) {
      return (
        <div className="input_field custom-section" >
          <label>{label}</label>
          <div className="input_holder file-attachment-section">
            <input name='file_name' type="text" defaultValue={fileName} />
            {fileName && <Icon name='eye' title="upload" className='icon preview-input' onClick={this.toggle} />}
            <label htmlFor={idTxt} className={lableClasses}>
              <Icon name='file' title="upload" className='icon' />
            </label>
          </div>
        </div>
      )
    } else {
      return (
        <label htmlFor={idTxt}>
          <Icon name='upload' title="upload" />
        </label>
      )
    }
  }

  render() {
    const { input, id, meta: { touched, error }, label, showInput, savedFileName } = this.props
    const { fileName } = this.state
    let className = classNames('std_field', {
      "error": touched && error,
    });
    const { imageUrl, mimeType } = generateBlobUrl(input.value)
    const idTxt = id ? id : input.name
    const downloadFileName = fileName || savedFileName || 'FILENAME'
    return (
      <div className="file_field" >
        <Popup open={this.state.open} close={this.toggle}
          header="Preview" description={<PreviewImage close={this.toggle} imageUrl={imageUrl} base64={input.value} mimeType={mimeType} fileName={downloadFileName} />} />
        <div className="image-upload icons">
          {this.renderCustomDesign(showInput, label, idTxt)}
          <input
            id={idTxt}
            type="file"
            accept="image/png, image/jpeg"
            name={input.name}
            className={className}
            onChange={this.onChange.bind(this)}
          />
          {touched && error && <p className="error_message">{error}</p>}
          {!showInput && imageUrl && <Icon name="eye" onClick={this.toggle} title="preview" />}
          {!showInput && imageUrl && <a download={`${downloadFileName}.${mimeType.split('/').pop()}`} href={input.value} className="icons" title="download">
            <Icon name="download" />
          </a>}
        </div>
      </div>
    )
  }
}

export default FieldUpload
