import React, { Component } from 'react'
import Popup from 'components/Common/Popup';
import AttachmentsPopup from './AttachmentsPopup';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';
import jsonLogic from 'json-logic-js';

class MultipleAttachments extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      fileName: null,
    };
    this.toggle = this.toggle.bind(this)
  }

  toggle() {
    this.setState({ open: !this.state.open })
  }

  showLink(rule, rowInfo) {
    if (rule) {
      return jsonLogic.apply(rule, rowInfo)
    } else {
      return true
    }
  }

  render() {
    const { title, formValues, dependentValues, linkJsonRule } = this.props
    return (
      <div className="multiple-attachment-wrapper">
        <Popup open={this.state.open} close={this.toggle}
          header={title} description={<AttachmentsPopup
            {...this.props}
            formValues={formValues ? formValues.values : {}}
            rowInfo={dependentValues ? dependentValues : null}
          />} close={this.toggle} />
        {this.showLink(linkJsonRule, dependentValues) && <a onClick={this.toggle}>+ Attachments</a>}
      </div>
    )
  }
}

const mapStateToProps = state => ({
  formValues: state.form.TripPlan,
});

export default compose(withTranslation('TripPlan'), connect(mapStateToProps, null))(MultipleAttachments)