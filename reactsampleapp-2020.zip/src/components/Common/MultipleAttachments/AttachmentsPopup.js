import React, { Component } from 'react'
import DataGrid from 'components/Common/DataGrid';
import ImageFormatter from 'components/Common/DataGrid/ImageFormatter';
import FileUploadEditor from 'components/Common/DataGrid/FileUploadEditor';
import DropDownEditor from 'components/Common/DataGrid/DropDownEditor';
import ObjectFormatter from 'components/Common/DataGrid/ObjectFormatter';
import { Grid } from "semantic-ui-react";
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withTranslation } from 'react-i18next';
import * as tripAttachmentsAction from 'actions/tripAttachmentsAction';
import { formatFormValues } from 'lib/CommonHelper';
import i18n from 'i18n';
import _ from 'lodash';

const DisplayImageName = ({ dependentValues }) => {
  if (dependentValues.tpad_attachment && dependentValues.tpad_attachment.fileName) {
    return dependentValues.tpad_attachment.fileName
  } else
    return ''
};

const headers = [
  { key: "tpad_document_code", name: i18n.t('tripAttachments:attachmentType'), editor: <DropDownEditor propName="typeOptions" resultType="object" />, formatter: <ObjectFormatter fieldName='tpad_document_code' /> },
  { key: "tpad_attachment_file_name", name: i18n.t('tripAttachments:attachmentFileName'), formatter: DisplayImageName, getRowMetaData: (row) => row },
  { key: "tpad_attachment", name: i18n.t('tripAttachments:attachment'), editor: FileUploadEditor, formatter: <ImageFormatter fileColumn='tpad_attachment' />, getRowMetaData: (row) => row },
]

class AttachmentsPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      updatedRows: [],
    }
    this.rowEdit = this.rowEdit.bind(this)
    this.dropSelectedRows = this.dropSelectedRows.bind(this)
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
    this.save = this.save.bind(this)
  }

  buildDynamicQueryStr(props) {
    const { formValues, docType, rowInfo } = props
    let queryString = `tpad_doc_type=${docType}&pageNo=${1}&limit=${10}`
    if (docType === 'THUPOD') {
      queryString = queryString + `&tpad_doc_no=${formValues.ddh_dispatch_doc_no.value}`
    } else if (docType === 'INCIDENT') {
      queryString = queryString + `&tpad_doc_no=${rowInfo.tlid_incident_id}`
    } else {
      queryString = queryString + `&tpad_parent_guid=${rowInfo.tms_tled_guid}`
    }

    return queryString
  }

  componentDidMount() {
    const { formValues, docType, getTripAttachments, getTypeOptions } = this.props
    getTripAttachments(formValues.trip_id, this.buildDynamicQueryStr(this.props), 10)
    getTypeOptions(docType)
  }

  changeLimit(pageNo, limit) {
    const { formValues } = this.props
    this.props.getTripAttachments(formValues.trip_id, this.buildDynamicQueryStr(this.props), limit)
  }

  paginationHandler(pageNo, limit) {
    const { formValues } = this.props
    this.props.getTripAttachments(formValues.trip_id, this.buildDynamicQueryStr(this.props), limit)
  }

  rowEdit(row, updateValue) {
    _.merge(row, updateValue)
    if (row && row.new === true) {
      let { updatedRows } = this.state
      if (!row.hasOwnProperty('tpad_seqno')) {
        let { attachments } = this.props
        if (updatedRows.length > 0) {
          attachments = updatedRows
        }
        const attachment = attachments[attachments.length - 1]
        if (attachment && attachment['tpad_seqno'])
          row['tpad_seqno'] = parseInt(attachment['tpad_seqno']) + 1
        else
          row['tpad_seqno'] = 1
      }
      if (updatedRows.length > 0) {
        const recordIndex = _.findIndex(updatedRows, (item) => item.id === row.id)
        if (recordIndex >= 0) {
          updatedRows[recordIndex] = row
        } else {
          updatedRows.push(row)
        }
      } else {
        updatedRows.push(row)
      }
      this.setState({ updatedRows })
    }
    else {
      let { updatedRows } = this.state
      const response = _.reduce(this.props.attachments, (arr, item) => {
        if (item.tpad_line_no === row.tpad_line_no) {
          _.merge(item, updateValue)
          arr.push(item)
        }
        return arr
      }, [])
      updatedRows = updatedRows.concat(response)
      this.setState({ updatedRows })
    }
  }

  dropSelectedRows(rows) {
    if (rows.length > 0) {
      const { formValues, docType } = this.props
      let queryString = `tpad_doc_type=${docType}`
      this.props.deleteTripAttachments(formValues.trip_id, _.map(rows, 'tpad_line_no'), queryString)
    }
  }

  save() {
    const { updatedRows } = this.state
    if (updatedRows.length > 0) {
      const { formValues, docType, rowInfo } = this.props
      let hash = formatFormValues(formValues)
      hash['tpad_doc_type'] = docType
      if (docType === 'THUPOD') {
        hash['tpad_doc_no'] = formValues.ddh_dispatch_doc_no.value
      } else if (docType === 'INCIDENT') {
        hash['tpad_doc_no'] = rowInfo.tlid_incident_id
      } else {
        hash['tpad_parent_guid'] = rowInfo.tms_tled_guid
      }
      this.props.saveTripAttachments(formValues.trip_id, { rows: updatedRows, ...hash })
      this.setState({ updatedRows: [] })
    }
  }

  renderPrimaryLabel() {
    const { docType, formValues, rowInfo } = this.props
    let labels = []
    if (formValues.ddh_dispatch_doc_no) {
      labels.push(
        <Grid.Column width='5'>
          <label>Dispatch Doc No: {formValues.ddh_dispatch_doc_no.label}</label>
        </Grid.Column>)
    }
    if (docType === 'INCIDENT') {
      labels.push(
        <Grid.Column width='5'>
          <label>Incident ID: {rowInfo.tlid_incident_id}</label>
        </Grid.Column>)
    }
    return labels
  }

  render() {
    const { formValues, attachments, totalPage, totalRecord, pageLimit, t } = this.props
    const { updatedRows } = this.state
    const disabled = updatedRows.length > 0
    return (
      <Grid stackable className="fixed-grid">
        <Grid.Row style={{ fontSize: "13px" }}>
          <Grid.Column width='5'>
            <label>Trip id: {formValues.trip_id}</label>
          </Grid.Column>
          {this.renderPrimaryLabel()}
        </Grid.Row>
        <Grid.Row>
          <Grid.Column width={16} >
            <DataGrid
              columns={headers}
              rows={attachments}
              rowEdit={this.rowEdit}
              width={250}
              showSelectedCount={false}
              totalPages={totalPage}
              changeLimit={this.changeLimit}
              paginationHandler={this.paginationHandler}
              totalRecord={totalRecord}
              pageLimit={pageLimit}
              addRow={true}
              deleteRow={true}
              removeColumnHeaderFormatter={true}
              dropSelectedRows={this.dropSelectedRows}
            />
          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column width={16}>
            <div className="text-center">
              <button id='save' type="button" className="primary btn-small btn-long" disabled={!disabled} onClick={this.save}> {t('saveBtn')}</button>
            </div>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    )
  }
}

const mapDispatchToProps = dispatch => ({
  getTripAttachments: (tripId, queryString, limit) => dispatch(tripAttachmentsAction.getTripAttachments(tripId, queryString, limit)),
  saveTripAttachments: (tripId, params) => dispatch(tripAttachmentsAction.saveTripAttachments(tripId, params)),
  deleteTripAttachments: (tripId, lineNumbers, queryString) => dispatch(tripAttachmentsAction.deleteTripAttachments(tripId, lineNumbers, queryString)),
  getTypeOptions: (type) => dispatch(tripAttachmentsAction.getTypeOptions(type)),
});
const mapStateToProps = state => ({
  attachments: state.tripAttachmentsReducer.attachments,
  totalPage: state.tripAttachmentsReducer.totalPage,
  totalRecord: state.tripAttachmentsReducer.totalRecord,
  pageLimit: state.tripAttachmentsReducer.limit,
  typeOptions: state.tripAttachmentsReducer.typeOptions,
});

export default compose(withTranslation('tripAttachments'), connect(mapStateToProps, mapDispatchToProps))(AttachmentsPopup)