import React from 'react'

const renderRadioField = ({ onSelect, value, label, htmlFor, input, disabled, type, error_messages, meta: { touched, error, warning } }) => {
  return (
    <div className="input_field">
      {label && <label htmlFor={htmlFor}>{label}</label>}
      <div className="input_holder_checkbox">
        <input id={htmlFor} disabled={disabled} {...input} type={type} onClick={onSelect} />
      </div>
    </div>
  )
}

export default renderRadioField
