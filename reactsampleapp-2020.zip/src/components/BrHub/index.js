import React, { Component } from "react";
import DataGrid from "components/Common/DataGrid";
import Wrapper from "components/LandingPage/Wrapper";
import { Grid } from "semantic-ui-react";
import inputField from "components/Common/InputField";
import { reduxForm, Field } from "redux-form";
import { connect } from "react-redux";
import Checkbox from "components/Common/Checkbox";
import Dropdown from "./../Common/Dropdown";
import DateTimePicker from "components/Common/DateTimePicker";
import Footer from "components/BrHub/Footer";
import * as masterActions from "actions/masterAction";
import * as brHubActions from "actions/brHubActions";
import InputSearchField from "components/Common/InputSearchField";
import { SEARCH_WORD_COUNT } from "config";
import { Link } from "react-router-dom";
import CustomRadioFiled from "components/Common/CustomRadio";
import _ from "lodash";
import "./brhub.css";

const LinkFormatter = ({ value }) => {
  return <Link to={`/acceptance/${value}`}>{value}</Link>;
};

const columns = [
  { key: "br_request_id", name: "Booking Request ID", formatter: LinkFormatter },
  { key: "br_customer_id", name: "Customer ID" },
  { key: "custname", name: "Customer Name" },
  { key: "brstatus", name: "Booking Request Status" },
  { key: "br_creation_date", name: "Booking Request Creation Date" },
  { key: "br_type", name: "Booking Request Type" },
  { key: "br_original_br_id", name: "Original Booking Request ID" },
  { key: "br_customer_ref_no", name: "Customer reference No." },
  { key: "br_sender_ref_no", name: "Sender's Reference No." },
  { key: "br_receiver_ref_no", name: "Receiver's Reference No." },
  { key: "ddh_dispatch_doc_type", name: "Document Type.", editable: true },
  { key: "ddh_dispatch_doc_no", name: "Document No.", editable: true },
  { key: "brsd_from_pick_date", name: "Pickup Date" },
  { key: "brsd_to_delivery_date", name: "Delivery Date" },
  { key: "br_customer_location", name: "BR Location" },
  { key: "tesed_event_desc", name: "Last Event", editable: true },
  // { key: "", name: "Event Location", editable: true },
  { key: "br_created_by", name: "Created By", editable: true },
  { key: "br_hazardous", name: "Hazardous Consignment" },
  { key: "wms_paramdesc", name: "Creation Mode", editable: true },
  { key: "cod_or_cop", name: "COD or COP", editable: true },
  { key: "br_service_type", name: "Shipment Type", editable: true },
  { key: "br_sub_service_type", name: "Service Mode" },
  // { key: "", name: "Current Location" },
  { key: "bill_status", name: "Billing Status" },
  { key: "ctsd_serial_no", name: "Tracking No./Bar Code" },
  { key: "tmfdh_br_id", name: "Failed Attempts", editable: true },
  { key: "brdm_disbursement_mode", name: "Disbursement Mode", editable: true },
  { key: "brdm_bank_name", name: "Bank Name", editable: true },
  { key: "brdm_account_no", name: "Account No.", editable: true },
  { key: "brdm_bank_code", name: "Bank Code", editable: true },
  { key: "brdm_accountholder_name", name: "Account Holder Name", editable: true },
  { key: "brdm_kyc_id", name: "KYC ID", editable: true },
  { key: "brdm_ewalletid", name: "E Wallet ID", editable: true },
  { key: "cd_amount_collected", name: "Total Amount to Be Collected", editable: true },
  { key: "br_last_modified_by", name: "Amended By", editable: true },
  //{ key: "", name: "Cash Received", editable: true },
  { key: "ccd_created_by", name: "Deposited By", editable: true },
  { key: "ccd_depositrefdocno", name: "Deposit Reference Number", editable: true },
  { key: "brsd_to_contact_person", name: "Consignee Name" },
  { key: "brsd_to_address_line1", name: "Consignee Address" },
  { key: "brsd_to_subzone", name: "Consignee Barangay" },
  { key: "brsd_to_city", name: "Consignee City" },
  { key: "brsd_to_state", name: "Consignee Province" },
  { key: "brsd_to_country", name: "Consignee Country" },
  { key: "brsd_from_contact_person", name: "Shipper Name" },
  { key: "brsd_from_address_line1", name: "Shipper Address" },
  { key: "brsd_from_subzone", name: "Shipper Barangay" },
  { key: "brsd_from_city", name: "Shipper City" },
  { key: "brsd_from_state", name: "Shipper Province" },
  { key: "brsd_from_country", name: "Shipper Country" }
];
class BrHub extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIds: null
    }
    this.onSort = this.onSort.bind(this);
    this.onFilter = this.onFilter.bind(this);
    this.search = this.search.bind(this);
    this.fillData = this.fillData.bind(this);
    this.formSubmit = this.formSubmit.bind(this);
    this.selectedRows = this.selectedRows.bind(this);
    this.changeLimit = this.changeLimit.bind(this)
    this.paginationHandler = this.paginationHandler.bind(this)
  }
  componentDidMount() {
    const {
      getQuickCodeMaster,
      getEventDetail,
      getEventLocation,
      shipment_type,
      service_mode,
      request_type,
      last_event,
      event_location,
      failed_attempts,
      creation_mode,
      request_status,
      billing_status,
      current_location
    } = this.props;
    if (shipment_type.length === 0) {
      getQuickCodeMaster("shipment_type");
    }
    if (service_mode.length === 0) {
      getQuickCodeMaster("service_mode");
    }

    if (request_type.length === 0) {
      getQuickCodeMaster("request_type");
    }

    if (billing_status.length === 0) {
      getQuickCodeMaster("billing_status");
    }

    if (last_event.length === 0) {
      getEventDetail("last_event");
    }

    if (event_location.length === 0) {
      getEventLocation("event_location");
    }

    if (failed_attempts.length === 0) {
      getEventDetail("failed_attempts");
    }

    if (creation_mode.length === 0) {
      getQuickCodeMaster("creation_mode");
    }

    if (request_status.length === 0) {
      getQuickCodeMaster("request_status");
    }

    if (current_location.length === 0) {
      getQuickCodeMaster("current_location")
    }
    this.AddShortcuts()
  }

  AddShortcuts() {
    document.addEventListener("keydown", e => {
      if (e.altKey) {
        switch (e.keyCode) {
          case 67: // key=c for confirm
            e.preventDefault();
            document.getElementById('confirm').click()
            break;
          case 70: // key=f for search
            e.preventDefault();
            document.getElementById('search').click()
            break;
          case 83: // key=s for short close
            e.preventDefault();
            document.getElementById('shortClose').click()
            break;
          case 65: // key=a for  amend
            e.preventDefault();
            document.getElementById('amend').click()
            break;
          case 82: // key=r for Reject
            e.preventDefault();
            document.getElementById('reject').click()
            break;
          case 80: // key=p for print
            e.preventDefault();
            document.getElementById('print').click()
            break;
          default:
            break;
        }
      }
    });
  }

  changeLimit(pageNo, limit) {
    this.props.search(this.props.formValues.values, pageNo, limit);
  }

  paginationHandler(pageNo, limit) {
    this.props.search(this.props.formValues.values, pageNo, limit);
  }

  onSort() {
    // Sorting API call
  }

  onFilter() {
    // Filter API call
  }

  search(value, fieldName) {
    if (value.length >= SEARCH_WORD_COUNT) {
      let queryString = `keyword=${value}`;
      if (fieldName === "shipper") {
        queryString += "&searchField=wms_customer_id";
        this.props.getShipper("shipper", queryString, fieldName);
      }
      if (fieldName === "reason_code") {
        this.props.getReasonCode("reason_code", queryString, fieldName);
      }
    }
  }

  fillData(option, fieldName) {
    let hash = _.cloneDeep(this.props.formValues.values);
    if (fieldName === 'reason_code') {
      hash['br_reason_code'] = option.wms_code_desc
    } else {
      hash["brsd_from_contact_person"] = option.wms_customer_description;
      if (fieldName === "shipper") {
        hash["br_customer_id"] = option.wms_customer_id;
      }
    }
    this.props.initialize(hash);
  }

  selectedRows(values) {
    this.setState({ selectedIds: values })
  }

  formSubmit(values) {
    this.props.search(values, 1, 10);
  }

  render() {
    const {
      handleSubmit, shipment_type, service_mode, currentUser, shipper, request_type, billing_status, shipperFirstName, last_event, event_location, failed_attempts, creation_mode, request_status, brRecords, totalPage, isRequested, totalRecord, reason_code, current_location
    } = this.props;
    const locations = (currentUser && currentUser.locations) || [];
    return (
      <Wrapper DisableBranch={true}>
        <div className="collection-head">
          <h3>BR HUB</h3>
        </div>
        <div className="brhub-wrapper">
          <form onSubmit={handleSubmit(this.formSubmit)}>
            <Grid stackable>
              <Grid.Row>
                <Grid.Column width={10}>
                  <h3>Search</h3>
                </Grid.Column>
                <Grid.Column width={3}>
                  <button type="button" className="secondary btn-small">
                    <Link to="/acceptance">Quick Booking Request</Link>
                  </button>
                </Grid.Column>
                <Grid.Column width={3}>
                  <button type="button" className="secondary btn-small">
                    CCM Booking Request
                  </button>
                </Grid.Column>
              </Grid.Row>
              <Grid.Row>
                <Grid.Column width={4}>
                  <Field label="Tracking No./Bar Code" name="ctsd_serial_no" component={inputField} />
                  <Field label="Booking Request ID" name="br_request_id" component={inputField} />
                  <div className="col-2-checkbox">
                    <Field name="br_cop" component={Checkbox} type="checkbox" label="COP" />
                    <Field name="br_cod" component={Checkbox} type="checkbox" label="COD" />
                  </div>
                  <Field name="br_customer_id" component={InputSearchField} findByCompanyAndFLMName={this.search}
                    fillNameValues={this.fillData} options={shipper} id="shipper" label="Customer ID" />
                  <Field name="brsd_from_contact_person" component={InputSearchField} id="shipper_first_name" findByCompanyAndFLMName={this.search} fillNameValues={this.fillData} options={shipperFirstName} label="Customer Name" />
                  <Field name="br_service_type" component={Dropdown} label="Shipment Type" options={shipment_type} />
                  <Field name="br_sub_service_type" component={Dropdown} label="Service Mode" options={service_mode} />
                  <Field name="br_customer_location" component={Dropdown} label="BR Location" options={locations} />
                  <Field name="br_creation_date" component={DateTimePicker} label="Creation Date" />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field label="Customer Reference No." name="br_customer_ref_no" component={inputField} />
                  <Field label="Sender's Reference No." name="br_sender_ref_no" component={inputField} />
                  <Field label="Receiver's Reference No." name="br_receiver_ref_no" component={inputField} />
                  <Field name="brsd_to_deliverytime_slot_from_1" component={DateTimePicker} label="Delivery Date From" />
                  <Field name="brsd_to_deliverytime_slot_from_2" component={DateTimePicker} label="Delivery Date To" />
                  <Field name="tesed_event_id" component={Dropdown} label="Last Event" options={last_event} />
                  <Field name="plepd_leg_to" component={Dropdown} label="Event Location" options={event_location} />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field name="brsd_from_picktime_slot_from_1" component={DateTimePicker} label="Pickup Date From" />
                  <Field name="brsd_from_picktime_slot_from_2" component={DateTimePicker} label="Pickup Date To" />
                  <Field name="br_type" component={Dropdown} label="Request Type" options={request_type} />
                  <Field name="failed_atte" component={Dropdown} label="Failed Attempts" options={failed_attempts} />
                  <Field label="Original BR ID" name="br_original_br_id" component={inputField} />
                  <Field label="Created By" name="br_created_by" component={inputField} />
                  <Field label="Booking Request Status" name="br_status" component={Dropdown} options={request_status} />
                  <Field label="Billing Status" name="br_billing_status" component={Dropdown} options={billing_status} />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field label="Current Location" name="br_customer_location" component={Dropdown} options={current_location} />
                  <Field label="Creation Mode" name="br_creation_source" component={Dropdown} options={creation_mode} />
                  <div className="input_field">
                    <label>Hazardous Consignment</label>
                    <div className="input_holder">
                      <div className="radio">
                        <Field name="ctsd_hac_code" htmlFor="radio1" value="Y" label="Yes" type="radio" component={CustomRadioFiled} />
                        <Field name="ctsd_hac_code" htmlFor="radio2" value="N" label="No" type="radio" component={CustomRadioFiled} />
                      </div>
                    </div>
                  </div>
                  <Field name="br_reason_code" component={InputSearchField} findByCompanyAndFLMName={this.search}
                    fillNameValues={this.fillData} options={reason_code} id="reason_code" label="Reason Code" />
                </Grid.Column>
              </Grid.Row>
              <Grid.Row>
                <Grid.Column width={16} className="text-center">
                  <button id="search" disabled={isRequested} type="submit" className="primary btn-small btn-long">
                    Search
                  </button>
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </form>
          <Grid stackable>
            <Grid.Row>
              <Grid.Column width={16}>
              </Grid.Column>
              <Grid.Column width={16}>
                <DataGrid
                  columns={columns}
                  rows={brRecords}
                  rowKey="br_request_id"
                  totalPages={totalPage}
                  selectedRows={this.selectedRows}
                  width={150}
                  showSelectedCount={false}
                  totalRecord={totalRecord}
                  changeLimit={this.changeLimit}
                  paginationHandler={this.paginationHandler}
                  enableExport={true}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={16}>
                <Footer selectedRecords={this.state.selectedIds} />
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </div>
      </Wrapper>
    );
  }
}

BrHub = reduxForm({
  form: "BrHub"
})(BrHub);

const mapDispatchToProps = dispatch => ({
  getEventLocation: type => dispatch(masterActions.getEventDetail(type, "")),
  getQuickCodeMaster: type =>
    dispatch(masterActions.getQuickCodeMaster(type, "")),
  getEventDetail: type => dispatch(masterActions.getEventDetail(type, "")),
  getShipper: (action, queryStr, stateName) =>
    dispatch(masterActions.getShipper(action, queryStr, stateName)),
  getReasonCode: (action, queryStr, stateName) =>
    dispatch(masterActions.getReasonCode(action, queryStr, stateName)),
  search: (data, pageNo, limit) => dispatch(brHubActions.search(data, pageNo, limit))

});

const mapStateToProps = state => ({
  shipment_type: state.masterReducer.options.shipment_type,
  service_mode: state.masterReducer.options.service_mode,
  request_type: state.masterReducer.options.request_type,
  current_location: state.masterReducer.options.current_location,
  billing_status: state.masterReducer.options.billing_status,
  last_event: state.masterReducer.options.last_event,
  event_location: state.masterReducer.options.event_location,
  failed_attempts: state.masterReducer.options.failed_attempts,
  reason_code: state.masterReducer.options.reason_code,
  creation_mode: state.masterReducer.options.creation_mode,
  request_status: state.masterReducer.options.request_status,
  shipper: state.masterReducer.options.shipper,
  shipperFirstName: state.masterReducer.options.shipper_first_name,
  currentUser: state.loginReducer.user,
  formValues: state.form.BrHub,
  brRecords: state.brhubReducer.result,
  totalPage: state.brhubReducer.totalPage,
  totalRecord: state.brhubReducer.totalRecord,
  isRequested: state.brhubReducer.isRequested
});

export default connect(mapStateToProps, mapDispatchToProps)(BrHub);
