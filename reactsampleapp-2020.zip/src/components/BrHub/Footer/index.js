import React, { Component } from "react";
import Popup from "components/Common/Popup";
import Cancel from "components/Footer/Cancel";
import Amend from "components/Footer/Amend";
import { Icon } from "semantic-ui-react";
import { isMobile } from "config";
import "components/Footer/footer.css";
import _ from 'lodash'
import { connect } from 'react-redux';
import { reduxForm } from "redux-form";
import * as brHubActions from "actions/brHubActions";
import { AlertError } from 'lib/Alert'
import { withTranslation } from 'react-i18next';
import { compose } from 'redux';


class Footer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cancel: false,
      amend: false,
      showFtMenu: false,
      printOption: 'SHIPPER COPY'
    };
    this.handleOpenCancel = this.handleOpenCancel.bind(this);
    this.handleCloseCancel = this.handleCloseCancel.bind(this);
    this.handleOpenAmend = this.handleOpenAmend.bind(this);
    this.handleCloseAmend = this.handleCloseAmend.bind(this);
    this.changeBrtoConfirm = this.changeBrtoConfirm.bind(this);
    this.handleShortClose = this.handleShortClose.bind(this);
    this.printOptionChange = this.printOptionChange.bind(this);
  }

  handleOpenCancel() {
    this.setState({ cancel: true });
  }

  handleCloseCancel() {
    this.setState({ cancel: false });
  }

  handleOpenAmend() {
    if (this.props.selectedRecords) {
      let brStatusArr = _.map(this.props.selectedRecords, 'brstatus')
      let brStatus = _.uniq(brStatusArr);
      if (brStatus.length === 1 && brStatus[0] === 'Confirmed')
        this.setState({ amend: true });
      else
        AlertError("Selected Br status is not confirmed")
    }
  }

  changeBrtoConfirm() {

    if (this.props.selectedRecords) {
      let brStatusArr = _.map(this.props.selectedRecords, 'brstatus')
      let brStatus = _.uniq(brStatusArr);
      let brIds = _.map(this.props.selectedRecords, 'br_request_id')

      if ((brStatus.length === 2 && (brStatus.includes('Under Amendment') && brStatus.includes('Incomplete'))) || (brStatus.length === 1 && brStatus.includes('Incomplete'))) {
        AlertError("Selected Br is incomplete.So not able to confirm in BrHub")
      }
      else {
        if (brStatus.length === 1 && brStatus.includes('Under Amendment')) {
          this.props.confirm(brIds, "", "confirm")
        } else {
          AlertError("Selected Br status is not Under Amendment and Incomplete")
        }
      }
    }
  }

  handleShortClose() {
    if (this.props.selectedRecords) {
      let brStatusArr = _.map(this.props.selectedRecords, 'brstatus')
      let uniqStatus = _.uniq(brStatusArr);
      let brStatus = ['Incomplete', 'Confirmed', 'Hold', 'Under Execution', 'Planned', 'Under Amendment', 'Undelivered', 'Under Planning', 'Under Planning û Tendering', 'Under Planning V Tendering Confirmed']
      let statuscompare = _.differenceWith(uniqStatus, brStatus, _.isEqual)
      if (statuscompare.length > 0) {
        AlertError("Selected Br status is not able to short close")
        return false
      }
      let brIds = _.map(this.props.selectedRecords, 'br_request_id')
      this.props.shortclose(brIds, "", "shortclose")
    }
  }

  handleCloseAmend() {
    this.setState({ amend: false });
  }

  triggerMenu() {
    this.setState(prevState => ({
      showFtMenu: !prevState.showFtMenu
    }));
  }

  renderMobileView() {
    return (
      <div className="footer">
        <div
          className={this.state.showFtMenu ? "popupMenu active" : "popupMenu"}
        >
          <Popup
            trigger={<button className="secondary">Print POD</button>}
            header="Print POD"
            description={<h1>Add Description</h1>}
          />
          <Popup
            trigger={<button className="secondary">Print Label</button>}
            header="Print Label"
            description={<h1>Print lable clicked</h1>}
          />
          <Popup
            size="mini"
            open={this.state.amend}
            close={this.handleCloseAmend}
            trigger={
              <button onClick={() => {
                this.handleOpenAmend();
              }}
                className="secondary"
              >
                Amend
              </button>
            }
            header="Amend"
            description={<Amend handleClose={this.handleCloseAmend} />}
          />
        </div>

        <div className="actions">
          <button
            type="button"
            className="secondary"
            onClick={() => this.triggerMenu()}
          >
            <Icon name="ellipsis horizontal" />
          </button>
          <Popup
            size="mini"
            open={this.state.cancel}
            close={this.handleCloseCancel}
            trigger={
              <button
                onClick={() => {
                  this.handleOpenCancel();
                }}
                className="secondary"
              >
                Void
              </button>
            }
            header="Cancel"
            description={<Cancel handleClose={this.handleCloseCancel} />}
          />
          <button className="primary">Confirm Amendment</button>
        </div>
      </div>
    );
  }

  printOptionChange(e) {
    this.setState({ printOption: e.target.value })
  }

  renderDesktopView() {
    const { t } = this.props
    return (
      <div className="footer">
        <div className="actions br-hd-footer">
          <div>
            <button className="primary btn-small" disabled={!this.props.selectedRecords} onClick={() => {
              this.handleShortClose();
            }}>{t('shortCloseBtn')}</button>
            <button id="confirm" className="primary btn-small" disabled={!this.props.selectedRecords} onClick={() => {
              this.changeBrtoConfirm();
            }}>{t('confirmBtn')}</button>
            <div className="print-option">
              <select id="print-select" onChange={this.printOptionChange}>
                <option value="SHIPPER COPY">SHIPPER COPY</option>
                <option value="POD COPY">POD COPY</option>
                <option value="Acknowledgement receipt">Acknowledgement receipt</option>
                <option value="LABEL PRINTING ">LABEL PRINTING </option>
              </select>
            </div>
            <Popup
              trigger={<button type="button" id="print" className="primary btn-small">Print</button>}
              header="Print"
              description={<h1>{this.state.printOption}</h1>}
            />
            <Popup
              size="mini"
              open={this.state.cancel}
              close={this.handleCloseCancel}
              trigger={
                <button id="reject" type="button" disabled={!this.props.selectedRecords} onClick={() => { this.handleOpenCancel(); }} className="primary btn-small">
                  {t('rejectBtn')}
                </button>
              }
              header="Reject"
              description={<Cancel selectedIds={_.map(this.props.selectedRecords, 'br_request_id')} closePopup={this.handleCloseCancel} />}
            />
            <Popup
              size="mini"
              open={this.state.amend}
              close={this.handleCloseAmend}
              trigger={
                <button id="amend" type="button" disabled={!this.props.selectedRecords} onClick={() => { this.handleOpenAmend(); }} className="primary btn-small">
                  {t('amendBtn')}
                </button>
              }
              header="Amend"
              description={<Amend selectedIds={_.map(this.props.selectedRecords, 'br_request_id')} handleClose={this.handleCloseAmend} from='HUB' />}
            />
          </div>
        </div>
      </div>
    );
  }

  render() {
    if (isMobile) return this.renderMobileView();
    else return this.renderDesktopView();
  }
}

Footer = reduxForm({
  form: 'FooterForm'
})(Footer);

const mapDispatchToProps = (dispatch) => ({
  confirm: (ids, reason, action) => dispatch(brHubActions.brActions(ids, reason, action)),
  shortclose: (ids, reason, action) => dispatch(brHubActions.brActions(ids, reason, action))
})

const mapStateToProps = state => ({

})

export default compose(withTranslation('brHubFooter'), connect(mapStateToProps, mapDispatchToProps))(Footer)

