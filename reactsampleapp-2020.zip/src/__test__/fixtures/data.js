export const user = {
  id: 1
}

export const shipper = {
  wms_customer_id: 'LOC_00001',
  wms_customer_ou: 1,
  wms_customer_name: 'test',
  wms_customer_status: 'AC',
}

export const bookingSearchSuccess = {
  status: 200,
  result: {
    tms_br_booking_request_hdr: { br_request_id: 'R000000149' }
  }
}

export const bookingSearchError = {
  message: "Booking ID is not found.",
  status: 404
}