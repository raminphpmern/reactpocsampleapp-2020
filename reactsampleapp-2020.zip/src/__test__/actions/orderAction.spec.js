import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/orderAction'
import * as types from 'types/order.type'
import expect from 'expect'
const middlewares = [thunk]

const mockStore = configureMockStore(middlewares)
const store = mockStore({
  bookingReducer: {
    bookingData: null,
    message: null,
    isSearching: false,
    isRequested: false,
    currentBooking: {},
    isSuccess: false,
    activeStep: 2,
    currentStep: 2
  }
})

describe('#Order Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#Order Actions -  Create', () => {
    it('Should create order booking', () => {
      fetchMock.post('*', {
        body: { status: 200, data: { booking_id: 123 } },
      })
      const expectedActions = [
        { type: types.CREATE_ORDER_REQUEST, isRequested: true },
        { type: types.CREATE_ORDER_SUCCESS, data: { booking_id: 123 }, activeStep: 2, currentStep: 2 },
        { type: types.CREATE_ORDER_REQUEST, isRequested: false }
      ]

      return store.dispatch(actions.create({}, 2, 123)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error on create if the booking id is incorrect', () => {
      fetchMock.post('*', {
        body: { status: 404, message: "something went wrong" },
      })
      const expectedActions = [
        { type: types.CREATE_ORDER_REQUEST, isRequested: true },
        { type: types.CREATE_ORDER_FAILURE, msg: "something went wrong" },
        { type: types.CREATE_ORDER_REQUEST, isRequested: false }
      ]
      return store.dispatch(actions.create({}, 2, null)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

  describe('#Order Actions -  Update', () => {
    it('Should update order booking', () => {
      fetchMock.post('*', {
        body: { status: 200, data: { booking_id: 123 } },
      })
      const expectedActions = [
        { type: types.CREATE_ORDER_REQUEST, isRequested: true },
        { type: types.CREATE_ORDER_SUCCESS, data: { booking_id: 123 }, activeStep: 2, currentStep: 2 },
        { type: types.CREATE_ORDER_REQUEST, isRequested: false }
      ]

      return store.dispatch(actions.create({}, 2, 123)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error on update if the booking id is incorrect', () => {
      fetchMock.post('*', {
        body: { status: 404, message: "something went wrong" },
      })
      const expectedActions = [
        { type: types.CREATE_ORDER_REQUEST, isRequested: true },
        { type: types.CREATE_ORDER_FAILURE, msg: "something went wrong" },
        { type: types.CREATE_ORDER_REQUEST, isRequested: false }
      ]
      return store.dispatch(actions.create({}, 2, null)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

  describe('#Order Actions -  Compute', () => {
    it('Should compute order booking', () => {
      fetchMock.post('*', {
        body: {
          status: 200, contract: { booking_id: 123, value_shipment: true },
          calculatedTariff: {
            result: [], data: []
          }
        },
      })
      const expectedActions = [
        { type: types.V_SHIPMENT_REQUEST, isRequested: true },
        { type: types.V_SHIPMENT_SUCCESS, contract: { booking_id: 123, value_shipment: true }, result: [], data: [] },
        { type: types.CREATE_ORDER_REQUEST, isRequested: false }
      ]

      return store.dispatch(actions.compute({}, 123)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error on update if the booking id is incorrect', () => {
      fetchMock.post('*', {
        body: { status: 404, message: "something went wrong" },
      })
      const expectedActions = [
        { type: types.V_SHIPMENT_REQUEST, isRequested: true },
        { type: types.CREATE_ORDER_FAILURE, msg: "something went wrong" },
        { type: types.CREATE_ORDER_REQUEST, isRequested: false }
      ]
      return store.dispatch(actions.compute({}, null)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

})