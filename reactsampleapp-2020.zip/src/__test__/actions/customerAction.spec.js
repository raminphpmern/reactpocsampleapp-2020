import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/customerActions'
import * as types from 'types/customer.type'
import expect from 'expect'
const middlewares = [thunk]

const mockStore = configureMockStore(middlewares)
const store = mockStore({
  bookingReducer: {
    copyBooking: null
  }
})

describe('#Booking Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#Booking Actions -  Create Booking', () => {
    it('Should create new booking', () => {
      fetchMock.post('*', {
        body: { status: 200, data: [] },
      })
      const expectedActions = [{ type: types.CUSTOMER_CREATE_REQUEST, isRequested: true },
      { type: types.CUSTOMER_CREATE_SUCCESS, data: [], activeStep: 2, currentStep: 2 },
      { type: types.CUSTOMER_CREATE_REQUEST, isRequested: false }]
      let params = {}
      params.tms_br_booking_request_hdr = {
        br_recurring_flag: 'N'
      }
      return store.dispatch(actions.create(params, 1)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should not create new booking', () => {
      fetchMock.post('*', {
        body: { status: 404, message: "Something went wrong" },
      })
      const expectedActions = [{ type: types.CUSTOMER_CREATE_REQUEST, isRequested: true },
      { type: types.CUSTOMER_CREATE_FAILURE, msg: 'Something went wrong' },
      { type: types.CUSTOMER_CREATE_REQUEST, isRequested: false }]

      return store.dispatch(actions.create({}, 1)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

  describe('#Booking Actions -  Update Booking', () => {

    it('Should update existing booking', () => {
      fetchMock.put('*', {
        body: { status: 200, data: [] },
      })
      const expectedActions = [{ type: types.CUSTOMER_CREATE_REQUEST, isRequested: true },
      { type: types.CUSTOMER_CREATE_SUCCESS, data: [], activeStep: 2, currentStep: 2 },
      { type: types.CUSTOMER_CREATE_REQUEST, isRequested: false }]
      let params = {}
      params.tms_br_booking_request_hdr = {
        br_recurring_flag: 'N',
        br_status: 'Incomplete',
      }
      return store.dispatch(actions.update(params, 1, 1)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should not update the booking', () => {
      fetchMock.put('*', {
        body: { status: 404, message: "Something went wrong" },
      })
      const expectedActions = [{ type: types.CUSTOMER_CREATE_REQUEST, isRequested: true },
      { type: types.CUSTOMER_CREATE_FAILURE, msg: 'Something went wrong' },
      { type: types.CUSTOMER_CREATE_REQUEST, isRequested: false }]

      return store.dispatch(actions.update({}, 1, 1)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

})