import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/hubReceiptLoadAction'
import * as types from 'types/hubreceiptload.type'
import expect from 'expect'
import { e500 } from 'lib/messages'

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const store = mockStore({
  csReducer: {
    message: null,
    isRequested: false,
    equipmentResult: [],
    equipmentTotalPage: 0,
    equipmentTotalRecord: 0,
    equipmentCurrentPage: 1
  }
})

describe('#Help on equipment Search Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#Help on equipment Search Actions', () => {
    it('Should give result in the state if the search result is correct', () => {
      fetchMock.post('*', { result: [{ wms_eqp_equipment_id: "33468S" }], status: 200 })
      const expectedActions = [
        { type: types.HUB_EQUIPMENT_FETCH_REQUEST, isRequested: true },
        { type: types.HUB_EQUIPMENT_FETCH_SUCCESS, data: [{ wms_eqp_equipment_id: "33468S" }] },
        { type: types.HUB_EQUIPMENT_FETCH_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.equipmentSearch()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error if the search result is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.HUB_EQUIPMENT_FETCH_REQUEST, isRequested: true },
        { type: types.HUB_EQUIPMENT_FETCH_FAILURE, message: e500 },
        { type: types.HUB_EQUIPMENT_FETCH_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.equipmentSearch()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })
})

