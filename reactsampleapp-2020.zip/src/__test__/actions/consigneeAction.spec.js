import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/consigneeAction'
import * as types from 'types/consignee.type'
import expect from 'expect'
const middlewares = [thunk]

const mockStore = configureMockStore(middlewares)
const store = mockStore({})

describe('#Booking Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#Consignee Actions -  Consignee create', () => {
    it('should create new consignee', async () => {
      fetchMock.post('*', {
        body: { status: 200, data: [] },
      })
      const expectedActions = [{ type: types.CREATE_CONSIGNEE_REQUEST, isLoading: true },
      { type: types.CREATE_CONSIGNEE_SUCCESS, consignee: [] },
      { type: types.CREATE_CONSIGNEE_REQUEST, isLoading: false }]

      await store.dispatch(actions.create({}))
      expect(store.getActions()).toEqual(expectedActions)
    })

    it('should show error creating consignee', async () => {
      fetchMock.post('*', {
        body: { status: 400, message: 'Something went wrong' },
      })
      const expectedActions = [
        { type: types.CREATE_CONSIGNEE_REQUEST, isLoading: true },
        { type: types.CREATE_CONSIGNEE_FAILURE, message: 'Something went wrong' },
        { type: types.CREATE_CONSIGNEE_REQUEST, isLoading: false }]

      await store.dispatch(actions.create({}))
      expect(store.getActions()).toEqual(expectedActions)
    })

    it('should initialize the form', async () => {
      const expectedActions = [{ "type": "CREATE_CONSIGNEE_INITIALIZE" }]
      await store.dispatch(actions.initializeForm())
      expect(store.getActions()).toEqual(expectedActions)
    })
  })
})