import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/documentAction'
import * as types from 'types/document.type'
import expect from 'expect'
const middlewares = [thunk]

const mockStore = configureMockStore(middlewares)
const store = mockStore({
  bookingReducer: {
    bookingData: null,
    message: null,
    isSearching: false,
    isRequested: false,
    currentBooking: {},
    isSuccess: false,
    activeStep: 3,
    currentStep: 3
  }
})

describe('#Document Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#Document Actions -  Create', () => {
    it('Should create Document Attachment', () => {
      fetchMock.post('*', {
        body: { status: 200, data: { booking_id: 123 } },
      })
      const expectedActions = [
        { type: types.CREATE_DOCUMENT_REQUEST, isRequested: true },
        { type: types.CREATE_DOCUMENT_SUCCESS, data: { booking_id: 123 }, activeStep: 2, currentStep: 2 },
        { type: types.CREATE_DOCUMENT_REQUEST, isRequested: false }
      ]

      return store.dispatch(actions.create({}, 2, 123)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error on create if the booking id is incorrect', () => {
      fetchMock.post('*', {
        body: { status: 404, message: "something went wrong" },
      })
      const expectedActions = [
        { type: types.CREATE_DOCUMENT_REQUEST, isRequested: true },
        { type: types.CREATE_DOCUMENT_FAILURE, msg: "something went wrong" },
        { type: types.CREATE_DOCUMENT_REQUEST, isRequested: false }
      ]
      return store.dispatch(actions.create({}, 2, null)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

  describe('#Document Actions -  Update', () => {
    it('Should update document attachement', () => {
      fetchMock.put('*', {
        body: { status: 200, data: { booking_id: 123 } },
      })
      const expectedActions = [
        { type: types.CREATE_DOCUMENT_REQUEST, isRequested: true },
        { type: types.CREATE_DOCUMENT_SUCCESS, data: { booking_id: 123 }, activeStep: 4, currentStep: 4 },
        { type: types.CREATE_DOCUMENT_REQUEST, isRequested: false }
      ]

      return store.dispatch(actions.update({ booking_id: 123 }, 4, 4)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error on update if the booking id is incorrect', () => {
      fetchMock.put('*', {
        body: { status: 404, message: "something went wrong" },
      })
      const expectedActions = [
        { type: types.CREATE_DOCUMENT_REQUEST, isRequested: true },
        { type: types.CREATE_DOCUMENT_FAILURE, msg: "something went wrong" },
        { type: types.CREATE_DOCUMENT_REQUEST, isRequested: false }
      ]
      return store.dispatch(actions.update({ booking_id: 123 }, 2, 1)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

})