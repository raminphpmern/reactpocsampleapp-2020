import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/inventoryHubAction'
import * as types from 'types/inventoryHub.type'
import expect from 'expect'
import { e500 } from 'lib/messages'

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const store = mockStore({
  inventoryHubReducer: {
    message: null,
    isRequested: false,
    result: [],
    totalPage: 0,
    totalRecord: 0,
    currentPage: 1
  }
})

describe('#InventoryHub Search Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#InventoryHub Search Actions', () => {
    it('Should save the result in the state if the search result is correct', () => {
      fetchMock.post('*', { result: [{ br_request_id: "AN00098" }], status: 200 })
      const expectedActions = [
        { type: types.IH_FETCH_REQUEST, isRequested: true },
        { type: types.IH_FETCH_SUCCESS, data: [{ br_request_id: "AN00098" }] },
        { type: types.IH_FETCH_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.search()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error if the search result is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.IH_FETCH_REQUEST, isRequested: true },
        { type: types.IH_FETCH_FAILURE, message: e500 },
        { type: types.IH_FETCH_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.search()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })
})

