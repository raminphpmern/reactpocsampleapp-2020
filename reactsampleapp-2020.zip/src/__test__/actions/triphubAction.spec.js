import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/tripHubAction'
import * as types from 'types/tripHub.type'
import expect from 'expect'
import { e500 } from 'lib/messages'

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const store = mockStore({
  csReducer: {
    message: null,
    isRequested: false,
    result: [],
    tripsToday: 0,
    tripsWeek: 0,
    all: 0,
    totalPage: 0,
    totalRecord: 0,
    currentPage: 1,
    limit: 10,
  }
})

describe('#TripHub Search Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#TripHub Search Actions', () => {
    it('Should save the result in the state if the search result is correct', () => {
      fetchMock.post('*', { result: [{ plpth_trip_plan_id: "TID000000001" }], status: 200 })
      const expectedActions = [
        { type: types.TRIPHUB_FETCH_REQUEST, isRequested: true, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/begin' },
        {
          type: types.TRIPHUB_FETCH_SUCCESS,
          data: [{ plpth_trip_plan_id: "TID000000001" }],
          filterType: "all",
          limit: undefined,
          totalPage: undefined,
          totalRecord: undefined
        },
        { type: types.TRIPHUB_FETCH_REQUEST, isRequested: false, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/end', },
      ]
      return store.dispatch(actions.search(
        { periodic_filter: "all" })).then(() => {
          expect(store.getActions()).toEqual(expectedActions)
        })
    })

    it('Should show error if the search result is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.TRIPHUB_FETCH_REQUEST, isRequested: true, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/begin', },
        { type: types.TRIPHUB_FETCH_FAILURE, message: e500 },
        { type: types.TRIPHUB_FETCH_REQUEST, isRequested: false, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/end', },
      ]
      return store.dispatch(actions.search()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })
})

