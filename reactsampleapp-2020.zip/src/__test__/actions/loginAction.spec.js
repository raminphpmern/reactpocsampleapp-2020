import * as userActions from 'actions/loginAction';
import { user } from '../fixtures/data';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import { e500 } from 'lib/messages';

const middlewares = [thunk]
const mockStore = configureStore(middlewares)
const store = mockStore({})
const userObj = {username: 'siva', newUser: false, loggedIn: true}

describe('Login Action', () => {
  beforeEach(() => {
    store.clearActions()
  })

  afterEach(() => {
    fetchMock.reset();
  })

  describe('initialize', () => {
    it('should dispatch the initialize success action', () => {
      const response = userActions.initialize()
      expect(response).toEqual({type: "LOGIN_INITIALIZE"})
    })
  })

  describe('initializeUser', () => {
    it('should dispatch the user initialize success action', () => {
      store.dispatch(userActions.initializeUser())
      const actions =  store.getActions()
      expect(actions).toEqual([{type: "LOGIN_INITIALIZE"}])
    })
  })

  describe('loginSuccess', () => {
    it('should dispatch the login success action', () => {
      const response = userActions.loginSuccess(user)
      expect(response).toEqual({type: "LOGIN_SUCCESS", user: user})
    })
  })

  describe('loginFailure', () => {
    it('should dispatch the login failure action', () => {
      const response = userActions.loginFailure('error')
      expect(response).toEqual({type: "LOGIN_FAILURE", message: 'error'})
    })
  })

  describe('loginRequest', () => {
    it('should dispatch the login request action', () => {
      const response = userActions.loginRequest(true)
      expect(response).toEqual({type: "LOGIN_REQUEST",isLoading: true})
    })
  })

  describe('logout', () => {
    it('should dispatch the logout action', () => {
      const response = userActions.logout()
      expect(response).toEqual({type: "LOGOUT"})
    })
  })

  describe('userLogout', () => {
    it('should dispatch the user logout action', () => {
      store.dispatch(userActions.userLogout())
      const expectedActions = [
        {type: "LOGOUT"}
      ]
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })
  })

  describe('userLogin', () => {
    it('should dispatch the user login success action', async () => {
      fetchMock.post('*', { data: {username: 'siva'}, status: 200 })
      const expectedActions = [
        { type: "LOGIN_REQUEST", isLoading: true },
        { type: "LOGIN_SUCCESS", user: {username: 'siva'}}
      ]
      await store.dispatch(userActions.userLogin({username: 'siva'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })

    it('should dispatch the user login failure action', async () => {
      fetchMock.post('*', { message: e500 ,status: 404 })
      const expectedActions = [
        { type: "LOGIN_REQUEST", isLoading: true },
        { type: "LOGIN_FAILURE", message: e500}
      ]
      await store.dispatch(userActions.userLogin({username: 'siva'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })

    it('should dispatch the user login failure action', async () => {
      fetchMock.post('*', 500)
      const expectedActions = [
        { type: "LOGIN_REQUEST", isLoading: true },
        { type: "LOGIN_FAILURE", message: e500}
      ]
      await store.dispatch(userActions.userLogin({username: 'siva'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })
  })

  describe('createPassword', () => {
    it('should dispatch the user create password success action', async () => {
      fetchMock.post('*', {status: 200, message: "Success", data: userObj})
      const expectedActions = [
        {type: "LOGIN_REQUEST", isLoading: true},
        {type: "LOGIN_SUCCESS", user: userObj}
      ]
      await store.dispatch(userActions.createPassword({new_password: '1234', confirm_password: '1234'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })

    it('should dispatch the user create password failure action', async () => {
      fetchMock.post('*', {status: 422, message: e500})
      const expectedActions = [
        {type: "LOGIN_REQUEST", isLoading: true},
        {type: "LOGIN_FAILURE", message: e500}
      ]
      await store.dispatch(userActions.createPassword({new_password: '1234', confirm_password: '12345'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })

    it('should dispatch the user create password failure action', async () => {
      fetchMock.post('*', 500)
      const expectedActions = [
        {type: "LOGIN_REQUEST", isLoading: true},
        {type: "LOGIN_FAILURE", message: e500}
      ]
      await store.dispatch(userActions.createPassword({new_password: '1234', confirm_password: '12345'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })
  })

  describe('passwordLogin', () => {
    it('shoulde dispatch the user password login success action', async () => {
      fetchMock.post('*', {status: 200, message: 'Success', data: userObj})
      const expectedActions = [
        {type: "LOGIN_REQUEST", isLoading: true},
        {type: "LOGIN_SUCCESS", user: userObj}
      ]
      await store.dispatch(userActions.passwordLogin({username: 'siva', password: '1234'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })

    it('shoulde dispatch the user password login failure action', async () => {
      fetchMock.post('*', {status: 422, message: e500})
      const expectedActions = [
        {type: "LOGIN_REQUEST", isLoading: true},
        {type: "LOGIN_FAILURE", message: e500}
      ]
      await store.dispatch(userActions.passwordLogin({username: 'siva', password: '1234'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })

    it('shoulde dispatch the user password login failure action', async () => {
      fetchMock.post('*', 500)
      const expectedActions = [
        {type: "LOGIN_REQUEST", isLoading: true},
        {type: "LOGIN_FAILURE", message: e500}
      ]
      await store.dispatch(userActions.passwordLogin({username: 'siva', password: '1234'}))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })
  })
})
