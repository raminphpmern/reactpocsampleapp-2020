import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/thuInventoryAction'
import * as types from 'types/thuInventory.type'
import expect from 'expect'
import { e500 } from 'lib/messages'

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const store = mockStore({
  Reducer: {
    message: null,
    isRequested: false,
    result: [],
    total: 0,
    available: 0,
    allocated: 0,
    totalPage: 0,
    totalRecord: 0,
    currentPage: 1,
    limit: 10,
  }
})

describe('#ThuInventory Search Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#ThuInventoryHub Search Actions', () => {
    it('Should save the result in the state if the search result is correct', () => {
      fetchMock.post('*', { result: [{ wms_thu_id: "KB Large" }], status: 200 })
      const expectedActions = [
        { type: types.THUINVENTORY_SEARCH_REQUEST, isRequested: true },
        {
          type: types.THUINVENTORY_SEARCH_SUCCESS,
          data: [{ wms_thu_id: "KB Large" }],
          filterType: "total",
          limit: undefined,
          totalPage: undefined,
          totalRecord: undefined
        },
        { type: types.THUINVENTORY_SEARCH_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.search(
        { periodic_filter: "total" })).then(() => {
          expect(store.getActions()).toEqual(expectedActions)
        })
    })

    it('Should show error if the search result is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.THUINVENTORY_SEARCH_REQUEST, isRequested: true },
        { type: types.THUINVENTORY_SEARCH_FAILURE, message: e500 },
        { type: types.THUINVENTORY_SEARCH_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.search()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })
})

