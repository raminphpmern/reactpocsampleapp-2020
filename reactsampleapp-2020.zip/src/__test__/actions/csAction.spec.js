import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/csAction'
import * as types from 'types/cs.type'
import expect from 'expect'
import { e500 } from 'lib/messages'

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const store = mockStore({
  csReducer: {
    message: null,
    isRequested: false,
    result: [],
    totalPage: 0,
    totalRecord: 0,
    currentPage: 1
  }
})

describe('#CollectionSummary Search Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#CollectionSummary Search Actions', () => {
    it('Should save the result in the state if the search result is correct', () => {
      fetchMock.post('*', { result: [{ ccd_br_no: "AAIFF/00003" }], status: 200 })
      const expectedActions = [
        { type: types.CS_FETCH_REQUEST, isRequested: true, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/begin', },
        { type: types.CS_FETCH_SUCCESS, data: [{ ccd_br_no: "AAIFF/00003" }] },
        { type: types.CS_FETCH_REQUEST, isRequested: false, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/end', },
      ]
      return store.dispatch(actions.search()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error if the search result is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.CS_FETCH_REQUEST, isRequested: true, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/begin', },
        { type: types.CS_FETCH_FAILURE, message: e500 },
        { type: types.CS_FETCH_REQUEST, isRequested: false, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/end', },
      ]
      return store.dispatch(actions.search()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })


  describe('#CollectionSummary button events actions', () => {
    it('Should save the result in the state if the search result is correct', () => {
      fetchMock.post('*', { result: [{ 'ccd_receipt_no': '1' }], status: 200, crStatus: "DF", message: "Selected Collections status changed" })
      const expectedActions = [

        { type: types.CS_STATUS_UPDATE_REQUEST, isRequested: true },
        { type: types.CS_STATUS_UPDATE_RESET },
        { type: types.CS_FETCH_SUCCESS, data: [], totalPage: 0, totalRecord: 0 },
        { type: types.CS_STATUS_UPDATE_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.buttonAction({ a: 1 }, 'save')).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error if the search result is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.CS_STATUS_UPDATE_REQUEST, isRequested: true },
        { type: types.CS_STATUS_UPDATE_FAILURE, message: 'Something went wrong!!!' },
        { type: types.CS_STATUS_UPDATE_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.buttonAction({ a: 1 }, 'save')).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

  describe('#CollectionSummary Receipt Helper actions', () => {
    it('Should fetch the records for the appropriate receipt details', () => {
      fetchMock.post('*', { result: [{ ccd_receipt_no_from: "0001" }], status: 200 })
      const expectedActions = [

        { type: types.CS_RECEIPT_REQUEST, isRequested: true },
        { type: types.CS_RECEIPT_SUCCESS, data: [{ ccd_receipt_no_from: "0001" }] },
        { type: types.CS_RECEIPT_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.searchReceipt()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error if the search result is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.CS_RECEIPT_REQUEST, isRequested: true },
        { type: types.CS_RECEIPT_FAILURE, message: 'Something went wrong!!!' },
        { type: types.CS_RECEIPT_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.searchReceipt()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

  describe('#CollectionSummary Employee Helper actions', () => {
    it('Should fetch the records for the appropriate employee details', () => {
      fetchMock.post('*', { result: [{ wms_emp_employee_code: "0001" }], status: 200 })
      const expectedActions = [

        { type: types.CS_EMPLOYEE_REQUEST, isRequested: true },
        { type: types.CS_EMPLOYEE_SUCCESS, data: [{ wms_emp_employee_code: "0001" }] },
        { type: types.CS_EMPLOYEE_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.searchEmployeeId()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error if the search result is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.CS_EMPLOYEE_REQUEST, isRequested: true },
        { type: types.CS_EMPLOYEE_FAILURE, message: 'Something went wrong!!!' },
        { type: types.CS_EMPLOYEE_REQUEST, isRequested: false },
      ]
      return store.dispatch(actions.searchEmployeeId()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })
})

