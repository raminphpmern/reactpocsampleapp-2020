import * as shipperActions from 'actions/shipperAction';
import { shipper } from '../fixtures/data';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import { e500 } from 'lib/messages';

const middlewares = [thunk]
const mockStore = configureStore(middlewares)
const store = mockStore({})

describe('Shipper Action', () => {
  beforeEach(() => {
    store.clearActions()
  })

  afterEach(() => {
    fetchMock.reset();
  })

  describe('initialize', () => {
    it('should dispatch the initialize success action', () => {
      const response = shipperActions.initialize()
      expect(response).toEqual({type: "CREATE_SHIPPER_INITIALIZE"})
    })
  })

  describe('initializeForm', () => {
    it('should dispatch the form initialize success action', () => {
      store.dispatch(shipperActions.initializeForm())
      const actions =  store.getActions()
      expect(actions).toEqual([{type: "CREATE_SHIPPER_INITIALIZE"}])
    })
  })

  describe('Request', () => {
    it('should dispatch the request action', () => {
      const response = shipperActions.Request(true)
      expect(response).toEqual({type: "CREATE_SHIPPER_REQUEST", isLoading: true})
    })
  })

  describe('Success', () => {
    it('should dispatch the success action', () => {
      const response = shipperActions.Success(shipper)
      expect(response).toEqual({type: "CREATE_SHIPPER_SUCCESS", shipper: shipper})
    })
  })

  describe('Failure', () => {
    it('should dispatch the failure action', () => {
      const response = shipperActions.Failure(e500)
      expect(response).toEqual({type: "CREATE_SHIPPER_FAILURE", message: e500})
    })
  })

  describe('create', () => {
    it('should dispatch the create success action', async () => {
      fetchMock.post('*', { data: shipper, status: 200 })
      const expectedActions = [
        { type: "CREATE_SHIPPER_REQUEST", isLoading: true },
        { type: "CREATE_SHIPPER_SUCCESS", shipper: shipper },
        { type: "CREATE_SHIPPER_REQUEST", isLoading: false }
      ]
      await store.dispatch(shipperActions.create(shipper))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })

    it('should dispatch the create failure action', async () => {
      fetchMock.post('*', { message: e500, status: 500 })
      const expectedActions = [
        { type: "CREATE_SHIPPER_REQUEST", isLoading: true },
        { type: "CREATE_SHIPPER_FAILURE", message: e500 },
        { type: "CREATE_SHIPPER_REQUEST", isLoading: false }
      ]
      await store.dispatch(shipperActions.create(shipper))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })

    it('should dispatch the create failure action', async () => {
      fetchMock.post('*', 500)
      const expectedActions = [
        { type: "CREATE_SHIPPER_REQUEST", isLoading: true },
        { type: "CREATE_SHIPPER_FAILURE", message: e500 },
        { type: "CREATE_SHIPPER_REQUEST", isLoading: false }
      ]
      await store.dispatch(shipperActions.create(shipper))
      const actions = store.getActions()
      expect(actions).toEqual(expectedActions)
    })
  })
})