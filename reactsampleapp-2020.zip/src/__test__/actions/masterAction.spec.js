import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/masterAction'
import * as types from 'types/master.type'
import expect from 'expect'
const middlewares = [thunk]

const mockStore = configureMockStore(middlewares)
const store = mockStore({
  masterReducer: {
    options: {
      countries: [],
      province: [],
      city: [],
      barangay: [],
      zip: [],
      brsd_from_ship_point_id: [],
      brsd_to_ship_point_id: [],
      zone: [],
      sub_zone: [],
      shipper: [],
      shipper_first_name: [],
      shipper_last_name: [],
      consignee: [],
      consignee_first_name: [],
      consignee_last_name: []
    },
    isSuccess: false,
    isLoading: false,
    isSearching: false,
    lastPage: null
  }
})

describe('#Master Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#Master Actions -  Master data Search', () => {
    it('should fetch the master data based on query string', () => {
      fetchMock.get('*', {
        body: { status: 200, result: [{ value: 'Ind', label: 'India' }] },
      })
      const expectedActions = [{ type: types.MASTER_FETCH_REQUEST, isLoading: true },
      {
        type: types.MASTER_FETCH_SUCCESS,
        data:
        {
          countries: [],
          province: [],
          city: [],
          barangay: [{ value: 'Ind', label: 'India' }],
          zip: [],
          brsd_from_ship_point_id: [],
          brsd_to_ship_point_id: [],
          zone: [],
          sub_zone: [],
          shipper: [],
          shipper_first_name: [],
          shipper_last_name: [],
          consignee: [],
          consignee_first_name: [],
          consignee_last_name: []
        }
      },
      { type: types.MASTER_FETCH_REQUEST, isLoading: false }]
      return store.dispatch(actions.getGeoOptions('barangay', 'wms_geo_country_code=Ind&wms_geo_state_code=TN&wms_geo_city_code=Chennai', '')).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should return empty array if the search string not matches', () => {
      fetchMock.get('*', {
        body: { status: 200, result: [] },
      })
      const expectedActions = [{ type: types.MASTER_FETCH_REQUEST, isLoading: true },
      {
        type: types.MASTER_FETCH_SUCCESS,
        data:
        {
          countries: [],
          province: [],
          city: [],
          barangay: [],
          zip: [],
          brsd_from_ship_point_id: [],
          brsd_to_ship_point_id: [],
          zone: [],
          sub_zone: [],
          shipper: [],
          shipper_first_name: [],
          shipper_last_name: [],
          consignee: [],
          consignee_first_name: [],
          consignee_last_name: []
        }
      },
      { type: types.MASTER_FETCH_REQUEST, isLoading: false }]
      return store.dispatch(actions.getGeoOptions('barangay', 'wms_geo_country_code=Ind&wms_geo_state_code=TN&wms_geo_city_code=Chennai', '')).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

  describe('#Master Action -  Search ship point', () => {
    it('should search ship point based on filter given', () => {
      fetchMock.post('*', {
        body: { status: 200, result: [{ brsd_from_ship_point_id: "Chennai" }], last_page: 1, total: 10 },
      })
      const expectedActions = [{ type: types.MASTER_MULTI_SEARCH_REQUEST, isSearching: true },
      { type: types.INITIALIZE_SHIPPER_IDS },
      { type: types.PAGINATION_ATTR, lastPage: 1, total: 10 },
      { type: types.MASTER_SHIPPING_FETCH_SUCCESS, data: [{ brsd_from_ship_point_id: "Chennai" }] },
      { type: types.MASTER_MULTI_SEARCH_REQUEST, isSearching: false }]

      return store.dispatch(actions.searchShippingHelp({}, 1)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('should throw error', () => {
      fetchMock.post('*', {
        body: { status: 404, message: "Something went wrong" },
      })
      const expectedActions = [{ type: types.MASTER_MULTI_SEARCH_REQUEST, isSearching: true },
      { type: types.MASTER_FETCH_FAILURE, err: 'Something went wrong' },
      { type: types.MASTER_MULTI_SEARCH_REQUEST, isSearching: false }]
      return store.dispatch(actions.searchShippingHelp(undefined, {}, 1)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })
})