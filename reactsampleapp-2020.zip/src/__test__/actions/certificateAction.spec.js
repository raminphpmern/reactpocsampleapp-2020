import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/certificateAction'
import * as types from 'types/certificate.type'
import expect from 'expect'
const middlewares = [thunk]

const mockStore = configureMockStore(middlewares)
const store = mockStore({
  bookingReducer: {
    bookingData: null,
    message: null,
    isSearching: false,
    isRequested: false,
    currentBooking: {},
    isSuccess: false,
    activeStep: 3,
    currentStep: 3
  }
})

describe('#Certificate Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#Certificate Actions -  Create', () => {
    it('Should create Certificate Details', () => {
      fetchMock.post('*', {
        body: { status: 200, data: { booking_id: 123 } },
      })
      const expectedActions = [
        { type: types.CREATE_CERTIFICATE_REQUEST, isRequested: true },
        { type: types.CREATE_CERTIFICATE_SUCCESS, data: { certificate_detail: { booking_id: 123 } } },
        { type: types.CREATE_CERTIFICATE_REQUEST, isRequested: false }
      ]
      return store.dispatch(actions.create({}, 123)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error on create if the booking id is incorrect', () => {
      fetchMock.post('*', {
        body: { status: 404, message: "something went wrong" },
      })
      const expectedActions = [
        { type: types.CREATE_CERTIFICATE_REQUEST, isRequested: true },
        { type: types.CREATE_CERTIFICATE_FAILURE, msg: "something went wrong" },
        { type: types.CREATE_CERTIFICATE_REQUEST, isRequested: false }
      ]
      return store.dispatch(actions.create({}, null)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

  describe('#Disbursement Actions -  Update', () => {
    it('Should update Disbursement details', () => {
      fetchMock.put('*', {
        body: { status: 200, data: { booking_id: 123 } },
      })
      const expectedActions = [
        { type: types.CREATE_CERTIFICATE_REQUEST, isRequested: true },
        { type: types.CREATE_CERTIFICATE_SUCCESS, data: { certificate_detail: { booking_id: 123 } } },
        { type: types.CREATE_CERTIFICATE_REQUEST, isRequested: false }
      ]

      return store.dispatch(actions.update({}, 123)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error on update if the booking id is incorrect', () => {
      fetchMock.put('*', {
        body: { status: 404, message: "something went wrong" },
      })
      const expectedActions = [
        { type: types.CREATE_CERTIFICATE_REQUEST, isRequested: true },
        { type: types.CREATE_CERTIFICATE_FAILURE, msg: "something went wrong" },
        { type: types.CREATE_CERTIFICATE_REQUEST, isRequested: false }
      ]
      return store.dispatch(actions.update({}, 1)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })

})