import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/bookingActions'
import * as types from 'types/booking.type'
import expect from 'expect'
import { bookingSearchSuccess, bookingSearchError } from '../fixtures/data';
const middlewares = [thunk]

const mockStore = configureMockStore(middlewares)
const store = mockStore({
  form: {
    CustomerDetailsForm: {}
  }
})

describe('#Booking Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#Booking Actions -  Booking ID Search', () => {
    it('Should save the result in the state if the booking id is correct', () => {
      fetchMock.get('*', {
        body: bookingSearchSuccess,
      })
      const expectedActions = [
        { type: types.BOOKING_SEARCH_REQUEST, isSearching: true },
        { type: types.BOOKING_SEARCH_SUCCESS, data: { tms_br_booking_request_hdr: { br_request_id: 'R000000149' } } },
        { type: types.BOOKING_SEARCH_REQUEST, isSearching: false }
      ]
      return store.dispatch(actions.search('R000000149', 'type="booking"', false)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error if the booking id is incorrect', () => {
      fetchMock.get('*', {
        body: bookingSearchError,
      })
      const expectedActions = [
        { type: types.BOOKING_SEARCH_REQUEST, isSearching: true },
        { type: types.BOOKING_SEARCH_FAILURE, message: "Booking ID is not found." },
        { type: types.BOOKING_SEARCH_REQUEST, isSearching: false }
      ]
      return store.dispatch(actions.search('R1', false)).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })
})