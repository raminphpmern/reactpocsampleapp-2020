import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as dispatchactions from 'actions/dispatchDocumentAction'
import { dispatchsearch } from '../fixtures/data';
import expect from 'expect'
const middlewares = [thunk]

const mockStore = configureMockStore(middlewares)
const store = mockStore({
  dispatchReducer: {
    options: {
      dispatch_type: [],
      service_type: [],
      subservice_type: [],
      br_service_type: [],
      currency_value: [],
      unit_value: [],
      weight_value: [],
      consignee_list: [],
      consignor_list: [],
      doc_status: [],
      dispatch_type: [],
    },
    isSuccess: false,
    isLoading: false,
    isSearching: false,
    lastPage: null,
    isRequested: false
  }
})

describe('Search', () => {
  it('should dispatch the success action', async () => {
    fetchMock.post('*', {
      body: { status: 200, data: { ddh_dispatch_doc_no: 'KD_1577096062566' } },
    })

    const expectedActions = [
      { type: "DISPATCH_FETCH_REQUEST", isRequested: true },
      {
        type: "DISPATCH_FETCH_SUCCESS", data: { data: { ddh_dispatch_doc_no: "KD_1577096062566" }, status: 200 }
      },
      { type: "DISPATCH_FETCH_REQUEST", isRequested: false }
    ]

    return store.dispatch(dispatchactions.search({})).then(() => {
      expect(store.getActions()).toEqual(expectedActions)
    })
  });

})
