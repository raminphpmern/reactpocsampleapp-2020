import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store'
import * as actions from 'actions/brHubActions'
import * as types from 'types/brHub.type'
import expect from 'expect'
import { e500 } from 'lib/messages'
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const store = mockStore({})

describe('#BRHUB Search Actions Test Cases', () => {
  afterEach(() => {
    fetchMock.restore()
  })
  beforeEach(() => {
    store.clearActions()
  })

  describe('#BRHUB Search Actions -  Booking ID Search', () => {
    it('Should save the result in the state if the booking id is correct', () => {
      fetchMock.post('*', { result: [{ br_request_id: "BB000000001" }], status: 200 })
      const expectedActions = [
        { type: types.BRHUB_FETCH_REQUEST, isRequested: true, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/begin', },
        { type: types.BRHUB_FETCH_SUCCESS, data: { result: [{ br_request_id: "BB000000001" }], status: 200 } },
        { type: types.BRHUB_FETCH_REQUEST, isRequested: false, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/end', },
      ]
      return store.dispatch(actions.search()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })

    it('Should show error if the booking id is incorrect', () => {
      fetchMock.post('*', { message: e500, status: 404 })
      const expectedActions = [
        { type: types.BRHUB_FETCH_REQUEST, isRequested: true, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/begin', },
        { type: types.BRHUB_FETCH_FAILURE, msg: e500 },
        { type: types.BRHUB_FETCH_REQUEST, isRequested: false, '@@react-redux-spinner/pending-task': '@@react-redux-spinner/end', },
      ]
      return store.dispatch(actions.search()).then(() => {
        expect(store.getActions()).toEqual(expectedActions)
      })
    })
  })
})
