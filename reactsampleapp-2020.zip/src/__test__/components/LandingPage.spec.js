import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import LandingPage from 'components/LandingPage';
import configureMockStore from 'redux-mock-store';
import { BrowserRouter as Router } from 'react-router-dom';


const mockStore = configureMockStore();
const sessionState = { loginReducer: { user: { loggedIn: true } }, bookingReducer: {} }
// let store;

let store = mockStore({
  bookingReducer: {
    bookingData: null,
    message: null,
    isSearching: false,
    isRequested: false,
    currentBooking: {},
    isSuccess: false,
    activeStep: 3,
    currentStep: 3
  }
})

describe('<LandingPage />', () => {
  window._env_ = { "API_URL": "http://localhost:3000" }
  describe('validate', () => {
    it('validate menu elements', () => {
      // TODO:
      store = mockStore(sessionState);
      const landingPage = mount(
        <Provider store={store}>
          <Router>
            <LandingPage />
          </Router>
        </Provider>)
      // expect(landingPage.find('DropdownItem[text="Acceptance"]').length).toBe(1)
      // expect(landingPage.find('DropdownItem[text="Pickup Request / Supplies Request"]').length).toBe(1)
      // expect(landingPage.find('.landing-box').length).toBe(4)
    })
  })
})
