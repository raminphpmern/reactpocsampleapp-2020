import React from 'react';
import ReactDOM from "react-dom";
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import NewShipper from 'components/Qbr/CustomerDetails/NewShipper';
import store from 'store';
import { I18nextProvider } from 'react-i18next';
import i18n from '../../i18n';

describe('<NewShipper />', () => {
  const mockfn = jest.fn()
  const props = {
    countries: [],
    province: [],
    city: [],
    barangay: [],
    zip: [],
    dropDownonSelect: mockfn,
    close: mockfn,
    open: true,
    handleSubmit: mockfn
  }
  let wrapper;

  describe('form validation', () => {
    beforeEach(() => {
      wrapper = mount(
        <Provider store={store} >
          <I18nextProvider i18n={i18n}>
            <NewShipper {...props} />
          </I18nextProvider>
        </Provider>
      );
    });

    describe('input#wms_customer_name --- Company Name', () => {
      it('should throw error if leave blank', () => {
        let companyName = wrapper.find('input#wms_customer_name');
        expect(companyName.prop('type')).toBe('text');
        expect(companyName.prop('placeholder')).toBe('');
        companyName.simulate('blur');
        expect(wrapper.find('input#wms_customer_name').prop('className')).toBe('error');
        expect(wrapper.find('.error_message').length).toBe(1);
      })
    })

    describe('input#wms_customer_lastname --- Last Name', () => {
      let lastName;
      beforeEach(() => {
        lastName = wrapper.find('input#wms_customer_lastname');
      })
      it('should throw error if leave blank', () => {
        expect(lastName.prop('type')).toBe('text');
        expect(lastName.prop('placeholder')).toBe('');
        lastName.simulate('blur');
        expect(wrapper.find('input#wms_customer_lastname').prop('className')).toBe('error');
        expect(wrapper.find('.error_message').last().text()).toBe('Last Name is required.');
      })

      it('should not throw error if value given', () => {
        expect(lastName.prop('type')).toBe('text');
        expect(lastName.prop('placeholder')).toBe('');
        lastName.simulate('change', { target: { value: 'test' } });
        expect(wrapper.find('input#wms_customer_lastname').prop('className')).toBe('');
        expect(wrapper.find('.error_message').length).toBe(0);
      })
    })
  })

  describe('input#wms_customer_firstname --- First Name', () => {
    let firstName;
    beforeEach(() => {
      firstName = wrapper.find('input#wms_customer_firstname');
    })

    it('should throw error if leave blank', () => {
      expect(firstName.prop('type')).toBe('text');
      expect(firstName.prop('placeholder')).toBe('');
      firstName.simulate('blur');
      expect(wrapper.find('input#wms_customer_firstname').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('First Name is required.');
    })

    it('should not throw error if value given', () => {
      expect(firstName.prop('type')).toBe('text');
      expect(firstName.prop('placeholder')).toBe('');
      firstName.simulate('change', { target: { value: 'test' } });
      expect(wrapper.find('input#wms_customer_firstname').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_middlename --- Middle Name', () => {
    it('should not throw error if leave blank', () => {
      let middleName = wrapper.find('input#wms_customer_middlename');
      expect(middleName.prop('type')).toBe('text');
      expect(middleName.prop('placeholder')).toBe('');
      middleName.simulate('blur');
      expect(wrapper.find('input#wms_customer_middlename').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_address1 --- Address', () => {
    let address;
    beforeEach(() => {
      address = wrapper.find('input#wms_customer_address1');
    })
    it('should throw error if leave blank', () => {
      expect(address.prop('type')).toBe('text');
      expect(address.prop('placeholder')).toBe('');
      address.simulate('blur');
      expect(wrapper.find('input#wms_customer_address1').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('Address is required.');
    })

    it('should not throw error if value given', () => {
      expect(address.prop('type')).toBe('text');
      expect(address.prop('placeholder')).toBe('');
      address.simulate('change', { target: { value: 'test' } });
      expect(wrapper.find('input#wms_customer_address1').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_country --- Country', () => {
    let countryInput, countrySelect;

    beforeEach(() => {
      countryInput = wrapper.find('Select#wms_customer_country input');
      countrySelect = wrapper.find('Select#wms_customer_country');
    })
    it('should throw error if leave blank', () => {
      expect(countrySelect.prop('label')).toBe('COUNTRY');
      expect(countrySelect.prop('placeholder')).toBe('');
      countryInput.simulate('blur');
      expect(wrapper.find('Select#wms_customer_country').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('Country is required.');
    })

    it('should not throw error if value given', () => {
      expect(countrySelect.prop('label')).toBe('COUNTRY');
      expect(countrySelect.prop('placeholder')).toBe('');
      countrySelect.props().onChange(1)
      countryInput.simulate('mouseDown', {
        button: 0
      });
      expect(wrapper.find('Select#wms_customer_country').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_state --- Province', () => {
    let stateInput, stateSelect;

    beforeEach(() => {
      stateInput = wrapper.find('Select#wms_customer_state input');
      stateSelect = wrapper.find('Select#wms_customer_state');
    })

    it('should throw error if leave blank', () => {
      expect(stateSelect.prop('label')).toBe('PROVINCE');
      expect(stateSelect.prop('placeholder')).toBe('');
      stateInput.simulate('blur');
      expect(wrapper.find('Select#wms_customer_state').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('Province is required.');
    })

    it('should not throw error if value given', () => {
      expect(stateSelect.prop('label')).toBe('PROVINCE');
      expect(stateSelect.prop('placeholder')).toBe('');
      stateSelect.props().onChange(1)
      stateInput.simulate('mouseDown', {
        button: 0
      });
      expect(wrapper.find('Select#wms_customer_state').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_city --- City', () => {
    let cityInput, citySelect;

    beforeEach(() => {
      cityInput = wrapper.find('Select#wms_customer_city input');
      citySelect = wrapper.find('Select#wms_customer_city');
    })

    it('should throw error if leave blank', () => {
      expect(citySelect.prop('label')).toBe('CITY');
      expect(citySelect.prop('placeholder')).toBe('');
      cityInput.simulate('blur');
      expect(wrapper.find('Select#wms_customer_city').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('City is required.');
    })

    it('should not throw error if value given', () => {
      expect(citySelect.prop('label')).toBe('CITY');
      expect(citySelect.prop('placeholder')).toBe('');
      citySelect.props().onChange(1)
      cityInput.simulate('mouseDown', {
        button: 0
      });
      expect(wrapper.find('Select#wms_customer_city').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_suburb --- Barangay', () => {
    let barangayInput, barangaySelect;

    beforeEach(() => {
      barangayInput = wrapper.find('Select#wms_customer_suburb input');
      barangaySelect = wrapper.find('Select#wms_customer_suburb');
    })

    it('should throw error if leave blank', () => {
      expect(barangaySelect.prop('label')).toBe('BARANGAY');
      expect(barangaySelect.prop('placeholder')).toBe('');
      barangayInput.simulate('blur');
      expect(wrapper.find('Select#wms_customer_suburb').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('Barangay is required.');
    })

    it('should not throw error if value given', () => {
      expect(barangaySelect.prop('label')).toBe('BARANGAY');
      expect(barangaySelect.prop('placeholder')).toBe('');
      barangaySelect.props().onChange(1)
      barangayInput.simulate('mouseDown', {
        button: 0
      });
      expect(wrapper.find('Select#wms_customer_suburb').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_postal_code --- Zip code', () => {
    let postalInput, postalSelect;

    beforeEach(() => {
      postalInput = wrapper.find('Select#wms_customer_postal_code input');
      postalSelect = wrapper.find('Select#wms_customer_postal_code');
    })

    it('should throw error if leave blank', () => {
      expect(postalSelect.prop('label')).toBe('BARANGAY ID');
      expect(postalSelect.prop('placeholder')).toBe('');
      postalInput.simulate('blur');
      expect(wrapper.find('Select#wms_customer_postal_code').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('Zip code is required.');
    })

    it('should not throw error if value given', () => {
      expect(postalSelect.prop('label')).toBe('BARANGAY ID');
      expect(postalSelect.prop('placeholder')).toBe('');
      postalSelect.props().onChange(1)
      postalInput.simulate('mouseDown', {
        button: 0
      });
      expect(wrapper.find('Select#wms_customer_postal_code').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_phone1 --- Mobile no', () => {
    let mobileNo;

    beforeEach(() => {
      mobileNo = wrapper.find('input#wms_customer_phone1');
    })

    it('should throw error if leave blank', () => {
      expect(mobileNo.prop('type')).toBe('tel');
      expect(mobileNo.prop('placeholder')).toBe('');
      mobileNo.simulate('blur');
      expect(wrapper.find('input#wms_customer_phone1').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('Mobile no is required.');
    })

    it('should throw error if invalid value given', () => {
      expect(mobileNo.prop('type')).toBe('tel');
      expect(mobileNo.prop('placeholder')).toBe('');
      mobileNo.simulate('change', { target: { value: '+98404' } });
      expect(wrapper.find('input#wms_customer_phone1').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('Mobile no is invalid.');
    })

    it('should not throw error if value given', () => {
      expect(mobileNo.prop('type')).toBe('tel');
      expect(mobileNo.prop('placeholder')).toBe('');
      mobileNo.simulate('change', { target: { value: '+91 9840402155' } });
      expect(wrapper.find('input#wms_customer_phone1').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_phone2 --- Contact no', () => {
    it('should not throw error if leave blank', () => {
      let contactNo = wrapper.find('input#wms_customer_phone2');
      expect(contactNo.prop('type')).toBe('tel');
      expect(contactNo.prop('placeholder')).toBe('');
      contactNo.simulate('blur');
      expect(wrapper.find('input#wms_customer_phone2').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })

  describe('input#wms_customer_email --- Email Address', () => {
    let email;

    beforeEach(() => {
      email = wrapper.find('input#wms_customer_email');
    })

    it('should not throw error if leave blank', () => {
      expect(email.prop('type')).toBe('text');
      expect(email.prop('placeholder')).toBe('');
      email.simulate('blur');
      expect(wrapper.find('input#wms_customer_email').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })

    it('should throw error if invalid email entered', () => {
      expect(email.prop('type')).toBe('text');
      expect(email.prop('placeholder')).toBe('');
      email.simulate('change', { target: { value: 'test' } });
      expect(wrapper.find('input#wms_customer_email').prop('className')).toBe('error');
      expect(wrapper.find('.error_message').text()).toBe('Invalid email address.');
    })

    it('should not throw error if valid email entered', () => {
      expect(email.prop('type')).toBe('text');
      expect(email.prop('placeholder')).toBe('');
      email.simulate('change', { target: { value: 'test@test.com' } });
      expect(wrapper.find('input#wms_customer_email').prop('className')).toBe('');
      expect(wrapper.find('.error_message').length).toBe(0);
    })
  })
})
