import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import Wrapper from 'components/LandingPage/Wrapper';
import configureMockStore from 'redux-mock-store';
import { BrowserRouter as Router } from 'react-router-dom';
import thunk from 'redux-thunk';

const mockStore = configureMockStore([thunk])
const sessionState = {loginReducer: {user: {loggedIn: true, fullname: 'test'}}}
const sessionOff = {loginReducer: {user: {loggedIn: false, fullname: 'test'}}}
const initialState = {loginReducer: {user: null}}
let store;

describe('<Wrapper />', () => {
  window._env_ = {"API_URL": "http://localhost:3000"}
  describe('validate', () => {
    it('validate menu elements', () => {
      store = mockStore(sessionState);
      const wrapper = mount(
                            <Provider store={store}>
                              <Router>
                                <Wrapper  />
                              </Router>
                            </Provider>)
      expect(wrapper.find('.version-details span').first().text()).toContain('Version')
    })

    it('validate elements without user session', () => {
      store = mockStore(sessionOff);
      const wrapper = mount(
                            <Provider store={store}>
                              <Router>
                                <Wrapper/>
                              </Router>
                            </Provider>)
      const logoutLink = wrapper.find('a.change-user')
      expect(logoutLink.length).toBe(0);
    })

    it('validate elements on user session', () => {
      store = mockStore(sessionState);
      const wrapper = mount(
                            <Provider store={store}>
                              <Router>
                                <Wrapper/>
                              </Router>
                            </Provider>)
      const logoutLink = wrapper.find('a.change-user')
      expect(logoutLink.length).toBe(1);
    })

    it('validate elements event on user session', () => {
      store = mockStore(sessionState);
      const mockfn = jest.fn()
      const wrapper = mount(
        <Provider store={store}>
          <Router>
          <Wrapper changeUser={mockfn()}/> </Router>
        </Provider>
      )
      const logoutLink = wrapper.find('a.change-user')
      logoutLink.simulate('click')
      expect(mockfn).toHaveBeenCalled();
    })
  })
})
