import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import Login from 'components/Login';
import renderer from 'react-test-renderer';
import store from 'store';

const mockfn = jest.fn();

describe('<Login />', () => {

  let wrapper;

  const props = {
    handleSubmit: mockfn
  };

  describe('form validation', () => {
    beforeEach(() => {
      wrapper = mount(
          <Provider store={store} >
            <Router>
              <Login {...props} />
            </Router>
          </Provider>
        );
    });

    describe('input#username', () => {
      it('set error class when username is set to blank', () => {
        let userNameField = wrapper.find('input[name="username"]');
        expect(userNameField.prop('type')).toBe('text');
        expect(userNameField.prop('placeholder')).toBe('');
        userNameField.simulate('blur');
        expect(wrapper.find('input[name="username"]').prop('className')).toBe('error');
        expect(wrapper).toBeDefined();
      })

      it('no error class when username is set', () => {
        let userNameField = wrapper.find('input[name="username"]');
        userNameField.simulate('blur',{target: {name: 'username', value: 'siva'}});
        expect(wrapper.find('input[name="username"]').prop('className')).toBe('');
      })
    })
  });

  describe('<Login /> --- Snapshot', () => {
    it('capture screenshot of login component', () => {
      const login = renderer.create(<Provider store={store} >
        <Login {...props} />
      </Provider>).toJSON()
      expect(login).toMatchSnapshot()
    })
  })
})
