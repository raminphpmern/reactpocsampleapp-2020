import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import CreatePassword from 'components/Login/CreatePassword';
import renderer from 'react-test-renderer';
import store from 'store';

const mockfn = jest.fn();

describe('<CreatePassword />', () => {
  let wrapper;
  let props = {
    handleSubmit: mockfn
  }

  describe('Element validation', () => {
    beforeEach(() => {
      store.dispatch({type: 'LOGIN_SUCCESS', user: {newUser: true}})

      wrapper = mount(
          <Provider store={store}>
            <Router>
              <CreatePassword  {...props}/>
            </Router>
          </Provider>
        )
    })

    describe('<a />', () => {
      it('anchor tag should present', () => {
        let aTag = wrapper.find('a');
        expect(aTag.text()).toBe('Change User');
      })

      it('should clickable', () => {
        wrapper.find('a').simulate('click');
        //wrapper.instance().changeUser = mockfn;
        wrapper.update();
      })
    })

    describe('input#newPassword', () => {
      it('set error class when new password is set to blank', () => {
        let newPasswordField = wrapper.find('input#newPassword');
        expect(newPasswordField.prop('type')).toBe('password');
        expect(newPasswordField.prop('placeholder')).toBe('');
        newPasswordField.simulate('blur');
        expect(wrapper.find('input#newPassword').prop('className')).toBe('error');
      })
    })

    describe('input#confirmPassword', () => {
      it('set error class when new password is set to blank', () => {
        let confirmPasswordField = wrapper.find('input#confirmPassword');
        expect(confirmPasswordField.prop('type')).toBe('password');
        expect(confirmPasswordField.prop('placeholder')).toBe('');
        confirmPasswordField.simulate('blur');
        expect(wrapper.find('input#confirmPassword').prop('className')).toBe('error');
      })
    })

    describe('password validation', () => {
      it('throw error if password & confirm password is not match', () => {
        let newPasswordField = wrapper.find('input#newPassword');
        let confirmPasswordField = wrapper.find('input#confirmPassword');
        newPasswordField.simulate('blur',{target: {name: 'new_password', value: '1234'}});
        confirmPasswordField.simulate('blur',{target: {name: 'confirm_password', value: '5678'}});
        expect(wrapper.find('input#newPassword').prop('className')).toBe('error');
        expect(wrapper.find('input#confirmPassword').prop('className')).toBe('error');
        expect(wrapper.find('p.error_message').last().text()).toBe('Password mismatched');
      })

      it('should accept password & confirm password if both are same', () => {
        let newPasswordField = wrapper.find('input#newPassword');
        let confirmPasswordField = wrapper.find('input#confirmPassword');
        newPasswordField.simulate('blur',{target: {name: 'new_password', value: '1234'}});
        confirmPasswordField.simulate('blur',{target: {name: 'confirm_password', value: '1234'}});
        expect(wrapper.find('input#newPassword').prop('className')).toBe('');
        expect(wrapper.find('input#confirmPassword').prop('className')).toBe('');
      })
    })

    describe('Login Button', () => {
      it('Login button should present', () => {
        let aTag = wrapper.find('button');
        expect(aTag.text()).toBe('Login');
      })

      it('should clickable', () => {
        let newPasswordField = wrapper.find('input#newPassword');
        let confirmPasswordField = wrapper.find('input#confirmPassword');
        newPasswordField.simulate('blur',{target: {name: 'new_password', value: '1234'}});
        confirmPasswordField.simulate('blur',{target: {name: 'new_password', value: '1234'}});
        wrapper.find('button').simulate('submit');
        expect(mockfn).toHaveBeenCalled();
      })
    })
  })

  describe('<CreatePassword /> --- Snapshot', () => {
    it('capture screenshot of password component', () => {
      const createPassword = renderer.create(
          <Provider store={store} >
            <Router>
              <CreatePassword {...props} />
            </Router>
          </Provider>
        ).toJSON()
      expect(createPassword).toMatchSnapshot()
    })
  })
})
