import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import Password from 'components/Login/Password';
import renderer from 'react-test-renderer';
import store from 'store';

const mockfn = jest.fn();

describe('<Password />', () => {

  let wrapper;

  const props = {
    handleSubmit: mockfn
  };

  describe('form validation', () => {

    beforeEach(() => {
      wrapper = mount(
          <Provider store={store}>
            <Router>
              <Password {...props} />
            </Router>
          </Provider>
        )
    })

    describe('input#password', () => {
      it('set error class when password is set as blank', () => {
        let passwordField = wrapper.find('input#password');
        expect(passwordField.prop('type')).toBe('password');
        passwordField.simulate('blur');
        expect(wrapper.find('input#password').prop('className')).toBe('error');
        expect(wrapper).toBeDefined();
      })

      it('no error class when password is set', () => {
        let passwordField = wrapper.find('input#password');
        expect(passwordField.prop('type')).toBe('password');
        passwordField.simulate('blur', {target: {name: 'password', value: '1234'}});
        expect(wrapper.find('input#password').prop('className')).toBe('');
      })
    })

    describe('check for a tag', () => {
      it('anchor tag should present', () => {
        let aTag = wrapper.find('a');
        expect(aTag.text()).toBe('Change User');
      })
    })
  });

  describe('<Password /> --- Snapshot', () => {
    it('capture screenshot of password component', () => {
      const password = renderer.create(
          <Provider store={store} >
            <Router>
              <Password {...props} />
            </Router>
          </Provider>
        ).toJSON()
      expect(password).toMatchSnapshot()
    })
  })
})
