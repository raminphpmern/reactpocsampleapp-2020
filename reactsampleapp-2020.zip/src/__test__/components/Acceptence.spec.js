import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import Acceptence from 'components/Qbr/Acceptence';
import renderer from 'react-test-renderer';
import configureMockStore from 'redux-mock-store';
import { BrowserRouter as Router } from 'react-router-dom';
import thunk from 'redux-thunk';
import { reducer as formReducer } from 'redux-form'
import history from 'routes/history';

const mockStore = configureMockStore([thunk])
const sessionState = {
  loginReducer: { user: { loggedIn: true, locations: [] } },
  bookingReducer: {
    activeStep: 3, currentStep: 2, currentBooking: {
      shipment_details: [],
      tms_br_booking_request_hdr: {},
      tms_brsd_shipment_details: {
        brsd_to_country: {},
        brsd_from_country: {},
        brsd_to_city: {},
        brsd_from_city: {},
        brsd_from_state: {},
        brsd_to_state: {},
        brsd_from_suburb: {},
        brsd_to_suburb: {},
        brsd_from_postal_code: {},
        brsd_to_postal_code: {}
      },
      tms_brccd_consgt_consignee_details: {}
    },
    recurring: 'N'
  },
  masterReducer: {
    total_cop: 0,
    options: {
      countries: [],
      service_mode: [],
      shipment_type: [],
      payment_type: [],
      mode_of_collections: [],
      vas: [],
      class_of_stores: [],
      temp_uom: [],
      alt_uom: [],
      codIncludes: [],
    }
  },
  form: formReducer
}
let store;

describe('<Acceptence />', () => {
  window._env_ = { "API_URL": "http://localhost:3000" }
  describe('validate', () => {

    it('render acceptence', () => {
      window.HTMLElement.prototype.scrollTo = function () { };
      store = mockStore(sessionState);
      const acceptence = mount(
        <Provider store={store}>
          <Router>
            <Acceptence match={{ params: { id: 1 } }} history={history} />
          </Router>
        </Provider>, { attachTo: document.body }
      )

      const orderDetailsTab = acceptence.find('Tab').at(1)
      orderDetailsTab.simulate('click')
      expect(acceptence.find('li').at(0).text()).toBe('Customer Details')
      expect(acceptence.find('li').at(1).text()).toBe('Order Details')
      expect(acceptence.find('li').at(2).text()).toBe('Document Attachment')
      expect(acceptence.find('li').at(3).text()).toBe('Charges')
      expect(acceptence.find('Tab').at(0).prop('selected')).toBeFalsy()
      expect(acceptence.find('TabPanel').at(0).prop('selected')).toBeFalsy()
      expect(acceptence.find('Tab').at(1).prop('selected')).toBeTruthy()
      expect(acceptence.find('TabPanel').at(1).prop('selected')).toBeTruthy()
    })
  })

  describe('<Acceptence /> --- Snapshot', () => {
    it('capture screenshot of acceptence component', () => {
      store = mockStore(sessionState);
      const login = renderer.create(<Router><Provider store={store} >
        <Acceptence match={{ params: { id: 1 } }} history={history} />
      </Provider></Router>).toJSON()
      expect(login).toMatchSnapshot()
    })
  })
});
