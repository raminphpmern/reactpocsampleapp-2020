import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import Utilities from 'components/Utilities';
import configureMockStore from 'redux-mock-store';
import { BrowserRouter as Router } from 'react-router-dom';

const mockStore = configureMockStore();
const sessionState = {loginReducer: {user: {loggedIn: true}}}
let store;

describe('<Utilities />', () => {
  window._env_ = {"API_URL": "http://localhost:3000"}
  describe('validate', () => {
    it('validate label elements', () => {
      store = mockStore(sessionState);
      const utilitiesPage = mount(
                              <Provider store={store}>
                                <Router>
                                  <Utilities  />
                                </Router>
                              </Provider>)
      expect(utilitiesPage.find('.utilities-wrapper h3').text()).toBe('Utilities')
      expect(utilitiesPage.find('.utilities-wrapper a').length).toBe(10)
    })
  })
})
