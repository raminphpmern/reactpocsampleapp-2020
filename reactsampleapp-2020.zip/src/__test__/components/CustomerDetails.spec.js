import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import CustomerDetails from 'components/Qbr/CustomerDetails'
import store from 'store';
import renderer from 'react-test-renderer';

const mockfn = jest.fn();
describe('<CustomerDetails />', () => {

  const props = {
    handleSubmit: mockfn
  };

  let wrapper;

  describe('validate', () => {
    beforeEach(() => {
      wrapper = mount(
          <Provider store={store} >
            <CustomerDetails {...props} />
          </Provider>, { attachTo: document.body }
        );
    });

    it('should has search by label', () => {
      // console.log("wrapper", wrapper.find('.ash-background').debug())
    })

  })

  describe('<CustomerDetails /> --- Snapshot', () => {
    it('capture screenshot of customer details component', () => {
      const login = renderer.create(<Provider store={store} >
        <CustomerDetails {...props} />
      </Provider>).toJSON()
      expect(login).toMatchSnapshot()
    })
  })

})
