import React from 'react';
import { shallow } from 'enzyme';
import { Provider } from 'react-redux';
import Header from 'components/Header';
import configureMockStore from 'redux-mock-store';
import renderer from 'react-test-renderer';
import { BrowserRouter as Router } from 'react-router-dom';

const mockStore = configureMockStore();
const sessionState = {loginReducer: {user: {loggedIn: true, locations: []}}}
let store;

describe('<Header />', () => {
  window._env_ = {"API_URL": "http://localhost:3000"}
  it('renders a header component', () => {
    store = mockStore(sessionState);
    const wrapper = shallow(<Provider store={store}><Header /> </Provider>)
    expect(wrapper.contains(<Header />)).toBe(true);
  })
})

describe('<Header /> with user session --- Snapshot', () => {
  it('capture screenshot of header', () => {
    store = mockStore(sessionState);
    const header = renderer.create(<Router><Header store={store}/></Router>).toJSON()
    expect(header).toMatchSnapshot()
  })
})  
