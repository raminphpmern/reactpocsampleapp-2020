import reducer, { initialState } from 'reducers/csReducer'

describe('Collection Summary Reducer', () => {
  it('should return the initial state', () => {
    expect(reducer(undefined, {})).toEqual(
      initialState
    )
  })
})

describe('CS_FETCH_REQUEST', () => {
  it('should return search request state', () => {
    const action = {
      type: 'CS_FETCH_REQUEST',
      isRequested: true
    }
    expect(reducer({}, action)).toEqual({
      isRequested: true,
    });
  })
})

describe('CS_FETCH_SUCCESS', () => {
  it('should return search request state', () => {
    const action = {
      type: 'CS_FETCH_SUCCESS',
      data: {},
      totalPage: 0,
      totalRecord: 0
    }
    expect(reducer({}, action)).toEqual({
      result: {},
      totalPage: 0,
      totalRecord: 0

    });
  })
})

describe('CS_FETCH_FAILURE', () => {
  it('should return search request state', () => {
    const action = {
      type: 'CS_FETCH_FAILURE',
      message: "Something went wrong"
    }
    expect(reducer({}, action)).toEqual({
      message: "Something went wrong"
    });
  })
})

describe('CS_STATUS_UPDATE_REQUEST', () => {
  it('should return save request state', () => {
    const action = {
      type: 'CS_STATUS_UPDATE_REQUEST',
      isRequested: true
    }
    expect(reducer({}, action)).toEqual({
      isRequested: true,
    });
  })
})

describe('CS_STATUS_UPDATE_RESET', () => {
  it('should return save request state', () => {
    const action = {
      type: 'CS_STATUS_UPDATE_RESET',
      result: []
    }
    expect(reducer({}, action)).toEqual({
      result: []
    });
  })
})

describe('CS_STATUS_UPDATE_FAILURE', () => {
  it('should return save request state', () => {
    const action = {
      type: 'CS_STATUS_UPDATE_FAILURE',
      message: "Something went wrong"
    }
    expect(reducer({}, action)).toEqual({
      message: "Something went wrong"
    });
  })
})

describe('CS_STATUS_UPDATE_REQUEST', () => {
  it('should return search request state', () => {
    const action = {
      type: 'CS_STATUS_UPDATE_REQUEST',
      isRequested: true
    }
    expect(reducer({}, action)).toEqual({
      isRequested: true,
    });
  })
})

describe('CS_STATUS_UPDATE_FAILURE', () => {
  it('should return search request state', () => {
    const action = {
      type: 'CS_STATUS_UPDATE_FAILURE',
      message: "Something went worng"
    }
    expect(reducer({}, action)).toEqual({
      message: "Something went worng"
    });
  })
})
