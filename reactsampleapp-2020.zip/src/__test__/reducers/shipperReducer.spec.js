import reducer, { initialState } from 'reducers/shipperReducer'
import { shipper } from '../fixtures/data'

describe('shipperReducer', () => {

  describe('CREATE_SHIPPER_INITIALIZE', () => {
    it('should return the shipper create initialize state', () => {
      const action = {
        type: 'CREATE_SHIPPER_INITIALIZE',
      }
      expect(reducer({}, action)).toEqual(initialState);
    })
  })

  describe('CREATE_SHIPPER_REQUEST', () => {
    it('should return the shipper create request state', () => {
      const action = {
        type: 'CREATE_SHIPPER_REQUEST',
        isLoading: true
      }
      expect(reducer({}, action)).toEqual({isLoading: true});
    })
  })

  describe('CREATE_SHIPPER_SUCCESS', () => {
    it('should return the shipper create success state', () => {
      const action = {
        type: 'CREATE_SHIPPER_SUCCESS',
        shipper: shipper,
        isSuccess: true
      }
      expect(reducer({}, action)).toEqual({currentShipper: shipper, isSuccess: true});
    })
  })

  describe('CREATE_SHIPPER_FAILURE', () => {
    it('should return the shipper create failure state', () => {
      const errorMsg = 'Something went wrong!!!'
      const action = {
        type: 'CREATE_SHIPPER_FAILURE',
        message: errorMsg,
        isSuccess: false
      }
      expect(reducer({}, action)).toEqual({isSuccess: false, message: errorMsg});
    })
  })
});