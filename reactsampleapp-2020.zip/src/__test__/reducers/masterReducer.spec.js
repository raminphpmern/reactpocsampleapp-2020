import reducer, { initialState } from 'reducers/masterReducer'

describe('masterReducer', () => {

  describe('MASTER_FETCH_INITIALIZE', () => {
    it('should return the master fetch initialize state', () => {
      const action = {
        type: 'MASTER_FETCH_INITIALIZE',
      }
      expect(reducer({}, action)).toEqual(initialState);
    })
  })

  describe('MASTER_FETCH_REQUEST', () => {
    it('should return the master fetch request state', () => {
      const action = {
        type: 'MASTER_FETCH_REQUEST',
        isLoading: true
      }
      expect(reducer({}, action)).toEqual({ isLoading: true, lastPage: 0 });
    })
  })

  describe('MASTER_FETCH_SUCCESS', () => {
    it('should return the master fetch success state', () => {
      const action = {
        type: 'MASTER_FETCH_SUCCESS',
        data: initialState.options,
        isSuccess: true
      }
      expect(reducer({}, action)).toEqual({ options: initialState.options, isSuccess: true });
    })
  })

  describe('MASTER_FETCH_FAILURE', () => {
    it('should return the master fetch failure state', () => {
      const action = {
        type: 'MASTER_FETCH_FAILURE',
        data: initialState.options,
        isSuccess: false
      }
      expect(reducer({}, action)).toEqual({ isSuccess: false });
    })
  })
})