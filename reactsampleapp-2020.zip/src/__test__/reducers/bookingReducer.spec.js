import reducer, { initialState } from 'reducers/bookingReducer'

describe('Booking Reducer', () => {
  it('should return the initial state', () => {
    expect(reducer(undefined, {})).toEqual(
      {
        bookingData: null,
        message: null,
        isSearching: false,
        isRequested: false,
        currentBooking: null,
        isSuccess: false,
        activeStep: 1,
        currentStep: 1,
        prePrintedIsValid: true,
        copyBooking: null,
        recurring: 'N',
        trackingValid: false,
        taxDetails: [],
        uomResult: [],
        ethuTrackingValid: false,
        prePrintedIsValidEthu: true,
        ethuProduct: [],
        chargesData: null,
        vShipment: false,
        tariff: [],
        contract: {},
        childThuValid: true,
        validationProfile: null,
        isPromoRequest: false,
        isPromoValid: false,
      }
    )
  })

})

describe('CUSTOMER_CREATE_REQUEST', () => {
  it('should return the customer create request state', () => {
    const action = {
      type: 'CUSTOMER_CREATE_REQUEST',
      isRequested: true
    }
    expect(reducer({}, action)).toEqual({
      isRequested: true,
    });
  })
})

describe('CUSTOMER_CREATE_SUCCESS', () => {
  it('should return the customer create success state', () => {
    const action = {
      type: 'CUSTOMER_CREATE_SUCCESS',
      data: {},
      isSuccess: true,
      activeStep: 1,
      currentStep: 1
    }

    expect(reducer({}, action)).toEqual({
      currentBooking: {},
      isSuccess: true,
      isRequested: false,
      activeStep: 1,
      currentStep: 1,
      copyBooking: null
    });
  })
})

describe('CUSTOMER_CREATE_FAILURE', () => {
  it('should return the customer create failure state', () => {
    const action = {
      type: 'CUSTOMER_CREATE_FAILURE',
      message: "Failed",
      isSuccess: false,
    }

    expect(reducer({}, action)).toEqual({
      message: "Failed",
      isRequested: false,
      isSuccess: false
    });
  })
})

describe('BOOKING_SEARCH_REQUEST', () => {
  it('should return the BOOKING_SEARCH_REQUEST state', () => {
    const action = {
      type: 'BOOKING_SEARCH_REQUEST',
      isSearching: true,
    }
    expect(reducer({}, action)).toEqual({
      isSearching: true
    });
  })
})

describe('BOOKING_SEARCH_SUCCESS', () => {
  it('should return the BOOKING_SEARCH_SUCCESS state', () => {
    const action = {
      type: 'BOOKING_SEARCH_SUCCESS',
      data: {},
      message: null
    }
    expect(reducer({}, action)).toEqual({
      bookingData: {},
      currentBooking: {},
      message: null,
      isRequested: false,
    });
  })
})


describe('BOOKING_SEARCH_FAILURE', () => {
  it('should return the BOOKING_SEARCH_FAILURE state', () => {
    const action = {
      type: 'BOOKING_SEARCH_FAILURE',
      message: "Failed"
    }
    expect(reducer({}, action)).toEqual({
      message: "Failed",
      isRequested: false,
    });
  })
})

describe('BOOKING_STEP_CHANGE', () => {
  it('should return the BOOKING_STEP_CHANGE state', () => {
    const action = {
      type: 'BOOKING_STEP_CHANGE',
      step: 1
    }
    expect(reducer({}, action)).toEqual({
      currentStep: 1,
      isRequested: false,
    });
  })
})