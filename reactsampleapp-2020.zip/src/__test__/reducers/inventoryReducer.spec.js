import reducer, { initialState } from 'reducers/inventoryHubReducer'

describe('InventoryHub Reducer', () => {
  it('should return the initial state', () => {
    expect(reducer(undefined, {})).toEqual(
      initialState
    )
  })
})

describe('IH_FETCH_REQUEST', () => {
  it('should return search request state', () => {
    const action = {
      type: 'IH_FETCH_REQUEST',
      isRequested: true
    }
    expect(reducer({}, action)).toEqual({
      isRequested: true,
    });
  })
})

describe('IH_FETCH_SUCCESS', () => {
  it('should return search request state', () => {
    const action = {
      type: 'IH_FETCH_SUCCESS',
      data: {},
      totalPage: 0,
      totalRecord: 0
    }
    expect(reducer({}, action)).toEqual({
      result: {},
      totalPage: 0,
      totalRecord: 0

    });
  })
})

describe('IH_FETCH_FAILURE', () => {
  it('should return search request state', () => {
    const action = {
      type: 'IH_FETCH_FAILURE',
      message: "Something went wrong"
    }
    expect(reducer({}, action)).toEqual({
      message: "Something went wrong"
    });
  })
})

