import reducer from 'reducers/loginReducer';
import { user } from '../fixtures/data';

describe('loginReducer', () => {
  describe('LOGIN_SUCCESS', () => {
    it('should return the success state', () => {
      const action = {
        type: 'LOGIN_SUCCESS',
        user: user
      }
      expect(reducer({}, action)).toEqual({user: user, message: null});
    })
  })

  describe('LOGIN_INITIALIZE', () => {
    it('should return the initialize state', () => {
      const action = {
        type: 'LOGIN_INITIALIZE',
      }
      expect(reducer({}, action)).toEqual({user: null, message: null});
    })
  })

  describe('LOGIN_REQUEST', () => {
    it('should return the request state', () => {
      const action = {
        type: 'LOGIN_REQUEST',
      }
      
      expect(reducer({}, action)).toEqual({message: null});
    })
  })

  describe('LOGIN_FAILURE', () => {
    it('should return the failure state', () => {
      const action = {
        type: 'LOGIN_FAILURE',
        message: 'Error'
      }
      expect(reducer({}, action)).toEqual({message: 'Error'});
    })
  })

  describe('LOGOUT', () => {
    it('should return the failure state', () => {
      const action = {
        type: 'LOGOUT',
      }
      expect(reducer({}, action)).toEqual({user: null, message: null});
    })
  })
})
