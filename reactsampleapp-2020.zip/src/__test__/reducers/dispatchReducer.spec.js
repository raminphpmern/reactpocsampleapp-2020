import reducer, { initialState } from 'reducers/dispatchReducer'
import { dispatchsearch } from '../fixtures/data'

describe('dispatchReducer', () => {


  describe('DISPATCH_FETCH_REQUEST', () => {
    it('should return the Dispatch request state', () => {
      const action = {
        type: 'DISPATCH_FETCH_REQUEST',
        isRequested: true
      }
      expect(reducer({}, action)).toEqual({ isRequested: true });
    })
  })

  describe('DISPATCH_FETCH_SUCCESS', () => {
    it('should return the Dispatch success state', () => {
      const action = {
        type: 'DISPATCH_FETCH_SUCCESS',
        data: {
          result: [],
          totalPage: 0,
          totalRecord: 0
        }
      }
      expect(reducer({}, action)).toEqual({
        result: [],
        totalPage: 0,
        totalRecord: 0
      });
    })
  })

  describe('DISPATCH_FETCH_FAILURE', () => {
    it('should return the dispatch failure state', () => {
      const errorMsg = 'Something went wrong!!!'
      const action = {
        type: 'DISPATCH_FETCH_FAILURE',
        message: errorMsg,
        isSuccess: false
      }
      expect(reducer({}, action)).toEqual({ isSuccess: false, message: errorMsg });
    })
  })
});